 /**
 * <interfacename>TscAsyncMgr</interfacename>
 * <description> 
 *	<p>Interface of the asynchronous job manager. This job manager enables, to execute synchronous jobs
 *	asynchronously.</p>
 * </description>
 *
 * <copyright>(c) 2003-2010 3S-Smart Software Solutions</copyright>
 */


	
	
#ifndef _TSCASYNCMGRITF_H_
#define _TSCASYNCMGRITF_H_

#include "CmpStd.h"

 

 




/* State of an async job*/
#define ASYNCSTATE_INVALID				UINT32_MAX
#define ASYNCSTATE_PENDING				0
#define ASYNCSTATE_ACTIVE				1
#define ASYNCSTATE_READY				2
#define ASYNCSTATE_ERROR				3
#define ASYNCSTATE_TIMEOUT				4
#define ASYNCSTATE_READY_TO_REMOVE		5

#define ASYNC_TIMEOUT_INFINITE			0 

#ifndef ASYNCMGR_NUM_OF_STATIC_JOBS
	#define ASYNCMGR_NUM_OF_STATIC_JOBS	5
#endif                      


typedef void HUGEPTR(CDECL *PFASYNCJOBFUNCTION)(void *pParam);

typedef struct
{
	void* pInstance;
	void* pParam;
	RTS_RESULT out;
}ASYNCJOB_IECCALLPARAM_METH;

typedef struct
{
	void* pParam;
	RTS_RESULT out;
}ASYNCJOB_IECCALLPARAM_FUNC;

typedef struct
{
	RTS_UI32 ulJobPriority;
	char* pszExtEvtName; 
	RTS_UI32 bDeamon;
} ASYNCJOB_PARAM;

typedef struct
{
	PFASYNCJOBFUNCTION pfJob;
	void* pParam;
	void* pInstance;
	RTS_UI32* pulState;
	int bIecFunc;
	RTS_UI32 ulTimeout;
	ASYNCJOB_PARAM jobParam;
	RTS_UI32 ulJobReturnVal;
	RTS_UI32 ulStartTime;
	PFTASKEXCEPTIONHANDLER pfExceptionHandler;
	RTS_HANDLE *phJob;
	RTS_HANDLE hTaskHandle;
    RTS_BOOL cycleState;
} ASYNCJOB_INFO;

typedef struct
{
	PFASYNCJOBFUNCTION pfAsyncJobFunc;
	void* pParam;
	void* pInstance;
	RTS_UI32* pulState;
	int bIecFunc;
	RTS_UI32 ulTimeout;
	RTS_UI32 ulJobPriority; 
	RTS_RESULT *pResult;
	RTS_HANDLE out;
}tscasyncadd_struct;

typedef struct
{
	PFASYNCJOBFUNCTION pfAsyncJobFunc;
	void* pParam;
	void* pInstance;
	RTS_UI32* pulState;
	int bIecFunc;
	RTS_UI32 ulTimeout;
	ASYNCJOB_PARAM*	pJobParam;
	RTS_RESULT *pResult;
	RTS_HANDLE out;
}tscasyncaddjob_struct;

typedef struct
{
	RTS_HANDLE hJob;
	RTS_RESULT out;
}tscasyncremove_struct;

typedef struct
{
	RTS_RESULT out;
}tscasyncremoveall_struct;

typedef struct
{
	RTS_HANDLE hJob;
	RTS_UI32* pulRetVal;
	RTS_RESULT out;
}tscasyncgetjobreturnvalue_struct;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * DEPRECATED: This funtcion is depracted due to new options for an asyncjob.
 *			   Use the TscAsyncAddJob() or TscAsyncAddJob2() functions instead
 * 
 * <description> This function adds a new async job in a jobqueue</description>
 * <param name="pfAsyncJobFunc" type="IN">Pointer to sync Funktion</param>
 * <param name="pParam" type="IN">Pointer to the Parameters of the function</param>
 * <param name="pInstance" type="IN">Pointer to instance of an fb (if the function is an fb function)</param>
 * <param name="pulState" type="IN">Pointer to actual state of async function</param>
 * <param name="bIECFunc" type="IN">C or IEC function</param>
 * <param name="ulTimeout" type="IN">timeout for the async job function</param>
 * <param name="ulJobPriority" type="IN">priority of the async job</param>
 * <param name="pResult" type="OUT">Error code</param>
 * <result>Handle to the jog object</result>
 */
RTS_HANDLE CDECL TscAsyncAdd(PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, RTS_UI32 ulJobPriority, RTS_RESULT *pResult);
typedef RTS_HANDLE (CDECL * PFTSCASYNCADD) (PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, RTS_UI32 ulJobPriority, RTS_RESULT *pResult);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCADD_NOTIMPLEMENTED)
	#define USE_TscAsyncAdd
	#define EXT_TscAsyncAdd
	#define GET_TscAsyncAdd(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscAsyncAdd(p0,p1,p2,p3,p4,p5,p6,p7)  (RTS_HANDLE)RTS_INVALID_HANDLE
	#define CHK_TscAsyncAdd  FALSE
	#define EXP_TscAsyncAdd  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscAsyncAdd
	#define EXT_TscAsyncAdd
	#define GET_TscAsyncAdd(fl)  CAL_CMGETAPI( "TscAsyncAdd" ) 
	#define CAL_TscAsyncAdd  TscAsyncAdd
	#define CHK_TscAsyncAdd  TRUE
	#define EXP_TscAsyncAdd  CAL_CMEXPAPI( "TscAsyncAdd" ) 
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_TscAsyncAdd
	#define EXT_TscAsyncAdd
	#define GET_TscAsyncAdd(fl)  CAL_CMGETAPI( "TscAsyncAdd" ) 
	#define CAL_TscAsyncAdd  TscAsyncAdd
	#define CHK_TscAsyncAdd  TRUE
	#define EXP_TscAsyncAdd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncAdd", (RTS_UINTPTR)TscAsyncAdd, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrTscAsyncAdd
	#define EXT_TscAsyncMgrTscAsyncAdd
	#define GET_TscAsyncMgrTscAsyncAdd  ERR_OK
	#define CAL_TscAsyncMgrTscAsyncAdd pITscAsyncMgr->ITscAsyncAdd
	#define CHK_TscAsyncMgrTscAsyncAdd (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncMgrTscAsyncAdd  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscAsyncAdd
	#define EXT_TscAsyncAdd
	#define GET_TscAsyncAdd(fl)  CAL_CMGETAPI( "TscAsyncAdd" ) 
	#define CAL_TscAsyncAdd pITscAsyncMgr->ITscAsyncAdd
	#define CHK_TscAsyncAdd (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncAdd  CAL_CMEXPAPI( "TscAsyncAdd" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscAsyncAdd  PFTSCASYNCADD pfTscAsyncAdd;
	#define EXT_TscAsyncAdd  extern PFTSCASYNCADD pfTscAsyncAdd;
	#define GET_TscAsyncAdd(fl)  s_pfCMGetAPI2( "TscAsyncAdd", (RTS_VOID_FCTPTR *)&pfTscAsyncAdd, (fl), 0, 0)
	#define CAL_TscAsyncAdd  pfTscAsyncAdd
	#define CHK_TscAsyncAdd  (pfTscAsyncAdd != NULL)
	#define EXP_TscAsyncAdd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncAdd", (RTS_UINTPTR)TscAsyncAdd, 0, 0) 
#endif



void CDECL CDECL_EXT tscasyncadd(tscasyncadd_struct *p);
typedef void (CDECL CDECL_EXT* PFTSCASYNCADD_IEC) (tscasyncadd_struct *p);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCADD_NOTIMPLEMENTED)
	#define USE_tscasyncadd
	#define EXT_tscasyncadd
	#define GET_tscasyncadd(fl)  ERR_NOTIMPLEMENTED
	#define CAL_tscasyncadd(p0) 
	#define CHK_tscasyncadd  FALSE
	#define EXP_tscasyncadd  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_tscasyncadd
	#define EXT_tscasyncadd
	#define GET_tscasyncadd(fl)  CAL_CMGETAPI( "tscasyncadd" ) 
	#define CAL_tscasyncadd  tscasyncadd
	#define CHK_tscasyncadd  TRUE
	#define EXP_tscasyncadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncadd", (RTS_UINTPTR)tscasyncadd, 1, 0, 0x01000000) 
	#define EXTREF_ITF_tscasyncadd {(RTS_VOID_FCTPTR)tscasyncadd, "tscasyncadd", 0, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_tscasyncadd
	#define EXT_tscasyncadd
	#define GET_tscasyncadd(fl)  CAL_CMGETAPI( "tscasyncadd" ) 
	#define CAL_tscasyncadd  tscasyncadd
	#define CHK_tscasyncadd  TRUE
	#define EXP_tscasyncadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncadd", (RTS_UINTPTR)tscasyncadd, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrtscasyncadd
	#define EXT_TscAsyncMgrtscasyncadd
	#define GET_TscAsyncMgrtscasyncadd  ERR_OK
	#define CAL_TscAsyncMgrtscasyncadd  tscasyncadd
	#define CHK_TscAsyncMgrtscasyncadd  TRUE
	#define EXP_TscAsyncMgrtscasyncadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncadd", (RTS_UINTPTR)tscasyncadd, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_tscasyncadd
	#define EXT_tscasyncadd
	#define GET_tscasyncadd(fl)  CAL_CMGETAPI( "tscasyncadd" ) 
	#define CAL_tscasyncadd  tscasyncadd
	#define CHK_tscasyncadd  TRUE
	#define EXP_tscasyncadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncadd", (RTS_UINTPTR)tscasyncadd, 1, 0, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_tscasyncadd  PFTSCASYNCADD_IEC pftscasyncadd;
	#define EXT_tscasyncadd  extern PFTSCASYNCADD_IEC pftscasyncadd;
	#define GET_tscasyncadd(fl)  s_pfCMGetAPI2( "tscasyncadd", (RTS_VOID_FCTPTR *)&pftscasyncadd, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0, 0x01000000)
	#define CAL_tscasyncadd  pftscasyncadd
	#define CHK_tscasyncadd  (pftscasyncadd != NULL)
	#define EXP_tscasyncadd   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncadd", (RTS_UINTPTR)tscasyncadd, 1, 0, 0x01000000) 
#endif


/**
 * 
 * 
 * <description> This function adds a new async job in a jobqueue</description>
 * <param name="pfAsyncJobFunc" type="IN">Pointer to sync Funktion</param>
 * <param name="pParam" type="IN">Pointer to the Parameters of the function</param>
 * <param name="pInstance" type="IN">Pointer to instance of an fb (if the function is an fb function)</param>
 * <param name="pulState" type="IN">Pointer to actual state of async function</param>
 * <param name="bIECFunc" type="IN">C or IEC function</param>
 * <param name="ulTimeout" type="IN">timeout for the async job function</param>
 * <param name="pAsyncJobParam" type="IN">async job parameter. see ASYNCJOB_PARAM structure</param>
 * <param name="pResult" type="OUT">Error code</param>
 * <result>Handle to the jog object</result>
 */
RTS_HANDLE CDECL TscAsyncAddJob(PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, ASYNCJOB_PARAM* pAsyncJobParam, RTS_RESULT *pResult);
typedef RTS_HANDLE (CDECL * PFTSCASYNCADDJOB) (PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, ASYNCJOB_PARAM* pAsyncJobParam, RTS_RESULT *pResult);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCADDJOB_NOTIMPLEMENTED)
	#define USE_TscAsyncAddJob
	#define EXT_TscAsyncAddJob
	#define GET_TscAsyncAddJob(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscAsyncAddJob(p0,p1,p2,p3,p4,p5,p6,p7)  (RTS_HANDLE)RTS_INVALID_HANDLE
	#define CHK_TscAsyncAddJob  FALSE
	#define EXP_TscAsyncAddJob  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscAsyncAddJob
	#define EXT_TscAsyncAddJob
	#define GET_TscAsyncAddJob(fl)  CAL_CMGETAPI( "TscAsyncAddJob" ) 
	#define CAL_TscAsyncAddJob  TscAsyncAddJob
	#define CHK_TscAsyncAddJob  TRUE
	#define EXP_TscAsyncAddJob  CAL_CMEXPAPI( "TscAsyncAddJob" ) 
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_TscAsyncAddJob
	#define EXT_TscAsyncAddJob
	#define GET_TscAsyncAddJob(fl)  CAL_CMGETAPI( "TscAsyncAddJob" ) 
	#define CAL_TscAsyncAddJob  TscAsyncAddJob
	#define CHK_TscAsyncAddJob  TRUE
	#define EXP_TscAsyncAddJob  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncAddJob", (RTS_UINTPTR)TscAsyncAddJob, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrTscAsyncAddJob
	#define EXT_TscAsyncMgrTscAsyncAddJob
	#define GET_TscAsyncMgrTscAsyncAddJob  ERR_OK
	#define CAL_TscAsyncMgrTscAsyncAddJob pITscAsyncMgr->ITscAsyncAddJob
	#define CHK_TscAsyncMgrTscAsyncAddJob (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncMgrTscAsyncAddJob  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscAsyncAddJob
	#define EXT_TscAsyncAddJob
	#define GET_TscAsyncAddJob(fl)  CAL_CMGETAPI( "TscAsyncAddJob" ) 
	#define CAL_TscAsyncAddJob pITscAsyncMgr->ITscAsyncAddJob
	#define CHK_TscAsyncAddJob (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncAddJob  CAL_CMEXPAPI( "TscAsyncAddJob" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscAsyncAddJob  PFTSCASYNCADDJOB pfTscAsyncAddJob;
	#define EXT_TscAsyncAddJob  extern PFTSCASYNCADDJOB pfTscAsyncAddJob;
	#define GET_TscAsyncAddJob(fl)  s_pfCMGetAPI2( "TscAsyncAddJob", (RTS_VOID_FCTPTR *)&pfTscAsyncAddJob, (fl), 0, 0)
	#define CAL_TscAsyncAddJob  pfTscAsyncAddJob
	#define CHK_TscAsyncAddJob  (pfTscAsyncAddJob != NULL)
	#define EXP_TscAsyncAddJob  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncAddJob", (RTS_UINTPTR)TscAsyncAddJob, 0, 0) 
#endif



void CDECL CDECL_EXT tscasyncaddjob(tscasyncaddjob_struct *p);
typedef void (CDECL CDECL_EXT* PFTSCASYNCADDJOB_IEC) (tscasyncaddjob_struct *p);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCADDJOB_NOTIMPLEMENTED)
	#define USE_tscasyncaddjob
	#define EXT_tscasyncaddjob
	#define GET_tscasyncaddjob(fl)  ERR_NOTIMPLEMENTED
	#define CAL_tscasyncaddjob(p0) 
	#define CHK_tscasyncaddjob  FALSE
	#define EXP_tscasyncaddjob  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_tscasyncaddjob
	#define EXT_tscasyncaddjob
	#define GET_tscasyncaddjob(fl)  CAL_CMGETAPI( "tscasyncaddjob" ) 
	#define CAL_tscasyncaddjob  tscasyncaddjob
	#define CHK_tscasyncaddjob  TRUE
	#define EXP_tscasyncaddjob  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncaddjob", (RTS_UINTPTR)tscasyncaddjob, 1, 0, 0x01000000) 
	#define EXTREF_ITF_tscasyncaddjob {(RTS_VOID_FCTPTR)tscasyncaddjob, "tscasyncaddjob", 0, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_tscasyncaddjob
	#define EXT_tscasyncaddjob
	#define GET_tscasyncaddjob(fl)  CAL_CMGETAPI( "tscasyncaddjob" ) 
	#define CAL_tscasyncaddjob  tscasyncaddjob
	#define CHK_tscasyncaddjob  TRUE
	#define EXP_tscasyncaddjob  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncaddjob", (RTS_UINTPTR)tscasyncaddjob, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrtscasyncaddjob
	#define EXT_TscAsyncMgrtscasyncaddjob
	#define GET_TscAsyncMgrtscasyncaddjob  ERR_OK
	#define CAL_TscAsyncMgrtscasyncaddjob  tscasyncaddjob
	#define CHK_TscAsyncMgrtscasyncaddjob  TRUE
	#define EXP_TscAsyncMgrtscasyncaddjob  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncaddjob", (RTS_UINTPTR)tscasyncaddjob, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_tscasyncaddjob
	#define EXT_tscasyncaddjob
	#define GET_tscasyncaddjob(fl)  CAL_CMGETAPI( "tscasyncaddjob" ) 
	#define CAL_tscasyncaddjob  tscasyncaddjob
	#define CHK_tscasyncaddjob  TRUE
	#define EXP_tscasyncaddjob  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncaddjob", (RTS_UINTPTR)tscasyncaddjob, 1, 0, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_tscasyncaddjob  PFTSCASYNCADDJOB_IEC pftscasyncaddjob;
	#define EXT_tscasyncaddjob  extern PFTSCASYNCADDJOB_IEC pftscasyncaddjob;
	#define GET_tscasyncaddjob(fl)  s_pfCMGetAPI2( "tscasyncaddjob", (RTS_VOID_FCTPTR *)&pftscasyncaddjob, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0, 0x01000000)
	#define CAL_tscasyncaddjob  pftscasyncaddjob
	#define CHK_tscasyncaddjob  (pftscasyncaddjob != NULL)
	#define EXP_tscasyncaddjob   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncaddjob", (RTS_UINTPTR)tscasyncaddjob, 1, 0, 0x01000000) 
#endif


/**
 * <description> This function adds a new async job in a jobqueue. Could be used in C-Functions</description>
 * <param name="pJob" type="IN">Pointer job info structure</param>
 * <result>error code</result>
 */
RTS_RESULT CDECL TscAsyncAddJob2(ASYNCJOB_INFO *pJob);
typedef RTS_RESULT (CDECL * PFTSCASYNCADDJOB2) (ASYNCJOB_INFO *pJob);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCADDJOB2_NOTIMPLEMENTED)
	#define USE_TscAsyncAddJob2
	#define EXT_TscAsyncAddJob2
	#define GET_TscAsyncAddJob2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscAsyncAddJob2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscAsyncAddJob2  FALSE
	#define EXP_TscAsyncAddJob2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscAsyncAddJob2
	#define EXT_TscAsyncAddJob2
	#define GET_TscAsyncAddJob2(fl)  CAL_CMGETAPI( "TscAsyncAddJob2" ) 
	#define CAL_TscAsyncAddJob2  TscAsyncAddJob2
	#define CHK_TscAsyncAddJob2  TRUE
	#define EXP_TscAsyncAddJob2  CAL_CMEXPAPI( "TscAsyncAddJob2" ) 
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_TscAsyncAddJob2
	#define EXT_TscAsyncAddJob2
	#define GET_TscAsyncAddJob2(fl)  CAL_CMGETAPI( "TscAsyncAddJob2" ) 
	#define CAL_TscAsyncAddJob2  TscAsyncAddJob2
	#define CHK_TscAsyncAddJob2  TRUE
	#define EXP_TscAsyncAddJob2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncAddJob2", (RTS_UINTPTR)TscAsyncAddJob2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrTscAsyncAddJob2
	#define EXT_TscAsyncMgrTscAsyncAddJob2
	#define GET_TscAsyncMgrTscAsyncAddJob2  ERR_OK
	#define CAL_TscAsyncMgrTscAsyncAddJob2 pITscAsyncMgr->ITscAsyncAddJob2
	#define CHK_TscAsyncMgrTscAsyncAddJob2 (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncMgrTscAsyncAddJob2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscAsyncAddJob2
	#define EXT_TscAsyncAddJob2
	#define GET_TscAsyncAddJob2(fl)  CAL_CMGETAPI( "TscAsyncAddJob2" ) 
	#define CAL_TscAsyncAddJob2 pITscAsyncMgr->ITscAsyncAddJob2
	#define CHK_TscAsyncAddJob2 (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncAddJob2  CAL_CMEXPAPI( "TscAsyncAddJob2" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscAsyncAddJob2  PFTSCASYNCADDJOB2 pfTscAsyncAddJob2;
	#define EXT_TscAsyncAddJob2  extern PFTSCASYNCADDJOB2 pfTscAsyncAddJob2;
	#define GET_TscAsyncAddJob2(fl)  s_pfCMGetAPI2( "TscAsyncAddJob2", (RTS_VOID_FCTPTR *)&pfTscAsyncAddJob2, (fl), 0, 0)
	#define CAL_TscAsyncAddJob2  pfTscAsyncAddJob2
	#define CHK_TscAsyncAddJob2  (pfTscAsyncAddJob2 != NULL)
	#define EXP_TscAsyncAddJob2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncAddJob2", (RTS_UINTPTR)TscAsyncAddJob2, 0, 0) 
#endif




/**
 * <description> This function removes an async job from a job queue</description>
 * <param name="hJob" type="IN">Handle to the job</param>
 * <result>error code</result>
 */
RTS_RESULT CDECL TscAsyncRemove(RTS_HANDLE hJob);
typedef RTS_RESULT (CDECL * PFTSCASYNCREMOVE) (RTS_HANDLE hJob);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCREMOVE_NOTIMPLEMENTED)
	#define USE_TscAsyncRemove
	#define EXT_TscAsyncRemove
	#define GET_TscAsyncRemove(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscAsyncRemove(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscAsyncRemove  FALSE
	#define EXP_TscAsyncRemove  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscAsyncRemove
	#define EXT_TscAsyncRemove
	#define GET_TscAsyncRemove(fl)  CAL_CMGETAPI( "TscAsyncRemove" ) 
	#define CAL_TscAsyncRemove  TscAsyncRemove
	#define CHK_TscAsyncRemove  TRUE
	#define EXP_TscAsyncRemove  CAL_CMEXPAPI( "TscAsyncRemove" ) 
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_TscAsyncRemove
	#define EXT_TscAsyncRemove
	#define GET_TscAsyncRemove(fl)  CAL_CMGETAPI( "TscAsyncRemove" ) 
	#define CAL_TscAsyncRemove  TscAsyncRemove
	#define CHK_TscAsyncRemove  TRUE
	#define EXP_TscAsyncRemove  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncRemove", (RTS_UINTPTR)TscAsyncRemove, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrTscAsyncRemove
	#define EXT_TscAsyncMgrTscAsyncRemove
	#define GET_TscAsyncMgrTscAsyncRemove  ERR_OK
	#define CAL_TscAsyncMgrTscAsyncRemove pITscAsyncMgr->ITscAsyncRemove
	#define CHK_TscAsyncMgrTscAsyncRemove (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncMgrTscAsyncRemove  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscAsyncRemove
	#define EXT_TscAsyncRemove
	#define GET_TscAsyncRemove(fl)  CAL_CMGETAPI( "TscAsyncRemove" ) 
	#define CAL_TscAsyncRemove pITscAsyncMgr->ITscAsyncRemove
	#define CHK_TscAsyncRemove (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncRemove  CAL_CMEXPAPI( "TscAsyncRemove" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscAsyncRemove  PFTSCASYNCREMOVE pfTscAsyncRemove;
	#define EXT_TscAsyncRemove  extern PFTSCASYNCREMOVE pfTscAsyncRemove;
	#define GET_TscAsyncRemove(fl)  s_pfCMGetAPI2( "TscAsyncRemove", (RTS_VOID_FCTPTR *)&pfTscAsyncRemove, (fl), 0, 0)
	#define CAL_TscAsyncRemove  pfTscAsyncRemove
	#define CHK_TscAsyncRemove  (pfTscAsyncRemove != NULL)
	#define EXP_TscAsyncRemove  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncRemove", (RTS_UINTPTR)TscAsyncRemove, 0, 0) 
#endif



void CDECL CDECL_EXT tscasyncremove(tscasyncremove_struct *p);
typedef void (CDECL CDECL_EXT* PFTSCASYNCREMOVE_IEC) (tscasyncremove_struct *p);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCREMOVE_NOTIMPLEMENTED)
	#define USE_tscasyncremove
	#define EXT_tscasyncremove
	#define GET_tscasyncremove(fl)  ERR_NOTIMPLEMENTED
	#define CAL_tscasyncremove(p0) 
	#define CHK_tscasyncremove  FALSE
	#define EXP_tscasyncremove  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_tscasyncremove
	#define EXT_tscasyncremove
	#define GET_tscasyncremove(fl)  CAL_CMGETAPI( "tscasyncremove" ) 
	#define CAL_tscasyncremove  tscasyncremove
	#define CHK_tscasyncremove  TRUE
	#define EXP_tscasyncremove  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremove", (RTS_UINTPTR)tscasyncremove, 1, 0, 0x01000000) 
	#define EXTREF_ITF_tscasyncremove {(RTS_VOID_FCTPTR)tscasyncremove, "tscasyncremove", 0, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_tscasyncremove
	#define EXT_tscasyncremove
	#define GET_tscasyncremove(fl)  CAL_CMGETAPI( "tscasyncremove" ) 
	#define CAL_tscasyncremove  tscasyncremove
	#define CHK_tscasyncremove  TRUE
	#define EXP_tscasyncremove  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremove", (RTS_UINTPTR)tscasyncremove, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrtscasyncremove
	#define EXT_TscAsyncMgrtscasyncremove
	#define GET_TscAsyncMgrtscasyncremove  ERR_OK
	#define CAL_TscAsyncMgrtscasyncremove  tscasyncremove
	#define CHK_TscAsyncMgrtscasyncremove  TRUE
	#define EXP_TscAsyncMgrtscasyncremove  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremove", (RTS_UINTPTR)tscasyncremove, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_tscasyncremove
	#define EXT_tscasyncremove
	#define GET_tscasyncremove(fl)  CAL_CMGETAPI( "tscasyncremove" ) 
	#define CAL_tscasyncremove  tscasyncremove
	#define CHK_tscasyncremove  TRUE
	#define EXP_tscasyncremove  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremove", (RTS_UINTPTR)tscasyncremove, 1, 0, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_tscasyncremove  PFTSCASYNCREMOVE_IEC pftscasyncremove;
	#define EXT_tscasyncremove  extern PFTSCASYNCREMOVE_IEC pftscasyncremove;
	#define GET_tscasyncremove(fl)  s_pfCMGetAPI2( "tscasyncremove", (RTS_VOID_FCTPTR *)&pftscasyncremove, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0, 0x01000000)
	#define CAL_tscasyncremove  pftscasyncremove
	#define CHK_tscasyncremove  (pftscasyncremove != NULL)
	#define EXP_tscasyncremove   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremove", (RTS_UINTPTR)tscasyncremove, 1, 0, 0x01000000) 
#endif


/**
 * <description> This function removes all async jobs from a job queue</description>
 * <result>error code</result>
 */
RTS_RESULT CDECL TscAsyncRemoveAll(void);
typedef RTS_RESULT (CDECL * PFTSCASYNCREMOVEALL) (void);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCREMOVEALL_NOTIMPLEMENTED)
	#define USE_TscAsyncRemoveAll
	#define EXT_TscAsyncRemoveAll
	#define GET_TscAsyncRemoveAll(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscAsyncRemoveAll()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscAsyncRemoveAll  FALSE
	#define EXP_TscAsyncRemoveAll  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscAsyncRemoveAll
	#define EXT_TscAsyncRemoveAll
	#define GET_TscAsyncRemoveAll(fl)  CAL_CMGETAPI( "TscAsyncRemoveAll" ) 
	#define CAL_TscAsyncRemoveAll  TscAsyncRemoveAll
	#define CHK_TscAsyncRemoveAll  TRUE
	#define EXP_TscAsyncRemoveAll  CAL_CMEXPAPI( "TscAsyncRemoveAll" ) 
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_TscAsyncRemoveAll
	#define EXT_TscAsyncRemoveAll
	#define GET_TscAsyncRemoveAll(fl)  CAL_CMGETAPI( "TscAsyncRemoveAll" ) 
	#define CAL_TscAsyncRemoveAll  TscAsyncRemoveAll
	#define CHK_TscAsyncRemoveAll  TRUE
	#define EXP_TscAsyncRemoveAll  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncRemoveAll", (RTS_UINTPTR)TscAsyncRemoveAll, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrTscAsyncRemoveAll
	#define EXT_TscAsyncMgrTscAsyncRemoveAll
	#define GET_TscAsyncMgrTscAsyncRemoveAll  ERR_OK
	#define CAL_TscAsyncMgrTscAsyncRemoveAll pITscAsyncMgr->ITscAsyncRemoveAll
	#define CHK_TscAsyncMgrTscAsyncRemoveAll (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncMgrTscAsyncRemoveAll  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscAsyncRemoveAll
	#define EXT_TscAsyncRemoveAll
	#define GET_TscAsyncRemoveAll(fl)  CAL_CMGETAPI( "TscAsyncRemoveAll" ) 
	#define CAL_TscAsyncRemoveAll pITscAsyncMgr->ITscAsyncRemoveAll
	#define CHK_TscAsyncRemoveAll (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncRemoveAll  CAL_CMEXPAPI( "TscAsyncRemoveAll" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscAsyncRemoveAll  PFTSCASYNCREMOVEALL pfTscAsyncRemoveAll;
	#define EXT_TscAsyncRemoveAll  extern PFTSCASYNCREMOVEALL pfTscAsyncRemoveAll;
	#define GET_TscAsyncRemoveAll(fl)  s_pfCMGetAPI2( "TscAsyncRemoveAll", (RTS_VOID_FCTPTR *)&pfTscAsyncRemoveAll, (fl), 0, 0)
	#define CAL_TscAsyncRemoveAll  pfTscAsyncRemoveAll
	#define CHK_TscAsyncRemoveAll  (pfTscAsyncRemoveAll != NULL)
	#define EXP_TscAsyncRemoveAll  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncRemoveAll", (RTS_UINTPTR)TscAsyncRemoveAll, 0, 0) 
#endif



void CDECL CDECL_EXT tscasyncremoveall(tscasyncremoveall_struct *p);
typedef void (CDECL CDECL_EXT* PFTSCASYNCREMOVEALL_IEC) (tscasyncremoveall_struct *p);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCREMOVEALL_NOTIMPLEMENTED)
	#define USE_tscasyncremoveall
	#define EXT_tscasyncremoveall
	#define GET_tscasyncremoveall(fl)  ERR_NOTIMPLEMENTED
	#define CAL_tscasyncremoveall(p0) 
	#define CHK_tscasyncremoveall  FALSE
	#define EXP_tscasyncremoveall  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_tscasyncremoveall
	#define EXT_tscasyncremoveall
	#define GET_tscasyncremoveall(fl)  CAL_CMGETAPI( "tscasyncremoveall" ) 
	#define CAL_tscasyncremoveall  tscasyncremoveall
	#define CHK_tscasyncremoveall  TRUE
	#define EXP_tscasyncremoveall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremoveall", (RTS_UINTPTR)tscasyncremoveall, 1, 0, 0x01000000) 
	#define EXTREF_ITF_tscasyncremoveall {(RTS_VOID_FCTPTR)tscasyncremoveall, "tscasyncremoveall", 0, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_tscasyncremoveall
	#define EXT_tscasyncremoveall
	#define GET_tscasyncremoveall(fl)  CAL_CMGETAPI( "tscasyncremoveall" ) 
	#define CAL_tscasyncremoveall  tscasyncremoveall
	#define CHK_tscasyncremoveall  TRUE
	#define EXP_tscasyncremoveall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremoveall", (RTS_UINTPTR)tscasyncremoveall, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrtscasyncremoveall
	#define EXT_TscAsyncMgrtscasyncremoveall
	#define GET_TscAsyncMgrtscasyncremoveall  ERR_OK
	#define CAL_TscAsyncMgrtscasyncremoveall  tscasyncremoveall
	#define CHK_TscAsyncMgrtscasyncremoveall  TRUE
	#define EXP_TscAsyncMgrtscasyncremoveall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremoveall", (RTS_UINTPTR)tscasyncremoveall, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_tscasyncremoveall
	#define EXT_tscasyncremoveall
	#define GET_tscasyncremoveall(fl)  CAL_CMGETAPI( "tscasyncremoveall" ) 
	#define CAL_tscasyncremoveall  tscasyncremoveall
	#define CHK_tscasyncremoveall  TRUE
	#define EXP_tscasyncremoveall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremoveall", (RTS_UINTPTR)tscasyncremoveall, 1, 0, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_tscasyncremoveall  PFTSCASYNCREMOVEALL_IEC pftscasyncremoveall;
	#define EXT_tscasyncremoveall  extern PFTSCASYNCREMOVEALL_IEC pftscasyncremoveall;
	#define GET_tscasyncremoveall(fl)  s_pfCMGetAPI2( "tscasyncremoveall", (RTS_VOID_FCTPTR *)&pftscasyncremoveall, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0, 0x01000000)
	#define CAL_tscasyncremoveall  pftscasyncremoveall
	#define CHK_tscasyncremoveall  (pftscasyncremoveall != NULL)
	#define EXP_tscasyncremoveall   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncremoveall", (RTS_UINTPTR)tscasyncremoveall, 1, 0, 0x01000000) 
#endif


/**
 * <description> This function retrieves the return value of the job function</description>
 * <param name="hJob" type="IN">Handle to the job</param>
 * <param name="pulReturnVal" type="IN">Pointer to the return value</param>
 * <result>error code</result>
 */
RTS_RESULT CDECL TscAsyncGetJobReturnValue(RTS_HANDLE hJob, RTS_UI32* pulRetVal);
typedef RTS_RESULT (CDECL * PFTSCASYNCGETJOBRETURNVALUE) (RTS_HANDLE hJob, RTS_UI32* pulRetVal);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCGETJOBRETURNVALUE_NOTIMPLEMENTED)
	#define USE_TscAsyncGetJobReturnValue
	#define EXT_TscAsyncGetJobReturnValue
	#define GET_TscAsyncGetJobReturnValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscAsyncGetJobReturnValue(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscAsyncGetJobReturnValue  FALSE
	#define EXP_TscAsyncGetJobReturnValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscAsyncGetJobReturnValue
	#define EXT_TscAsyncGetJobReturnValue
	#define GET_TscAsyncGetJobReturnValue(fl)  CAL_CMGETAPI( "TscAsyncGetJobReturnValue" ) 
	#define CAL_TscAsyncGetJobReturnValue  TscAsyncGetJobReturnValue
	#define CHK_TscAsyncGetJobReturnValue  TRUE
	#define EXP_TscAsyncGetJobReturnValue  CAL_CMEXPAPI( "TscAsyncGetJobReturnValue" ) 
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_TscAsyncGetJobReturnValue
	#define EXT_TscAsyncGetJobReturnValue
	#define GET_TscAsyncGetJobReturnValue(fl)  CAL_CMGETAPI( "TscAsyncGetJobReturnValue" ) 
	#define CAL_TscAsyncGetJobReturnValue  TscAsyncGetJobReturnValue
	#define CHK_TscAsyncGetJobReturnValue  TRUE
	#define EXP_TscAsyncGetJobReturnValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncGetJobReturnValue", (RTS_UINTPTR)TscAsyncGetJobReturnValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrTscAsyncGetJobReturnValue
	#define EXT_TscAsyncMgrTscAsyncGetJobReturnValue
	#define GET_TscAsyncMgrTscAsyncGetJobReturnValue  ERR_OK
	#define CAL_TscAsyncMgrTscAsyncGetJobReturnValue pITscAsyncMgr->ITscAsyncGetJobReturnValue
	#define CHK_TscAsyncMgrTscAsyncGetJobReturnValue (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncMgrTscAsyncGetJobReturnValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscAsyncGetJobReturnValue
	#define EXT_TscAsyncGetJobReturnValue
	#define GET_TscAsyncGetJobReturnValue(fl)  CAL_CMGETAPI( "TscAsyncGetJobReturnValue" ) 
	#define CAL_TscAsyncGetJobReturnValue pITscAsyncMgr->ITscAsyncGetJobReturnValue
	#define CHK_TscAsyncGetJobReturnValue (pITscAsyncMgr != NULL)
	#define EXP_TscAsyncGetJobReturnValue  CAL_CMEXPAPI( "TscAsyncGetJobReturnValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscAsyncGetJobReturnValue  PFTSCASYNCGETJOBRETURNVALUE pfTscAsyncGetJobReturnValue;
	#define EXT_TscAsyncGetJobReturnValue  extern PFTSCASYNCGETJOBRETURNVALUE pfTscAsyncGetJobReturnValue;
	#define GET_TscAsyncGetJobReturnValue(fl)  s_pfCMGetAPI2( "TscAsyncGetJobReturnValue", (RTS_VOID_FCTPTR *)&pfTscAsyncGetJobReturnValue, (fl), 0, 0)
	#define CAL_TscAsyncGetJobReturnValue  pfTscAsyncGetJobReturnValue
	#define CHK_TscAsyncGetJobReturnValue  (pfTscAsyncGetJobReturnValue != NULL)
	#define EXP_TscAsyncGetJobReturnValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscAsyncGetJobReturnValue", (RTS_UINTPTR)TscAsyncGetJobReturnValue, 0, 0) 
#endif



void CDECL CDECL_EXT tscasyncgetjobreturnvalue(tscasyncgetjobreturnvalue_struct *p);
typedef void (CDECL CDECL_EXT* PFTSCASYNCGETJOBRETURNVALUE_IEC) (tscasyncgetjobreturnvalue_struct *p);
#if defined(TSCASYNCMGR_NOTIMPLEMENTED) || defined(TSCASYNCGETJOBRETURNVALUE_NOTIMPLEMENTED)
	#define USE_tscasyncgetjobreturnvalue
	#define EXT_tscasyncgetjobreturnvalue
	#define GET_tscasyncgetjobreturnvalue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_tscasyncgetjobreturnvalue(p0) 
	#define CHK_tscasyncgetjobreturnvalue  FALSE
	#define EXP_tscasyncgetjobreturnvalue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_tscasyncgetjobreturnvalue
	#define EXT_tscasyncgetjobreturnvalue
	#define GET_tscasyncgetjobreturnvalue(fl)  CAL_CMGETAPI( "tscasyncgetjobreturnvalue" ) 
	#define CAL_tscasyncgetjobreturnvalue  tscasyncgetjobreturnvalue
	#define CHK_tscasyncgetjobreturnvalue  TRUE
	#define EXP_tscasyncgetjobreturnvalue  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncgetjobreturnvalue", (RTS_UINTPTR)tscasyncgetjobreturnvalue, 1, 0, 0x01000000) 
	#define EXTREF_ITF_tscasyncgetjobreturnvalue {(RTS_VOID_FCTPTR)tscasyncgetjobreturnvalue, "tscasyncgetjobreturnvalue", 0, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCASYNCMGR_EXTERNAL)
	#define USE_tscasyncgetjobreturnvalue
	#define EXT_tscasyncgetjobreturnvalue
	#define GET_tscasyncgetjobreturnvalue(fl)  CAL_CMGETAPI( "tscasyncgetjobreturnvalue" ) 
	#define CAL_tscasyncgetjobreturnvalue  tscasyncgetjobreturnvalue
	#define CHK_tscasyncgetjobreturnvalue  TRUE
	#define EXP_tscasyncgetjobreturnvalue  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncgetjobreturnvalue", (RTS_UINTPTR)tscasyncgetjobreturnvalue, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscAsyncMgrtscasyncgetjobreturnvalue
	#define EXT_TscAsyncMgrtscasyncgetjobreturnvalue
	#define GET_TscAsyncMgrtscasyncgetjobreturnvalue  ERR_OK
	#define CAL_TscAsyncMgrtscasyncgetjobreturnvalue  tscasyncgetjobreturnvalue
	#define CHK_TscAsyncMgrtscasyncgetjobreturnvalue  TRUE
	#define EXP_TscAsyncMgrtscasyncgetjobreturnvalue  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncgetjobreturnvalue", (RTS_UINTPTR)tscasyncgetjobreturnvalue, 1, 0, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_tscasyncgetjobreturnvalue
	#define EXT_tscasyncgetjobreturnvalue
	#define GET_tscasyncgetjobreturnvalue(fl)  CAL_CMGETAPI( "tscasyncgetjobreturnvalue" ) 
	#define CAL_tscasyncgetjobreturnvalue  tscasyncgetjobreturnvalue
	#define CHK_tscasyncgetjobreturnvalue  TRUE
	#define EXP_tscasyncgetjobreturnvalue  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncgetjobreturnvalue", (RTS_UINTPTR)tscasyncgetjobreturnvalue, 1, 0, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_tscasyncgetjobreturnvalue  PFTSCASYNCGETJOBRETURNVALUE_IEC pftscasyncgetjobreturnvalue;
	#define EXT_tscasyncgetjobreturnvalue  extern PFTSCASYNCGETJOBRETURNVALUE_IEC pftscasyncgetjobreturnvalue;
	#define GET_tscasyncgetjobreturnvalue(fl)  s_pfCMGetAPI2( "tscasyncgetjobreturnvalue", (RTS_VOID_FCTPTR *)&pftscasyncgetjobreturnvalue, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0, 0x01000000)
	#define CAL_tscasyncgetjobreturnvalue  pftscasyncgetjobreturnvalue
	#define CHK_tscasyncgetjobreturnvalue  (pftscasyncgetjobreturnvalue != NULL)
	#define EXP_tscasyncgetjobreturnvalue   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"tscasyncgetjobreturnvalue", (RTS_UINTPTR)tscasyncgetjobreturnvalue, 1, 0, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif



typedef struct
{
	IBase_C *pBase;
	PFTSCASYNCADD ITscAsyncAdd;
 	PFTSCASYNCADDJOB ITscAsyncAddJob;
 	PFTSCASYNCADDJOB2 ITscAsyncAddJob2;
 	PFTSCASYNCREMOVE ITscAsyncRemove;
 	PFTSCASYNCREMOVEALL ITscAsyncRemoveAll;
 	PFTSCASYNCGETJOBRETURNVALUE ITscAsyncGetJobReturnValue;
 } ITscAsyncMgr_C;

#ifdef CPLUSPLUS
class ITscAsyncMgr : public IBase
{
	public:
		virtual RTS_HANDLE CDECL ITscAsyncAdd(PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, RTS_UI32 ulJobPriority, RTS_RESULT *pResult) =0;
		virtual RTS_HANDLE CDECL ITscAsyncAddJob(PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, ASYNCJOB_PARAM* pAsyncJobParam, RTS_RESULT *pResult) =0;
		virtual RTS_RESULT CDECL ITscAsyncAddJob2(ASYNCJOB_INFO *pJob) =0;
		virtual RTS_RESULT CDECL ITscAsyncRemove(RTS_HANDLE hJob) =0;
		virtual RTS_RESULT CDECL ITscAsyncRemoveAll(void) =0;
		virtual RTS_RESULT CDECL ITscAsyncGetJobReturnValue(RTS_HANDLE hJob, RTS_UI32* pulRetVal) =0;
};
	#ifndef ITF_TscAsyncMgr
		#define ITF_TscAsyncMgr static ITscAsyncMgr *pITscAsyncMgr = NULL;
	#endif
	#define EXTITF_TscAsyncMgr
#else	/*CPLUSPLUS*/
	typedef ITscAsyncMgr_C		ITscAsyncMgr;
	#ifndef ITF_TscAsyncMgr
		#define ITF_TscAsyncMgr
	#endif
	#define EXTITF_TscAsyncMgr
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCASYNCMGRITF_H_*/
