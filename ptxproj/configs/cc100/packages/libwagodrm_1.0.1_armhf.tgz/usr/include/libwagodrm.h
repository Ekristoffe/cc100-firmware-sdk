//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libwagodrm.h
///
///  \brief    Interface to WAGO DRM licensing functions
///
///  \author   WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_LIBWAGODRM_H_
#define INC_LIBWAGODRM_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif

#include <wago/drm/drm_interface.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
}
#endif

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------

typedef struct
{
  char hardwareID[HW_ID_LENGTH +1];
  uint16_t hardwareIDLength;
}tHardwareID;

typedef struct
{
  uint8_t licenseData[LICENSES_DATA_MAX_LENGTH]; //max 1392 Bytes
  uint16_t licensesDataLength;
}tLicensesData;

typedef struct
{
  char shortenedLicenses[MAX_LICENSES * SHORTENED_KEY_LENGTH + 1];
  uint16_t keyLength;
  uint16_t numLicenses;
}tShortenedLicenseKeys;


typedef enum LibWagoDrmErrno
{
  Success = 0,

  //libwagodrm function error 1-100
  NullPointerError = 1,

  //DRM errors 100-199
  InternalError = 100,
  LicenseKeyAlreadyExists = 101,
  LicenseKeyNotTransferable = 102,
  StorageTargetNotAvailable = 103,
  LicenseKeyNotValid = 104,
  EvaluationModeNotExtendable = 105,
  MaximumLicenseReached = 106,
  LicenseInUse = 107,
  LicenseLocked = 108,
  LicenseNotFound = 109,
  InvalidState = 110,
  LicenseNotCovered = 111,
  NotEnoughCreditsAvailable = 112,
  NotReady = 113,

  //System functions errors 200-299
  FileOpenFailed = 200,
  FileCloseFailed = 201,
  IoctlError = 202

} T_LibWagoDrmErrno;

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

/**
 * @brief Function to find the given explicit license is covered or not
 *
 * @param licenseType Value which represents the type of the explicit license.
 * @param licenseCode Specific code of the explicit license.
 * @return LibWagoDrmErrno error code 0: Success -> license covered ; 111: License is not covered; other: Error
 */
T_LibWagoDrmErrno FindExplicitLicense(uint8_t licenseType, uint16_t licenseCode);

/**
* @brief Function to check if a function requiring the given explicit license may run or not
*
* @param licenseType Value which represents the type of the explicit license.
* @param licenseCode Specific code of the explicit license.
* @param pGeneratedHandleNumber Address of a uint64_t variable, that will get an unique number from the DRM system, if the license is covered,
*                               to handle the requested explicit license.
*                               To release the explicit license in the DRM system the number is necessary.
* @return LibWagoDrmErrno error code 0: Success -> license covered or evaluation mode active; 42: Application may not run; other: Error
*/
T_LibWagoDrmErrno CheckExplicitLicense(uint8_t licenseType, uint16_t licenseCode, uint64_t *pGeneratedHandleNumber);

/**
 * @brief Function to release the requested explicit license
 * @param licenseType Value which represents the type of the explicit license.
 * @param licenseCode Specific code of the explicit license.
 * @param handleNumber Generated number from the DRM system to release the specific request of a explicit license.
 * @return LibWagoDrmErrno error code
 */
T_LibWagoDrmErrno ReleaseExplicitLicense(uint8_t licenseType, uint16_t licenseCode, uint64_t handleNumber);

/**
 * @brief Function to get the actual state of the device regarding the license management.
 *
 * This function gets the actual license state and the remaining seconds of the evaluation mode.
 * The license state of the device are defined in the following states:
 * 0 - Licensed
 * 1 - Evaluation Mode
 * 2 - Expired
 *
 * @param licenseState Address of a variable who will get the current licenses state.
 * @param evalTime Address of a variable which will get the remaining time of the evaluation mode in seconds.
 * @return DRM error code
 */
T_LibWagoDrmErrno GetLicenseState(uint16_t* licenseState, uint32_t* evalTime);

/**
 * @brief Function to get all license keys in a shortened representation
 *
 * This function provides all licenses, which are stored on the device, in a shortened representation.
 * Moreover, the function also provides the length of a shortened key and the amount of license.
 * The results are accessible over the given structure.
 *
 * @param shortenedLicenseKeys Address of a structure from type ShortenedLicenseKeys.
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno GetShortenedLicenseKeys(tShortenedLicenseKeys* pShortenedLicenseKeys);

/**
 * @brief Function to get the maximum amount of licenses.
 *
 * The function gives information about the maximum amount of licenses, which can be stored on the device.
 * @param maxLicenses Address of a variable who will get the value.
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno GetMaximumLicenses(uint16_t* maxLicenses);

/**
 * @brief Get the licenses data
 *
 * The function retrieves all encrypted licenses data stored in the license data file.
 * The input parameter licenseSource defines the storage location of the license data file:
 * 0 - Device (internal storage)
 * 1 - Memory Card (not supported)
 *
 * @param licenseSource Input parameter to define the location of the license data file
 * @param licensesData Address of a structure from type tLicensesData to store the data
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno GetLicenses(uint16_t licenseSource, tLicensesData* licensesData);

/**
 * @brief Begin with one or more license operations
 *
 * IMPORTANT: This function has to be called every time before any other license operation function, e.g. AddLicense,
 * to change the DRM daemon into the operation state. Only in the operation state the DRM Deamon will accept
 * operation calls such as add or remove licenses.
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno BeginLicenseOperation(void);

/**
 * @brief Add a license to the device or memory card
 *
 * Function will add licenses to the device or memory card, depends on the input parameter licenseStorageLocation.
 * Following parameter are allowed:
 * 0 - Device (internal storage)
 * 1 - Memory Card (not supported)
 *
 * @param licenseStorageLocation Input parameter to define the storage location
 * @param licenseKey The encrypted license key
 * @param customerName The customer name which fits to the license
 * @param customerNameLength The length of the customer name
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno AddLicense(uint16_t licenseStorageLocation, const char* licenseKey, const char* customerName, uint16_t customerNameLength);

/**
 * @brief Remove a license with shortened key information
 *
 * Function needs the shortened license key as information to remove a specific license from the device
 * Format: "XXXXX-...-XXXXX" (First and last 5 character of the license)
 * @param shortenedKey Address to a char array which contains the shortened license key
 * @param shortenedKeyLength Length of the shortened license key
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno RemoveLicenseShortened(const char* shortenedKey, uint16_t shortenedKeyLength);

/**
 * @brief Commit the transferred licenses operation
 *
 * For executing the license operation , e.g add/remove licenses, and finishing the license operation mode, this function has to be called.
 * After calling this function the device will execute each operation and switch out from the license operation mode.
 * If one of the executing operations will fail, the index number of the operation will be written in the given variable.
 * First operation starts at index 1
 *
 * @param pFailedOperation Address to a variable which will store the index of the failed operation
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno CommitLicenseOperation(uint32_t* pFailedOperation);

/**
 * @brief Cancel transfered license operations e.g. add or remove licenses
 *
 * This function will cancel the transfered license operation and finish the operation mode state on the device
 *
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno CancelLicenseOperation(void);

/**
 * @brief Allocate the given amount of credits of the given credit type.
 *
 * @param creditType Type of credits
 * @param creditAmount Amount of credits
 * @param pGeneratedHandleNumber Generated unique number from the DRM system, if the allocation was successful,
 *                               to handle the requested amount of credits.
 *                               To release this specific amount of credits in the DRM system the handle number is necessary.
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno AllocateCredits(uint8_t creditType, uint32_t creditAmount, uint64_t *pGeneratedHandleNumber);

/**
 * @brief Release the specific amount of credits with the generated handle number.
 *
 * @param handleNumber Generated number from the DRM system to release the specific requested amount of credits.
 * @return LIBWAGODRM error code
 */
T_LibWagoDrmErrno ReleaseCredits(uint64_t handleNumber);

/**
 * @brief Get the current balance from a specific credit type
 * @param creditType Type of credits
 * @param pFreeCredits Current amount of credits
 * @return
 */
T_LibWagoDrmErrno GetFreeCredits(uint8_t creditType, int32_t *pFreeCredits);


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function implementation
//------------------------------------------------------------------------------


#endif /* INC_LIBWAGODRM_H_ */
//---- End of source file ------------------------------------------------------

