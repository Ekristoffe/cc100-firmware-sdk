 /**
 * <interfacename>TscParamServ</interfacename>
 * <description>
 *  This component provides the function GetParamServBackend, which delivers the backend to the parameter service. 
 *  An example how to use this can be seen in IoDrvRlb, which adds rlb topology to the backend.
 * </description>
 *
 * <copyright>
 *  Copyright (c) 2020-2022 WAGO GmbH & Co. KG. All rights reserved.
 * </copyright>
 */


	
	
#ifndef _TSCPARAMSERVITF_H_
#define _TSCPARAMSERVITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 *{attribute 'conditionalshow'}
 *{attribute 'conditionalshow' := 'SomeText'}
 *{attribute 'hide'}
 */
#define ERROR_NO_ERROR    RTS_IEC_INT_C(0x0)	
#define ERROR_TIME_OUT    RTS_IEC_INT_C(0x1)	
/* Typed enum definition */
#define ERROR    RTS_IEC_INT

/**
 * <description>
 *  GetParamServFrontend
 *  This struct includes a void pointer to frontend of parameter service. It is a void pointer, because 
 *  classes are implemented in C++, so when getting this, it needs to be casted to parameter_service_frontend_i*.
 * </description>
 */
typedef struct tagGetParamServFrontend_struct
{
	RTS_IEC_INT GetParamServFrontend;	/* VAR_OUTPUT */
	void *frontend;	/* VAR_OUTPUT */
} GetParamServFrontend_struct;

void CDECL GetParamServFrontend(GetParamServFrontend_struct *p);
typedef void (CDECL * PFGETPARAMSERVFRONTEND) (GetParamServFrontend_struct *p);
#if defined(TSCPARAMSERV_NOTIMPLEMENTED) || defined(GETPARAMSERVFRONTEND_NOTIMPLEMENTED)
	#define USE_GetParamServFrontend
	#define EXT_GetParamServFrontend
	#define GET_GetParamServFrontend(fl)  ERR_NOTIMPLEMENTED
	#define CAL_GetParamServFrontend(p0)  
	#define CHK_GetParamServFrontend  FALSE
	#define EXP_GetParamServFrontend  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_GetParamServFrontend
	#define EXT_GetParamServFrontend
	#define GET_GetParamServFrontend(fl)  CAL_CMGETAPI( "GetParamServFrontend" ) 
	#define CAL_GetParamServFrontend  GetParamServFrontend
	#define CHK_GetParamServFrontend  TRUE
	#define EXP_GetParamServFrontend  CAL_CMEXPAPI( "GetParamServFrontend" ) 
#elif defined(MIXED_LINK) && !defined(TSCPARAMSERV_EXTERNAL)
	#define USE_GetParamServFrontend
	#define EXT_GetParamServFrontend
	#define GET_GetParamServFrontend(fl)  CAL_CMGETAPI( "GetParamServFrontend" ) 
	#define CAL_GetParamServFrontend  GetParamServFrontend
	#define CHK_GetParamServFrontend  TRUE
	#define EXP_GetParamServFrontend  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"GetParamServFrontend", (RTS_UINTPTR)GetParamServFrontend, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscParamServGetParamServFrontend
	#define EXT_TscParamServGetParamServFrontend
	#define GET_TscParamServGetParamServFrontend  ERR_OK
	#define CAL_TscParamServGetParamServFrontend pITscParamServ->IGetParamServFrontend
	#define CHK_TscParamServGetParamServFrontend (pITscParamServ != NULL)
	#define EXP_TscParamServGetParamServFrontend  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_GetParamServFrontend
	#define EXT_GetParamServFrontend
	#define GET_GetParamServFrontend(fl)  CAL_CMGETAPI( "GetParamServFrontend" ) 
	#define CAL_GetParamServFrontend pITscParamServ->IGetParamServFrontend
	#define CHK_GetParamServFrontend (pITscParamServ != NULL)
	#define EXP_GetParamServFrontend  CAL_CMEXPAPI( "GetParamServFrontend" ) 
#else /* DYNAMIC_LINK */
	#define USE_GetParamServFrontend  PFGETPARAMSERVFRONTEND pfGetParamServFrontend;
	#define EXT_GetParamServFrontend  extern PFGETPARAMSERVFRONTEND pfGetParamServFrontend;
	#define GET_GetParamServFrontend(fl)  s_pfCMGetAPI2( "GetParamServFrontend", (RTS_VOID_FCTPTR *)&pfGetParamServFrontend, (fl), 0, 0)
	#define CAL_GetParamServFrontend  pfGetParamServFrontend
	#define CHK_GetParamServFrontend  (pfGetParamServFrontend != NULL)
	#define EXP_GetParamServFrontend  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"GetParamServFrontend", (RTS_UINTPTR)GetParamServFrontend, 0, 0) 
#endif




/**
 * <description>
 *  GetParamServBackend
 *  This struct includes a void pointer to backend of parameter service. It is a void pointer, because 
 *  classes are implemented in C++, so when getting this, it needs to be casted to parameter_service_backend_i*.
 * </description>
 */
typedef struct tagGetParamServBackend_struct
{
	RTS_IEC_INT GetParamServBackend;	/* VAR_OUTPUT */
	void *backend;	/* VAR_OUTPUT */
	void *backend_notification_manager;	/* VAR_OUTPUT */
} GetParamServBackend_struct;

void CDECL GetParamServBackend(GetParamServBackend_struct *p);
typedef void (CDECL * PFGETPARAMSERVBACKEND) (GetParamServBackend_struct *p);
#if defined(TSCPARAMSERV_NOTIMPLEMENTED) || defined(GETPARAMSERVBACKEND_NOTIMPLEMENTED)
	#define USE_GetParamServBackend
	#define EXT_GetParamServBackend
	#define GET_GetParamServBackend(fl)  ERR_NOTIMPLEMENTED
	#define CAL_GetParamServBackend(p0)  
	#define CHK_GetParamServBackend  FALSE
	#define EXP_GetParamServBackend  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_GetParamServBackend
	#define EXT_GetParamServBackend
	#define GET_GetParamServBackend(fl)  CAL_CMGETAPI( "GetParamServBackend" ) 
	#define CAL_GetParamServBackend  GetParamServBackend
	#define CHK_GetParamServBackend  TRUE
	#define EXP_GetParamServBackend  CAL_CMEXPAPI( "GetParamServBackend" ) 
#elif defined(MIXED_LINK) && !defined(TSCPARAMSERV_EXTERNAL)
	#define USE_GetParamServBackend
	#define EXT_GetParamServBackend
	#define GET_GetParamServBackend(fl)  CAL_CMGETAPI( "GetParamServBackend" ) 
	#define CAL_GetParamServBackend  GetParamServBackend
	#define CHK_GetParamServBackend  TRUE
	#define EXP_GetParamServBackend  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"GetParamServBackend", (RTS_UINTPTR)GetParamServBackend, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscParamServGetParamServBackend
	#define EXT_TscParamServGetParamServBackend
	#define GET_TscParamServGetParamServBackend  ERR_OK
	#define CAL_TscParamServGetParamServBackend pITscParamServ->IGetParamServBackend
	#define CHK_TscParamServGetParamServBackend (pITscParamServ != NULL)
	#define EXP_TscParamServGetParamServBackend  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_GetParamServBackend
	#define EXT_GetParamServBackend
	#define GET_GetParamServBackend(fl)  CAL_CMGETAPI( "GetParamServBackend" ) 
	#define CAL_GetParamServBackend pITscParamServ->IGetParamServBackend
	#define CHK_GetParamServBackend (pITscParamServ != NULL)
	#define EXP_GetParamServBackend  CAL_CMEXPAPI( "GetParamServBackend" ) 
#else /* DYNAMIC_LINK */
	#define USE_GetParamServBackend  PFGETPARAMSERVBACKEND pfGetParamServBackend;
	#define EXT_GetParamServBackend  extern PFGETPARAMSERVBACKEND pfGetParamServBackend;
	#define GET_GetParamServBackend(fl)  s_pfCMGetAPI2( "GetParamServBackend", (RTS_VOID_FCTPTR *)&pfGetParamServBackend, (fl), 0, 0)
	#define CAL_GetParamServBackend  pfGetParamServBackend
	#define CHK_GetParamServBackend  (pfGetParamServBackend != NULL)
	#define EXP_GetParamServBackend  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"GetParamServBackend", (RTS_UINTPTR)GetParamServBackend, 0, 0) 
#endif




#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFGETPARAMSERVFRONTEND IGetParamServFrontend;
 	PFGETPARAMSERVBACKEND IGetParamServBackend;
 } ITscParamServ_C;

#ifdef CPLUSPLUS
class ITscParamServ : public IBase
{
	public:
		virtual void CDECL IGetParamServFrontend(GetParamServFrontend_struct *p) =0;
		virtual void CDECL IGetParamServBackend(GetParamServBackend_struct *p) =0;
};
	#ifndef ITF_TscParamServ
		#define ITF_TscParamServ static ITscParamServ *pITscParamServ = NULL;
	#endif
	#define EXTITF_TscParamServ
#else	/*CPLUSPLUS*/
	typedef ITscParamServ_C		ITscParamServ;
	#ifndef ITF_TscParamServ
		#define ITF_TscParamServ
	#endif
	#define EXTITF_TscParamServ
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCPARAMSERVITF_H_*/
