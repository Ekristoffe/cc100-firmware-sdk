//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     ntp_parameter_provider.hpp
///
///  \brief    Parameter provider for network time protocol settings.
///
///  \author   BA : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_PP_NETWORKTIME_NTP_PARAMETER_PROVIDER_HPP_
#define INCLUDE_WAGO_PP_NETWORKTIME_NTP_PARAMETER_PROVIDER_HPP_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>

namespace wago::pp_networktime
{
//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------

/// \class ntp_parameter_provider
/// \brief This parameter providers allows to access network time protocol settings.
class ntp_parameter_provider final
    : public wago::wdx::base_parameter_provider
{
    ntp_parameter_provider(ntp_parameter_provider const &) = delete;
    ntp_parameter_provider& operator=(ntp_parameter_provider const &) = delete;
public:
    ntp_parameter_provider();
    ~ntp_parameter_provider() override;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
        std::vector<wago::wdx::value_request> value_requests) override;

    future<wdx::method_invocation_response> invoke_method(
        wdx::parameter_instance_id method_id, std::vector<std::shared_ptr<wdx::parameter_value>> in_args) override;

private:
    class detail;
    detail * d_ptr;
};

} // namespace wago::pp_networktime

#endif /* INCLUDE_WAGO_PP_NETWORKTIME_NTP_PARAMETER_PROVIDER_HPP_ */

//---- End of source file ------------------------------------------------------

