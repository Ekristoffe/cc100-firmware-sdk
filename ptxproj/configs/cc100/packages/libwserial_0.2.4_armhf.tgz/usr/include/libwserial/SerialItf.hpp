//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     SerialItf.hpp
///
///  \brief    Library for controlling serial port
///
///  \author   TBi : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_SERIALITF_HPP_
#define INC_SERIALITF_HPP_

#include "libwserial_api.h"
#include "libwserial_error.hpp"
#include <string>
#include <memory>

namespace wago {
namespace libwserial {

enum class SerialMode {
	RS232,
	RS485,
};

enum class StatusCode {
	SUCCESS,
	OWNER_NOT_UNASSIGNED
};

enum class BiasNetworkMode {
  OFF,
  LOW,
  HIGH
};

/// \brief Main class for Serial-Interface.
///
/// An instance of this class can be used to control the mode for a serial port.
class LIBWSERIAL_API SerialItf {
private:
	int dev_fd;
	class SerialOwnerImpl;
	std::unique_ptr<SerialOwnerImpl> current_owner;
public:
	/// Constructor for Serial-Interface Object.
	///
	/// \param filename
	///   Device-File of the serial interface.
	///
	/// \throws libwserial_error
	///   When Device-File could not be opened successfully.
	SerialItf(const std::string& filename);
	virtual ~SerialItf();

	/// Method to set the current mode for the serial port via ioctl.
	///
	/// \note This feature is optional!
	///   If the current platform does not support the configuration of the
	///   mode then this method will throw a libwserial_error which
	///   contains the error message "Not supported".
	///
	/// \param mode
	///   Either SerialMode::RS232 or SerialMode::RS485.
	///
	/// \throws libwserial_error
	///   When mode could not be set due to failed ioctl.
	///
	/// \return
	///   SUCCESS when current mode is changed successfully.
	///   OWNER_NOT_UNASSIGNED when serial port owner is not None.
	StatusCode set_mode(SerialMode mode);

	/// Method to get the current mode of the serial port via ioctl.
	///
	/// \throws libwserial_error
	///   When mode could not be retrieved due to failed ioctl.
	///
	/// \return
	///   Either SerialMode::RS232 or SerialMode::RS485.
	SerialMode get_mode();

	/// Method to set the configured mode for the serial port in file.
	/// \note This feature is optional!
	///   The actual mode of the port is not changed. This method is
	///   used to persist the mode so that a startup script or program
	///   can update the actual mode according to the setting in the
	///   file.
	///   If the current platform does not support the configuration of the
	///   persistent mode then this method will throw a libwserial_error which
	///   contains the error message "Not supported".
	///
	/// \throws libwserial_error
	///   When mode in file could not be written successfully.
	///
	/// \param mode
	///   Either SerialMode::RS232 or SerialMode::RS485.
	void set_persistent_mode(SerialMode mode);

	/// Method to get the configured mode for the serial port from file.
	/// \note The mode returned is not necessarily the actual mode of the port.
	///   This method is used to get the persisted mode so that a
	///   startup script or program is able to determine if the actual
	///   mode needs to be adjusted.
	///
	/// \throws libwserial_error
	///   When mode could not be read from file or an invalid mode is read.
	///
	/// \return
	///   Either SerialMode::RS232 or SerialMode::RS485.
	SerialMode get_persistent_mode();

	/// Method to get termination resistor state.
	/// \note The feature set resistor on serial interface is optional.
	///   If no resistor exist on hardware, the Method returns always false.
	/// \throws libwserial_error
	///   When an ioctl error occurs.
	/// \return
	///   true if resistor is connected to serial port, otherwise false.
	bool get_termination_resistor();

	/// Method to set termination resistor on serial interface.
	///
	/// \param state
	///   if true the resistor will be switch on, otherwise the resistor will switch off.
	/// \note The feature to set a resistor as termination is optional.
	///   If no resistor exist set state = true leads to throw.
	///
	/// \throws libwserial_error
	///   When state could not be set due to failed ioctl.
	void set_termination_resistor(bool state);

	/// Method to get the current Bias Network Mode
	///
	/// \note This feature is optional!
	///   If Bias Network is not supported this method will always return
	///   BiasNetworkMode::OFF.
	///
	/// \throws libwserial_error
	///   When an internal error occurs.
	///
	/// \return
	///   Either BiasNetworkMode::OFF, BiasNetworkMode::LOW or
	///   BiasNetworkMode::HIGH.
	BiasNetworkMode get_bias_network();

	/// Method to set the Bias Network Mode
	///
	/// \note This feature is optional!
	///   If the current platform does not support the configuration of the
	///   Bias Network then this method will throw a libwserial_error which
	///   contains the error message "Not supported".
	///
	/// \throws libwserial_error
	///   When not supported or an internal error occurs.
	///
	/// \param mode
	///   One of the modes of enum BiasNetworkMode
void set_bias_network(BiasNetworkMode mode);
};

} // namespace libwserial
} // namespace wago

#endif /* INC_SERIALITF_HPP_ */

