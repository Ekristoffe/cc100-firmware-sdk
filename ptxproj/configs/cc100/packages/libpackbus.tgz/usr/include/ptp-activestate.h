//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    ptp-activestate.h
///
///  \brief   API for the 'Active' state of the PTP state machine
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef PTP_ACTIVESTATE_H
#define PTP_ACTIVESTATE_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "ptp-types.h"
#include "ptp-states.h"
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
void PTP_state_transitionToActiveState(PTP_state_ptr state);
void active_set_ptp(PTP_state_ptr state);
void active_get_ptp(PTP_state_ptr state);

#endif
