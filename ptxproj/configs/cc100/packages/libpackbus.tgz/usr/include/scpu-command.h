//------------------------------------------------------------------------------
// Copyright (c) 2013-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file      scpu-command.h
///
///  \brief     Slave CPU command module interface
///
///  \attention This is a submodule used by the SCPU module. It is not expected
///             that any other module uses it.
///
///  \author    Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// Documentation
//------------------------------------------------------------------------------
/// \defgroup SCPU-COMMAND SCPU Command mechanism
/// @{
/// \section SCPU-COMMAND-DATA Data on the wire
///
/// A command always consists of two words of two bytes. The first word contains
/// the command itself, encoded as defined in ::SCPU_command.
/// The second word contains the length of additional data required for the
/// command. If the command does not require a parameter, the length is
/// nevertheless sent and encoded with 0x0000.
///
/// A command reply always consists of a three (3) word header.
/// The first word contains the command, as sent by the command request.
/// The second word contains the general status of the command. A zero
/// means no failure.
/// The third word contains the length of the remaining data.
/// @}

#ifndef SCPU_COMMAND_H
#define SCPU_COMMAND_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdint.h>
#include <stddef.h>
//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
typedef enum SCPU_command_error
{
  SCPU_COMMAND_ERR_NO_ERROR          = 0,
  SCPU_COMMAND_ERR_EXECUTION_FAILURE = 1,
  SCPU_COMMAND_ERR_INVALID_PARAMETER = 2
} SCPU_command_error_t;


/// \brief Commands for the slave cpu
/// \attention This enumeration is part of associative arrays. Do not change
/// the order or values of entries carelessly!
typedef enum SCPU_command
{
  SCPU_COMMAND_NOP			= 0,
  SCPU_COMMAND_RESET                 	= 1,    ///< Perform a software reset. This allows a graceful shutdown of the slave cpu.  
  SCPU_COMMAND_GET_ID			= 2,    ///< Retrieve an identifier of the slave cpu.
						///  This can be used to distinguish the underlying hardware or software and adapt the SCPU
						///  module behavior. The lowest three bits are a hardware identifier.
  SCPU_COMMAND_RESET_RAIL               = 3,	///< Reset the rail only
  SCPU_COMMAND_SET_RAIL_SPEED	        = 4,  	///< Set the speed of the rail (kHz)
  SCPU_COMMAND_GET_RAIL_STATUS       	= 5,    ///< Retrieve the status of the rail
  SCPU_COMMAND_GET_TERMINAL_POS		= 6,	///< Retrieve the bit position of each terminal
  SCPU_COMMAND_GET_TERMINAl_SIZE	= 7,	///< Retrieve the bit size of each terminal
  SCPU_COMMAND_GET_TERMINAL_DATATYPE	= 8,	///< Retrieve the data type information of the terminal
  SCPU_COMMAND_GET_TERMINAL_REGISTER 	= 9,    ///< Retrieve a specific register of each terminal
  SCPU_COMMAND_GET_RAIL_QUALITY		= 10,	///< Retrieve the quality statistics of the rail
  SCPU_COMMAND_TEST_COMMAND_INTERFACE	= 11,	///< Debug only
  SCPU_COMMAND_TEST_SET_DATA_LENGTH  	= 12,	///< Debug only
  SCPU_COMMAND_COUNT                  	= 13,
} SCPU_command_t;
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
SCPU_command_error_t SCPU_encode_command_no_args(SCPU_command_t cmd, uint8_t *buf, void *arg);


SCPU_command_error_t SCPU_encode_command_one_arg(SCPU_command_t cmd, uint8_t *buf, const void *arg);


SCPU_command_error_t SCPU_decode_reply(SCPU_command_t cmd, uint8_t *in, size_t expected_data_len, void *out);


uint8_t SCPU_command_get_last_error(SCPU_command_t cmd);
#endif
