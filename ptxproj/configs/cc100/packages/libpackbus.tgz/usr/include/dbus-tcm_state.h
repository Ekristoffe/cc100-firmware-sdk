//------------------------------------------------------------------------------
// Copyright (c) 2016-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
/// \file    dbus-tcm_state.h
///
/// \brief   API for the 'TCM Active' state of the DBus state machine
///
/// \version $Revision$
///
/// \author  WAGO GmbH & Co. KG
///
/// \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef DBUS_TCM_STATE_H
#define DBUS_TCM_STATE_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "dbus-states.h"
#include "../kbus-dbus.h"
#include "../kbus-dal.h"
#include "rail-info.h"

//---------------------------------------------------------------------------------------------------------------------
// defines
//---------------------------------------------------------------------------------------------------------------------
enum
{
  TCM_REPLACE_MODE_CLEAN  =  0,   /// clean TCM input PI
  TCM_REPLACE_MODE_LAST   =  1,   /// copy last received value in TCM input PI
  TCM_REPLACE_MODE_VALUE  =  2,   /// copy given value in TCM input PI
  MAX_TCM_REPLACE_MODE
};

//---------------------------------------------------------------------------------------------------------------------
// types
//---------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------
// functions
//---------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------
/// function switches state machine in TCM if possible
///
/// \param[in]    state:      pointer to state machine context
///
/// \return       nothing
//---------------------------------------------------------------------------------------------------------------------
void DBUS_state_transitionToTcmState(DBUS_state_ptr state);




//---------------------------------------------------------------------------------------------------------------------
/// function modifies register index  and count input PI access for table 116
///
/// \param[in]      pCtx:         pointer to state machine context
/// \param[in/out]  idx_register: pointer to index of first requested register
/// \param[in/out]  cnt:          pointer to number of requested register
///
/// \return         nothing
//---------------------------------------------------------------------------------------------------------------------
void TCM_ModifyInputPiIdxCnt( DBUS_state_ptr pCtx, uint16_t * const idx_register, uint16_t * const cnt );




//---------------------------------------------------------------------------------------------------------------------
/// function modifies register index and count of output PI access for table 112
///
/// \param[in]      pCtx:         pointer to state machine context
/// \param[in/out]  idx_register: pointer to index of first requested register
/// \param[in/out]  cnt:          pointer to number of requested register (limited in case of read access)
/// \param[in]      mode:         access mode read/write
///
/// \return         status:       0 = OK
///                               1 = error parameter
//---------------------------------------------------------------------------------------------------------------------
uint32_t TCM_ModifyOutputPiIdxCnt(DBUS_state_ptr pCtx, uint16_t * const idx_register, uint16_t * const cnt, KBUS_dbus_access_t mode);




//---------------------------------------------------------------------------------------------------------------------
/// function checks if addressed terminal is in TCM
///
/// \param[in]    state:      pointer to state machine
/// \param[in]    slotNo:     slot number of addressed terminal
///
/// \return       TRUE:       addressed terminal is in TCM
///               FALSE:      else
//---------------------------------------------------------------------------------------------------------------------
bool TCM_CheckActive(DBUS_state_ptr state, uint16_t slotNo);




//---------------------------------------------------------------------------------------------------------------------
/// function checks TCM is active
///
/// \param[in]    state:      pointer to state machine
///
/// \return       TRUE:       TCM is active
///               FALSE:      else
//---------------------------------------------------------------------------------------------------------------------
bool TCM_Active( DBUS_state_ptr state );




//---------------------------------------------------------------------------------------------------------------------
/// function returns slot number of active terminal in TCM
///
/// \param[in]    state:          pointer to state machine
///
/// \return       TCM is active:  slot number of terminal
///               else:           null
//---------------------------------------------------------------------------------------------------------------------
uint16_t TCM_GetSlotNo(DBUS_state_ptr state);




//---------------------------------------------------------------------------------------------------------------------
/// function checks if module is supported by TCM
///
/// \param[in]    pRailDesc:      pointer to rail description of terminal
/// \param[in]    slotNo:         slot number of terminal
///
/// \return       true:           supported terminal
///               false:          else
//---------------------------------------------------------------------------------------------------------------------
bool TCM_SupportedTerminal( RAIL_DESC const * const pRailDesc, uint16_t slotNo );




//---------------------------------------------------------------------------------------------------------------------
/// function checks requested version to available version
///
/// \param[in]    Version:        requested version of TCM
///
/// \return       true:           requested version is available or available version is compatible
///               false:          available version is incompatible
//---------------------------------------------------------------------------------------------------------------------
bool TCM_Valid_Config( uint32_t Version );
#endif
