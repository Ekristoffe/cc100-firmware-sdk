//------------------------------------------------------------------------------
// Copyright (c) 2000 - 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     ssc-access.h
///
///  \version  $Revision$
///
///  \brief    Accessing the SSC contents
///
///  This module is the interface for users who want to access data from
///  terminals which is not register data. In a more traditional approach, you
///  would say this module transfers the view of a process image to the reality
///  of the data transfer to the terminals.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef SSC_ACCESS_H
#define SSC_ACCESS_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include "ssc-types.h"
#include "rail-info.h"
//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
#define MAX_COPY_TABLE_ENTRIES 12000


/// defines to switch between CS2 <-> CS3
#define SSC_DAL_MODE_CS2_PI_DESCRIPTION     0x040E3u  // PA analog vor digital ohne Controlbytefilter
#define SSC_DAL_MODE_CS3_PI_DESCRIPTION     0x140E3u  // PA analog vor digital mit  Controlbytefilter
#define SSC_DAL_MODE_CS3_PI_DESCRIPTION_II  0xB00C3u  // PA analog vor digital ohne Fuellbytes mit Controlbytefilter

/// define for communication with IO_CHECK see also ssc-access.c 'ssc_config[SSC_MODE_REGCOM].pi_desc'
#define SSC_DBUS_IO_CHECK_PI_DESCRIPTION    0x44AE7u  // PA analog vor digital mit alle C/S mit Controlbytefilter

#define SSC_PI_DESCRIPTION_CBF_ALT_COM      0x10000u  // Steuerbit fuer den Controlbytefilter mit Wechselbetrieb
#define SSC_PI_DESCRIPTION_CBF              0x50000u  // Steuerbits die den CBF aktivieren
#define SSC_PI_DESCRIPTION_TCM_ACTIVE      0x100000u  // Steuerbit fuer den klemmenspezifischen Steuermodus TCM


/// \defgroup SSC SSC Documentation
/// @{
/// \section Introduction
/// The access to the SSC data is handled over a copy table.
/// The user requests an address and a length of data. These two values
/// are matched against one or more table entries. Each table entry
/// contains a set of copy instructions to perform, when a match occurs.
/// The granularity of the copy instruction is not pre-defined per se,
/// but depends on the copy table contents.
/// It is possible to use only one copy table entry, spanning the whole process
/// image area, thus imitating the behavior of the traditional series 750 devices.
///
/// Currently, there is only support for one copy table entry per byte/offset,
/// so each offset address is a correct array index at the same time.
///
/// The copy table stores an offset into a contiguous block of memory for
/// operations, which is mapped to a full address when copying the data. This
/// way it's possible to use a triple buffer, where the correct address changes
/// during runtime.
///
/// \note There is only one (1) user and one (1) open connection allowed per ::SSC_access_mode_t.
///
/// \internal The image of a copy table is only for explanation. The internal representation
/// might be anything between an array, a linked list or a balanced avl tree.
/// @}


/// \brief Tags the contents of the union in \ref SSC_cpy_instruction_t.
typedef enum SSC_cpy_instruction_tag
{
  SSC_CPY_SKIP = 0,     ///< Skip the instruction (for whatever reason - but as
                        ///  its value is 0, it also works automatically as
                        /// "skip when not initialized properly")
  SSC_CPY_BIT  = 1,     ///< This is an instruction to copy a bit
  SSC_CPY_BYTE = 2,     ///< This is an instruction to copy a linear array of bytes
  SSC_CPY_CODE = 3,     ///< This is an instruction that will use machine code for copying
  SSC_CPY_FCS  = 4,     ///< This is an instruction to generate a checksum
  SSC_CPY_M_BYTE = 5    ///< This is an instruction to mask and copy one byte
} SSC_cpy_instruction_tag_t;


/// \brief Contains the necessary parameters for a memcpy command
typedef struct SSC_memcpy_param
{
  uint32_t  ssc;     ///< Offset in bytes within the SSC buffer
  size_t    n;       ///< Length of data to copy
} SSC_memcpy_param_t;


/// \brief Contains the necessary parameters for a byte mask and copy command
typedef struct SSC_byte_mask_copy_param
{
  uint32_t  ssc;       ///< Offset in bytes within the SSC buffer
  uint8_t   req_mask;  ///< Mask for valid bits in the byte
} SSC_byte_mask_copy_param_t;


/// \brief Contains the necessary parameters to copy a bit.
/// The bits don't necessarily share the same bit position in source and destination.
typedef struct SSC_bitcpy_param
{
  uint32_t  ssc;       ///< Offset in bytes within the SSC buffer
                       ///  (equals dst for write and src for read)
  uint8_t  ssc_mask;   ///< Mask for the bit in the byte
  uint8_t  req_mask;   ///< Mask that is valid for the request
} SSC_bitcpy_param_t;


/// \brief Contains the necessary parameters to execute machine code
/// \attention This is currently not supported and might never be.
typedef struct SSC_codecpy_param
{
  void  *pc;            ///< Address to change the PC register to
} SSC_codecpy_param_t;


/// \brief Parameters for a frame checksum generation
typedef struct SSC_fcscpy_param
{
    uint16_t cnt_max_mbx_bytes;       // Length of the array of byteoffsets_mbx_bytes - when this limit is reached,
                                      // it is necessary to reallocate the byteoffsets_mbx_bytes array and generate
                                      // more memory
    uint16_t cnt_cur_mbx_bytes;       // Count of used array elements
    uint16_t *byteoffsets_mbx_bytes;  // Array of length cnt_mbx_bytes!
    uint16_t byteoffset_fcs;          // Destination offset for the checksum
} SSC_fcscpy_param_t;


/// \brief Describes one copy instruction.
/// A copy instruction is either to copy a(n array of) byte(s), to copy a single bit or to generate a checksum.
typedef struct SSC_cpy_instruction
{
  SSC_cpy_instruction_tag_t  tag;
  union
  {
    SSC_bitcpy_param_t          bit;
    SSC_memcpy_param_t          byte;
    SSC_byte_mask_copy_param_t  mbyte;
    SSC_codecpy_param_t         code;
    SSC_fcscpy_param_t        * fcs;
  } cpy;
  bool PiFromTcmToNowhere;            // terminal is not controlled by application
} SSC_cpy_instruction_t;


/// \brief Describes an entry in the copy table.
typedef struct SSC_copy_table_entry
{
  uint32_t               offset;           ///< Address requested and compared with together with the len
  size_t                 len;              ///< Length this copy entry table is valid for
  SSC_cpy_instruction_t  *actions;         ///< Copy actions to perform to satisfy this request - this is an array!
  size_t                 cnt_actions;      ///< Count of actions or length of array
} SSC_copy_table_entry_t;


/// \brief Error codes from the SSC module
typedef enum SSC_error
{
  SSC_NO_ERROR,                     ///< Request performed as expected
  SSC_NOT_READY,                    ///< SSC module is not (yet) ready / initizialized
  SSC_INVALID_PARAMETER,            ///< One parameter was very invalid (as in: a NULL-pointer)
  SSC_OUT_OF_RANGE_UPPER_BOUND,     ///< Request would validate the upper bound,
                                    ///  either because the address is already outside
                                    ///  or the request is too long
  SSC_OUT_OF_RANGE_LOWER_BOUND      ///< Request would validate the lower bound,
                                    ///  because the address is below the expected value
} SSC_error_t;


/// \brief Determines the mode of the SSC access used.
/// As different requesters might have a different point of view how a process image
/// should look like, this flag can be used to switch between different modes.
/// \internal Basically this allows the differentation between different copy tables
/// in use.
typedef enum SSC_access_mode
{
  SSC_MODE_DAL      = 0,         ///< DAL mode access is requested
                                 ///< which is the process image point of view of the DAL
  SSC_MODE_REGCOM   = 1,         ///< Register communication access is requested
  SSC_MODE_DAL_TCM  = 2,         ///< DAL mode access is requested and TCM is active
  SSC_MODE_COUNT                 ///< Count of enumeration entries
} SSC_access_mode_t;


/// \brief Handle to use for access after the "connection" was established.
typedef struct SSC_descriptor *SSC_descriptor_t;

//********************************* MODULE INFORMATION ************************
// These functions are used by other modules to retrieve information about the
// SSC module.

/// \brief Retrieves length information about the process image view
///
/// The function fills the pointers with the length information. NULL is allowed if
/// there is no need for a particular length information.
///
/// \param[in]  mode  Process image view the length information shall be retrieved from
/// \param[out] bitlenAnalogOut   Pointer to store the analog output length value
/// \param[out] bitlenAnalogIn    Pointer to store the analog input length value
/// \param[out] bitlenDigitalOut  Pointer to store the digital out length value
/// \param[out] bitlenDigitalIn   Pointer to store the digital in length value
/// \param[out] bitposDigitalOut  Pointer to store the start offset of digital output data
/// \param[out] bitposDigitalIn   Pointer to store the start offset of digital input data
void SSC_get_process_image_content_length(SSC_access_mode_t mode,
                                          uint32_t *bitlenAnalogOut,
                                          uint32_t *bitlenAnalogIn,
                                          uint32_t *bitlenDigitalOut,
                                          uint32_t *bitlenDigitalIn,
                                          uint32_t *bitposDigitalOut,
                                          uint32_t *bitposDigitalIn);

/// \brief Retrieves the process image description as binary blob
///
/// This function is only used for register communication, which is able to understand the binary blob.
///
/// \param[in] idx  An index as requested. If the index is higher than ::SSC_get_process_image_count() -1, then 0 is
///                 returned.
///
/// \return The process image description value, which is never 0, if it's a valid one
uint32_t ulSSC_get_process_image_description(unsigned int idx);


/// \brief Retrieves the process image description as binary blob
///
/// This function is only used for register communication, which is able to understand the binary blob.
///
/// \param[in] idx  An index as requested. If the index is higher than ::SSC_get_process_image_count() -1, then 0 is
///                 returned.
///
/// \return The process image description value, which is never 0, if it's a valid one
uint16_t SSC_get_process_image_description(unsigned int idx);


/// \brief Writes the process image description as binary blob
///
/// \param[in]  uiIndex:    An index as requested. If the index is higher than ::SSC_get_process_image_count() -1,
///                         then an error code is returned.
///
/// \param[out] ulValue:    Value to write into the register
///
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_set_process_image_description( uint uiIndex, uint32_t ulValue );


/// \brief Retrieve the count of supported process image views
/// \return The count of supported process images views
uint16_t SSC_get_process_image_count(void);


//********************************* UPPER LAYER *******************************
// These functions are used by the kbus-dal module to pass "down" requests from
// the SDI.

/// Inits the SSC module and let's it perform tasks that need to be done prior
/// an open call can be used.
/// It is not advised to call this function more than once, as descriptors,
/// which were handed out by SSC_Open would become invalid.
/// \attention This function requires the rail info module to be up and running.
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Init(void);


/// Update the SSC copy table
/// This function recreates the copy table and can be called, when the rail
/// has changed. It will retrieve the latest information from the rail info
/// module itself.
/// This function only works when SSC_Init() was called. It is not required to
/// call SSC_Update() after SSC_Init(). SSC_Init() will create a copy table already.
/// \attention This function requires the rail info module to be up and running.
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Update(void);


/// Update single SSC copy table
/// This function recreates one copy table and can be called, when the rail
/// or the PI description have changed. It will retrieve the latest information
/// from the rail info module itself.
/// This function only works when SSC_Init() was called.
/// \attention This function requires the rail info module to be up and running.
/// \param[in] mode Determines the access mode of the PI
/// \param[in] SlotNo addresses terminal for TCM
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_UpdateSinglePI( SSC_access_mode_t mode, uint8_t SlotNo );


/// Opens a connection to the SSC module.
/// \internal Right now this has no real use, except to have a consistent look
/// and feel over the various modules and to be future-proof.
/// \param[in] mode Determines the access mode used for this connection
/// \return A descriptor for the ::SSC_Put(), ::SSC_Get() and ::SSC_Close() functions or
/// NULL in case of an error
SSC_descriptor_t SSC_Open(SSC_access_mode_t mode);


/// clears LWD buffer
/// \return    SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Reset( void );


/// Retrieves data from the SSC module.
/// \param[in] sd       A valid descriptor obtained by ::SSC_Open()
/// \param[in] offset   Address that is requested (as in: process image address)
/// \param[in] len      Length of data requested
/// \param[in] buf      Pointer where to put the data into that was retrieved
///                     It's the job of the caller to make sure that buf is big enough to hold \a len
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Get(SSC_descriptor_t sd,
                    uint32_t         offset,
                    size_t           len,
                    uint8_t          *buf);


/// Puts data into the SSC module.
/// \param[in] sd       A valid descriptor obtained by ::SSC_Open()
/// \param[in] offset   Address that shall be set (as in: process image address)
/// \param[in] len      Length of data requested
/// \param[in] buf      Pointer where to get the data from that shall be put into the SSC
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Put(SSC_descriptor_t sd,
                    uint32_t         offset,
                    size_t           len,
                    uint8_t          *buf);


/// Puts data into the SSC module for TCM (PI input data for application).
/// \param[in] sd       A valid descriptor obtained by ::SSC_Open()
/// \param[in] offset   Address that shall be set (as in: process image address)
/// \param[in] len      Length of data requested
/// \param[in] buf      Pointer where to get the data from that shall be put into the SSC
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Put_TCM(SSC_descriptor_t sd,
                        uint32_t         offset,
                        size_t           len,
                        uint8_t          *buf);


/// copies PI input data to TCM buffer
/// \return    SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Copy_Inputs_To_TCM( void );


/// clears TCM buffer
/// \return    SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Clear_TCM( void );


/// Get data that was put into the SSC module.
/// \param[in] sd       A valid descriptor obtained by ::SSC_Open()
/// \param[in] offset   Address that shall be get (as in: process image address)
/// \param[in] len      Length of data requested
/// \param[in] buf      Pointer where to put the data into that was retrieved
///                     It's the job of the caller to make sure that buf is big enough to hold \a len
/// \attention THIS FUNCTION IS ONLY FOR THE DBUS MODULE! DBUS register calls and DAL process data calls are mutually
/// exclusive, as IOCheck is not allowed to run with a PFC application. This function relies on this, as a triple
/// buffer does not handle multiple consumers/producers. This is a second (rival) consumer for the triple buffer
/// (the SCPU module being the first consumer).
SSC_error_t SSC_PutGet(SSC_descriptor_t sd,
                       uint32_t         offset,
                       size_t           len,
                       uint8_t          *buf);


/// Retrieves a data bit from the SSC module.
/// \param[in] sd          A valid descriptor obtained by ::SSC_Open()
/// \param[in] bitoffset   Address that is requested (as in: process image address) in bits
/// \param[in] buf         Pointer where to put the data into that was retrieved
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Get_Bit(SSC_descriptor_t sd,
                        uint32_t         bitoffset,
                        uint8_t          *buf);


/// Sets a data bit from the SSC module.
/// \param[in] sd          A valid descriptor obtained by ::SSC_Open()
/// \param[in] bitoffset   Address that is requested (as in: process image address) in bits
/// \param[in] buf         Pointer where to to get the data from to set
SSC_error_t SSC_Put_Bit(SSC_descriptor_t sd,
                        uint32_t         bitoffset,
                        uint8_t          *buf);


/// Closes the connection to the SSC module and frees any resources used by ::SSC_Open().
/// \param[in] sd A valid descriptor obtained by ::SSC_Open()
/// \return SSC_NO_ERROR or any other allowed error code
SSC_error_t SSC_Close(SSC_descriptor_t sd);


/// Frees any resources used by ::SSC_Init() and disables the module.
void SSC_Free(void);


/// handles transmit spin buffer
void SSC_access_handle_tx_buffer(void);


/// handles receive spin buffer
void SSC_access_handle_rx_buffer(void);


//********************************* LOWER LAYER *******************************
// These functions are used by the PTP module to pass "down" requests from
// the register communication
/// \brief Retrieve a transmit buffer where the ptp layer can read data from
/// \param[in] mux The multiplex channel the buffer is for
/// \return A pointer where the latest SSC contents can be get from
uint8_t * SSC_access_get_tx_buffer(unsigned mux);


/// \brief Retrieve a buffer where the ptp layer can write data to
uint8_t * SSC_access_get_DTS_buffer(unsigned mux);


/// \brief     Retrieve a receive buffer where the ptp layer can read data from
/// \param[in] mux The multiplex channel the buffer is for
/// \attention The returned pointer stays valid till a new call to
///            SSC_access_refresh_rx_buffer(). Then the old pointer must not be used
///            again!
/// \attention The contents the pointer points to do not update. So it's \b not
///            sufficient to call this function once and store the pointer
///            somewhere for future use. Then you will always retrieve the same
///            data, without ever getting any updates from the SCPU.
/// \return    A pointer from where the current SSC contents can be read from
uint8_t * SSC_access_get_rx_buffer(unsigned mux);


/// \brief Refresh the receive buffer with the current SSC content
void SSC_access_refresh_rx_buffer(void);


/// \brief Refresh the DTS buffer with the transmit buffer content
void SSC_access_refresh_tx_buffer(void);


//********************************* LOWER LAYER *******************************
/// \brief     Retrieve a buffer where the lower layer can read current data from
/// \param[in] mux The multiplex channel the buffer is for
/// \attention Never call this from the DAL layer!
/// \attention The contents the pointer points to do not update. So it's \b not
///            sufficient to call this function once and store the pointer
///            somewhere for future use. Then you will always retrieve the same
///            data, without ever getting any updates from the DAL.
/// \return    A pointer from where the current SSC contents can be read from
uint8_t * SSC_access_get_src_buffer(unsigned mux);


/// \brief Retrieve a destination buffer where the lower layer can write data to
/// \param[in] mux The multiplex channel the buffer is for
/// \attention Never call this from the DAL layer!
/// \attention This buffer must be released again!
/// \return A pointer where the latest SSC contents can be put in
uint8_t * SSC_access_get_dst_buffer(unsigned mux);


/// \brief Release the destination buffer
/// Call this function when the writes are finished. The destination buffer
/// must be released before changes become valid for the system, so it's
/// \b not okay to store the result of SSC_access_get_dst_buffer() and use this
/// reference forever.
/// \attention Never call this from the DAL layer!
void SSC_access_release_dst_buffer(void);
#endif
