//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    ptp-idlestate.h
///
///  \brief   API for the 'Idle' state of the PTP state machine
///
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef PTP_IDLESTATE_H
#define PTP_IDLESTATE_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "ptp-states.h"
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
void PTP_state_transitionToIdleState(PTP_state_ptr state);
#endif
