//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material.
// All manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    os_conf_xml_xsd.h
///
///  \brief   Module for retrieving xsd information
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef OS_CONF_XML_XSD_H
#define OS_CONF_XML_XSD_H
#include <libxml/xmlstring.h>

/// Retrieve the xsd as parseable null-terminated UTF-8 string
const xmlChar *os_conf_xml_get_xsd(void);

#endif
