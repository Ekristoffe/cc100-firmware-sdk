//------------------------------------------------------------------------------
///
///  \file     mem-buffer.h
///
///  \brief    Interface for the mem-buffer module
///
///  A triple buffer works only correctly with one (1) consumer and  one (1)
///  producer.
///
///  The usage for the consumer is:
///  \code
///   MEM_snapshot_buffer();
///   MEM_get_read_buffer();
///   Read data at will
///   Repeat as desired
///  \endcode
///
///  The usage for the producer is:
///  \code
///   MEM_get_write_buffer();
///   Write data at will
///   MEM_flip_buffer();
///   Repeat as desired
///  \endcode
///
///  If you follow this simple procedure, all will be good.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc  Copyright
///
//------------------------------------------------------------------------------
#ifndef MEM_BUFFER_H
#define MEM_BUFFER_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <pthread.h>
#include <stdint.h>
//------------------------------------------------------------------------------
// Public datatypes
//------------------------------------------------------------------------------
/// \brief Error codes of the module
typedef enum MEM_error
{
  MEM_ERR_NO_ERROR,
  MEM_ERR_INVALID_PARAMETER
} MEM_error_t;

/// \brief Defines data required for a single triple buffer
/// \internal Incomplete forward declaration
typedef struct MEM_triple_buffer MEM_triple_buffer_t;
//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------
/// \brief Create a memory triple buffer
/// \param[in] memsize Size in bytes of (one) memory buffer, which must be higher than 0
/// \return A pointer to the buffer descriptor or NULL
/// \sa ::MEM_destroy_buffer()
MEM_triple_buffer_t *MEM_create_buffer(size_t memsize);


/// \brief Destroys a previously created triple buffer
/// \param[in] buf Pointer to a buffer created with ::MEM_create_buffer()
/// \retval MEM_ERR_NO_ERROR    Buffer was destroyed
/// \retval MEM_INVALID_BUFFER  \a buf was not valid
/// \sa ::MEM_create_buffer()
MEM_error_t MEM_destroy_buffer(MEM_triple_buffer_t **buf);


/// \brief Takes a snapshot of the copy buffer
/// This function needs to be called before data is read by the consumer.
/// \param[in] buf Pointer to a valid triple buffer description
MEM_error_t MEM_snapshot_buffer(MEM_triple_buffer_t *buf);


/// \brief Flips the working and copy buffer
/// This function needs to be called after the producer finished writing data.
/// \param[in] buf Pointer to a valid triple buffer description
MEM_error_t MEM_flip_buffer(MEM_triple_buffer_t *buf);


/// \brief Retrieves a pointer to the current valid read buffer
/// The pointer returned will always point to the same contents, unless
/// ::MEM_snapshot_buffer() is called. So it's \b not okay to store the result
/// of this function and use the stored reference forever.
/// \retval NULL when the pointer buffer is not valid
/// \sa ::MEM_snapshot_buffer()
uint8_t *MEM_get_read_buffer(MEM_triple_buffer_t *buf);


/// \brief Retrieves a pointer to the current valid write buffer
/// The write buffer must be released with ::MEM_flip_buffer() before changes
/// become valid for the consumer, so it's \b not okay to store the result of
/// this function and use the stored reference forever.
/// \retval NULL when the pointer buffer is not valid
/// \sa ::MEM_flip_buffer()
uint8_t *MEM_get_write_buffer(MEM_triple_buffer_t *buf);


/// \brief Retrieve the useable buffer size of the memory buffer
/// \return 0 when the buffer pointer is not valid or the length of the buffer
size_t MEM_get_buffer_size(MEM_triple_buffer_t *buf);

/// \brief Clears the data memory of the buffer, setting all data values to 0
void MEM_clear_buffer(MEM_triple_buffer_t *buf);
#endif
