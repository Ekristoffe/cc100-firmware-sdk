//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     ssc-types.h
///
///  \brief    Datatypes and legacy interface definitions
///
///  This header file contains datatypes and interface definitions which are
///  ported from the core 750er series code. Most items in here were not
///  touched, to prevent errors through the porting process. Once the
///  correctness of the library is verified, this header could be cleaned up
///  more and integrated in the proper sub-modules.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef SSC_TYPES_H
#define SSC_TYPES_H

#include <stdint.h>
#include <stdbool.h>

/// Exists for compatibility reasons
#define ERR_ARG_DATA_TYPE   0x0002

/// The amount of different process views required
/// Although only 2 process views are required, this should be set to 4 for legacy code compatibility reasons
#define MAX_PROCESS_VIEWS   4

/// \name Process view IDs
/// @{
#define FB_PROCESS      0x00  ///< Process view for the fieldbus - unused
#define PFC_PROCESS     0x01  ///< Process view for the plc runtime
#define SER_PROCESS     0x02  ///< Process view for the serial interface, as required by WAGO GUI software
#define KBUS_PROCESS    0x03  ///< Process view for the kbus - unused
/// @}


/// \name Terminal type bitmask information
/// @{
#define TYPE_INP            0x0001  ///< Terminal has input data
#define TYPE_OUTP           0x0002  ///< Terminal has output data
#define TYPE_PROZ           0x0080  ///< Terminal is complex
#define TERMINAL_TYPE_MASK  0x000F  ///< Bitmask to retrieve the terminal type
/// @}


/// \name Legacy error codes
/// @{
#define COUPLER_ERR           0x01 ///< Error code
#define ASSIGN_LIST_TOO_SMALL 0x08 ///< GetCnfFromRail return value
/// @}

/*----  Datentypregister der Prozessorklemmmen                                                                          ----*/
/*----------------------------------------------------------------------*/
/*----------------------------------------------------------------------*/
/* Datentypen der komplexen Busklemmen                                  */
/*----------------------------------------------------------------------*/
/*----------------------------------------------------------------------*/
#define UNKNOWN_DATATYPE                0x00
#define NO_DATA_TYPE                    0x00
/*----------------------------------------------------------------------*/
/* MAPPING fuer ARRAY_OF_BYTES                                          */
/*----------------------------------------------------------------------*/
/* KBUS    : D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11 */
/* MOTOROLA: D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11 */
/*           +--------------------------------------------------------+ */
/*                                   BYTESTREAM                         */
/*----------------------------------------------------------------------*/
#define ARRAY_OF_BYTES                  0x01
#define ARRAY__BYTE                     0x01 // Bytearray
/*----------------------------------------------------------------------*/
/* MAPPING fuer STRUCT_CS_ARRAY_OF_BYTES                                */
/*----------------------------------------------------------------------*/
/* KBUS    : C/S, D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : C/S, D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10 */
/* MOTOROLA: C/S, D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10 */
/*           +--------------------------------------------------------+ */
/*                                   BYTESTREAM                         */
/*----------------------------------------------------------------------*/
#define STRUCT_CS_ARRAY_OF_BYTES        0x02
#define STRUCT_BYTE                     0x02 // Struktur 1 Byte n Bytes
/*----------------------------------------------------------------------*/
/* MAPPING fuer ARRAY_OF_WORDS                                          */
/*----------------------------------------------------------------------*/
/* KBUS    : D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : D00, D01, D02, D03, D04, D05, D06, D07, D08, D08, D10, D11 */
/* MOTOROLA: D01, D00, D03, D02, D05, D04, D07, D06, D09, D08, D11, D10 */
/*           +------+  +------+  +------+  +------+  +------+  +------+ */
/*            WORD0     WORD1     WORD2     WORD3     WORD4     WORD5   */
/*----------------------------------------------------------------------*/
#define ARRAY_OF_WORDS                  0x03
#define ARRAY__WORD                     0x03 // Wordarray
/*----------------------------------------------------------------------*/
/* MAPPING fuer STRUCT_CS_ARRAY_OF_WORDS                                */
/*----------------------------------------------------------------------*/
/* KBUS    : C/S, D00, D01, RES, D02, D03, RES, D04, D05, RES, D06, D07 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : C/S, RES, D00, D01, D02, D03, D04, D05, D06, D07           */
/* MOTOROLA: C/S, RES, D01, D00, D03, D02, D05, D04, D07, D06           */
/*           +------+  +------+  +------+  +------+  +------+           */
/*             C/S      WORD0     WORD1     WORD2     WORD3             */
/*----------------------------------------------------------------------*/
#define STRUCT_CS_ARRAY_OF_WORDS        0x04
#define STRUCT_BYTE_WORD                0x04 // Struktur jeweils 1 Byte und 1 Wort
/*----------------------------------------------------------------------*/
/* MAPPING fuer ARRAY_OF_DWORDS                                         */
/*----------------------------------------------------------------------*/
/* KBUS    : D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : D00, D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11 */
/* MOTOROLA: D03, D02, D01, D00, D07, D06, D05, D04, D11, D10, D09, D08 */
/*           +----------------+  +----------------+  +----------------+ */
/*                 DWORD0              DWORD1              DWORD2       */
/*----------------------------------------------------------------------*/
#define ARRAY_OF_DWORDS                 0x05
#define ARRAY__DWORD                    0x05 // Doppelwortarray
/*----------------------------------------------------------------------*/
/* MAPPING fuer STRUCT_CS_ARRAY_OF_DWORDS                               */
/*----------------------------------------------------------------------*/
/* KBUS    : C/S, D00, D01, RES, D02, D03, RES, D04, D05, RES, D06, D07 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : C/S, RES, D00, D01, D02, D03, D04, D05, D06, D07           */
/* MOTOROLA: C/S, RES, D03, D02, D01, D00, D07, D06, D05, D04           */
/*           +------+  +----------------+  +----------------+           */
/*             C/S           DWORD0              DWORD1                 */
/*----------------------------------------------------------------------*/
#define STRUCT_CS_ARRAY_OF_DWORDS       0x06
#define STRUCT_DWORD                    0x06 // Struktur 1 Byte n Doppelworte
/*----------------------------------------------------------------------*/
/* MAPPING fuer STRUCT_CS_WORD                                          */
/*----------------------------------------------------------------------*/
/* KBUS    : C/S, D00, D01, RES, D02, D03, RES, D04, D05, RES, D06, D07 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : C/S, D00, D01, C/S, D02, D03, C/S, D04, D05, C/S, D06, D07 */
/* MOTOROLA: C/S, D01, D00, C/S, D03, D02, C/S, D05, D04, C/S, D07, D06 */
/*           +-+  +------+  +-+  +------+  +-+ +------+   +-+  +------+ */
/*           C/S   WORD0    C/S   WORD1    C/S  WORD2     C/S   WORD3   */
/*----------------------------------------------------------------------*/
#define STRUCT_CS_WORD                  0x07
#define STRUCT_WORD                     0x07 // Struktur 1 Byte n Worte
/*----------------------------------------------------------------------*/
/* MAPPING fuer STRUCT_CS_DWORD                                         */
/*----------------------------------------------------------------------*/
/* KBUS    : C/S, D00, D01, C/S, D02, D03, C/S, D04, D05, C/S, D06, D07 */
/*           +-----------+  +-----------+  +-----------+  +-----------+ */
/*               MUX0           MUX1           MUX2           MUX3      */
/*----------------------------------------------------------------------*/
/* INTEL   : C/S, C/S, D00, D01, D02, D03, C/S, C/S, D04, D05, D06, D07 */
/* MOTOROLA: C/S, C/S, D03, D02, D01, D00, C/S, C/S, D07, D06, D05, D04 */
/*           +------+  +----------------+  +------+  +----------------+ */
/*             C/S           DWORD0          C/S           DWORD1       */
/*----------------------------------------------------------------------*/
#define STRUCT_CS_DWORD                 0x08
#define STRUCT_BYTE_DWORD               0x08 // Struktur jeweils 1 Byte und 1 Doppelwort

/* Datentypen mit variabler logischer Kanallaenge   */
/* identisch mit den oberen Datentypen              */
#define VAR_ARRAY_OF_BYTES              0x11
#define ARRAY__VAR_BYTE                 0x11 // Bytearray
#define STRUCT_CS_VAR_ARRAY_OF_BYTES    0x12
#define STRUCT_VAR_BYTE                 0x12 // Struktur 1 Byte n Bytes
#define VAR_ARRAY_OF_WORDS              0x13
#define ARRAY__VAR_WORD                 0x13 // Wordarray
#define STRUCT_CS_VAR_ARRAY_OF_WORDS    0x14
#define STRUCT_VAR_WORD                 0x14 // Struktur 1 Byte n Worte
#define VAR_ARRAY_OF_DWORDS             0x15
#define ARRAY__VAR_DWORD                0x15 // Doppelwortarray
#define STRUCT_CS_VAR_ARRAY_OF_DWORDS   0x16
#define STRUCT_VAR_DWORD                0x16 // Struktur 1 Byte n Doppelworte
#define STRUCT_CS_PROFISAFE             0x20 // PROFIsafe Datenstruktur
#define STRUCT_CS_WORD_VAR_DWORD        0x26 // Struktur 1 Byte 1 Wort n Doppelworte


#define MAX_MUX_COUNT   4       ///< Max multiplex channels on rail
#define MAX_SSC_SIZE    3000    ///< 250 terminals with 12 byte width


/// Determines what kind of inline code should be generated.
enum eInlineTarget
{
  GEN_FB_MAPPING,           // Mapping fuer Feldbus generieren
  GEN_SER_MAPPING,          // fuer serielle Schnittstelle (WAGO-IO-Check)
  GEN_PFC_OFS_MAPPING,      // fuer PFC, mit Offset-Verschiebung der digitalen EA's
  GEN_PFC_ABS_MAPPING,      // fuer PFC, ohne Offset-Verschiebung der digitalen EA's
  SPEC_PFC_LIB_MAPPING,     // Reichstein 07.02.01, fuer WAGO-IO-PRO-Libs zum Aufbau einer Tabelle
  SPEC_FB_PFCVAR_MAPPING,   // WK 20.02.01 PFC-Variablenmapping in das FB-PA
  SPEC_FB_VAR_MAPPING,      // RS 20.03.01 Variablenmapping in das FB-PA
  CAN_FB_MAPPING            // Mapping fuer CAN-Feldbus generieren
};


/// Contains the result of the GenCnfFromRail conversion.
/// RailDesc data and PROCESS_IMAGE_DESC and EInlineTarget, both as part of SSC_config_t, are processed and
/// the output consists of data about the terminal regarding the SSC (Pos, MuxKanal) and the process view
/// (EvenByteOffs, ByteVar, ...). This can then be used to generate a copy table.
typedef struct
{
  unsigned short  Pos;          ///< Bitoffset within the SSC this entry is for
  unsigned short  EvenByteOffs; ///< Byteoffset in the process view
  unsigned char   MuxKanal;     ///< For which multiplex channel this entry is valid for
  unsigned char   LogKanal;     ///< Signal channel in the process view (0...15)
  unsigned char   BitOffs;      ///< Bitoffset in the process view word (0...15)
  unsigned char   Slot;         ///< Slot position of the terminal on the rail
  unsigned char   Mask;         ///< Mask for 'mask and copy' action
  bool            Zero;         ///< Entry to generate a zero byte in the process view - this should not occur
  bool            ByteVar;      ///< Whether this is a bit (false) or byte (true) variable
  bool            DiagVar;      ///< This is diagnostic information  - this should not occur
  bool            AcyclicMbx;   ///< This is acyclic mailbox data - this should not occur
  bool            AddByteToFCS; ///< This byte is part of the frame checksum
  bool            FCSVar;       ///< This byte IS the frame checksum
  bool            MByte;        ///< This Byte has to be masked before it is copied
  bool            TCM_Active;   ///< terminal runs in specific control mode (IDE controlled)
} ZUORD;


typedef struct
{
  unsigned
    Active           : 1,
    AutoConfig       : 1,
    CmplxTerminals   : 1,
    MotorolaFormat   : 1,

    SwapDigitalByte  : 1, // LB <-> HB wenn wortweise auf digitale Klemmen zugegriffen wird
    WordAlign        : 1,
    InputFreeRun     : 1,
    OutputFreeRun    : 1,

    ReactOnFBusErr   : 2, // LSB's, Reichstein 13.07.00, Config Library (WAGO-IO-PRO)
    ReactOnTBusErr   : 2, // LSB's

    ReactOnFBusErr_  : 1, // MSB
    ReactOnTBusErr_  : 1, // MSB
    AlignOddDataSize : 1,
    dummy_1          : 1,

    CtrlByFiAlterCom : 1, // TRUE: mask and copy control byte and alternate between Reg-Com and PI-Exchange;
    NoDummyBytes     : 1, // TRUE: no additional dummy bytes will be added
    CtrlByFiOnly     : 1, // TRUE: mask and copy control byte; FALSE: just copy byte
    DigTermOnByAddr  : 1, // TRUE: digital terminals will be mapped to byte addresses

    TCM_Active       : 1; // TRUE: addressed terminal runs in specific control mode
} PROCESS_IMAGE_DESC;

#endif
