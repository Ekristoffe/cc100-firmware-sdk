//------------------------------------------------------------------------------
// Copyright (c) 2013-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     scpu-gpio.h
///
///  \brief    Slave CPU GPIO submodule interface
///
///  This module capsulates the GPIO access to the slave cpu.
///
///  \attention This is a submodule used by the SCPU module. It is not expected
///             that any other module uses it.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef SCPU_GPIO_H
#define SCPU_GPIO_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <poll.h>
#include <pthread.h>
#include <signal.h>
//------------------------------------------------------------------------------
// Documentation
//------------------------------------------------------------------------------
/// \defgroup GPIO GPIO Documentation
/// The GPIO module capsulates the underlying GPIO mechanism to perform certain
/// functions expected on all platforms.


/// \defgroup GPIO-API GPIO API description
/// @{

/// GPIO pins supported by the scpu_gpio module.
/// \attention This enumeration is part of an associative arrays! Do not change the order of entries carelessly.
typedef enum
{
  GPIO_RESET,
  GPIO_SYNC,
  GPIO_CMDSEL,
  GPIO_READY,
  GPIO_IRQ,
  GPIO_ERROR,
  GPIO_ERROR_BIT_0,
  GPIO_ERROR_BIT_1,
  GPIO_ERROR_BIT_2,
  GPIO_ERROR_BIT_3,
  GPIO_LAST = GPIO_ERROR_BIT_3
} SCPU_gpio_pin_t;


/// States the thread is in or should be in
typedef enum
{
  GPIO_THREAD_PREINIT,    ///< The thread isn't running and isn't initialized
  GPIO_THREAD_STARTED,    ///< The thread is ready and running
  GPIO_THREAD_CLOSING,    ///< The thread is closing (this is actually a request for termination)
  GPIO_THREAD_TERMINATED  ///< The thread is ready to be joined
} SCPU_gpio_thread_state;


/// Descriptor for access to the scpu_gpio module functions.
typedef struct SCPU_gpio_descriptor * SCPU_gpio_descriptor_t;


/// Performs necessary initialization of the gpio submodul.
/// This function has to be called at least once before calling any other scpu_gpio_* functions. It is not recommended to call
/// the function when there is an open connection to the scpu_gpio module. Close it first with ::SCPU_gpio_close(), before
/// calling this function.
void SCPU_gpio_init(void);


/// The function opens a connection to the GPIO submodul and returns a descriptor to use for any other functions (besides init()).
/// \return A descriptor or NULL when an error occurred.
SCPU_gpio_descriptor_t SCPU_gpio_open(void);


/// Sets the GPIO ouput \a pin to an enabled state.
/// \note It depends on the pin what "enabled state" means. This does NOT equal the signal level high.
/// \param[in] sd   A valid descriptor obtained by ::SCPU_gpio_open()
/// \param[in] pin  The pin to set
void SCPU_gpio_enable(SCPU_gpio_descriptor_t sd,
                      SCPU_gpio_pin_t        pin);


/// Sets the GPIO output \a pin to a disabled state.
/// \note It depends on the pin what "disabled state" means. This does NOT equal the signal level low.
/// \param[in] sd   A valid descriptor obtained by ::SCPU_gpio_open()
/// \param[in] pin  The pin to set
void SCPU_gpio_disable(SCPU_gpio_descriptor_t sd,
                       SCPU_gpio_pin_t        pin);


/// Waits for the GPIO input \a pin to get into enabled state.
/// \note It depends on the pin what "enabled state" means. This does NOT equal the signal level high.
/// \param[in] sd   A valid descriptor obtained by ::SCPU_gpio_open()
/// \param[in] pin  The pin to wait for
void SCPU_gpio_wait_enable(SCPU_gpio_descriptor_t sd,
                           SCPU_gpio_pin_t        pin);


/// Waits for the GPIO input \a pin to get into disabled state.
/// \note It depends on the pin what "disabled state" means. This does NOT equal the signal level low.
/// \param[in] sd   A valid descriptor obtained by ::SCPU_gpio_open()
/// \param[in] pin  The pin to wait for
void SCPU_gpio_wait_disable(SCPU_gpio_descriptor_t sd,
                            SCPU_gpio_pin_t        pin);


/// Triggers the GPIO output \a pin, that is enables it for \a delay microseconds and disables it again
/// \note It depends on the pin what "enabled" and "disabled" means. This does NOT equal the signal levels.
/// \param[in] sd   A valid descriptor obtained by ::SCPU_gpio_open()
/// \param[in] pin  The pin to set
/// \param[in] delay The delay in microseconds before disabling the \a pin again
void SCPU_gpio_trigger(SCPU_gpio_descriptor_t sd,
                       SCPU_gpio_pin_t        pin,
                       unsigned int           delay);


/// Returns the current enabled or disabled state of the GPIO.
/// \note The return values do not indicate the signal level.
/// \param[in] sd   A valid descriptor obtained by ::SCPU_gpio_open()
/// \param[in] pin  The pin to poll
/// \retval -1 Error
/// \retval  0 Disabled state
/// \retval  1 Enabled state
int SCPU_gpio_state(SCPU_gpio_descriptor_t sd,
                    SCPU_gpio_pin_t        pin);


/// Closes the connection to the GPIO module and invalidates the descriptor.
/// The descriptor will be NULL after this function and cannot be used further.
/// \param[in,out] sd A pointer to a valid descriptor obtained by ::SCPU_gpio_open()
void SCPU_gpio_close(SCPU_gpio_descriptor_t *sd);

///@}
#endif
