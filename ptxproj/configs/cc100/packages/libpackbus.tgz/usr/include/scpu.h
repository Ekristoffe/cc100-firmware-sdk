//------------------------------------------------------------------------------
///
///  \file     scpu.h
///
///  \brief    Slave CPU Access module.
///
///  This module contains the access to the slave cpu and is the core component
///  for the KBus module to retrieve data from the KBus rail.
///
///  \version  $Revision$
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc  Copyright
///
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// Documentation
//------------------------------------------------------------------------------
/// \defgroup SCPU-API SCPU API description
/// @{
///
/// These functions define the official SCPU API.
/// Neither behavior nor interface should change without prior notice. So even
/// if the implementation inside changes, modules which worked successfully with
/// prior versions will work with later versions, too.
///
/// \section Usage
/// A module that wants to use the SCPU module should call ::SCPU_Init() and then
/// ::SCPU_Open() to retrieve a handle. From there on, the additional functions
/// can be used. When done, the handle should be closed via ::SCPU_Close().
/// Instead of always calling ::SCPU_Init() you can also check the module state with
/// ::SCPU_GetMode() and only call ::SCPU_Init() when the module state is
/// SCPU_MODE_PRE_INIT. Either way is fine.
///

//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#ifndef SCPU_H
#define SCPU_H
#include <stdint.h>
#include "scpu-gpio.h"
#include "scpu-boot.h"
#include "scpu-command.h"
#include "spi.h"
#include <ffi.h>

#define WAIT_BOOT_DURATION_OF_SCPU   (50000)  // 50 000 [ns]
//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
/// \brief Error conditions of the SCPU module
typedef enum SCPU_error
{
  SCPU_ERR_NO_ERROR             = 0,  ///< No error. Function acted as expected or at least, could not detect an error.
  SCPU_ERR_ERROR                = 1,  ///< An error that does not match any other error code occurred.
  SCPU_ERR_INVALID_PARAMETER    = 2,  ///< A parameter passed is not valid, f.e. a NULL pointer where this is not allowed.
  SCPU_ERR_OUT_OF_MEMORY        = 3,  ///< Not enough memory to process the request
  SCPU_ERR_UNSUPPORTED_IN_MODE  = 4,  ///< The function is not possible right now, f.e. a data exchange request while the firmware is downloading.
  SCPU_ERR_UNSUPPORTED_COMMAND  = 5,  ///< The slave CPU does not support the command sent via ::SCPU_Command()
  SCPU_ERR_COMMUNICATION_FAILED = 6,  ///< The communication with the slave cpu itself failed - no reply from slave
  SCPU_ERR_EXECUTION_FAILED     = 7,  ///< The slave received the command, but processing it failed
  SCPU_ERR_LAST                 = 7   ///< Last known error
} SCPU_error_t;

/// \brief Possible modes of the SCPU module.
typedef enum SCPU_mode
{
  SCPU_MODE_PRE_INIT    = 0, ///< Is not yet initialized
  SCPU_MODE_IDLE        = 1, ///< Waiting for D-Bus message for slave firmware
  SCPU_MODE_FW_TRANSFER = 2, ///< Is currently downloading a firmware
  SCPU_MODE_COMMAND     = 3, ///< Is in command mode, transferring commands or waiting for reply
  SCPU_MODE_DATA        = 4, ///< Is in data exchange mode, transferring SSC data
  SCPU_MODE_SHUTDOWN    = 5, ///< Is shutting down communication
  SCPU_MODE_LAST        = 5  ///< Last legal SCPU mode
} SCPU_mode_t;


typedef enum SCPU_event_type
{
  SCPU_EVENT_TYPE_ERROR,    ///< Event type is an error.
  SCPU_EVENT_TYPE_EVENT,    ///< Event type is an event.
  SCPU_EVENT_TYPE_BOTH      ///< Event type is considered as both error and event - this is only used to _set_ desired events. A triggered event is never BOTH.
} SCPU_event_type_t;


/// \brief Error conditions of the slave cpu.
/// As the CPU has 4 GPIOs to signal an error, 16 different error conditions are possible.
/// Basically, this enumeration contains the condition of ErrorStatus when nIRQ = 1, nError = 1
typedef enum SCPU_slave_error
{
  SCPU_SLAVE_ERR_NO_ERROR = 0,
  SCPU_SLAVE_ERR_1        = 1,
  SCPU_SLAVE_ERR_2        = 2,
  SCPU_SLAVE_ERR_3        = 3,
  SCPU_SLAVE_ERR_4        = 4,
  SCPU_SLAVE_ERR_5        = 5,
  SCPU_SLAVE_ERR_6        = 6,
  SCPU_SLAVE_ERR_7        = 7,
  SCPU_SLAVE_ERR_8        = 8,
  SCPU_SLAVE_ERR_9        = 9,
  SCPU_SLAVE_ERR_10       = 10,
  SCPU_SLAVE_ERR_11       = 11,
  SCPU_SLAVE_ERR_12       = 12,
  SCPU_SLAVE_ERR_13       = 13,
  SCPU_SLAVE_ERR_14       = 14,
  SCPU_SLAVE_ERR_15       = 15,
  SCPU_SLAVE_ERR_LAST     = 15,
} SCPU_slave_error_t;


/// \brief  Event conditions of the slave cpu.
/// As the CPU has 4 GPIOs to signal an event, 16 different event conditions are possible
/// Basically, this enumeration contains the condition of ErrorStatus when nIRQ = 1, nError = 0
typedef enum SCPU_event
{
  SCPU_SLAVE_EVENT_0    = 0,
  SCPU_SLAVE_EVENT_1    = 1,
  SCPU_SLAVE_EVENT_2    = 2,
  SCPU_SLAVE_EVENT_3    = 3,
  SCPU_SLAVE_EVENT_4    = 4,
  SCPU_SLAVE_EVENT_5    = 5,
  SCPU_SLAVE_EVENT_6    = 6,
  SCPU_SLAVE_EVENT_7    = 7,
  SCPU_SLAVE_EVENT_8    = 8,
  SCPU_SLAVE_EVENT_9    = 9,
  SCPU_SLAVE_EVENT_10   = 10,
  SCPU_SLAVE_EVENT_11   = 11,
  SCPU_SLAVE_EVENT_12   = 12,
  SCPU_SLAVE_EVENT_13   = 13,
  SCPU_SLAVE_EVENT_14   = 14,
  SCPU_SLAVE_EVENT_15   = 15,
  SCPU_SLAVE_EVENT_LAST = 15,
} SCPU_event_t;


/// \brief Test description for SPI performance
typedef struct SCPU_spi_test_description
{
  unsigned int  lenByte;               ///< Length of SSC in bytes
  unsigned int  cntMux;                ///< Required Mux channels
  unsigned int  cntRepetitions;        ///< How often to repeat the test
} SCPU_spi_test_description_t;
//------------------------------------------------------------------------------
// Upper Layer
//------------------------------------------------------------------------------
/// \brief Context data of the SCPU module
typedef struct SPCU_context
{
  SCPU_mode_t       modstate;             ///< Contains the state of the scpu module
  uint32_t          cnt_connections;      ///< Contains the count of open connections. Only when the count is reaching zero, the GPIO filesystem descriptors are really closed.
  bool              is_recovery_enabled;  ///< Whether the data exchange will try to recover from errors
  pthread_mutex_t   access;               ///< Prevent concurrent access by multiple open connections
  SPI_descriptor_t  spid;                 ///< SPI descriptor used by the module
  bool              bErrReacEva;          ///< error reaction evaluated (watchdog)
} SCPU_context_t;


/// \brief Descriptor data for the SCPU access
/// \attention The contents are not part of the API and subject to change without notice! Do not access the structure
/// contents in your code, not even read them.
typedef struct SCPU_descriptor
{
  SCPU_context_t      *ctx;             ///< Reference to the module context data
} *SCPU_descriptor_t;

/// \name Functions - API - Core
///@{

/// \brief Inits the scpu module.
/// \param[in] skip_boot If TRUE, slave cpu will not be booted
SCPU_error_t       SCPU_Init(bool skip_boot);

/// \brief Open a connection to the scpu module.
/// This function returns a descriptor on success or NULL when an error occurred.
SCPU_descriptor_t  SCPU_Open(void);

/// \brief Evaluates error reaction for dal-watchdog
/// Function sends zero initialized process data to SCPU, waits 'time4wait' [us], sends again
/// zero initialized process data to SCPU and locks transmission.
/// \param[in]  sd   The scpu descriptor received via ::SCPU_Open().
/// \param[in]  time4wait wait time between first and second/last transmission
SCPU_error_t  SCPU_EvaluateWatchdogErrorReaction(SCPU_descriptor_t sd, __useconds_t time4wait);


/// \brief Download firmware data into slave cpu RAM.
/// This function sends the firmware data to the slave cpu. The function returns when the data was sent and the
/// slave cpu either acknowledged the proper startup, an error or a timeout occurred.
/// \param[in] sd   The scpu descriptor received via ::SCPU_Open().
/// \param[in] buf  Pointer to the data to download
/// \param[in] len  The length of data to download
SCPU_error_t       SCPU_Download(SCPU_descriptor_t sd,
                                 uint8_t           *buf,
                                 unsigned int      len);

/// \brief Send a command to the slave cpu.
/// This function sends a command to the slave cpu to process it. A command is an API function that is not
/// required to be supported and can fail with SCPU_ERR_UNSUPPORTED_COMMAND and this failure should not affect the
/// system.
/// The SCPU module continues as if the command did work in this case. In other words, all these commands are
/// transferred "as-is" to the slave cpu and it's up to its implementation, what to do with it.
///
/// \param[in] sd   		The scpu descriptor received via ::SCPU_Open().
/// \param[in] cmd  		The command to send
/// \param[in] data 		Additional data for the command to send
/// \param[in] datalen  	Length of additional data
/// \param[in] replybuf 	Buffer for a reply (can be NULL if no reply data is expected)
/// \param[in] replybuflen	Length of reply buffer
SCPU_error_t       SCPU_Command(SCPU_descriptor_t sd,
                                SCPU_command_t    cmd,
                                const void        *data,
                                unsigned int      datalen,
				void 		  *replybuf,
				unsigned int 	  replybuflen
 			      );

/// \brief Perform a data exchange cycle.
/// Sends the SSC buffer data to the slave cpu and receives the SSC buffer.
/// \param[in]  sd   The scpu descriptor received via ::SCPU_Open().
SCPU_error_t       SCPU_DataExchange(SCPU_descriptor_t sd);

/// \brief Aborts a data exchange cycle.
/// Default, the SCPU_DataExchange module will try to perform a data exchange
/// forever, as long as it fails. ::SCPU_Abort will abort this failure recovery
/// for ongoing and future data exchanges.
SCPU_error_t       SCPU_Abort(void);

/// \brief Reset the slave cpu.
/// Performs a reset of the slave cpu.
/// \param[in] sd   The scpu descriptor received via ::SCPU_Open().
SCPU_error_t       SCPU_Reset(SCPU_descriptor_t sd);

/// \brief Closes the scpu descriptor.
/// This function ends the communication gracefully between host and slave cpu.
/// \param[in] sd   The scpu descriptor received via ::SCPU_Open().
SCPU_error_t       SCPU_Close(SCPU_descriptor_t sd);

/// \brief Returns the current error status of the slave cpu.
/// \param[in]  sd  The scpu descriptor received via ::SCPU_Open().
/// \param[out] err Buffer where to write the error value to, NULL is allowed if
///                 only the basic information, if there is an error, is required.
/// \retval SCPU_ERR_INVALID_PARAMETER Descriptor not valid
/// \retval SCPU_ERR_NO_ERROR  Slave cpu reports no error, \a err is untouched.
/// \retval SCPU_ERR_ERROR     Slave cpu did report an error, \a err contains the error value.
///                            This error code does not indicate that the function itself failed!
SCPU_error_t       SCPU_GetErrorStatus(SCPU_descriptor_t  sd,
                                       SCPU_slave_error_t *err);

/// \brief Returns the current mode the slave cpu module is in.
/// \note This does not mean that the slave cpu is in this mode.
SCPU_mode_t        SCPU_GetMode(void);
///@}

/// \name Functions - API - Asynchronous communication mechanism
/// The SCPU module provides basic callback functions to inform everyone who cares about events or errors from the
/// slave cpu.
///@{

/// \brief Handler for events and errors (function pointer).
typedef void (*fpSCPU_Handler)(SCPU_event_type_t, unsigned int);


/// \brief Adds an error handler to the SCPU module.
/// The handler is called when an error or event or both is received from the slave cpu, depending on the \a event_type
/// parameter.
SCPU_error_t       SCPU_AddHandler(SCPU_event_type_t event_type,
                                   fpSCPU_Handler    fpHandler);

/// \brief Removes a handler from the SCPU module.
/// The handler is removed from the SCPU module and no further error is reported.
/// Removing a handler that wasn't set in the first place is no error.
SCPU_error_t       SCPU_RemoveHandler(SCPU_event_type_t event_type,
                                      fpSCPU_Handler    fpHandler);

/// \brief Adds an error handler to the SCPU module.
/// The handler is called whenever an error is received from the slave cpu and the slave cpu error is passed
/// as parameter.
/// \attention The code in each error handler modifies the timing behavior in the SCPU module. It is the responsibility
/// of the error handler programmer to make sure that the handler does not degrade system performance.
/// \param[in] fpErrorHandler The callback function to set.
SCPU_error_t       SCPU_AddErrorHandler(fpSCPU_Handler fpErrorHandler);

/// \brief Removes an error handler from the SCPU module.
/// The handler is removed from the SCPU module and no further error is reported.
/// Removing a handler that wasn't set in the first place is no error.
/// \param[in] fpErrorHandler The callback function to remove.
SCPU_error_t       SCPU_RemoveErrorHandler(fpSCPU_Handler fpErrorHandler);

/// \brief Adds an event handler to the SCPU module.
/// The handler is called whenever an event is received from the slave cpu and the slave cpu event is passed
/// as parameter.
/// \attention The code in each event handler modifies the timing behavior in the SCPU module. It is the responsibility
/// of the event handler programmer to make sure that the handler does not degrade system performance.
/// \param[in] fpEventHandler The callback function to set.
SCPU_error_t       SCPU_AddEventHandler(fpSCPU_Handler fpEventHandler);

/// The handler is removed from the SCPU module and no further event is reported.
/// Removing a handler that wasn't set in the first place is no error.
/// \param[in] fpEventHandler The callback function to remove.
SCPU_error_t       SCPU_RemoveEventHandler(fpSCPU_Handler fpEventHandler);
///@}

///@}
//------------------------------------------------------------------------------
// Lower Layer
//------------------------------------------------------------------------------
#endif
//---- End of source file ------------------------------------------------------
