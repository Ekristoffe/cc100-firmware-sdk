//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     bacnet_config_api.h
///
///  \brief    Header for interface functions to read (get) and write (set)
///            BACnet configuration
///
///  \author   NiB : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef WAGO_INTERN_DEVICE_BACNET_BACNETCONFIG_SOURCE_BACNET_CONFIG_API_H_
#define WAGO_INTERN_DEVICE_BACNET_BACNETCONFIG_SOURCE_BACNET_CONFIG_API_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>
#include <glib-2.0/glib.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
//BACnetSC defines for path and files
#define BACNET_SC_CERT_DEFAULT_PATH       "/home/user/bacnet/cert/"
#define BACNET_SC_CERT_TMP_PATH           "/etc/bacnet/ca_def/"
#define BACNET_SC_CA_CERT_FILE_NAME       "bacSC_CA.crt"

#define BACNET_SC_FIRST_ISSUER_CERT_FILE_NAME  "bacSC_First_Issuer.crt"
#define BACNET_SC_SECOND_ISSUER_CERT_FILE_NAME "bacSC_Second_Issuer.crt"

#define BACNET_SC_CA_PKEY_FILE_NAME       "bacSC_CA_PKey.pem"
#define BACNET_SC_DEVICE_CERT_FILE_NAME   "bacSC_Device.crt"
#define BACNET_SC_PKEY_FILE_NAME          "bacSC_PKey.pem"
#define BACNET_SC_CSR_FILE_NAME           "bacSC_x509Req.csr"
#define BACNET_SC_CSR_OPTION_FILE_NAME    "csroption.ini"
#define BACNET_SC_REVOKE_LIST_FILE_NAME   "bacSC_revokelist.crl"

#define BACNET_SC_CA_CERT_FILE_PATH       BACNET_SC_CERT_DEFAULT_PATH  BACNET_SC_CA_CERT_FILE_NAME
#define BACNET_SC_CA_CERT_FILE_PATH_TMP   BACNET_SC_CERT_TMP_PATH      BACNET_SC_CA_CERT_FILE_NAME

#define BACNET_SC_FIRST_ISSUER_CERT_FILE_PATH  BACNET_SC_CERT_DEFAULT_PATH  BACNET_SC_FIRST_ISSUER_CERT_FILE_NAME
#define BACNET_SC_SECOND_ISSUER_CERT_FILE_PATH BACNET_SC_CERT_DEFAULT_PATH  BACNET_SC_SECOND_ISSUER_CERT_FILE_NAME


#define BACNET_SC_CA_PKEY_FILE_PATH       BACNET_SC_CERT_DEFAULT_PATH  BACNET_SC_CA_PKEY_FILE_NAME
#define BACNET_SC_CA_PKEY_FILE_PATH_TMP   BACNET_SC_CERT_TMP_PATH      BACNET_SC_CA_PKEY_FILE_NAME

#define BACNET_SC_DEVICE_CERT_FILE_PATH   BACNET_SC_CERT_DEFAULT_PATH BACNET_SC_DEVICE_CERT_FILE_NAME
#define BACNET_SC_PKEY_FILE_PATH          BACNET_SC_CERT_DEFAULT_PATH BACNET_SC_PKEY_FILE_NAME

#define BACNET_SC_CSR_FILE_PATH           BACNET_SC_CERT_DEFAULT_PATH BACNET_SC_CSR_FILE_NAME
#define BACNET_SC_CSR_OPTION_FILE_PATH    BACNET_SC_CERT_DEFAULT_PATH BACNET_SC_CSR_OPTION_FILE_NAME

#define BACNET_SC_REVOKE_LIST_FILE_PATH   BACNET_SC_CERT_DEFAULT_PATH BACNET_SC_REVOKE_LIST_FILE_NAME


#define WR_MAP_QUEUE_SIZE_MIN    (3000)
#define WR_MAP_QUEUE_SIZE_MAX   (10000)

#define BAC_CONFIG_STR_SIZE (512)

#define MAX_SIZE_STRING_DL_INI_FILE 128 //max. number of characters

// static config definitions
#define BAC_CONFIG_STORAGE_VALUE_FLASH   "internal-flash"
#define BAC_CONFIG_STORAGE_VALUE_CARD    "sd-card"
#define BAC_CONFIG_DATA_LINK_IP          "ip"
#define BAC_CONFIG_DATA_LINK_SC          "sc"
#define BAC_CONFIG_DATA_LINK_ROUTING     "routing"
#define BAC_CONFIG_DATA_TRACE_SOURCE     "0x00FF"
#define BAC_CONFIG_DATA_TRACE_SEVERITY   "0x0005"
#define BAC_CONFIG_DATA_TRACE_ENABLE     1
#define BAC_CONFIG_COV_CHECK_ENABLE      1
#define BAC_CONFIG_OVERRIDE_DESC         "override.xml"
#define BAC_BIND_TO_ANY                  0
#define BAC_CONFIG_BCAST_IAM             0
#define BAC_CONFIG_DL_SC_MODE_REGULAR_NODE      "regular"
#define BAC_CONFIG_DL_SC_MODE_PRIMARY_HUB       "primary"
#define BAC_CONFIG_DL_SC_MODE_FAILOVER_HUB      "failover"

// public defaults
#define DEFAULT_STATUS_INFO  "stopped"
#define DEFAULT_STORAGE      BAC_CONFIG_STORAGE_VALUE_FLASH
#define DEFAULT_PORT         47808
#define DEFAULT_TCP_PORT_SC  "47808"
#define DEFAULT_UDP_PORT_IP  "47808"
#define DEFAULT_BACNET_MODE  BAC_CONFIG_DATA_LINK_IP
#define DEFAULT_SC_MODE      BAC_CONFIG_DL_SC_MODE_REGULAR_NODE

// other
#define BACNET_SC_URI_PREFIX  "wss://"

#define KEY_CNT_DATA_LINK                   "cnt_data_link"
//#define KEY_PORTID                          "port_id"
#define KEY_TYPE                            "type"
#define KEY_MAX_MSG_REQ                     "max_msg_req"
#define KEY_NET_NUMBER                      "net_number"
#define KEY_LAN_NAME                        "lan_name"
#define KEY_TCP_PORT_SC                     "tcp_port_sc"
#define KEY_UDP_PORT_IP                     "udp_port_ip"
#define KEY_MODE                            "mode"
#define KEY_VIRTUAL_MAC_ADDRESS             "virtual_mac_address"
#define KEY_HUB_URI                         "hub_uri"
#define KEY_FAILOVER_HUB_URI                "failover_hub_uri"
#define KEY_ACCEPTS_CONNETIONS              "accepts_connections"
#define KEY_INITIATES_CONNECTIONS           "initiates_connections"
#define KEY_KEEP_ALIVE_INTERVAL             "keep_alive_interval"
#define KEY_KEEP_ALIVE_TIMEOUT              "keep_alive_timeout"
#define KEY_CONNECT_TIMEOUT                 "connect_timeout"
#define KEY_DISCONNECT_TIMEOUT              "disconnect_timeout"
#define KEY_RECONNECT_DELAY                 "reconnect_delay"
#define KEY_RECONNECT_RETRIES               "reconnect_retries"
#define KEY_ACTIVATE_WS_PING_PONG           "activate_ws_ping_pong"
#define KEY_ALLOW_SELF_SIGNED_CERTS         "allow_self_signed_certs"
#define KEY_ALLOW_NON_STRICT_HOSTNAME_CERTS "allow_non_strict_hostname_certs"
#define KEY_ALLOW_EXPIRED_CERTS             "allow_expired_certs"
#define KEY_UNSECURED_CONNECTIONS           "allow_unsecured_connections"
#define KEY_CLIENT_SERVER_TLS_V11           "allow_client_server_tls_v1_1"
#define KEY_CLIENT_SERVER_TLS_V12           "allow_client_server_tls_v1_2"
#define KEY_ACCEPT_ANY_SERVER_CERT          "accept_any_server_cert"
#define KEY_ACCEPT_ANY_CLIENT_CERT          "accept_any_client_cert"
#define KEY_SERVER_CHECKS_CLIENT_CERTS      "server_checks_client_certs"
#define KEY_SEC_LOG_FILE_PATH               "pre_shared_secret_log_file"
#define KEY_KEEP_ALIVE_RETRIES              "keep_alive_retries"

typedef enum tagBAC_CONFIG_DL_TYPE
{
  BAC_CONFIG_DL_IP = 1,
  BAC_CONFIG_DL_WSSC = 2,
}BAC_CONFIG_DL_TYPE;
#define DEFAULT_NUM_OF_SC_NODES 0

typedef enum tagBAC_CONFIG_STATUS{
  BAC_CONFIG_STATUS_OK,
  BAC_CONFIG_STATUS_NO_FILE,
  BAC_CONFIG_STATUS_ERROR_FILE,
  BAC_CONFIG_STATUS_UNKNOWN_PARAMETER_ID,
  BAC_CONFIG_STATUS_UNKNOWN_CB_TYPE,
  BAC_CONFIG_STATUS_INVALID_VALUE,
  BAC_CONFIG_STATUS_INVALID_DATA_TYPE,
  BAC_CONFIG_STATUS_DIFFERENT_DATA_TYPE,
  BAC_CONFIG_STATUS_ERROR,
  BAC_CONFIG_STATUS_EQUAL,
  BAC_CONFIG_STATUS_UNEQUAL,
  BAC_CONFIG_STATUS_OUT_OF_MEMORY
}BAC_CONFIG_STATUS;

typedef enum tagBAC_CONFIG_PARAMETER_ID{
  BAC_CONFIG_PARAM_DEVICE_ID,
  BAC_CONFIG_PARAM_CURRENT_STATE,
  BAC_CONFIG_PARAM_STATUS_INFO,
  BAC_CONFIG_PARAM_LICENSE_NAME,
  BAC_CONFIG_PARAM_LICENSE_INFO,
  BAC_CONFIG_PARAM_VERSION,
  BAC_CONFIG_PARAM_CONFIG_STATE,
  BAC_CONFIG_PARAM_WHO_IS_ONLINE_INTERVAL,
  BAC_CONFIG_PARAM_PERSISTENCE_INTERVAL,
  BAC_CONFIG_PARAM_PERSISTENCE_LOG_INTERVAL,
  BAC_CONFIG_PARAM_PERSISTENCE_STORAGE,
  BAC_CONFIG_PARAM_TRENDLOG_STORAGE,
  BAC_CONFIG_PARAM_EVENTLOG_STORAGE,
  BAC_CONFIG_PARAM_PERSISTENCE_DELETE,
  BAC_CONFIG_PARAM_WR_MAP_QUEUE_SIZE,
  BAC_CONFIG_PARAM_COV_SUBSC_PER_OBJECT,
  BAC_CONFIG_PARAM_DELETE_ALL,
  BAC_CONFIG_PARAM_MODE_CONFIG,
  BAC_CONFIG_PARAM_TRACE_ENABLE,
  BAC_CONFIG_PARAM_TRACE_SOURCE,
  BAC_CONFIG_PARAM_TRACE_SEVERITY,
  BAC_CONFIG_PARAM_COV_CHECK_REMOTE_ENTRY,
  BAC_CONFIG_PARAM_OVERRIDE_DESCRIPTION,
  BAC_CONFIG_PARAM_BIND_TO_ANY_ADDRESS,
  BAC_CONFIG_PARAM_CONNECTION_INFO,
  BAC_CONFIG_PARAM_MODE_INFO,
  BAC_CONFIG_PARAM_BCAST_IAM,
  BAC_CONFIG_PARAM_CA_FILE_DESCRIPTION,
  BAC_CONFIG_PARAM_CERT_FILE_DESCRIPTION,
  BAC_CONFIG_PARAM_CERT_LOAD_DEFAULT,
  BAC_CONFIG_PARAM_END
}BAC_CONFIG_PARAMETER_ID;

typedef enum tagBAC_CONFIG_DATA_TYPE{
  BAC_CONFIG_DATA_TYPE_UNKNOWN,
  BAC_CONFIG_DATA_TYPE_STRING,
  BAC_CONFIG_DATA_TYPE_PATH_STRING,
  BAC_CONFIG_DATA_TYPE_BOOL,
  BAC_CONFIG_DATA_TYPE_BOOL_LIST,
  BAC_CONFIG_DATA_TYPE_INT
}BAC_CONFIG_DATA_TYPE;

typedef enum tagBAC_CONFIG_STORAGE_OPTION{
  BAC_CONFIG_STORAGE_OPTION_ONLY_INTERNAL,
  BAC_CONFIG_STORAGE_OPTION_ALL,
  BAC_CONFIG_STORAGE_OPTION_ERROR
}BAC_CONFIG_STORAGE_OPTION;

typedef enum tagBAC_CONFIG_ACCESS{
  BAC_CONFIG_ACCESS_READ_ONLY,
  BAC_CONFIG_ACCESS_READ_WRITE
}BAC_CONFIG_ACCESS;

typedef enum tagBAC_CONFIG_DRM_LIC_TYPE{
  BAC_CONFIG_DRM_LIC_FULL,
  BAC_CONFIG_DRM_LIC_M,
  BAC_CONFIG_DRM_LIC_M_EXPIRED,
  BAC_CONFIG_DRM_LIC_S,
  BAC_CONFIG_DRM_LIC_S_EXPIRED,
  BAC_CONFIG_DRM_LIC_PLUS,
  BAC_CONFIG_DRM_LIC_EVAL,
  BAC_CONFIG_DRM_LIC_NO
}BAC_CONFIG_DRM_LIC_TYPE;


typedef struct {
    BAC_CONFIG_PARAMETER_ID paramId;
    BAC_CONFIG_DATA_TYPE dataType;
    void *pValue;
}BAC_CONFIG_PARAMETER_VALUE;

typedef struct{
    BAC_CONFIG_PARAMETER_VALUE paramVal;
    const char *pName;
    const char *pGroup;
    BAC_CONFIG_ACCESS paramAccess;
    const char *pComment;
}BAC_CONFIG_PARAMETER_CONTENTS;

typedef struct{
    const unsigned int listSize;
    BAC_CONFIG_PARAMETER_CONTENTS *paramContents;
}BAC_CONFIG_PARAMETER_LIST;


// when adding entries here, check libbacnetstack/source/bacnet_app/app/app_deviceobj.c in GetBackupRestoreTimesByOrder
typedef enum
{
  DEVICE_PFC100G2,
  DEVICE_PFC200G2,
  DEVICE_PFC300,
  DEVICE_CC100,
  DEVICE_CC100V2,
  DEVICE_TP600
} BAC_CONFIG_DEVICE_TYPE;

typedef struct
{
    uint16_t usDRMLicense;
    uint8_t  licType;
    uint16_t licCode;
    uint8_t  licPerfClass;
    uint16_t licObjLimit;
    BAC_CONFIG_DRM_LIC_TYPE eLicType;
}BAC_CONFIG_DRM_LICENSE_FORMAT;

/// ToDo deprecated replaced by BAC_CONFIG_DRM_LICENSE_FORMAT
typedef struct{
    uint8_t  type;
    uint16_t code;
    uint16_t performanceClass;
    BAC_CONFIG_DRM_LICENSE_FORMAT *pPossibleDRMLic;
}BAC_CONFIG_LICENSE_ID;
/// ToDo deprecated

typedef struct
{
   //unsigned int portId;
   char type[MAX_SIZE_STRING_DL_INI_FILE];
   unsigned int maxMsgReq;
   unsigned int netNumber;
   char lanName[MAX_SIZE_STRING_DL_INI_FILE];
   unsigned int tcpPortSc;
   unsigned int udpPortIp;
   char mode[MAX_SIZE_STRING_DL_INI_FILE];
   char virtualMacAddress[MAX_SIZE_STRING_DL_INI_FILE];
   char hubUri[MAX_SIZE_STRING_DL_INI_FILE];
   char failoverHubUri[MAX_SIZE_STRING_DL_INI_FILE];
   char keyLogFilePath[MAX_SIZE_STRING_DL_INI_FILE];
   bool acceptsConnections;
   bool initiatesConnections;
   unsigned int keepAliveInterval;
   unsigned int keepAliveTimeout;
   unsigned int keepAliveRetries;
   unsigned int connectTimeout;
   unsigned int disconnectTimeout;
   unsigned int reconnectDelay;
   unsigned int reconnectRetries;
   bool activateWSPingPong;
   bool allowSelfSignedCerts;
   bool allowNonStrictHostnameCerts;
   bool allowExpiredCerts;
   bool allowUnsecuredConnections;
   bool allowClientServerTLSv11;
   bool allowClientServerTLSv12;
   bool acceptAnyServerCert;
   bool acceptAnyClientCert;
   bool serverChecksClientCerts;
}BAC_CONFIG_DL;

#define SHARED_MEM_DATA_SIZE (2048u)
#define BAC_CONFIG_DL_PERMISSION (0666u)
#define BAC_CONFIG_DL_SHM_NAME "shmBACnetSC"
#define BAC_CONFIG_DL_SEM_NAME "semBACnetSC"

typedef struct
{
    uint32_t cmdfromExternal;
    uint32_t cmdtoExternal;
    uint32_t cmdData1;
    uint32_t cmdData2;
    uint32_t usedSize;
    bool flagDoAction;
}BAC_CONFIG_DL_COMHEADER;

typedef struct
{
   pthread_cond_t  condition;
   pthread_mutex_t mutex;
} BAC_CONFIG_DL_CONDITIONSHARED;

typedef struct
{
    BAC_CONFIG_DL_COMHEADER comHeader;
    BAC_CONFIG_DL_CONDITIONSHARED hCondToBACnetStack;
    BAC_CONFIG_DL_CONDITIONSHARED hCondFromBACnetStack;
    uint8_t data[SHARED_MEM_DATA_SIZE];
}BAC_CONFIG_DL_SHARED_MEM;


#define READ_CMD_OK  (0x80u)
#define READ_CMD_ERR (0xA0u)

typedef enum
{
  READ_WSSC_INFO_DATA = 0x01,
  READ_WSSC_STATISTICS = 0x02,
  READ_IP_STATISTICS = 0x03,
  READ_WSSC_INFO_DATA_FINISHED =  (READ_CMD_OK + READ_WSSC_INFO_DATA),
  READ_WSSC_STATISTICS_FINISHED = (READ_CMD_OK + READ_WSSC_STATISTICS),
  READ_IP_STATISTICS_FINISHED =   (READ_CMD_OK + READ_IP_STATISTICS),
  READ_WSSC_INFO_DATA_FINISHED_ERR =  (READ_CMD_ERR + READ_WSSC_INFO_DATA),
  READ_WSSC_STATISTICS_FINISHED_ERR = (READ_CMD_ERR + READ_WSSC_STATISTICS),
  READ_IP_STATISTICS_FINISHED_ERR =   (READ_CMD_ERR + READ_IP_STATISTICS),
}BAC_CONFIG_DL_SHAREDMEM_CMDS;



typedef struct
{
  char const *pKeyName;
  void *pValue;
  BAC_CONFIG_DATA_TYPE dataType;
}BAC_CONFIG_DL_KEY_VALUE;

#define NOF_CSR_SUBJECT_OPTIONS (7u)

typedef struct {
  char countryC[3];
  char stateST[65];
  char localityL[129];
  char organizationNameO[65];
  char organizationUnitOU[65];
  char commonNameCN[65];
  char emailAddressEA[65];
}BAC_CONFIG_CSR_OPTIONS;

typedef struct
{
  char const *pKeyValue;
  char const *pKeyX509;
}BAC_CONFIG_SIMPLE_CSR_OPTION_STRUCT;

typedef struct
{
  char *pKeyValue;
  char const *pKeyName;
  char const *pKeyX509;
  int valueLen;
  int X509Index;
}BAC_CONFIG_CSR_KEY_VALUE;

typedef struct {
  bool configState;
  int whoIsOnlineInterval;
  int wrMapQueueSize;
  int covSubsPerObject;
  char persStorage[BAC_CONFIG_STR_SIZE];
  char persTlogStorage[BAC_CONFIG_STR_SIZE];
  char persElogStorage[BAC_CONFIG_STR_SIZE];
  bool persDelete;
  bool deleteAll;
  int persInterval;
  int persLogInterval;
  char mode[BAC_CONFIG_STR_SIZE];
  bool traceEnable;
  char traceSource[BAC_CONFIG_STR_SIZE];
  char traceSeverity[BAC_CONFIG_STR_SIZE];
  bool covCheckRemoteEntry;
  char overrideDesc[BAC_CONFIG_STR_SIZE];
  bool bindToAnyAddress;
  bool broadcastIAm;
  char caFileDesc[BAC_CONFIG_STR_SIZE];
  char certFileDesc[BAC_CONFIG_STR_SIZE];
  bool certDelete;
} BAC_CONFIG_INI;

typedef struct {
  int deviceId;
  bool currentState;
  char statusInfo[BAC_CONFIG_STR_SIZE];
  char licenseName[BAC_CONFIG_STR_SIZE];
  char licenseInfo[BAC_CONFIG_STR_SIZE];
  char version[BAC_CONFIG_STR_SIZE];
  char uriInfo[BAC_CONFIG_STR_SIZE];
  char modeInfo[BAC_CONFIG_STR_SIZE];
} BAC_CONFIG_IPC;

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

  //----------------------------------------------------------------------------
  // helper functions
  //----------------------------------------------------------------------------
  BAC_CONFIG_PARAMETER_LIST *bac_CONFIG_getParameterList(void) __attribute__((const));
  BAC_CONFIG_PARAMETER_ID bac_CONFIG_getParameterIdByIndex(int unsigned indexVal) __attribute__((pure));
  BAC_CONFIG_DATA_TYPE bac_CONFIG_getDataTypeByIndex(unsigned int indexVal) __attribute__((pure));

  const char* bac_CONFIG_getPathFileName(void) __attribute__((const));
  const char *bac_CONFIG_getNameByIndex(unsigned int indexVal) __attribute__((pure));

  int bac_CONFIG_getIndexbyParameterId(BAC_CONFIG_PARAMETER_ID paramId) __attribute__((pure));
  int bac_CONFIG_getIndexByName(const char *pName) __attribute__((pure));

  unsigned int bac_CONFIG_getParameterCount(void) __attribute__((const));

  BAC_CONFIG_STORAGE_OPTION bac_CONFIG_getStorageOption(void);
  BAC_CONFIG_ACCESS bac_CONFIG_getAccessByIndex(unsigned int indexVal) __attribute__((pure));

  BAC_CONFIG_STATUS bac_CONFIG_compareParamterValue(BAC_CONFIG_PARAMETER_VALUE *pVal1,
                                                    BAC_CONFIG_PARAMETER_VALUE *pVal2) __attribute__((pure));

  BAC_CONFIG_STATUS bac_CONFIG_getDeviceType(const char * orderNumber, BAC_CONFIG_DEVICE_TYPE * deviceType);
  BAC_CONFIG_STATUS bac_CONFIG_getBACnetLicenceID(BAC_CONFIG_DRM_LICENSE_FORMAT **pLicenseID);
  BAC_CONFIG_STATUS bac_CONFIG_getBACnetHubLicenceID(BAC_CONFIG_DRM_LICENSE_FORMAT **pLicenseID);

  BAC_CONFIG_STATUS bac_CONFIG_setInt(int value, BAC_CONFIG_PARAMETER_ID id);
  BAC_CONFIG_STATUS bac_CONFIG_setBool(bool value, BAC_CONFIG_PARAMETER_ID id);
  BAC_CONFIG_STATUS bac_CONFIG_setString(const char *pValue, BAC_CONFIG_PARAMETER_ID id);

  //----------------------------------------------------------------------------
  // backup and restore
  //----------------------------------------------------------------------------
  BAC_CONFIG_STATUS bac_CONFIG_backupParameter(const char *pPathFileName);
  BAC_CONFIG_STATUS bac_CONFIG_restoreParameter(const char *pPathFileName);

  //----------------------------------------------------------------------------
  // main functions
  //----------------------------------------------------------------------------
  BAC_CONFIG_STATUS bac_CONFIG_getParameterValue(BAC_CONFIG_PARAMETER_VALUE *pParamValue);
  void bac_CONFIG_freeParameterValue(BAC_CONFIG_PARAMETER_VALUE *pParamValue);
  BAC_CONFIG_STATUS bac_CONFIG_setParameterValue(BAC_CONFIG_PARAMETER_VALUE *pParamValue);

  BAC_CONFIG_STATUS bac_CONFIG_getAllParamValues(BAC_CONFIG_PARAMETER_VALUE *pParamValList);
  void bac_CONFIG_freeAllParameterValues(BAC_CONFIG_PARAMETER_VALUE *pParamValList);




  //----------------------------------------------------------------------------
  // wbm functions
  //----------------------------------------------------------------------------
  void BAC_CONFIG_Deinit(void);
  void BAC_CONFIG_Init(void);

  //----------------------------------------------------------------------------
  // parameter provider functions
  //----------------------------------------------------------------------------
  bool bac_PP_OpenKeyFile(GKeyFile ** gKeyFile);
  bool bac_PP_GetKeyValue(GKeyFile * gKeyFile,
                          BAC_CONFIG_PARAMETER_VALUE * pParamValue);
  bool bac_PP_SetKeyValue(GKeyFile * gKeyFile,
                          BAC_CONFIG_PARAMETER_VALUE * pParamValue);
  bool bac_PP_SaveKeyFile(GKeyFile * gKeyFile);
  void bac_PP_CloseKeyFile(GKeyFile * gKeyFile);

  //----------------------------------------------------------------------------
  // BACnetSC CSR Interface
  //----------------------------------------------------------------------------
  BAC_CONFIG_STATUS bac_CONFIG_CreateCSROptionFile(void);

  BAC_CONFIG_STATUS bac_CONFIG_Genx509CSR(BAC_CONFIG_CSR_OPTIONS *pMergeCSROptions,
                                          bool bSaveOptToIniFile,
                                          bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_Genx509CSRBaseIniFile(bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_GetCSRSubjectDefaultValues(BAC_CONFIG_SIMPLE_CSR_OPTION_STRUCT *pCsrKeyValue,
                                                          int nofElements);


  BAC_CONFIG_CSR_OPTIONS * bac_CONFIG_GetCsrOptionStruct(void);

  unsigned int bac_CONFIG_GetCsrKeyValueArray(BAC_CONFIG_CSR_KEY_VALUE **pCsrKeyValue,
                                              bool readOptionFile);

  //----------------------------------------------------------------------------
  // BACnetSC Data Link Interface
  //----------------------------------------------------------------------------
  BAC_CONFIG_STATUS bac_CONFIG_CreateDefaultFileForlinkConfig(bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_ReadDatalinkConfig(BAC_CONFIG_DL *pDLData,
                                                  BAC_CONFIG_DL_TYPE typeDataLink,
                                                  bool bSwitchDebugPrintOn);

  unsigned int bac_CONFIG_GetDatalinkKeyValueArray(BAC_CONFIG_DL_TYPE typeDataLink,
                                                   BAC_CONFIG_DL_KEY_VALUE **pDLKeyValue);

  BAC_CONFIG_STATUS bac_CONFIG_WriteDatalinkConfig(BAC_CONFIG_DL *pDLData,
                                                   BAC_CONFIG_DL_TYPE typeDataLink,
                                                   bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_WriteKeyToDatalinkConfig(BAC_CONFIG_DL_KEY_VALUE *pDLData,
                                                        unsigned int nofNewKeyValues,
                                                        BAC_CONFIG_DL_TYPE typeDataLink,
                                                        bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_ReadKeyFromDatalinkConfig(BAC_CONFIG_DL_KEY_VALUE *pDLData,
                                                         unsigned int nofNewKeyValues,
                                                         BAC_CONFIG_DL_TYPE typeDataLink,
                                                         unsigned int maxStrLen,
                                                         bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_CheckForValidKeyDatalinkConfig(const char *pKey,
                                                              BAC_CONFIG_DL_TYPE typeDatalink,
                                                              BAC_CONFIG_DATA_TYPE *pDataType);


  BAC_CONFIG_STATUS bac_CONFIG_ReadDataFromSharedMem(const char *pFilename,
                                                     bool bSwitchDebugPrintOn);

  BAC_CONFIG_STATUS bac_CONFIG_ReadConInfoDataFromSharedMem(const char *pFilename,
                                                            const BAC_CONFIG_DL_TYPE typeDatalink,
                                                            bool bSwitchDebugPrintOn);


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function implementation
//------------------------------------------------------------------------------


#endif /* WAGO_INTERN_DEVICE_BACNET_BACNETCONFIG_SOURCE_BACNET_CONFIG_API_H_ */
//---- End of source file ------------------------------------------------------
