 /**
 * <interfacename>WagoSysCurl_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSCURL_INTERNAL_PFCITF_H_
#define _WAGOSYSCURL_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>fbcurl__main</description>
 */
typedef struct tagfbcurl_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of FbCurl */

	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Successful completion of the action. */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Action is still in progress. */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	/* Indicates an error. */
	RTS_IEC_UINT eErrorCode;			/* VAR_OUTPUT, Enum: ECURLCODE */
	RTS_IEC_STRING sErrorSource[256];	/* VAR_OUTPUT */	/* Source of an error. */
	RTS_IEC_STRING sErrorString[256];	/* VAR_OUTPUT */	/* Error string that describes the error */
	RTS_IEC_UDINT udiProgressNBytes;	/* VAR_OUTPUT */	/* Number of Bytes to transfer */
	RTS_IEC_UDINT udiProgressNBytesTransferred;	/* VAR_OUTPUT */	/* Number of Bytes, that are currently transferred */
	RTS_IEC_UDINT udiNBytesCompleteTranferredToRam;	/* VAR_OUTPUT */	/* Number of Bytes, that are transferred to RAM in the execution. This output is set if the execution is finished. */
	RTS_IEC_BYTE *pPrivateData;			/* Local variable */	
} fbcurl_struct;

/**
 * <description>fbcurl_curl_easy_setopt_string2</description>
 */
typedef struct tagfbcurl_curl_easy_setopt_string2_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_DINT eCurlOption;			/* VAR_INPUT, Enum: ECURLOPTIONS_STRING */
	RTS_IEC_STRING *pString;			/* VAR_INPUT */	
	RTS_IEC_UDINT udiStringLength;		/* VAR_INPUT */	
} fbcurl_curl_easy_setopt_string2_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_setopt_string2(fbcurl_curl_easy_setopt_string2_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_SETOPT_STRING2_IEC) (fbcurl_curl_easy_setopt_string2_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_SETOPT_STRING2_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_setopt_string2
	#define EXT_fbcurl__curl_easy_setopt_string2
	#define GET_fbcurl__curl_easy_setopt_string2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_setopt_string2(p0) 
	#define CHK_fbcurl__curl_easy_setopt_string2  FALSE
	#define EXP_fbcurl__curl_easy_setopt_string2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_setopt_string2
	#define EXT_fbcurl__curl_easy_setopt_string2
	#define GET_fbcurl__curl_easy_setopt_string2(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_string2" ) 
	#define CAL_fbcurl__curl_easy_setopt_string2  fbcurl__curl_easy_setopt_string2
	#define CHK_fbcurl__curl_easy_setopt_string2  TRUE
	#define EXP_fbcurl__curl_easy_setopt_string2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string2", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string2, 1, 0xD661A698, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_setopt_string2 {(RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_string2, "fbcurl__curl_easy_setopt_string2", 0xD661A698, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_setopt_string2
	#define EXT_fbcurl__curl_easy_setopt_string2
	#define GET_fbcurl__curl_easy_setopt_string2(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_string2" ) 
	#define CAL_fbcurl__curl_easy_setopt_string2  fbcurl__curl_easy_setopt_string2
	#define CHK_fbcurl__curl_easy_setopt_string2  TRUE
	#define EXP_fbcurl__curl_easy_setopt_string2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string2", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string2, 1, 0xD661A698, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string2
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string2
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string2  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string2  fbcurl__curl_easy_setopt_string2
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string2  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string2", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string2, 1, 0xD661A698, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_setopt_string2
	#define EXT_fbcurl__curl_easy_setopt_string2
	#define GET_fbcurl__curl_easy_setopt_string2(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_string2" ) 
	#define CAL_fbcurl__curl_easy_setopt_string2  fbcurl__curl_easy_setopt_string2
	#define CHK_fbcurl__curl_easy_setopt_string2  TRUE
	#define EXP_fbcurl__curl_easy_setopt_string2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string2", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string2, 1, 0xD661A698, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_setopt_string2  PFFBCURL__CURL_EASY_SETOPT_STRING2_IEC pffbcurl__curl_easy_setopt_string2;
	#define EXT_fbcurl__curl_easy_setopt_string2  extern PFFBCURL__CURL_EASY_SETOPT_STRING2_IEC pffbcurl__curl_easy_setopt_string2;
	#define GET_fbcurl__curl_easy_setopt_string2(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_setopt_string2", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_setopt_string2, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD661A698, 0x01000000)
	#define CAL_fbcurl__curl_easy_setopt_string2  pffbcurl__curl_easy_setopt_string2
	#define CHK_fbcurl__curl_easy_setopt_string2  (pffbcurl__curl_easy_setopt_string2 != NULL)
	#define EXP_fbcurl__curl_easy_setopt_string2   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string2", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string2, 1, 0xD661A698, 0x01000000) 
#endif


/**
 * <description>fbcurl_fb_exit</description>
 */
typedef struct tagfbcurl_fb_exit_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} fbcurl_fb_exit_struct;

void CDECL CDECL_EXT fbcurl__fb_exit(fbcurl_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__FB_EXIT_IEC) (fbcurl_fb_exit_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__FB_EXIT_NOTIMPLEMENTED)
	#define USE_fbcurl__fb_exit
	#define EXT_fbcurl__fb_exit
	#define GET_fbcurl__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__fb_exit(p0) 
	#define CHK_fbcurl__fb_exit  FALSE
	#define EXP_fbcurl__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__fb_exit
	#define EXT_fbcurl__fb_exit
	#define GET_fbcurl__fb_exit(fl)  CAL_CMGETAPI( "fbcurl__fb_exit" ) 
	#define CAL_fbcurl__fb_exit  fbcurl__fb_exit
	#define CHK_fbcurl__fb_exit  TRUE
	#define EXP_fbcurl__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_exit", (RTS_UINTPTR)fbcurl__fb_exit, 1, 0x3DC3DD5E, 0x01000000) 
	#define EXTREF_ITF_fbcurl__fb_exit {(RTS_VOID_FCTPTR)fbcurl__fb_exit, "fbcurl__fb_exit", 0x3DC3DD5E, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__fb_exit
	#define EXT_fbcurl__fb_exit
	#define GET_fbcurl__fb_exit(fl)  CAL_CMGETAPI( "fbcurl__fb_exit" ) 
	#define CAL_fbcurl__fb_exit  fbcurl__fb_exit
	#define CHK_fbcurl__fb_exit  TRUE
	#define EXP_fbcurl__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_exit", (RTS_UINTPTR)fbcurl__fb_exit, 1, 0x3DC3DD5E, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__fb_exit
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__fb_exit
	#define GET_WagoSysCurl_Internal_PFCfbcurl__fb_exit  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__fb_exit  fbcurl__fb_exit
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__fb_exit  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_exit", (RTS_UINTPTR)fbcurl__fb_exit, 1, 0x3DC3DD5E, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__fb_exit
	#define EXT_fbcurl__fb_exit
	#define GET_fbcurl__fb_exit(fl)  CAL_CMGETAPI( "fbcurl__fb_exit" ) 
	#define CAL_fbcurl__fb_exit  fbcurl__fb_exit
	#define CHK_fbcurl__fb_exit  TRUE
	#define EXP_fbcurl__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_exit", (RTS_UINTPTR)fbcurl__fb_exit, 1, 0x3DC3DD5E, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__fb_exit  PFFBCURL__FB_EXIT_IEC pffbcurl__fb_exit;
	#define EXT_fbcurl__fb_exit  extern PFFBCURL__FB_EXIT_IEC pffbcurl__fb_exit;
	#define GET_fbcurl__fb_exit(fl)  s_pfCMGetAPI2( "fbcurl__fb_exit", (RTS_VOID_FCTPTR *)&pffbcurl__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3DC3DD5E, 0x01000000)
	#define CAL_fbcurl__fb_exit  pffbcurl__fb_exit
	#define CHK_fbcurl__fb_exit  (pffbcurl__fb_exit != NULL)
	#define EXP_fbcurl__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_exit", (RTS_UINTPTR)fbcurl__fb_exit, 1, 0x3DC3DD5E, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_setopt_string</description>
 */
typedef struct tagfbcurl_curl_easy_setopt_string_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_DINT eCurlOption;			/* VAR_INPUT, Enum: ECURLOPTIONS_STRING */
	RTS_IEC_STRING sParameter[1024];	/* VAR_INPUT */	
} fbcurl_curl_easy_setopt_string_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_setopt_string(fbcurl_curl_easy_setopt_string_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_SETOPT_STRING_IEC) (fbcurl_curl_easy_setopt_string_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_SETOPT_STRING_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_setopt_string
	#define EXT_fbcurl__curl_easy_setopt_string
	#define GET_fbcurl__curl_easy_setopt_string(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_setopt_string(p0) 
	#define CHK_fbcurl__curl_easy_setopt_string  FALSE
	#define EXP_fbcurl__curl_easy_setopt_string  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_setopt_string
	#define EXT_fbcurl__curl_easy_setopt_string
	#define GET_fbcurl__curl_easy_setopt_string(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_string" ) 
	#define CAL_fbcurl__curl_easy_setopt_string  fbcurl__curl_easy_setopt_string
	#define CHK_fbcurl__curl_easy_setopt_string  TRUE
	#define EXP_fbcurl__curl_easy_setopt_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string, 1, 0x7BBBC567, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_setopt_string {(RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_string, "fbcurl__curl_easy_setopt_string", 0x7BBBC567, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_setopt_string
	#define EXT_fbcurl__curl_easy_setopt_string
	#define GET_fbcurl__curl_easy_setopt_string(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_string" ) 
	#define CAL_fbcurl__curl_easy_setopt_string  fbcurl__curl_easy_setopt_string
	#define CHK_fbcurl__curl_easy_setopt_string  TRUE
	#define EXP_fbcurl__curl_easy_setopt_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string, 1, 0x7BBBC567, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string  fbcurl__curl_easy_setopt_string
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string, 1, 0x7BBBC567, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_setopt_string
	#define EXT_fbcurl__curl_easy_setopt_string
	#define GET_fbcurl__curl_easy_setopt_string(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_string" ) 
	#define CAL_fbcurl__curl_easy_setopt_string  fbcurl__curl_easy_setopt_string
	#define CHK_fbcurl__curl_easy_setopt_string  TRUE
	#define EXP_fbcurl__curl_easy_setopt_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string, 1, 0x7BBBC567, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_setopt_string  PFFBCURL__CURL_EASY_SETOPT_STRING_IEC pffbcurl__curl_easy_setopt_string;
	#define EXT_fbcurl__curl_easy_setopt_string  extern PFFBCURL__CURL_EASY_SETOPT_STRING_IEC pffbcurl__curl_easy_setopt_string;
	#define GET_fbcurl__curl_easy_setopt_string(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_setopt_string", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_setopt_string, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7BBBC567, 0x01000000)
	#define CAL_fbcurl__curl_easy_setopt_string  pffbcurl__curl_easy_setopt_string
	#define CHK_fbcurl__curl_easy_setopt_string  (pffbcurl__curl_easy_setopt_string != NULL)
	#define EXP_fbcurl__curl_easy_setopt_string   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_string", (RTS_UINTPTR)fbcurl__curl_easy_setopt_string, 1, 0x7BBBC567, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_setopt_bool</description>
 */
typedef struct tagfbcurl_curl_easy_setopt_bool_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_DINT eCurlOption;			/* VAR_INPUT, Enum: ECURLOPTIONS_BOOL */
	RTS_IEC_BOOL xParameter;			/* VAR_INPUT */	
} fbcurl_curl_easy_setopt_bool_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_setopt_bool(fbcurl_curl_easy_setopt_bool_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_SETOPT_BOOL_IEC) (fbcurl_curl_easy_setopt_bool_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_SETOPT_BOOL_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_setopt_bool
	#define EXT_fbcurl__curl_easy_setopt_bool
	#define GET_fbcurl__curl_easy_setopt_bool(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_setopt_bool(p0) 
	#define CHK_fbcurl__curl_easy_setopt_bool  FALSE
	#define EXP_fbcurl__curl_easy_setopt_bool  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_setopt_bool
	#define EXT_fbcurl__curl_easy_setopt_bool
	#define GET_fbcurl__curl_easy_setopt_bool(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_bool" ) 
	#define CAL_fbcurl__curl_easy_setopt_bool  fbcurl__curl_easy_setopt_bool
	#define CHK_fbcurl__curl_easy_setopt_bool  TRUE
	#define EXP_fbcurl__curl_easy_setopt_bool  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_bool", (RTS_UINTPTR)fbcurl__curl_easy_setopt_bool, 1, 0xADFBFBA9, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_setopt_bool {(RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_bool, "fbcurl__curl_easy_setopt_bool", 0xADFBFBA9, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_setopt_bool
	#define EXT_fbcurl__curl_easy_setopt_bool
	#define GET_fbcurl__curl_easy_setopt_bool(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_bool" ) 
	#define CAL_fbcurl__curl_easy_setopt_bool  fbcurl__curl_easy_setopt_bool
	#define CHK_fbcurl__curl_easy_setopt_bool  TRUE
	#define EXP_fbcurl__curl_easy_setopt_bool  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_bool", (RTS_UINTPTR)fbcurl__curl_easy_setopt_bool, 1, 0xADFBFBA9, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_bool
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_bool
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_bool  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_bool  fbcurl__curl_easy_setopt_bool
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_bool  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_bool  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_bool", (RTS_UINTPTR)fbcurl__curl_easy_setopt_bool, 1, 0xADFBFBA9, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_setopt_bool
	#define EXT_fbcurl__curl_easy_setopt_bool
	#define GET_fbcurl__curl_easy_setopt_bool(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_bool" ) 
	#define CAL_fbcurl__curl_easy_setopt_bool  fbcurl__curl_easy_setopt_bool
	#define CHK_fbcurl__curl_easy_setopt_bool  TRUE
	#define EXP_fbcurl__curl_easy_setopt_bool  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_bool", (RTS_UINTPTR)fbcurl__curl_easy_setopt_bool, 1, 0xADFBFBA9, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_setopt_bool  PFFBCURL__CURL_EASY_SETOPT_BOOL_IEC pffbcurl__curl_easy_setopt_bool;
	#define EXT_fbcurl__curl_easy_setopt_bool  extern PFFBCURL__CURL_EASY_SETOPT_BOOL_IEC pffbcurl__curl_easy_setopt_bool;
	#define GET_fbcurl__curl_easy_setopt_bool(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_setopt_bool", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_setopt_bool, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xADFBFBA9, 0x01000000)
	#define CAL_fbcurl__curl_easy_setopt_bool  pffbcurl__curl_easy_setopt_bool
	#define CHK_fbcurl__curl_easy_setopt_bool  (pffbcurl__curl_easy_setopt_bool != NULL)
	#define EXP_fbcurl__curl_easy_setopt_bool   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_bool", (RTS_UINTPTR)fbcurl__curl_easy_setopt_bool, 1, 0xADFBFBA9, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_slist_append</description>
 */
typedef struct tagfbcurl_curl_slist_append_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_UINT uiSlistIndex;			/* VAR_INPUT */	
	RTS_IEC_STRING sString[256];		/* VAR_INPUT */	
	RTS_IEC_BOOL curl_slist_append;		/* VAR_OUTPUT */	
} fbcurl_curl_slist_append_struct;

void CDECL CDECL_EXT fbcurl__curl_slist_append(fbcurl_curl_slist_append_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_SLIST_APPEND_IEC) (fbcurl_curl_slist_append_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_SLIST_APPEND_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_slist_append
	#define EXT_fbcurl__curl_slist_append
	#define GET_fbcurl__curl_slist_append(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_slist_append(p0) 
	#define CHK_fbcurl__curl_slist_append  FALSE
	#define EXP_fbcurl__curl_slist_append  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_slist_append
	#define EXT_fbcurl__curl_slist_append
	#define GET_fbcurl__curl_slist_append(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_append" ) 
	#define CAL_fbcurl__curl_slist_append  fbcurl__curl_slist_append
	#define CHK_fbcurl__curl_slist_append  TRUE
	#define EXP_fbcurl__curl_slist_append  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append", (RTS_UINTPTR)fbcurl__curl_slist_append, 1, 0x6D8DA28D, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_slist_append {(RTS_VOID_FCTPTR)fbcurl__curl_slist_append, "fbcurl__curl_slist_append", 0x6D8DA28D, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_slist_append
	#define EXT_fbcurl__curl_slist_append
	#define GET_fbcurl__curl_slist_append(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_append" ) 
	#define CAL_fbcurl__curl_slist_append  fbcurl__curl_slist_append
	#define CHK_fbcurl__curl_slist_append  TRUE
	#define EXP_fbcurl__curl_slist_append  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append", (RTS_UINTPTR)fbcurl__curl_slist_append, 1, 0x6D8DA28D, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append  fbcurl__curl_slist_append
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append", (RTS_UINTPTR)fbcurl__curl_slist_append, 1, 0x6D8DA28D, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_slist_append
	#define EXT_fbcurl__curl_slist_append
	#define GET_fbcurl__curl_slist_append(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_append" ) 
	#define CAL_fbcurl__curl_slist_append  fbcurl__curl_slist_append
	#define CHK_fbcurl__curl_slist_append  TRUE
	#define EXP_fbcurl__curl_slist_append  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append", (RTS_UINTPTR)fbcurl__curl_slist_append, 1, 0x6D8DA28D, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_slist_append  PFFBCURL__CURL_SLIST_APPEND_IEC pffbcurl__curl_slist_append;
	#define EXT_fbcurl__curl_slist_append  extern PFFBCURL__CURL_SLIST_APPEND_IEC pffbcurl__curl_slist_append;
	#define GET_fbcurl__curl_slist_append(fl)  s_pfCMGetAPI2( "fbcurl__curl_slist_append", (RTS_VOID_FCTPTR *)&pffbcurl__curl_slist_append, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6D8DA28D, 0x01000000)
	#define CAL_fbcurl__curl_slist_append  pffbcurl__curl_slist_append
	#define CHK_fbcurl__curl_slist_append  (pffbcurl__curl_slist_append != NULL)
	#define EXP_fbcurl__curl_slist_append   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append", (RTS_UINTPTR)fbcurl__curl_slist_append, 1, 0x6D8DA28D, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_slist_free_all</description>
 */
typedef struct tagfbcurl_curl_slist_free_all_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_UINT uiSlistIndex;			/* VAR_INPUT */	
	RTS_IEC_BOOL curl_slist_free_all;	/* VAR_OUTPUT */	
} fbcurl_curl_slist_free_all_struct;

void CDECL CDECL_EXT fbcurl__curl_slist_free_all(fbcurl_curl_slist_free_all_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_SLIST_FREE_ALL_IEC) (fbcurl_curl_slist_free_all_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_SLIST_FREE_ALL_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_slist_free_all
	#define EXT_fbcurl__curl_slist_free_all
	#define GET_fbcurl__curl_slist_free_all(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_slist_free_all(p0) 
	#define CHK_fbcurl__curl_slist_free_all  FALSE
	#define EXP_fbcurl__curl_slist_free_all  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_slist_free_all
	#define EXT_fbcurl__curl_slist_free_all
	#define GET_fbcurl__curl_slist_free_all(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_free_all" ) 
	#define CAL_fbcurl__curl_slist_free_all  fbcurl__curl_slist_free_all
	#define CHK_fbcurl__curl_slist_free_all  TRUE
	#define EXP_fbcurl__curl_slist_free_all  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_free_all", (RTS_UINTPTR)fbcurl__curl_slist_free_all, 1, 0x21D758DC, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_slist_free_all {(RTS_VOID_FCTPTR)fbcurl__curl_slist_free_all, "fbcurl__curl_slist_free_all", 0x21D758DC, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_slist_free_all
	#define EXT_fbcurl__curl_slist_free_all
	#define GET_fbcurl__curl_slist_free_all(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_free_all" ) 
	#define CAL_fbcurl__curl_slist_free_all  fbcurl__curl_slist_free_all
	#define CHK_fbcurl__curl_slist_free_all  TRUE
	#define EXP_fbcurl__curl_slist_free_all  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_free_all", (RTS_UINTPTR)fbcurl__curl_slist_free_all, 1, 0x21D758DC, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_slist_free_all
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_slist_free_all
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_slist_free_all  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_slist_free_all  fbcurl__curl_slist_free_all
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_slist_free_all  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_slist_free_all  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_free_all", (RTS_UINTPTR)fbcurl__curl_slist_free_all, 1, 0x21D758DC, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_slist_free_all
	#define EXT_fbcurl__curl_slist_free_all
	#define GET_fbcurl__curl_slist_free_all(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_free_all" ) 
	#define CAL_fbcurl__curl_slist_free_all  fbcurl__curl_slist_free_all
	#define CHK_fbcurl__curl_slist_free_all  TRUE
	#define EXP_fbcurl__curl_slist_free_all  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_free_all", (RTS_UINTPTR)fbcurl__curl_slist_free_all, 1, 0x21D758DC, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_slist_free_all  PFFBCURL__CURL_SLIST_FREE_ALL_IEC pffbcurl__curl_slist_free_all;
	#define EXT_fbcurl__curl_slist_free_all  extern PFFBCURL__CURL_SLIST_FREE_ALL_IEC pffbcurl__curl_slist_free_all;
	#define GET_fbcurl__curl_slist_free_all(fl)  s_pfCMGetAPI2( "fbcurl__curl_slist_free_all", (RTS_VOID_FCTPTR *)&pffbcurl__curl_slist_free_all, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x21D758DC, 0x01000000)
	#define CAL_fbcurl__curl_slist_free_all  pffbcurl__curl_slist_free_all
	#define CHK_fbcurl__curl_slist_free_all  (pffbcurl__curl_slist_free_all != NULL)
	#define EXP_fbcurl__curl_slist_free_all   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_free_all", (RTS_UINTPTR)fbcurl__curl_slist_free_all, 1, 0x21D758DC, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_getresponsecode</description>
 */
typedef struct tagfbcurl_curl_easy_getresponsecode_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_LINT curl_easy_getResponseCode;	/* VAR_OUTPUT */	
} fbcurl_curl_easy_getresponsecode_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_getresponsecode(fbcurl_curl_easy_getresponsecode_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_GETRESPONSECODE_IEC) (fbcurl_curl_easy_getresponsecode_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_GETRESPONSECODE_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_getresponsecode
	#define EXT_fbcurl__curl_easy_getresponsecode
	#define GET_fbcurl__curl_easy_getresponsecode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_getresponsecode(p0) 
	#define CHK_fbcurl__curl_easy_getresponsecode  FALSE
	#define EXP_fbcurl__curl_easy_getresponsecode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_getresponsecode
	#define EXT_fbcurl__curl_easy_getresponsecode
	#define GET_fbcurl__curl_easy_getresponsecode(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_getresponsecode" ) 
	#define CAL_fbcurl__curl_easy_getresponsecode  fbcurl__curl_easy_getresponsecode
	#define CHK_fbcurl__curl_easy_getresponsecode  TRUE
	#define EXP_fbcurl__curl_easy_getresponsecode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_getresponsecode", (RTS_UINTPTR)fbcurl__curl_easy_getresponsecode, 1, 0x5F90EE00, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_getresponsecode {(RTS_VOID_FCTPTR)fbcurl__curl_easy_getresponsecode, "fbcurl__curl_easy_getresponsecode", 0x5F90EE00, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_getresponsecode
	#define EXT_fbcurl__curl_easy_getresponsecode
	#define GET_fbcurl__curl_easy_getresponsecode(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_getresponsecode" ) 
	#define CAL_fbcurl__curl_easy_getresponsecode  fbcurl__curl_easy_getresponsecode
	#define CHK_fbcurl__curl_easy_getresponsecode  TRUE
	#define EXP_fbcurl__curl_easy_getresponsecode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_getresponsecode", (RTS_UINTPTR)fbcurl__curl_easy_getresponsecode, 1, 0x5F90EE00, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_getresponsecode
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_getresponsecode
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_getresponsecode  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_getresponsecode  fbcurl__curl_easy_getresponsecode
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_getresponsecode  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_getresponsecode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_getresponsecode", (RTS_UINTPTR)fbcurl__curl_easy_getresponsecode, 1, 0x5F90EE00, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_getresponsecode
	#define EXT_fbcurl__curl_easy_getresponsecode
	#define GET_fbcurl__curl_easy_getresponsecode(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_getresponsecode" ) 
	#define CAL_fbcurl__curl_easy_getresponsecode  fbcurl__curl_easy_getresponsecode
	#define CHK_fbcurl__curl_easy_getresponsecode  TRUE
	#define EXP_fbcurl__curl_easy_getresponsecode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_getresponsecode", (RTS_UINTPTR)fbcurl__curl_easy_getresponsecode, 1, 0x5F90EE00, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_getresponsecode  PFFBCURL__CURL_EASY_GETRESPONSECODE_IEC pffbcurl__curl_easy_getresponsecode;
	#define EXT_fbcurl__curl_easy_getresponsecode  extern PFFBCURL__CURL_EASY_GETRESPONSECODE_IEC pffbcurl__curl_easy_getresponsecode;
	#define GET_fbcurl__curl_easy_getresponsecode(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_getresponsecode", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_getresponsecode, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5F90EE00, 0x01000000)
	#define CAL_fbcurl__curl_easy_getresponsecode  pffbcurl__curl_easy_getresponsecode
	#define CHK_fbcurl__curl_easy_getresponsecode  (pffbcurl__curl_easy_getresponsecode != NULL)
	#define EXP_fbcurl__curl_easy_getresponsecode   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_getresponsecode", (RTS_UINTPTR)fbcurl__curl_easy_getresponsecode, 1, 0x5F90EE00, 0x01000000) 
#endif


/**
 * <description>fbcurl_main</description>
 */
typedef struct tagfbcurl_main_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
} fbcurl_main_struct;

void CDECL CDECL_EXT fbcurl__main(fbcurl_main_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__MAIN_IEC) (fbcurl_main_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__MAIN_NOTIMPLEMENTED)
	#define USE_fbcurl__main
	#define EXT_fbcurl__main
	#define GET_fbcurl__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__main(p0) 
	#define CHK_fbcurl__main  FALSE
	#define EXP_fbcurl__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__main
	#define EXT_fbcurl__main
	#define GET_fbcurl__main(fl)  CAL_CMGETAPI( "fbcurl__main" ) 
	#define CAL_fbcurl__main  fbcurl__main
	#define CHK_fbcurl__main  TRUE
	#define EXP_fbcurl__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__main", (RTS_UINTPTR)fbcurl__main, 1, 0x00C82D1B, 0x01000000) 
	#define EXTREF_ITF_fbcurl__main {(RTS_VOID_FCTPTR)fbcurl__main, "fbcurl__main", 0x00C82D1B, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__main
	#define EXT_fbcurl__main
	#define GET_fbcurl__main(fl)  CAL_CMGETAPI( "fbcurl__main" ) 
	#define CAL_fbcurl__main  fbcurl__main
	#define CHK_fbcurl__main  TRUE
	#define EXP_fbcurl__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__main", (RTS_UINTPTR)fbcurl__main, 1, 0x00C82D1B, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__main
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__main
	#define GET_WagoSysCurl_Internal_PFCfbcurl__main  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__main  fbcurl__main
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__main  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__main", (RTS_UINTPTR)fbcurl__main, 1, 0x00C82D1B, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__main
	#define EXT_fbcurl__main
	#define GET_fbcurl__main(fl)  CAL_CMGETAPI( "fbcurl__main" ) 
	#define CAL_fbcurl__main  fbcurl__main
	#define CHK_fbcurl__main  TRUE
	#define EXP_fbcurl__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__main", (RTS_UINTPTR)fbcurl__main, 1, 0x00C82D1B, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__main  PFFBCURL__MAIN_IEC pffbcurl__main;
	#define EXT_fbcurl__main  extern PFFBCURL__MAIN_IEC pffbcurl__main;
	#define GET_fbcurl__main(fl)  s_pfCMGetAPI2( "fbcurl__main", (RTS_VOID_FCTPTR *)&pffbcurl__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x00C82D1B, 0x01000000)
	#define CAL_fbcurl__main  pffbcurl__main
	#define CHK_fbcurl__main  (pffbcurl__main != NULL)
	#define EXP_fbcurl__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__main", (RTS_UINTPTR)fbcurl__main, 1, 0x00C82D1B, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_set_ram</description>
 */
typedef struct tagfbcurl_curl_set_ram_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BYTE *pAddress;				/* VAR_INPUT */	
	RTS_IEC_UDINT udiSize;				/* VAR_INPUT */	
} fbcurl_curl_set_ram_struct;

void CDECL CDECL_EXT fbcurl__curl_set_ram(fbcurl_curl_set_ram_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_SET_RAM_IEC) (fbcurl_curl_set_ram_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_SET_RAM_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_set_ram
	#define EXT_fbcurl__curl_set_ram
	#define GET_fbcurl__curl_set_ram(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_set_ram(p0) 
	#define CHK_fbcurl__curl_set_ram  FALSE
	#define EXP_fbcurl__curl_set_ram  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_set_ram
	#define EXT_fbcurl__curl_set_ram
	#define GET_fbcurl__curl_set_ram(fl)  CAL_CMGETAPI( "fbcurl__curl_set_ram" ) 
	#define CAL_fbcurl__curl_set_ram  fbcurl__curl_set_ram
	#define CHK_fbcurl__curl_set_ram  TRUE
	#define EXP_fbcurl__curl_set_ram  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_ram", (RTS_UINTPTR)fbcurl__curl_set_ram, 1, 0x0EF50014, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_set_ram {(RTS_VOID_FCTPTR)fbcurl__curl_set_ram, "fbcurl__curl_set_ram", 0x0EF50014, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_set_ram
	#define EXT_fbcurl__curl_set_ram
	#define GET_fbcurl__curl_set_ram(fl)  CAL_CMGETAPI( "fbcurl__curl_set_ram" ) 
	#define CAL_fbcurl__curl_set_ram  fbcurl__curl_set_ram
	#define CHK_fbcurl__curl_set_ram  TRUE
	#define EXP_fbcurl__curl_set_ram  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_ram", (RTS_UINTPTR)fbcurl__curl_set_ram, 1, 0x0EF50014, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_set_ram
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_set_ram
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_set_ram  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_set_ram  fbcurl__curl_set_ram
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_set_ram  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_set_ram  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_ram", (RTS_UINTPTR)fbcurl__curl_set_ram, 1, 0x0EF50014, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_set_ram
	#define EXT_fbcurl__curl_set_ram
	#define GET_fbcurl__curl_set_ram(fl)  CAL_CMGETAPI( "fbcurl__curl_set_ram" ) 
	#define CAL_fbcurl__curl_set_ram  fbcurl__curl_set_ram
	#define CHK_fbcurl__curl_set_ram  TRUE
	#define EXP_fbcurl__curl_set_ram  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_ram", (RTS_UINTPTR)fbcurl__curl_set_ram, 1, 0x0EF50014, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_set_ram  PFFBCURL__CURL_SET_RAM_IEC pffbcurl__curl_set_ram;
	#define EXT_fbcurl__curl_set_ram  extern PFFBCURL__CURL_SET_RAM_IEC pffbcurl__curl_set_ram;
	#define GET_fbcurl__curl_set_ram(fl)  s_pfCMGetAPI2( "fbcurl__curl_set_ram", (RTS_VOID_FCTPTR *)&pffbcurl__curl_set_ram, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0EF50014, 0x01000000)
	#define CAL_fbcurl__curl_set_ram  pffbcurl__curl_set_ram
	#define CHK_fbcurl__curl_set_ram  (pffbcurl__curl_set_ram != NULL)
	#define EXP_fbcurl__curl_set_ram   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_ram", (RTS_UINTPTR)fbcurl__curl_set_ram, 1, 0x0EF50014, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_reset</description>
 */
typedef struct tagfbcurl_curl_easy_reset_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
} fbcurl_curl_easy_reset_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_reset(fbcurl_curl_easy_reset_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_RESET_IEC) (fbcurl_curl_easy_reset_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_RESET_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_reset
	#define EXT_fbcurl__curl_easy_reset
	#define GET_fbcurl__curl_easy_reset(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_reset(p0) 
	#define CHK_fbcurl__curl_easy_reset  FALSE
	#define EXP_fbcurl__curl_easy_reset  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_reset
	#define EXT_fbcurl__curl_easy_reset
	#define GET_fbcurl__curl_easy_reset(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_reset" ) 
	#define CAL_fbcurl__curl_easy_reset  fbcurl__curl_easy_reset
	#define CHK_fbcurl__curl_easy_reset  TRUE
	#define EXP_fbcurl__curl_easy_reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_reset", (RTS_UINTPTR)fbcurl__curl_easy_reset, 1, 0x3CD2811A, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_reset {(RTS_VOID_FCTPTR)fbcurl__curl_easy_reset, "fbcurl__curl_easy_reset", 0x3CD2811A, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_reset
	#define EXT_fbcurl__curl_easy_reset
	#define GET_fbcurl__curl_easy_reset(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_reset" ) 
	#define CAL_fbcurl__curl_easy_reset  fbcurl__curl_easy_reset
	#define CHK_fbcurl__curl_easy_reset  TRUE
	#define EXP_fbcurl__curl_easy_reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_reset", (RTS_UINTPTR)fbcurl__curl_easy_reset, 1, 0x3CD2811A, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_reset
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_reset
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_reset  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_reset  fbcurl__curl_easy_reset
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_reset  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_reset", (RTS_UINTPTR)fbcurl__curl_easy_reset, 1, 0x3CD2811A, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_reset
	#define EXT_fbcurl__curl_easy_reset
	#define GET_fbcurl__curl_easy_reset(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_reset" ) 
	#define CAL_fbcurl__curl_easy_reset  fbcurl__curl_easy_reset
	#define CHK_fbcurl__curl_easy_reset  TRUE
	#define EXP_fbcurl__curl_easy_reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_reset", (RTS_UINTPTR)fbcurl__curl_easy_reset, 1, 0x3CD2811A, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_reset  PFFBCURL__CURL_EASY_RESET_IEC pffbcurl__curl_easy_reset;
	#define EXT_fbcurl__curl_easy_reset  extern PFFBCURL__CURL_EASY_RESET_IEC pffbcurl__curl_easy_reset;
	#define GET_fbcurl__curl_easy_reset(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_reset", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_reset, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3CD2811A, 0x01000000)
	#define CAL_fbcurl__curl_easy_reset  pffbcurl__curl_easy_reset
	#define CHK_fbcurl__curl_easy_reset  (pffbcurl__curl_easy_reset != NULL)
	#define EXP_fbcurl__curl_easy_reset   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_reset", (RTS_UINTPTR)fbcurl__curl_easy_reset, 1, 0x3CD2811A, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_perform</description>
 */
typedef struct tagfbcurl_curl_easy_perform_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
} fbcurl_curl_easy_perform_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_perform(fbcurl_curl_easy_perform_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_PERFORM_IEC) (fbcurl_curl_easy_perform_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_PERFORM_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_perform
	#define EXT_fbcurl__curl_easy_perform
	#define GET_fbcurl__curl_easy_perform(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_perform(p0) 
	#define CHK_fbcurl__curl_easy_perform  FALSE
	#define EXP_fbcurl__curl_easy_perform  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_perform
	#define EXT_fbcurl__curl_easy_perform
	#define GET_fbcurl__curl_easy_perform(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_perform" ) 
	#define CAL_fbcurl__curl_easy_perform  fbcurl__curl_easy_perform
	#define CHK_fbcurl__curl_easy_perform  TRUE
	#define EXP_fbcurl__curl_easy_perform  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_perform", (RTS_UINTPTR)fbcurl__curl_easy_perform, 1, 0xC3DB6CB8, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_perform {(RTS_VOID_FCTPTR)fbcurl__curl_easy_perform, "fbcurl__curl_easy_perform", 0xC3DB6CB8, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_perform
	#define EXT_fbcurl__curl_easy_perform
	#define GET_fbcurl__curl_easy_perform(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_perform" ) 
	#define CAL_fbcurl__curl_easy_perform  fbcurl__curl_easy_perform
	#define CHK_fbcurl__curl_easy_perform  TRUE
	#define EXP_fbcurl__curl_easy_perform  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_perform", (RTS_UINTPTR)fbcurl__curl_easy_perform, 1, 0xC3DB6CB8, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_perform
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_perform
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_perform  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_perform  fbcurl__curl_easy_perform
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_perform  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_perform  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_perform", (RTS_UINTPTR)fbcurl__curl_easy_perform, 1, 0xC3DB6CB8, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_perform
	#define EXT_fbcurl__curl_easy_perform
	#define GET_fbcurl__curl_easy_perform(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_perform" ) 
	#define CAL_fbcurl__curl_easy_perform  fbcurl__curl_easy_perform
	#define CHK_fbcurl__curl_easy_perform  TRUE
	#define EXP_fbcurl__curl_easy_perform  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_perform", (RTS_UINTPTR)fbcurl__curl_easy_perform, 1, 0xC3DB6CB8, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_perform  PFFBCURL__CURL_EASY_PERFORM_IEC pffbcurl__curl_easy_perform;
	#define EXT_fbcurl__curl_easy_perform  extern PFFBCURL__CURL_EASY_PERFORM_IEC pffbcurl__curl_easy_perform;
	#define GET_fbcurl__curl_easy_perform(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_perform", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_perform, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC3DB6CB8, 0x01000000)
	#define CAL_fbcurl__curl_easy_perform  pffbcurl__curl_easy_perform
	#define CHK_fbcurl__curl_easy_perform  (pffbcurl__curl_easy_perform != NULL)
	#define EXP_fbcurl__curl_easy_perform   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_perform", (RTS_UINTPTR)fbcurl__curl_easy_perform, 1, 0xC3DB6CB8, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_set_logfile</description>
 */
typedef struct tagfbcurl_curl_set_logfile_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_STRING sFilePath[256];		/* VAR_INPUT */	
} fbcurl_curl_set_logfile_struct;

void CDECL CDECL_EXT fbcurl__curl_set_logfile(fbcurl_curl_set_logfile_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_SET_LOGFILE_IEC) (fbcurl_curl_set_logfile_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_SET_LOGFILE_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_set_logfile
	#define EXT_fbcurl__curl_set_logfile
	#define GET_fbcurl__curl_set_logfile(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_set_logfile(p0) 
	#define CHK_fbcurl__curl_set_logfile  FALSE
	#define EXP_fbcurl__curl_set_logfile  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_set_logfile
	#define EXT_fbcurl__curl_set_logfile
	#define GET_fbcurl__curl_set_logfile(fl)  CAL_CMGETAPI( "fbcurl__curl_set_logfile" ) 
	#define CAL_fbcurl__curl_set_logfile  fbcurl__curl_set_logfile
	#define CHK_fbcurl__curl_set_logfile  TRUE
	#define EXP_fbcurl__curl_set_logfile  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_logfile", (RTS_UINTPTR)fbcurl__curl_set_logfile, 1, 0x57B5D369, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_set_logfile {(RTS_VOID_FCTPTR)fbcurl__curl_set_logfile, "fbcurl__curl_set_logfile", 0x57B5D369, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_set_logfile
	#define EXT_fbcurl__curl_set_logfile
	#define GET_fbcurl__curl_set_logfile(fl)  CAL_CMGETAPI( "fbcurl__curl_set_logfile" ) 
	#define CAL_fbcurl__curl_set_logfile  fbcurl__curl_set_logfile
	#define CHK_fbcurl__curl_set_logfile  TRUE
	#define EXP_fbcurl__curl_set_logfile  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_logfile", (RTS_UINTPTR)fbcurl__curl_set_logfile, 1, 0x57B5D369, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_set_logfile
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_set_logfile
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_set_logfile  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_set_logfile  fbcurl__curl_set_logfile
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_set_logfile  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_set_logfile  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_logfile", (RTS_UINTPTR)fbcurl__curl_set_logfile, 1, 0x57B5D369, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_set_logfile
	#define EXT_fbcurl__curl_set_logfile
	#define GET_fbcurl__curl_set_logfile(fl)  CAL_CMGETAPI( "fbcurl__curl_set_logfile" ) 
	#define CAL_fbcurl__curl_set_logfile  fbcurl__curl_set_logfile
	#define CHK_fbcurl__curl_set_logfile  TRUE
	#define EXP_fbcurl__curl_set_logfile  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_logfile", (RTS_UINTPTR)fbcurl__curl_set_logfile, 1, 0x57B5D369, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_set_logfile  PFFBCURL__CURL_SET_LOGFILE_IEC pffbcurl__curl_set_logfile;
	#define EXT_fbcurl__curl_set_logfile  extern PFFBCURL__CURL_SET_LOGFILE_IEC pffbcurl__curl_set_logfile;
	#define GET_fbcurl__curl_set_logfile(fl)  s_pfCMGetAPI2( "fbcurl__curl_set_logfile", (RTS_VOID_FCTPTR *)&pffbcurl__curl_set_logfile, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x57B5D369, 0x01000000)
	#define CAL_fbcurl__curl_set_logfile  pffbcurl__curl_set_logfile
	#define CHK_fbcurl__curl_set_logfile  (pffbcurl__curl_set_logfile != NULL)
	#define EXP_fbcurl__curl_set_logfile   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_logfile", (RTS_UINTPTR)fbcurl__curl_set_logfile, 1, 0x57B5D369, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_setopt_dint</description>
 */
typedef struct tagfbcurl_curl_easy_setopt_dint_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_DINT eCurlOption;			/* VAR_INPUT, Enum: ECURLOPTIONS_DINT */
	RTS_IEC_DINT diParameter;			/* VAR_INPUT */	
} fbcurl_curl_easy_setopt_dint_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_setopt_dint(fbcurl_curl_easy_setopt_dint_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_SETOPT_DINT_IEC) (fbcurl_curl_easy_setopt_dint_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_SETOPT_DINT_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_setopt_dint
	#define EXT_fbcurl__curl_easy_setopt_dint
	#define GET_fbcurl__curl_easy_setopt_dint(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_setopt_dint(p0) 
	#define CHK_fbcurl__curl_easy_setopt_dint  FALSE
	#define EXP_fbcurl__curl_easy_setopt_dint  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_setopt_dint
	#define EXT_fbcurl__curl_easy_setopt_dint
	#define GET_fbcurl__curl_easy_setopt_dint(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_dint" ) 
	#define CAL_fbcurl__curl_easy_setopt_dint  fbcurl__curl_easy_setopt_dint
	#define CHK_fbcurl__curl_easy_setopt_dint  TRUE
	#define EXP_fbcurl__curl_easy_setopt_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_dint", (RTS_UINTPTR)fbcurl__curl_easy_setopt_dint, 1, 0x7216DD37, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_setopt_dint {(RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_dint, "fbcurl__curl_easy_setopt_dint", 0x7216DD37, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_setopt_dint
	#define EXT_fbcurl__curl_easy_setopt_dint
	#define GET_fbcurl__curl_easy_setopt_dint(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_dint" ) 
	#define CAL_fbcurl__curl_easy_setopt_dint  fbcurl__curl_easy_setopt_dint
	#define CHK_fbcurl__curl_easy_setopt_dint  TRUE
	#define EXP_fbcurl__curl_easy_setopt_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_dint", (RTS_UINTPTR)fbcurl__curl_easy_setopt_dint, 1, 0x7216DD37, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_dint
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_dint
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_dint  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_dint  fbcurl__curl_easy_setopt_dint
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_dint  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_dint", (RTS_UINTPTR)fbcurl__curl_easy_setopt_dint, 1, 0x7216DD37, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_setopt_dint
	#define EXT_fbcurl__curl_easy_setopt_dint
	#define GET_fbcurl__curl_easy_setopt_dint(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_dint" ) 
	#define CAL_fbcurl__curl_easy_setopt_dint  fbcurl__curl_easy_setopt_dint
	#define CHK_fbcurl__curl_easy_setopt_dint  TRUE
	#define EXP_fbcurl__curl_easy_setopt_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_dint", (RTS_UINTPTR)fbcurl__curl_easy_setopt_dint, 1, 0x7216DD37, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_setopt_dint  PFFBCURL__CURL_EASY_SETOPT_DINT_IEC pffbcurl__curl_easy_setopt_dint;
	#define EXT_fbcurl__curl_easy_setopt_dint  extern PFFBCURL__CURL_EASY_SETOPT_DINT_IEC pffbcurl__curl_easy_setopt_dint;
	#define GET_fbcurl__curl_easy_setopt_dint(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_setopt_dint", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_setopt_dint, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7216DD37, 0x01000000)
	#define CAL_fbcurl__curl_easy_setopt_dint  pffbcurl__curl_easy_setopt_dint
	#define CHK_fbcurl__curl_easy_setopt_dint  (pffbcurl__curl_easy_setopt_dint != NULL)
	#define EXP_fbcurl__curl_easy_setopt_dint   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_dint", (RTS_UINTPTR)fbcurl__curl_easy_setopt_dint, 1, 0x7216DD37, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_cleanup</description>
 */
typedef struct tagfbcurl_curl_easy_cleanup_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
} fbcurl_curl_easy_cleanup_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_cleanup(fbcurl_curl_easy_cleanup_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_CLEANUP_IEC) (fbcurl_curl_easy_cleanup_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_CLEANUP_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_cleanup
	#define EXT_fbcurl__curl_easy_cleanup
	#define GET_fbcurl__curl_easy_cleanup(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_cleanup(p0) 
	#define CHK_fbcurl__curl_easy_cleanup  FALSE
	#define EXP_fbcurl__curl_easy_cleanup  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_cleanup
	#define EXT_fbcurl__curl_easy_cleanup
	#define GET_fbcurl__curl_easy_cleanup(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_cleanup" ) 
	#define CAL_fbcurl__curl_easy_cleanup  fbcurl__curl_easy_cleanup
	#define CHK_fbcurl__curl_easy_cleanup  TRUE
	#define EXP_fbcurl__curl_easy_cleanup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_cleanup", (RTS_UINTPTR)fbcurl__curl_easy_cleanup, 1, 0x747D008E, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_cleanup {(RTS_VOID_FCTPTR)fbcurl__curl_easy_cleanup, "fbcurl__curl_easy_cleanup", 0x747D008E, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_cleanup
	#define EXT_fbcurl__curl_easy_cleanup
	#define GET_fbcurl__curl_easy_cleanup(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_cleanup" ) 
	#define CAL_fbcurl__curl_easy_cleanup  fbcurl__curl_easy_cleanup
	#define CHK_fbcurl__curl_easy_cleanup  TRUE
	#define EXP_fbcurl__curl_easy_cleanup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_cleanup", (RTS_UINTPTR)fbcurl__curl_easy_cleanup, 1, 0x747D008E, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_cleanup
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_cleanup
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_cleanup  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_cleanup  fbcurl__curl_easy_cleanup
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_cleanup  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_cleanup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_cleanup", (RTS_UINTPTR)fbcurl__curl_easy_cleanup, 1, 0x747D008E, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_cleanup
	#define EXT_fbcurl__curl_easy_cleanup
	#define GET_fbcurl__curl_easy_cleanup(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_cleanup" ) 
	#define CAL_fbcurl__curl_easy_cleanup  fbcurl__curl_easy_cleanup
	#define CHK_fbcurl__curl_easy_cleanup  TRUE
	#define EXP_fbcurl__curl_easy_cleanup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_cleanup", (RTS_UINTPTR)fbcurl__curl_easy_cleanup, 1, 0x747D008E, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_cleanup  PFFBCURL__CURL_EASY_CLEANUP_IEC pffbcurl__curl_easy_cleanup;
	#define EXT_fbcurl__curl_easy_cleanup  extern PFFBCURL__CURL_EASY_CLEANUP_IEC pffbcurl__curl_easy_cleanup;
	#define GET_fbcurl__curl_easy_cleanup(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_cleanup", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_cleanup, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x747D008E, 0x01000000)
	#define CAL_fbcurl__curl_easy_cleanup  pffbcurl__curl_easy_cleanup
	#define CHK_fbcurl__curl_easy_cleanup  (pffbcurl__curl_easy_cleanup != NULL)
	#define EXP_fbcurl__curl_easy_cleanup   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_cleanup", (RTS_UINTPTR)fbcurl__curl_easy_cleanup, 1, 0x747D008E, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_abort</description>
 */
typedef struct tagfbcurl_curl_easy_abort_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
} fbcurl_curl_easy_abort_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_abort(fbcurl_curl_easy_abort_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_ABORT_IEC) (fbcurl_curl_easy_abort_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_ABORT_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_abort
	#define EXT_fbcurl__curl_easy_abort
	#define GET_fbcurl__curl_easy_abort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_abort(p0) 
	#define CHK_fbcurl__curl_easy_abort  FALSE
	#define EXP_fbcurl__curl_easy_abort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_abort
	#define EXT_fbcurl__curl_easy_abort
	#define GET_fbcurl__curl_easy_abort(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_abort" ) 
	#define CAL_fbcurl__curl_easy_abort  fbcurl__curl_easy_abort
	#define CHK_fbcurl__curl_easy_abort  TRUE
	#define EXP_fbcurl__curl_easy_abort  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_abort", (RTS_UINTPTR)fbcurl__curl_easy_abort, 1, 0xA65EDF85, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_abort {(RTS_VOID_FCTPTR)fbcurl__curl_easy_abort, "fbcurl__curl_easy_abort", 0xA65EDF85, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_abort
	#define EXT_fbcurl__curl_easy_abort
	#define GET_fbcurl__curl_easy_abort(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_abort" ) 
	#define CAL_fbcurl__curl_easy_abort  fbcurl__curl_easy_abort
	#define CHK_fbcurl__curl_easy_abort  TRUE
	#define EXP_fbcurl__curl_easy_abort  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_abort", (RTS_UINTPTR)fbcurl__curl_easy_abort, 1, 0xA65EDF85, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_abort
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_abort
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_abort  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_abort  fbcurl__curl_easy_abort
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_abort  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_abort  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_abort", (RTS_UINTPTR)fbcurl__curl_easy_abort, 1, 0xA65EDF85, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_abort
	#define EXT_fbcurl__curl_easy_abort
	#define GET_fbcurl__curl_easy_abort(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_abort" ) 
	#define CAL_fbcurl__curl_easy_abort  fbcurl__curl_easy_abort
	#define CHK_fbcurl__curl_easy_abort  TRUE
	#define EXP_fbcurl__curl_easy_abort  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_abort", (RTS_UINTPTR)fbcurl__curl_easy_abort, 1, 0xA65EDF85, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_abort  PFFBCURL__CURL_EASY_ABORT_IEC pffbcurl__curl_easy_abort;
	#define EXT_fbcurl__curl_easy_abort  extern PFFBCURL__CURL_EASY_ABORT_IEC pffbcurl__curl_easy_abort;
	#define GET_fbcurl__curl_easy_abort(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_abort", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_abort, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA65EDF85, 0x01000000)
	#define CAL_fbcurl__curl_easy_abort  pffbcurl__curl_easy_abort
	#define CHK_fbcurl__curl_easy_abort  (pffbcurl__curl_easy_abort != NULL)
	#define EXP_fbcurl__curl_easy_abort   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_abort", (RTS_UINTPTR)fbcurl__curl_easy_abort, 1, 0xA65EDF85, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_init</description>
 */
typedef struct tagfbcurl_curl_easy_init_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
} fbcurl_curl_easy_init_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_init(fbcurl_curl_easy_init_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_INIT_IEC) (fbcurl_curl_easy_init_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_INIT_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_init
	#define EXT_fbcurl__curl_easy_init
	#define GET_fbcurl__curl_easy_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_init(p0) 
	#define CHK_fbcurl__curl_easy_init  FALSE
	#define EXP_fbcurl__curl_easy_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_init
	#define EXT_fbcurl__curl_easy_init
	#define GET_fbcurl__curl_easy_init(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_init" ) 
	#define CAL_fbcurl__curl_easy_init  fbcurl__curl_easy_init
	#define CHK_fbcurl__curl_easy_init  TRUE
	#define EXP_fbcurl__curl_easy_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_init", (RTS_UINTPTR)fbcurl__curl_easy_init, 1, 0x8AD3008A, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_init {(RTS_VOID_FCTPTR)fbcurl__curl_easy_init, "fbcurl__curl_easy_init", 0x8AD3008A, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_init
	#define EXT_fbcurl__curl_easy_init
	#define GET_fbcurl__curl_easy_init(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_init" ) 
	#define CAL_fbcurl__curl_easy_init  fbcurl__curl_easy_init
	#define CHK_fbcurl__curl_easy_init  TRUE
	#define EXP_fbcurl__curl_easy_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_init", (RTS_UINTPTR)fbcurl__curl_easy_init, 1, 0x8AD3008A, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_init
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_init
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_init  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_init  fbcurl__curl_easy_init
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_init  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_init", (RTS_UINTPTR)fbcurl__curl_easy_init, 1, 0x8AD3008A, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_init
	#define EXT_fbcurl__curl_easy_init
	#define GET_fbcurl__curl_easy_init(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_init" ) 
	#define CAL_fbcurl__curl_easy_init  fbcurl__curl_easy_init
	#define CHK_fbcurl__curl_easy_init  TRUE
	#define EXP_fbcurl__curl_easy_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_init", (RTS_UINTPTR)fbcurl__curl_easy_init, 1, 0x8AD3008A, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_init  PFFBCURL__CURL_EASY_INIT_IEC pffbcurl__curl_easy_init;
	#define EXT_fbcurl__curl_easy_init  extern PFFBCURL__CURL_EASY_INIT_IEC pffbcurl__curl_easy_init;
	#define GET_fbcurl__curl_easy_init(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_init", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8AD3008A, 0x01000000)
	#define CAL_fbcurl__curl_easy_init  pffbcurl__curl_easy_init
	#define CHK_fbcurl__curl_easy_init  (pffbcurl__curl_easy_init != NULL)
	#define EXP_fbcurl__curl_easy_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_init", (RTS_UINTPTR)fbcurl__curl_easy_init, 1, 0x8AD3008A, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_easy_setopt_slist</description>
 */
typedef struct tagfbcurl_curl_easy_setopt_slist_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_DINT eCurlOption;			/* VAR_INPUT, Enum: ECURLOPTIONS_SLIST */
	RTS_IEC_UINT uiSlistIndex;			/* VAR_INPUT */	
	RTS_IEC_BOOL curl_easy_setopt_slist;	/* VAR_OUTPUT */	
} fbcurl_curl_easy_setopt_slist_struct;

void CDECL CDECL_EXT fbcurl__curl_easy_setopt_slist(fbcurl_curl_easy_setopt_slist_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_EASY_SETOPT_SLIST_IEC) (fbcurl_curl_easy_setopt_slist_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_EASY_SETOPT_SLIST_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_easy_setopt_slist
	#define EXT_fbcurl__curl_easy_setopt_slist
	#define GET_fbcurl__curl_easy_setopt_slist(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_easy_setopt_slist(p0) 
	#define CHK_fbcurl__curl_easy_setopt_slist  FALSE
	#define EXP_fbcurl__curl_easy_setopt_slist  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_easy_setopt_slist
	#define EXT_fbcurl__curl_easy_setopt_slist
	#define GET_fbcurl__curl_easy_setopt_slist(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_slist" ) 
	#define CAL_fbcurl__curl_easy_setopt_slist  fbcurl__curl_easy_setopt_slist
	#define CHK_fbcurl__curl_easy_setopt_slist  TRUE
	#define EXP_fbcurl__curl_easy_setopt_slist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_slist", (RTS_UINTPTR)fbcurl__curl_easy_setopt_slist, 1, 0xA808A865, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_easy_setopt_slist {(RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_slist, "fbcurl__curl_easy_setopt_slist", 0xA808A865, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_easy_setopt_slist
	#define EXT_fbcurl__curl_easy_setopt_slist
	#define GET_fbcurl__curl_easy_setopt_slist(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_slist" ) 
	#define CAL_fbcurl__curl_easy_setopt_slist  fbcurl__curl_easy_setopt_slist
	#define CHK_fbcurl__curl_easy_setopt_slist  TRUE
	#define EXP_fbcurl__curl_easy_setopt_slist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_slist", (RTS_UINTPTR)fbcurl__curl_easy_setopt_slist, 1, 0xA808A865, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_slist
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_slist
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_slist  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_slist  fbcurl__curl_easy_setopt_slist
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_slist  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_easy_setopt_slist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_slist", (RTS_UINTPTR)fbcurl__curl_easy_setopt_slist, 1, 0xA808A865, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_easy_setopt_slist
	#define EXT_fbcurl__curl_easy_setopt_slist
	#define GET_fbcurl__curl_easy_setopt_slist(fl)  CAL_CMGETAPI( "fbcurl__curl_easy_setopt_slist" ) 
	#define CAL_fbcurl__curl_easy_setopt_slist  fbcurl__curl_easy_setopt_slist
	#define CHK_fbcurl__curl_easy_setopt_slist  TRUE
	#define EXP_fbcurl__curl_easy_setopt_slist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_slist", (RTS_UINTPTR)fbcurl__curl_easy_setopt_slist, 1, 0xA808A865, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_easy_setopt_slist  PFFBCURL__CURL_EASY_SETOPT_SLIST_IEC pffbcurl__curl_easy_setopt_slist;
	#define EXT_fbcurl__curl_easy_setopt_slist  extern PFFBCURL__CURL_EASY_SETOPT_SLIST_IEC pffbcurl__curl_easy_setopt_slist;
	#define GET_fbcurl__curl_easy_setopt_slist(fl)  s_pfCMGetAPI2( "fbcurl__curl_easy_setopt_slist", (RTS_VOID_FCTPTR *)&pffbcurl__curl_easy_setopt_slist, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA808A865, 0x01000000)
	#define CAL_fbcurl__curl_easy_setopt_slist  pffbcurl__curl_easy_setopt_slist
	#define CHK_fbcurl__curl_easy_setopt_slist  (pffbcurl__curl_easy_setopt_slist != NULL)
	#define EXP_fbcurl__curl_easy_setopt_slist   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_easy_setopt_slist", (RTS_UINTPTR)fbcurl__curl_easy_setopt_slist, 1, 0xA808A865, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_set_filepath</description>
 */
typedef struct tagfbcurl_curl_set_filepath_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_STRING sFilePath[256];		/* VAR_INPUT */	
} fbcurl_curl_set_filepath_struct;

void CDECL CDECL_EXT fbcurl__curl_set_filepath(fbcurl_curl_set_filepath_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_SET_FILEPATH_IEC) (fbcurl_curl_set_filepath_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_SET_FILEPATH_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_set_filepath
	#define EXT_fbcurl__curl_set_filepath
	#define GET_fbcurl__curl_set_filepath(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_set_filepath(p0) 
	#define CHK_fbcurl__curl_set_filepath  FALSE
	#define EXP_fbcurl__curl_set_filepath  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_set_filepath
	#define EXT_fbcurl__curl_set_filepath
	#define GET_fbcurl__curl_set_filepath(fl)  CAL_CMGETAPI( "fbcurl__curl_set_filepath" ) 
	#define CAL_fbcurl__curl_set_filepath  fbcurl__curl_set_filepath
	#define CHK_fbcurl__curl_set_filepath  TRUE
	#define EXP_fbcurl__curl_set_filepath  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_filepath", (RTS_UINTPTR)fbcurl__curl_set_filepath, 1, 0x010C8AC7, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_set_filepath {(RTS_VOID_FCTPTR)fbcurl__curl_set_filepath, "fbcurl__curl_set_filepath", 0x010C8AC7, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_set_filepath
	#define EXT_fbcurl__curl_set_filepath
	#define GET_fbcurl__curl_set_filepath(fl)  CAL_CMGETAPI( "fbcurl__curl_set_filepath" ) 
	#define CAL_fbcurl__curl_set_filepath  fbcurl__curl_set_filepath
	#define CHK_fbcurl__curl_set_filepath  TRUE
	#define EXP_fbcurl__curl_set_filepath  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_filepath", (RTS_UINTPTR)fbcurl__curl_set_filepath, 1, 0x010C8AC7, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_set_filepath
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_set_filepath
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_set_filepath  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_set_filepath  fbcurl__curl_set_filepath
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_set_filepath  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_set_filepath  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_filepath", (RTS_UINTPTR)fbcurl__curl_set_filepath, 1, 0x010C8AC7, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_set_filepath
	#define EXT_fbcurl__curl_set_filepath
	#define GET_fbcurl__curl_set_filepath(fl)  CAL_CMGETAPI( "fbcurl__curl_set_filepath" ) 
	#define CAL_fbcurl__curl_set_filepath  fbcurl__curl_set_filepath
	#define CHK_fbcurl__curl_set_filepath  TRUE
	#define EXP_fbcurl__curl_set_filepath  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_filepath", (RTS_UINTPTR)fbcurl__curl_set_filepath, 1, 0x010C8AC7, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_set_filepath  PFFBCURL__CURL_SET_FILEPATH_IEC pffbcurl__curl_set_filepath;
	#define EXT_fbcurl__curl_set_filepath  extern PFFBCURL__CURL_SET_FILEPATH_IEC pffbcurl__curl_set_filepath;
	#define GET_fbcurl__curl_set_filepath(fl)  s_pfCMGetAPI2( "fbcurl__curl_set_filepath", (RTS_VOID_FCTPTR *)&pffbcurl__curl_set_filepath, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x010C8AC7, 0x01000000)
	#define CAL_fbcurl__curl_set_filepath  pffbcurl__curl_set_filepath
	#define CHK_fbcurl__curl_set_filepath  (pffbcurl__curl_set_filepath != NULL)
	#define EXP_fbcurl__curl_set_filepath   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_set_filepath", (RTS_UINTPTR)fbcurl__curl_set_filepath, 1, 0x010C8AC7, 0x01000000) 
#endif


/**
 * <description>fbcurl_fb_init</description>
 */
typedef struct tagfbcurl_fb_init_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} fbcurl_fb_init_struct;

void CDECL CDECL_EXT fbcurl__fb_init(fbcurl_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__FB_INIT_IEC) (fbcurl_fb_init_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__FB_INIT_NOTIMPLEMENTED)
	#define USE_fbcurl__fb_init
	#define EXT_fbcurl__fb_init
	#define GET_fbcurl__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__fb_init(p0) 
	#define CHK_fbcurl__fb_init  FALSE
	#define EXP_fbcurl__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__fb_init
	#define EXT_fbcurl__fb_init
	#define GET_fbcurl__fb_init(fl)  CAL_CMGETAPI( "fbcurl__fb_init" ) 
	#define CAL_fbcurl__fb_init  fbcurl__fb_init
	#define CHK_fbcurl__fb_init  TRUE
	#define EXP_fbcurl__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_init", (RTS_UINTPTR)fbcurl__fb_init, 1, 0x1B40323E, 0x01000000) 
	#define EXTREF_ITF_fbcurl__fb_init {(RTS_VOID_FCTPTR)fbcurl__fb_init, "fbcurl__fb_init", 0x1B40323E, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__fb_init
	#define EXT_fbcurl__fb_init
	#define GET_fbcurl__fb_init(fl)  CAL_CMGETAPI( "fbcurl__fb_init" ) 
	#define CAL_fbcurl__fb_init  fbcurl__fb_init
	#define CHK_fbcurl__fb_init  TRUE
	#define EXP_fbcurl__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_init", (RTS_UINTPTR)fbcurl__fb_init, 1, 0x1B40323E, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__fb_init
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__fb_init
	#define GET_WagoSysCurl_Internal_PFCfbcurl__fb_init  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__fb_init  fbcurl__fb_init
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__fb_init  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_init", (RTS_UINTPTR)fbcurl__fb_init, 1, 0x1B40323E, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__fb_init
	#define EXT_fbcurl__fb_init
	#define GET_fbcurl__fb_init(fl)  CAL_CMGETAPI( "fbcurl__fb_init" ) 
	#define CAL_fbcurl__fb_init  fbcurl__fb_init
	#define CHK_fbcurl__fb_init  TRUE
	#define EXP_fbcurl__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_init", (RTS_UINTPTR)fbcurl__fb_init, 1, 0x1B40323E, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__fb_init  PFFBCURL__FB_INIT_IEC pffbcurl__fb_init;
	#define EXT_fbcurl__fb_init  extern PFFBCURL__FB_INIT_IEC pffbcurl__fb_init;
	#define GET_fbcurl__fb_init(fl)  s_pfCMGetAPI2( "fbcurl__fb_init", (RTS_VOID_FCTPTR *)&pffbcurl__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1B40323E, 0x01000000)
	#define CAL_fbcurl__fb_init  pffbcurl__fb_init
	#define CHK_fbcurl__fb_init  (pffbcurl__fb_init != NULL)
	#define EXP_fbcurl__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__fb_init", (RTS_UINTPTR)fbcurl__fb_init, 1, 0x1B40323E, 0x01000000) 
#endif


/**
 * <description>fbcurl_curl_slist_append2</description>
 */
typedef struct tagfbcurl_curl_slist_append2_struct
{
	fbcurl_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_UINT uiSlistIndex;			/* VAR_INPUT */	
	RTS_IEC_STRING *pString;			/* VAR_INPUT */	
	RTS_IEC_UDINT udiStringLength;		/* VAR_INPUT */	
	RTS_IEC_BOOL curl_slist_append2;	/* VAR_OUTPUT */	
} fbcurl_curl_slist_append2_struct;

void CDECL CDECL_EXT fbcurl__curl_slist_append2(fbcurl_curl_slist_append2_struct *p);
typedef void (CDECL CDECL_EXT* PFFBCURL__CURL_SLIST_APPEND2_IEC) (fbcurl_curl_slist_append2_struct *p);
#if defined(WAGOSYSCURL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBCURL__CURL_SLIST_APPEND2_NOTIMPLEMENTED)
	#define USE_fbcurl__curl_slist_append2
	#define EXT_fbcurl__curl_slist_append2
	#define GET_fbcurl__curl_slist_append2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbcurl__curl_slist_append2(p0) 
	#define CHK_fbcurl__curl_slist_append2  FALSE
	#define EXP_fbcurl__curl_slist_append2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbcurl__curl_slist_append2
	#define EXT_fbcurl__curl_slist_append2
	#define GET_fbcurl__curl_slist_append2(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_append2" ) 
	#define CAL_fbcurl__curl_slist_append2  fbcurl__curl_slist_append2
	#define CHK_fbcurl__curl_slist_append2  TRUE
	#define EXP_fbcurl__curl_slist_append2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append2", (RTS_UINTPTR)fbcurl__curl_slist_append2, 1, 0xC388A4D1, 0x01000000) 
	#define EXTREF_ITF_fbcurl__curl_slist_append2 {(RTS_VOID_FCTPTR)fbcurl__curl_slist_append2, "fbcurl__curl_slist_append2", 0xC388A4D1, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCURL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbcurl__curl_slist_append2
	#define EXT_fbcurl__curl_slist_append2
	#define GET_fbcurl__curl_slist_append2(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_append2" ) 
	#define CAL_fbcurl__curl_slist_append2  fbcurl__curl_slist_append2
	#define CHK_fbcurl__curl_slist_append2  TRUE
	#define EXP_fbcurl__curl_slist_append2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append2", (RTS_UINTPTR)fbcurl__curl_slist_append2, 1, 0xC388A4D1, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append2
	#define EXT_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append2
	#define GET_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append2  ERR_OK
	#define CAL_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append2  fbcurl__curl_slist_append2
	#define CHK_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append2  TRUE
	#define EXP_WagoSysCurl_Internal_PFCfbcurl__curl_slist_append2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append2", (RTS_UINTPTR)fbcurl__curl_slist_append2, 1, 0xC388A4D1, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fbcurl__curl_slist_append2
	#define EXT_fbcurl__curl_slist_append2
	#define GET_fbcurl__curl_slist_append2(fl)  CAL_CMGETAPI( "fbcurl__curl_slist_append2" ) 
	#define CAL_fbcurl__curl_slist_append2  fbcurl__curl_slist_append2
	#define CHK_fbcurl__curl_slist_append2  TRUE
	#define EXP_fbcurl__curl_slist_append2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append2", (RTS_UINTPTR)fbcurl__curl_slist_append2, 1, 0xC388A4D1, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fbcurl__curl_slist_append2  PFFBCURL__CURL_SLIST_APPEND2_IEC pffbcurl__curl_slist_append2;
	#define EXT_fbcurl__curl_slist_append2  extern PFFBCURL__CURL_SLIST_APPEND2_IEC pffbcurl__curl_slist_append2;
	#define GET_fbcurl__curl_slist_append2(fl)  s_pfCMGetAPI2( "fbcurl__curl_slist_append2", (RTS_VOID_FCTPTR *)&pffbcurl__curl_slist_append2, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC388A4D1, 0x01000000)
	#define CAL_fbcurl__curl_slist_append2  pffbcurl__curl_slist_append2
	#define CHK_fbcurl__curl_slist_append2  (pffbcurl__curl_slist_append2 != NULL)
	#define EXP_fbcurl__curl_slist_append2   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbcurl__curl_slist_append2", (RTS_UINTPTR)fbcurl__curl_slist_append2, 1, 0xC388A4D1, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysCurl_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysCurl_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysCurl_Internal_PFC
		#define ITF_WagoSysCurl_Internal_PFC static IWagoSysCurl_Internal_PFC *pIWagoSysCurl_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysCurl_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysCurl_Internal_PFC_C		IWagoSysCurl_Internal_PFC;
	#ifndef ITF_WagoSysCurl_Internal_PFC
		#define ITF_WagoSysCurl_Internal_PFC
	#endif
	#define EXTITF_WagoSysCurl_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSCURL_INTERNAL_PFCITF_H_*/
