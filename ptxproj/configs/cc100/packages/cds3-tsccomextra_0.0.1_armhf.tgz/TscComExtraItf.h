 /**
 * <interfacename>TscComExtra</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCCOMEXTRAITF_H_
#define _TSCCOMEXTRAITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eComHWLine</description>
 */
#define ECOMHWLINE_COMHWLINE_RTS    0	
#define ECOMHWLINE_COMHWLINE_CTS    1	
#define ECOMHWLINE_COMHWLINE_DTR    2	
#define ECOMHWLINE_COMHWLINE_DSR    3	
#define ECOMHWLINE_COMHWLINE_DCD    4	
#define ECOMHWLINE_COMHWLINE_RI    5	
/* Typed enum definition */
#define ECOMHWLINE    RTS_IEC_INT

/**
 * 
 * Retrieves the state of the hardware line, if available.
 * if no line states are available, always returns TRUE.
 * Note: Manipulating HW lines only works FOR RS232 on PFC200.
 * 
 * dwResult is set to 0 in case of success and contains tha appropriate errno value from ioctl(TIOCMGET) 
 * in error case
 * 
 * =============  ======================================================================================
 * ***result codes**
 * *-----------------------------------------------------------------------------------------------------
 * *TRUE         line state is high
 * *FALSE        line state is low
 * *=============  ======================================================================================
 */
typedef struct tagcomextra_get_line_state_struct
{
	RTS_IEC_HANDLE hCom;				/* VAR_INPUT */	
	RTS_IEC_INT eComLine;				/* VAR_INPUT, Enum: ECOMHWLINE */
	RTS_IEC_BOOL comextra_get_line_state;	/* VAR_OUTPUT */	
	RTS_IEC_DWORD dwResult;				/* VAR_OUTPUT */	
} comextra_get_line_state_struct;

void CDECL CDECL_EXT comextra_get_line_state(comextra_get_line_state_struct *p);
typedef void (CDECL CDECL_EXT* PFCOMEXTRA_GET_LINE_STATE_IEC) (comextra_get_line_state_struct *p);
#if defined(TSCCOMEXTRA_NOTIMPLEMENTED) || defined(COMEXTRA_GET_LINE_STATE_NOTIMPLEMENTED)
	#define USE_comextra_get_line_state
	#define EXT_comextra_get_line_state
	#define GET_comextra_get_line_state(fl)  ERR_NOTIMPLEMENTED
	#define CAL_comextra_get_line_state(p0) 
	#define CHK_comextra_get_line_state  FALSE
	#define EXP_comextra_get_line_state  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_comextra_get_line_state
	#define EXT_comextra_get_line_state
	#define GET_comextra_get_line_state(fl)  CAL_CMGETAPI( "comextra_get_line_state" ) 
	#define CAL_comextra_get_line_state  comextra_get_line_state
	#define CHK_comextra_get_line_state  TRUE
	#define EXP_comextra_get_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_get_line_state", (RTS_UINTPTR)comextra_get_line_state, 1, 0xA44D4774, 0x01000013) 
	#define EXTREF_ITF_comextra_get_line_state {(RTS_VOID_FCTPTR)comextra_get_line_state, "comextra_get_line_state", 0xA44D4774, 0x01000013}
#elif defined(MIXED_LINK) && !defined(TSCCOMEXTRA_EXTERNAL)
	#define USE_comextra_get_line_state
	#define EXT_comextra_get_line_state
	#define GET_comextra_get_line_state(fl)  CAL_CMGETAPI( "comextra_get_line_state" ) 
	#define CAL_comextra_get_line_state  comextra_get_line_state
	#define CHK_comextra_get_line_state  TRUE
	#define EXP_comextra_get_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_get_line_state", (RTS_UINTPTR)comextra_get_line_state, 1, 0xA44D4774, 0x01000013) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscComExtracomextra_get_line_state
	#define EXT_TscComExtracomextra_get_line_state
	#define GET_TscComExtracomextra_get_line_state  ERR_OK
	#define CAL_TscComExtracomextra_get_line_state  comextra_get_line_state
	#define CHK_TscComExtracomextra_get_line_state  TRUE
	#define EXP_TscComExtracomextra_get_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_get_line_state", (RTS_UINTPTR)comextra_get_line_state, 1, 0xA44D4774, 0x01000013) 
#elif defined(CPLUSPLUS)
	#define USE_comextra_get_line_state
	#define EXT_comextra_get_line_state
	#define GET_comextra_get_line_state(fl)  CAL_CMGETAPI( "comextra_get_line_state" ) 
	#define CAL_comextra_get_line_state  comextra_get_line_state
	#define CHK_comextra_get_line_state  TRUE
	#define EXP_comextra_get_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_get_line_state", (RTS_UINTPTR)comextra_get_line_state, 1, 0xA44D4774, 0x01000013) 
#else /* DYNAMIC_LINK */
	#define USE_comextra_get_line_state  PFCOMEXTRA_GET_LINE_STATE_IEC pfcomextra_get_line_state;
	#define EXT_comextra_get_line_state  extern PFCOMEXTRA_GET_LINE_STATE_IEC pfcomextra_get_line_state;
	#define GET_comextra_get_line_state(fl)  s_pfCMGetAPI2( "comextra_get_line_state", (RTS_VOID_FCTPTR *)&pfcomextra_get_line_state, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA44D4774, 0x01000013)
	#define CAL_comextra_get_line_state  pfcomextra_get_line_state
	#define CHK_comextra_get_line_state  (pfcomextra_get_line_state != NULL)
	#define EXP_comextra_get_line_state   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_get_line_state", (RTS_UINTPTR)comextra_get_line_state, 1, 0xA44D4774, 0x01000013) 
#endif


/**
 *
 * Checks if the driver and the protocol support manipulation of the hardware line
 * Returns TRUE if the given line is available for manipulation and FALSE otherwise.
 * Note that a line is not available for manipulation if it is used i.e. for flow control.
 * Getting HW line's status only works for RS232 on PFC200.
 *
 *=============  ======================================================================================
 ***result codes**
 *-----------------------------------------------------------------------------------------------------
 *TRUE         line manipulation is possible
 *FALSE        line manipulation is not possible
 *=============  ======================================================================================
 */
typedef struct tagcomextra_is_line_available_struct
{
	RTS_IEC_HANDLE hCom;				/* VAR_INPUT */	
	RTS_IEC_INT eComLine;				/* VAR_INPUT, Enum: ECOMHWLINE */
	RTS_IEC_BOOL comextra_is_line_available;	/* VAR_OUTPUT */	
} comextra_is_line_available_struct;

void CDECL CDECL_EXT comextra_is_line_available(comextra_is_line_available_struct *p);
typedef void (CDECL CDECL_EXT* PFCOMEXTRA_IS_LINE_AVAILABLE_IEC) (comextra_is_line_available_struct *p);
#if defined(TSCCOMEXTRA_NOTIMPLEMENTED) || defined(COMEXTRA_IS_LINE_AVAILABLE_NOTIMPLEMENTED)
	#define USE_comextra_is_line_available
	#define EXT_comextra_is_line_available
	#define GET_comextra_is_line_available(fl)  ERR_NOTIMPLEMENTED
	#define CAL_comextra_is_line_available(p0) 
	#define CHK_comextra_is_line_available  FALSE
	#define EXP_comextra_is_line_available  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_comextra_is_line_available
	#define EXT_comextra_is_line_available
	#define GET_comextra_is_line_available(fl)  CAL_CMGETAPI( "comextra_is_line_available" ) 
	#define CAL_comextra_is_line_available  comextra_is_line_available
	#define CHK_comextra_is_line_available  TRUE
	#define EXP_comextra_is_line_available  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_line_available", (RTS_UINTPTR)comextra_is_line_available, 1, 0x87588278, 0x01000013) 
	#define EXTREF_ITF_comextra_is_line_available {(RTS_VOID_FCTPTR)comextra_is_line_available, "comextra_is_line_available", 0x87588278, 0x01000013}
#elif defined(MIXED_LINK) && !defined(TSCCOMEXTRA_EXTERNAL)
	#define USE_comextra_is_line_available
	#define EXT_comextra_is_line_available
	#define GET_comextra_is_line_available(fl)  CAL_CMGETAPI( "comextra_is_line_available" ) 
	#define CAL_comextra_is_line_available  comextra_is_line_available
	#define CHK_comextra_is_line_available  TRUE
	#define EXP_comextra_is_line_available  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_line_available", (RTS_UINTPTR)comextra_is_line_available, 1, 0x87588278, 0x01000013) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscComExtracomextra_is_line_available
	#define EXT_TscComExtracomextra_is_line_available
	#define GET_TscComExtracomextra_is_line_available  ERR_OK
	#define CAL_TscComExtracomextra_is_line_available  comextra_is_line_available
	#define CHK_TscComExtracomextra_is_line_available  TRUE
	#define EXP_TscComExtracomextra_is_line_available  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_line_available", (RTS_UINTPTR)comextra_is_line_available, 1, 0x87588278, 0x01000013) 
#elif defined(CPLUSPLUS)
	#define USE_comextra_is_line_available
	#define EXT_comextra_is_line_available
	#define GET_comextra_is_line_available(fl)  CAL_CMGETAPI( "comextra_is_line_available" ) 
	#define CAL_comextra_is_line_available  comextra_is_line_available
	#define CHK_comextra_is_line_available  TRUE
	#define EXP_comextra_is_line_available  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_line_available", (RTS_UINTPTR)comextra_is_line_available, 1, 0x87588278, 0x01000013) 
#else /* DYNAMIC_LINK */
	#define USE_comextra_is_line_available  PFCOMEXTRA_IS_LINE_AVAILABLE_IEC pfcomextra_is_line_available;
	#define EXT_comextra_is_line_available  extern PFCOMEXTRA_IS_LINE_AVAILABLE_IEC pfcomextra_is_line_available;
	#define GET_comextra_is_line_available(fl)  s_pfCMGetAPI2( "comextra_is_line_available", (RTS_VOID_FCTPTR *)&pfcomextra_is_line_available, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x87588278, 0x01000013)
	#define CAL_comextra_is_line_available  pfcomextra_is_line_available
	#define CHK_comextra_is_line_available  (pfcomextra_is_line_available != NULL)
	#define EXP_comextra_is_line_available   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_line_available", (RTS_UINTPTR)comextra_is_line_available, 1, 0x87588278, 0x01000013) 
#endif


/**
 *
 * Returns UART tx empty state.
 * Returns reliable results for RS232 only (in RS485 mode the signal passes an RS232<->RS485 transceiver 
 * after it leaves the UART).
 *
 *=============  ======================================================================================
 ***result codes**
 *-----------------------------------------------------------------------------------------------------
 *0              Transmitter is empty and no more bytes to send
 *EINPROGRESS    Transmitter has still bytes to send
 *ENOSYS         This operation is not supported by the device.
 *=============  ======================================================================================
 */
typedef struct tagcomextra_is_tx_empty_struct
{
	RTS_IEC_HANDLE hCom;				/* VAR_INPUT */	
	RTS_IEC_DWORD comextra_is_tx_empty;	/* VAR_OUTPUT */	
} comextra_is_tx_empty_struct;

void CDECL CDECL_EXT comextra_is_tx_empty(comextra_is_tx_empty_struct *p);
typedef void (CDECL CDECL_EXT* PFCOMEXTRA_IS_TX_EMPTY_IEC) (comextra_is_tx_empty_struct *p);
#if defined(TSCCOMEXTRA_NOTIMPLEMENTED) || defined(COMEXTRA_IS_TX_EMPTY_NOTIMPLEMENTED)
	#define USE_comextra_is_tx_empty
	#define EXT_comextra_is_tx_empty
	#define GET_comextra_is_tx_empty(fl)  ERR_NOTIMPLEMENTED
	#define CAL_comextra_is_tx_empty(p0) 
	#define CHK_comextra_is_tx_empty  FALSE
	#define EXP_comextra_is_tx_empty  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_comextra_is_tx_empty
	#define EXT_comextra_is_tx_empty
	#define GET_comextra_is_tx_empty(fl)  CAL_CMGETAPI( "comextra_is_tx_empty" ) 
	#define CAL_comextra_is_tx_empty  comextra_is_tx_empty
	#define CHK_comextra_is_tx_empty  TRUE
	#define EXP_comextra_is_tx_empty  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_tx_empty", (RTS_UINTPTR)comextra_is_tx_empty, 1, 0x13F4CFEF, 0x01000013) 
	#define EXTREF_ITF_comextra_is_tx_empty {(RTS_VOID_FCTPTR)comextra_is_tx_empty, "comextra_is_tx_empty", 0x13F4CFEF, 0x01000013}
#elif defined(MIXED_LINK) && !defined(TSCCOMEXTRA_EXTERNAL)
	#define USE_comextra_is_tx_empty
	#define EXT_comextra_is_tx_empty
	#define GET_comextra_is_tx_empty(fl)  CAL_CMGETAPI( "comextra_is_tx_empty" ) 
	#define CAL_comextra_is_tx_empty  comextra_is_tx_empty
	#define CHK_comextra_is_tx_empty  TRUE
	#define EXP_comextra_is_tx_empty  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_tx_empty", (RTS_UINTPTR)comextra_is_tx_empty, 1, 0x13F4CFEF, 0x01000013) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscComExtracomextra_is_tx_empty
	#define EXT_TscComExtracomextra_is_tx_empty
	#define GET_TscComExtracomextra_is_tx_empty  ERR_OK
	#define CAL_TscComExtracomextra_is_tx_empty  comextra_is_tx_empty
	#define CHK_TscComExtracomextra_is_tx_empty  TRUE
	#define EXP_TscComExtracomextra_is_tx_empty  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_tx_empty", (RTS_UINTPTR)comextra_is_tx_empty, 1, 0x13F4CFEF, 0x01000013) 
#elif defined(CPLUSPLUS)
	#define USE_comextra_is_tx_empty
	#define EXT_comextra_is_tx_empty
	#define GET_comextra_is_tx_empty(fl)  CAL_CMGETAPI( "comextra_is_tx_empty" ) 
	#define CAL_comextra_is_tx_empty  comextra_is_tx_empty
	#define CHK_comextra_is_tx_empty  TRUE
	#define EXP_comextra_is_tx_empty  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_tx_empty", (RTS_UINTPTR)comextra_is_tx_empty, 1, 0x13F4CFEF, 0x01000013) 
#else /* DYNAMIC_LINK */
	#define USE_comextra_is_tx_empty  PFCOMEXTRA_IS_TX_EMPTY_IEC pfcomextra_is_tx_empty;
	#define EXT_comextra_is_tx_empty  extern PFCOMEXTRA_IS_TX_EMPTY_IEC pfcomextra_is_tx_empty;
	#define GET_comextra_is_tx_empty(fl)  s_pfCMGetAPI2( "comextra_is_tx_empty", (RTS_VOID_FCTPTR *)&pfcomextra_is_tx_empty, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x13F4CFEF, 0x01000013)
	#define CAL_comextra_is_tx_empty  pfcomextra_is_tx_empty
	#define CHK_comextra_is_tx_empty  (pfcomextra_is_tx_empty != NULL)
	#define EXP_comextra_is_tx_empty   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_is_tx_empty", (RTS_UINTPTR)comextra_is_tx_empty, 1, 0x13F4CFEF, 0x01000013) 
#endif


/**
 *
 *Sets the state of the hardware line.
 *Setting a HW line's status only works for RS232 on PFC200.
 *
 *=============  ======================================================================================
 ***result codes**
 *-----------------------------------------------------------------------------------------------------
 *0                 SUCCESS
 *EPROTONOSUPPORT   Device is configured for RS485 protocol
 *EBADF             Bad handle to serial port
 *
 *=============  ======================================================================================
 */
typedef struct tagcomextra_set_line_state_struct
{
	RTS_IEC_HANDLE hCom;				/* VAR_INPUT */	
	RTS_IEC_INT eComLine;				/* VAR_INPUT, Enum: ECOMHWLINE */
	RTS_IEC_BOOL bLineState;			/* VAR_INPUT */	
	RTS_IEC_DWORD comextra_set_line_state;	/* VAR_OUTPUT */	
} comextra_set_line_state_struct;

void CDECL CDECL_EXT comextra_set_line_state(comextra_set_line_state_struct *p);
typedef void (CDECL CDECL_EXT* PFCOMEXTRA_SET_LINE_STATE_IEC) (comextra_set_line_state_struct *p);
#if defined(TSCCOMEXTRA_NOTIMPLEMENTED) || defined(COMEXTRA_SET_LINE_STATE_NOTIMPLEMENTED)
	#define USE_comextra_set_line_state
	#define EXT_comextra_set_line_state
	#define GET_comextra_set_line_state(fl)  ERR_NOTIMPLEMENTED
	#define CAL_comextra_set_line_state(p0) 
	#define CHK_comextra_set_line_state  FALSE
	#define EXP_comextra_set_line_state  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_comextra_set_line_state
	#define EXT_comextra_set_line_state
	#define GET_comextra_set_line_state(fl)  CAL_CMGETAPI( "comextra_set_line_state" ) 
	#define CAL_comextra_set_line_state  comextra_set_line_state
	#define CHK_comextra_set_line_state  TRUE
	#define EXP_comextra_set_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_set_line_state", (RTS_UINTPTR)comextra_set_line_state, 1, 0x08349B1A, 0x01000013) 
	#define EXTREF_ITF_comextra_set_line_state {(RTS_VOID_FCTPTR)comextra_set_line_state, "comextra_set_line_state", 0x08349B1A, 0x01000013}
#elif defined(MIXED_LINK) && !defined(TSCCOMEXTRA_EXTERNAL)
	#define USE_comextra_set_line_state
	#define EXT_comextra_set_line_state
	#define GET_comextra_set_line_state(fl)  CAL_CMGETAPI( "comextra_set_line_state" ) 
	#define CAL_comextra_set_line_state  comextra_set_line_state
	#define CHK_comextra_set_line_state  TRUE
	#define EXP_comextra_set_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_set_line_state", (RTS_UINTPTR)comextra_set_line_state, 1, 0x08349B1A, 0x01000013) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscComExtracomextra_set_line_state
	#define EXT_TscComExtracomextra_set_line_state
	#define GET_TscComExtracomextra_set_line_state  ERR_OK
	#define CAL_TscComExtracomextra_set_line_state  comextra_set_line_state
	#define CHK_TscComExtracomextra_set_line_state  TRUE
	#define EXP_TscComExtracomextra_set_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_set_line_state", (RTS_UINTPTR)comextra_set_line_state, 1, 0x08349B1A, 0x01000013) 
#elif defined(CPLUSPLUS)
	#define USE_comextra_set_line_state
	#define EXT_comextra_set_line_state
	#define GET_comextra_set_line_state(fl)  CAL_CMGETAPI( "comextra_set_line_state" ) 
	#define CAL_comextra_set_line_state  comextra_set_line_state
	#define CHK_comextra_set_line_state  TRUE
	#define EXP_comextra_set_line_state  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_set_line_state", (RTS_UINTPTR)comextra_set_line_state, 1, 0x08349B1A, 0x01000013) 
#else /* DYNAMIC_LINK */
	#define USE_comextra_set_line_state  PFCOMEXTRA_SET_LINE_STATE_IEC pfcomextra_set_line_state;
	#define EXT_comextra_set_line_state  extern PFCOMEXTRA_SET_LINE_STATE_IEC pfcomextra_set_line_state;
	#define GET_comextra_set_line_state(fl)  s_pfCMGetAPI2( "comextra_set_line_state", (RTS_VOID_FCTPTR *)&pfcomextra_set_line_state, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x08349B1A, 0x01000013)
	#define CAL_comextra_set_line_state  pfcomextra_set_line_state
	#define CHK_comextra_set_line_state  (pfcomextra_set_line_state != NULL)
	#define EXP_comextra_set_line_state   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comextra_set_line_state", (RTS_UINTPTR)comextra_set_line_state, 1, 0x08349B1A, 0x01000013) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/



typedef struct
{
	IBase_C *pBase;
} ITscComExtra_C;

#ifdef CPLUSPLUS
class ITscComExtra : public IBase
{
	public:
};
	#ifndef ITF_TscComExtra
		#define ITF_TscComExtra static ITscComExtra *pITscComExtra = NULL;
	#endif
	#define EXTITF_TscComExtra
#else	/*CPLUSPLUS*/
	typedef ITscComExtra_C		ITscComExtra;
	#ifndef ITF_TscComExtra
		#define ITF_TscComExtra
	#endif
	#define EXTITF_TscComExtra
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCCOMEXTRAITF_H_*/
