 /**
 * <interfacename>TscIoDrvCC100</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCIODRVCC100ITF_H_
#define _TSCIODRVCC100ITF_H_

#include "CmpStd.h"

 

 




#if !defined CC100_DALI_PRODUCTION
#define TSCIODRVCC100_DISABLE_EXTREF
#else // !defined CC100_DALI_PRODUCTION

/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>
 * calibsettypfn
 * </description>
 * <element name="CalibSetTypFn" type=OUT></element>
 * <element name="inId" type=IN>KanalId</element>
 * <element name="inTyp" type=IN>Kanaltyp</element>
*/
typedef struct tagcalibsettypfn_struct
{
	RTS_IEC_DWORD inId;
	RTS_IEC_WORD inTyp;
	RTS_IEC_RESULT CalibSetTypFn;
} calibsettypfn_struct;

void CDECL CDECL_EXT calibsettypfn(calibsettypfn_struct *p);
typedef void (CDECL CDECL_EXT* PFCALIBSETTYPFN_IEC) (calibsettypfn_struct *p);
#if defined(TSCIODRVCC100_NOTIMPLEMENTED) || defined(CALIBSETTYPFN_NOTIMPLEMENTED)
	#define USE_calibsettypfn
	#define EXT_calibsettypfn
	#define GET_calibsettypfn(fl)  ERR_NOTIMPLEMENTED
	#define CAL_calibsettypfn(p0) 
	#define CHK_calibsettypfn  FALSE
	#define EXP_calibsettypfn  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_calibsettypfn
	#define EXT_calibsettypfn
	#define GET_calibsettypfn(fl)  CAL_CMGETAPI( "calibsettypfn" ) 
	#define CAL_calibsettypfn  calibsettypfn
	#define CHK_calibsettypfn  TRUE
	#define EXP_calibsettypfn  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"calibsettypfn", (RTS_UINTPTR)calibsettypfn, 1, 0x130B1A6D, 0x03051347) 
	#define EXTREF_ITF_calibsettypfn {(RTS_VOID_FCTPTR)calibsettypfn, "calibsettypfn", 0x130B1A6D, 0x03051347}
#elif defined(MIXED_LINK) && !defined(TSCIODRVCC100_EXTERNAL)
	#define USE_calibsettypfn
	#define EXT_calibsettypfn
	#define GET_calibsettypfn(fl)  CAL_CMGETAPI( "calibsettypfn" ) 
	#define CAL_calibsettypfn  calibsettypfn
	#define CHK_calibsettypfn  TRUE
	#define EXP_calibsettypfn  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"calibsettypfn", (RTS_UINTPTR)calibsettypfn, 1, 0x130B1A6D, 0x03051347) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscIoDrvCC100calibsettypfn
	#define EXT_TscIoDrvCC100calibsettypfn
	#define GET_TscIoDrvCC100calibsettypfn  ERR_OK
	#define CAL_TscIoDrvCC100calibsettypfn  calibsettypfn
	#define CHK_TscIoDrvCC100calibsettypfn  TRUE
	#define EXP_TscIoDrvCC100calibsettypfn  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"calibsettypfn", (RTS_UINTPTR)calibsettypfn, 1, 0x130B1A6D, 0x03051347) 
#elif defined(CPLUSPLUS)
	#define USE_calibsettypfn
	#define EXT_calibsettypfn
	#define GET_calibsettypfn(fl)  CAL_CMGETAPI( "calibsettypfn" ) 
	#define CAL_calibsettypfn  calibsettypfn
	#define CHK_calibsettypfn  TRUE
	#define EXP_calibsettypfn  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"calibsettypfn", (RTS_UINTPTR)calibsettypfn, 1, 0x130B1A6D, 0x03051347) 
#else /* DYNAMIC_LINK */
	#define USE_calibsettypfn  PFCALIBSETTYPFN_IEC pfcalibsettypfn;
	#define EXT_calibsettypfn  extern PFCALIBSETTYPFN_IEC pfcalibsettypfn;
	#define GET_calibsettypfn(fl)  s_pfCMGetAPI2( "calibsettypfn", (RTS_VOID_FCTPTR *)&pfcalibsettypfn, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x130B1A6D, 0x03051347)
	#define CAL_calibsettypfn  pfcalibsettypfn
	#define CHK_calibsettypfn  (pfcalibsettypfn != NULL)
	#define EXP_calibsettypfn   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"calibsettypfn", (RTS_UINTPTR)calibsettypfn, 1, 0x130B1A6D, 0x03051347) 
#endif


/**
 * <description>
 * setconffun
 * </description>
 * <element name="SetConfFun" type=OUT></element>
*/
typedef struct tagsetconffun_struct
{
	RTS_IEC_DWORD inId;
	RTS_IEC_WORD inConf;
	RTS_IEC_RESULT SetConfFun;
} setconffun_struct;

void CDECL CDECL_EXT setconffun(setconffun_struct *p);
typedef void (CDECL CDECL_EXT* PFSETCONFFUN_IEC) (setconffun_struct *p);
#if defined(TSCIODRVCC100_NOTIMPLEMENTED) || defined(SETCONFFUN_NOTIMPLEMENTED)
	#define USE_setconffun
	#define EXT_setconffun
	#define GET_setconffun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_setconffun(p0) 
	#define CHK_setconffun  FALSE
	#define EXP_setconffun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_setconffun
	#define EXT_setconffun
	#define GET_setconffun(fl)  CAL_CMGETAPI( "setconffun" ) 
	#define CAL_setconffun  setconffun
	#define CHK_setconffun  TRUE
	#define EXP_setconffun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setconffun", (RTS_UINTPTR)setconffun, 1, 0x58ED258D, 0x03051347) 
	#define EXTREF_ITF_setconffun {(RTS_VOID_FCTPTR)setconffun, "setconffun", 0x58ED258D, 0x03051347}
#elif defined(MIXED_LINK) && !defined(TSCIODRVCC100_EXTERNAL)
	#define USE_setconffun
	#define EXT_setconffun
	#define GET_setconffun(fl)  CAL_CMGETAPI( "setconffun" ) 
	#define CAL_setconffun  setconffun
	#define CHK_setconffun  TRUE
	#define EXP_setconffun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setconffun", (RTS_UINTPTR)setconffun, 1, 0x58ED258D, 0x03051347) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscIoDrvCC100setconffun
	#define EXT_TscIoDrvCC100setconffun
	#define GET_TscIoDrvCC100setconffun  ERR_OK
	#define CAL_TscIoDrvCC100setconffun  setconffun
	#define CHK_TscIoDrvCC100setconffun  TRUE
	#define EXP_TscIoDrvCC100setconffun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setconffun", (RTS_UINTPTR)setconffun, 1, 0x58ED258D, 0x03051347) 
#elif defined(CPLUSPLUS)
	#define USE_setconffun
	#define EXT_setconffun
	#define GET_setconffun(fl)  CAL_CMGETAPI( "setconffun" ) 
	#define CAL_setconffun  setconffun
	#define CHK_setconffun  TRUE
	#define EXP_setconffun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setconffun", (RTS_UINTPTR)setconffun, 1, 0x58ED258D, 0x03051347) 
#else /* DYNAMIC_LINK */
	#define USE_setconffun  PFSETCONFFUN_IEC pfsetconffun;
	#define EXT_setconffun  extern PFSETCONFFUN_IEC pfsetconffun;
	#define GET_setconffun(fl)  s_pfCMGetAPI2( "setconffun", (RTS_VOID_FCTPTR *)&pfsetconffun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x58ED258D, 0x03051347)
	#define CAL_setconffun  pfsetconffun
	#define CHK_setconffun  (pfsetconffun != NULL)
	#define EXP_setconffun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setconffun", (RTS_UINTPTR)setconffun, 1, 0x58ED258D, 0x03051347) 
#endif


/**
 * <description>
 * settypefun
 * </description>
 * <element name="SetTypeFun" type=OUT></element>
*/
typedef struct tagsettypefun_struct
{
	RTS_IEC_WORD inType;
	RTS_IEC_RESULT SetTypeFun;
} settypefun_struct;

void CDECL CDECL_EXT settypefun(settypefun_struct *p);
typedef void (CDECL CDECL_EXT* PFSETTYPEFUN_IEC) (settypefun_struct *p);
#if defined(TSCIODRVCC100_NOTIMPLEMENTED) || defined(SETTYPEFUN_NOTIMPLEMENTED)
	#define USE_settypefun
	#define EXT_settypefun
	#define GET_settypefun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_settypefun(p0) 
	#define CHK_settypefun  FALSE
	#define EXP_settypefun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_settypefun
	#define EXT_settypefun
	#define GET_settypefun(fl)  CAL_CMGETAPI( "settypefun" ) 
	#define CAL_settypefun  settypefun
	#define CHK_settypefun  TRUE
	#define EXP_settypefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"settypefun", (RTS_UINTPTR)settypefun, 1, 0x93B43421, 0x03051347) 
	#define EXTREF_ITF_settypefun {(RTS_VOID_FCTPTR)settypefun, "settypefun", 0x93B43421, 0x03051347}
#elif defined(MIXED_LINK) && !defined(TSCIODRVCC100_EXTERNAL)
	#define USE_settypefun
	#define EXT_settypefun
	#define GET_settypefun(fl)  CAL_CMGETAPI( "settypefun" ) 
	#define CAL_settypefun  settypefun
	#define CHK_settypefun  TRUE
	#define EXP_settypefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"settypefun", (RTS_UINTPTR)settypefun, 1, 0x93B43421, 0x03051347) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscIoDrvCC100settypefun
	#define EXT_TscIoDrvCC100settypefun
	#define GET_TscIoDrvCC100settypefun  ERR_OK
	#define CAL_TscIoDrvCC100settypefun  settypefun
	#define CHK_TscIoDrvCC100settypefun  TRUE
	#define EXP_TscIoDrvCC100settypefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"settypefun", (RTS_UINTPTR)settypefun, 1, 0x93B43421, 0x03051347) 
#elif defined(CPLUSPLUS)
	#define USE_settypefun
	#define EXT_settypefun
	#define GET_settypefun(fl)  CAL_CMGETAPI( "settypefun" ) 
	#define CAL_settypefun  settypefun
	#define CHK_settypefun  TRUE
	#define EXP_settypefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"settypefun", (RTS_UINTPTR)settypefun, 1, 0x93B43421, 0x03051347) 
#else /* DYNAMIC_LINK */
	#define USE_settypefun  PFSETTYPEFUN_IEC pfsettypefun;
	#define EXT_settypefun  extern PFSETTYPEFUN_IEC pfsettypefun;
	#define GET_settypefun(fl)  s_pfCMGetAPI2( "settypefun", (RTS_VOID_FCTPTR *)&pfsettypefun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x93B43421, 0x03051347)
	#define CAL_settypefun  pfsettypefun
	#define CHK_settypefun  (pfsettypefun != NULL)
	#define EXP_settypefun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"settypefun", (RTS_UINTPTR)settypefun, 1, 0x93B43421, 0x03051347) 
#endif


/**
 * <description>
 * writevaluefun
 * </description>
 * <element name="WriteValueFun" type=OUT></element>
*/
typedef struct tagwritevaluefun_struct
{
	RTS_IEC_DWORD inId;
	RTS_IEC_WORD inValue;
	RTS_IEC_RESULT WriteValueFun;
} writevaluefun_struct;

void CDECL CDECL_EXT writevaluefun(writevaluefun_struct *p);
typedef void (CDECL CDECL_EXT* PFWRITEVALUEFUN_IEC) (writevaluefun_struct *p);
#if defined(TSCIODRVCC100_NOTIMPLEMENTED) || defined(WRITEVALUEFUN_NOTIMPLEMENTED)
	#define USE_writevaluefun
	#define EXT_writevaluefun
	#define GET_writevaluefun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_writevaluefun(p0) 
	#define CHK_writevaluefun  FALSE
	#define EXP_writevaluefun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_writevaluefun
	#define EXT_writevaluefun
	#define GET_writevaluefun(fl)  CAL_CMGETAPI( "writevaluefun" ) 
	#define CAL_writevaluefun  writevaluefun
	#define CHK_writevaluefun  TRUE
	#define EXP_writevaluefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"writevaluefun", (RTS_UINTPTR)writevaluefun, 1, 0xB9AB9E80, 0x03051347) 
	#define EXTREF_ITF_writevaluefun {(RTS_VOID_FCTPTR)writevaluefun, "writevaluefun", 0xB9AB9E80, 0x03051347}
#elif defined(MIXED_LINK) && !defined(TSCIODRVCC100_EXTERNAL)
	#define USE_writevaluefun
	#define EXT_writevaluefun
	#define GET_writevaluefun(fl)  CAL_CMGETAPI( "writevaluefun" ) 
	#define CAL_writevaluefun  writevaluefun
	#define CHK_writevaluefun  TRUE
	#define EXP_writevaluefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"writevaluefun", (RTS_UINTPTR)writevaluefun, 1, 0xB9AB9E80, 0x03051347) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscIoDrvCC100writevaluefun
	#define EXT_TscIoDrvCC100writevaluefun
	#define GET_TscIoDrvCC100writevaluefun  ERR_OK
	#define CAL_TscIoDrvCC100writevaluefun  writevaluefun
	#define CHK_TscIoDrvCC100writevaluefun  TRUE
	#define EXP_TscIoDrvCC100writevaluefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"writevaluefun", (RTS_UINTPTR)writevaluefun, 1, 0xB9AB9E80, 0x03051347) 
#elif defined(CPLUSPLUS)
	#define USE_writevaluefun
	#define EXT_writevaluefun
	#define GET_writevaluefun(fl)  CAL_CMGETAPI( "writevaluefun" ) 
	#define CAL_writevaluefun  writevaluefun
	#define CHK_writevaluefun  TRUE
	#define EXP_writevaluefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"writevaluefun", (RTS_UINTPTR)writevaluefun, 1, 0xB9AB9E80, 0x03051347) 
#else /* DYNAMIC_LINK */
	#define USE_writevaluefun  PFWRITEVALUEFUN_IEC pfwritevaluefun;
	#define EXT_writevaluefun  extern PFWRITEVALUEFUN_IEC pfwritevaluefun;
	#define GET_writevaluefun(fl)  s_pfCMGetAPI2( "writevaluefun", (RTS_VOID_FCTPTR *)&pfwritevaluefun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB9AB9E80, 0x03051347)
	#define CAL_writevaluefun  pfwritevaluefun
	#define CHK_writevaluefun  (pfwritevaluefun != NULL)
	#define EXP_writevaluefun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"writevaluefun", (RTS_UINTPTR)writevaluefun, 1, 0xB9AB9E80, 0x03051347) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/
#endif // !defined CC100_DALI_PRODUCTION



typedef struct
{
	IBase_C *pBase;
} ITscIoDrvCC100_C;

#ifdef CPLUSPLUS
class ITscIoDrvCC100 : public IBase
{
	public:
};
	#ifndef ITF_TscIoDrvCC100
		#define ITF_TscIoDrvCC100 static ITscIoDrvCC100 *pITscIoDrvCC100 = NULL;
	#endif
	#define EXTITF_TscIoDrvCC100
#else	/*CPLUSPLUS*/
	typedef ITscIoDrvCC100_C		ITscIoDrvCC100;
	#ifndef ITF_TscIoDrvCC100
		#define ITF_TscIoDrvCC100
	#endif
	#define EXTITF_TscIoDrvCC100
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCIODRVCC100ITF_H_*/
