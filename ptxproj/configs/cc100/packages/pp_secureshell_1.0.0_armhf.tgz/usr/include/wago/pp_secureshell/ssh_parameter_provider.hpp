//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     ssh_parameter_provider.hpp
///
///  \brief    Parameter provider for secure shell protocol settings.
///
///  \author   BA : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_PP_SECURESHELL_SSH_PARAMETER_PROVIDER_HPP_
#define INCLUDE_WAGO_PP_SECURESHELL_SSH_PARAMETER_PROVIDER_HPP_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>

namespace wago::pp_secureshell
{

/// \class ssh_parameter_provider
/// \brief This parameter providers allows to access secure shell ptotocol settings.
class ssh_parameter_provider final
    : public wago::wdx::base_parameter_provider
{
    ssh_parameter_provider(ssh_parameter_provider const &) = delete;
    ssh_parameter_provider& operator=(ssh_parameter_provider const &) = delete;
public:
    ssh_parameter_provider();
    ~ssh_parameter_provider() override;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
        std::vector<wago::wdx::value_request> value_requests) override;

private:
    class detail;
    detail * d_ptr;
};

} // namespace wago::pp_secureshell

#endif /* INCLUDE_WAGO_PP_SECURESHELL_SSH_PARAMETER_PROVIDER_HPP_ */
//---- End of source file ------------------------------------------------------

