/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component TscSysExt/name>
 *  <description> 
 *  This Component íncludes system extention for CoDeSys sys layer 
 *  </description>
 *  <copyright>
 *  Copyright (c) WAGO GmbH & Co. KG
 *  </copyright>
 */
#ifndef _TSCSYSEXTDEP_H_
#define _TSCSYSEXTDEP_H_

#define COMPONENT_NAME "TscSysExt" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscSysExt)
#define COMPONENT_NAME_UNQUOTED TscSysExt





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscSysExt 	ADDVENDORID(CMP_VENDORID, TSCSYSEXT_CLASSID_C)
#define CMPID_TscSysExt		  TSCSYSEXT_CMPID
#define ITFID_TscSysExt    ADDVENDORID(CMP_VENDORID, TSCSYSEXT_CLASSID_C)

#define CMP_VERSION         UINT32_C(0x00000200)
#define CMP_VERSION_STRING "0.0.2.0"
#define CMP_VERSION_RC      0,0,2,0
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"				






/**
 * \file TscSysExtItf.h
 */
#include "TscSysExtItf.h"








#include "SysOutItf.h"



        
     
     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pISysOut == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysOut, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysOut = (ISysOut *)pIBase->QueryInterface(pIBase, ITFID_ISysOut, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pISysOut = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pISysOut != NULL) \
        { \
            pIBase = (IBase *)pISysOut->QueryInterface(pISysOut, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysOut = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCSYSEXT_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)internal_atomic_xor_32, "internal_atomic_xor_32", 0xDD012F14, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_tdec_32, "internal_atomic_tdec_32", 0x71B327DB, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_tas_32, "internal_atomic_tas_32", 0x1B037469, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_tar_32, "internal_atomic_tar_32", 0x0FD26AEF, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_swap_ptr, "internal_atomic_swap_ptr", 0x9406527A, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_swap_64, "internal_atomic_swap_64", 0xC5263B22, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_swap_32, "internal_atomic_swap_32", 0x74B9BA02, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_read_ptr, "internal_atomic_read_ptr", 0x897AEAD6, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_read_64, "internal_atomic_read_64", 0xDB1BA57B, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_read_32, "internal_atomic_read_32", 0x49EF1EB6, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_or_32, "internal_atomic_or_32", 0x3B260D64, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_cas_ptr, "internal_atomic_cas_ptr", 0x0419BF66, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_cas_64, "internal_atomic_cas_64", 0x754AACCB, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_cas_32, "internal_atomic_cas_32", 0x33C6F648, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_and_32, "internal_atomic_and_32", 0x0C258DD7, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_add_ptr, "internal_atomic_add_ptr", 0xC32754DC, 0x01000000 },\
          { (RTS_VOID_FCTPTR)internal_atomic_add_32, "internal_atomic_add_32", 0x4553D542, 0x01000000 },\
          { (RTS_VOID_FCTPTR)sysext_getfreesize, "sysext_getfreesize", 0x3BB3D489, 0x01000200 },\
          { (RTS_VOID_FCTPTR)sysext_filegetstat, "sysext_filegetstat", 0x78D745D6, 0x01000200 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCSYSEXT_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                              
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCSYSEXT_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                              \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut      \
    /*obsolete USE_LogAdd*/     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut     \
    /*obsolete USE_LogAdd*/     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysOut     \
    /*obsolete EXT_LogAdd*/ 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscSysExt__Entry
#endif


#ifdef CPLUSPLUS

class CTscSysExt : public IWagoTscSysExt 
{
    public:
        CTscSysExt() : hTscSysExt(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscSysExt()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoTscSysExt *)this);            
            else if (iid == ITFID_IWagoTscSysExt)
                pItf = dynamic_cast<IWagoTscSysExt *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hTscSysExt;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
