//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libprogexec.h
///
///  \brief    Execute command via program starter daemon progexecd.
///
///  \author   HJH, MOe : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef PROGEXEC_H_
#define PROGEXEC_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdbool.h>
#include <stddef.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------

// test options
#define TST_RESPONSE    1U
#define TST_STDOUT      2U
#define TST_STDERR      4U
#define TST_RETSTAT     8U
#define TST_ALL         15U

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus


//------------------------------------------------------------------------------
///
/// Execute command via program starter daemon progexecd.
///
/// \param cmd
///   Command to execute via progexecd. 'RUN' or 'RUNSH' has to be placed in front of the command to execute.
///   RUN:   Run command.
///   RUNSH: Run command in a shell environment.
/// \param rundir
///   Run directory of progexec daemon, default: /var/run/progexecd
/// \param socketname
///   Name of socket to connect to progexecd, default: ipcsocket
/// \param opt
///   Configuration of output.
///   TST_RESPONSE : Get response of progexecd including return value, length of stdout and length of stderr messages
///                  of executed command.
///   TST_STDOUT   : Print stdout of executed command to stdout.
///   TST_STDERR   : Print stderr of executed command to stdout.
///   TST_RETSTAT  : Return executed command's return value instead of function's return value.
///   TST_ALL      : Combine options TST_RESPONSE, TST_STDOUT, TST_STDERR and TST_RETSTAT.
/// \return
///   0 in case of successful execution,
///  -1 in case of error,
///  or return value of executed command in case TST_RETSTAT or TST_ALL is specified.
//------------------------------------------------------------------------------
int progexec_run_client(char * const cmd,
                        char const * const rundir,
                        char const * const socketname,
                        size_t const opt);


//------------------------------------------------------------------------------
///
/// Execute command via program starter daemon progexecd.
///
/// \param szCmd
///   Command to execute via progexecd.
/// \param szRunDir
///   Run directory of progexec daemon, default: /var/run/progexecd
/// \param szSocketName
///   Name of socket to connect to progexecd, default: ipcsocket
/// \param szOutput
///   Buffer to store stdout of executed command.
/// \param outputLength
///   Length of stdout buffer.
/// \param szError
///   Buffer to store stderr of executed command.
/// \param errorLength
///   Length of stderr buffer.
/// \param pReturnValue
///   Return value of executed program.
///
/// \return
///   0 in case of successful execution,
///  -ETIMEDOUT in case of a timeout,
///  -1 otherwise.
//------------------------------------------------------------------------------
int progexec_run_command(char const * const szCmd,
                         char const * const szRunDir,
                         char const * const szSocketName,
                         char * const szOutput,
                         size_t const outputLength,
                         char * const szError,
                         size_t const errorLength,
                         int * const pReturnValue);


//------------------------------------------------------------------------------
///
/// Execute command via program starter daemon progexecd in a shell environment.
///
/// \param szCmd
///   Command to execute via progexecd in a shell environment.
/// \param szRunDir
///   Run directory of progexec daemon, default: /var/run/progexecd
/// \param szSocketName
///   Name of socket to connect to progexecd, default: ipcsocket
/// \param szOutput
///   Buffer to store stdout of executed command.
/// \param outputLength
///   Length of stdout buffer.
/// \param szError
///   Buffer to store stderr of executed command.
/// \param errorLength
///   Length of stderr buffer.
/// \param pReturnValue
///   Return value of executed program.
///
/// \return
///   0 in case of successful execution,
///  -ETIMEDOUT in case of a timeout,
///  -1 otherwise.
//------------------------------------------------------------------------------
int progexec_run_shell(char const * const szCmd,
                       char const * const szRunDir,
                       char const * const szSocketName,
                       char * const szOutput,
                       size_t const outputLength,
                       char * const szError,
                       size_t const errorLength,
                       int * const pReturnValue,
                       int const timeout_ms);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function implementation
//------------------------------------------------------------------------------


#endif /* PROGEXEC_H_ */
//---- End of source file ------------------------------------------------------

