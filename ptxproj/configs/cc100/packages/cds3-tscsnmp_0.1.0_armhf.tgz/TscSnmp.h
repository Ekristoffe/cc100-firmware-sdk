//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     TscSnmp.h
///
///  \version  $Revision$
///
///  \brief    <Insert description here>
///
///  \author   <author> : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef TSCSNMP_H_
#define TSCSNMP_H_

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#undef LOG_INFO
#undef LOG_WARNING
#undef LOG_DEBUG
#include "CmpStd.h"
#include "CmpErrors.h"
#include "CmpItf.h"
#include "TscSnmpDep.h"

#include "WAGO_FbExecute.h"

#include <wagosnmp_API.h>

typedef struct {
    tWagoSnmpTrcvType   trcvType;
    long                version;
    int retries;
    int timeout_us;
    typSNMP_TLV         * typData;          /* VAR_OUTPUT */  /* Structured response data in Type-Length-Value(TLV) format */
    RTS_IEC_STRING    * sHost;      /* VAR_INPUT */ /* Hostname or IP-address in "dotted decimal format" */
    size_t              szHost;
    RTS_IEC_STRING    * sOID;     /* VAR_INPUT */ /* SNMP unique object identifier(OID) of requested data, e.g. '1.3.6.1.2.1.1.6.0' for "sysLocation" */
    size_t              szOID;
    RTS_IEC_STRING    * sEngineId;
    size_t              szEngineId;
    RTS_IEC_STRING    * sCommunity;    /* VAR_INPUT */ /* Community string typical: "public" */
    size_t              szCommunity;
    RTS_IEC_STRING    * sUsername;    /* VAR_INPUT */ /* SNMP-username. */
    size_t              szUsername;
    RTS_IEC_INT       * typSecLevel;      /* VAR_INPUT, Enum: TSNMP_SECURITYLEVEL */
    RTS_IEC_INT       * typAuthProt;      /* VAR_INPUT, Enum: TSNMP_AUTHENTICATIONPROTOCOL */
    RTS_IEC_STRING    * sAuthPass;    /* VAR_INPUT */ /* Password for the given username */
    size_t              szAuthPass;
    RTS_IEC_INT       * typPrivProt;      /* VAR_INPUT, Enum: TSNMP_PRIVACYPROTOCOL */
    RTS_IEC_STRING    * sPrivPass;    /* VAR_INPUT */ /* Passphrase for the given encryption type and username */
    size_t              szPrivPass;      /* VAR_INPUT, Enum: TSNMP_PRIVACYPROTOCOL */
    RTS_IEC_STRING    * sInformOID;
    size_t              szInformOID;
}tSnmpFb;



typedef struct {
    enum eMsgType            msgType;
    long                     version;
    int32_t                  status;
    tSnmpFb                  trcvData;
}tSnmpTraceive;



#define FB_INIT_COMMON(x) .typData=&(x->typData),\
    .timeout_us=-1,\
    .retries=-1,\
    .sHost=x->sHost,\
    .szHost=sizeof(x->sHost),\
    .sOID=NULL,\
    .szOID=0,\
    .sEngineId=NULL,\
    .szEngineId=0,\
    .sCommunity=NULL,\
    .szCommunity=0,\
    .sUsername=NULL,\
    .szUsername=0,\
    .typSecLevel=0,\
    .typAuthProt=0,\
    .sAuthPass=NULL,\
    .szAuthPass=0,\
    .typPrivProt=0,\
    .sPrivPass=NULL,\
    .szPrivPass=0,\
    .sInformOID=NULL,\
    .szInformOID=0

#define FB_MGR_INIT_COMMON(x) FB_INIT_COMMON(x),\
    .sOID=x->sOID,\
    .szOID=sizeof(x->sOID)

#define FB_INFORM_INIT_COMMON(x) FB_INIT_COMMON(x),\
    .sOID=x->sEnterprise,\
    .szOID=sizeof(x->sEnterprise),\
    .sInformOID=x->sOID,\
    .szInformOID=sizeof(x->sOID)

#define FB_V1_V2C_DATA_INIT(x) { FB_MGR_INIT_COMMON(x), \
    .timeout_us= (x->liTimeout_ms == -1) ? -1 :(1000 * x->liTimeout_ms),\
    .retries=x->liRetries,\
    .sCommunity=x->sCommunity,\
    .szCommunity=sizeof(x->sCommunity)}

#define FB_V1_V2C_INFORM_INIT(x) { FB_INFORM_INIT_COMMON(x), \
    .sCommunity=x->sCommunity,\
    .szCommunity=sizeof(x->sCommunity)}

#define FB_V3_DATA_INIT(x) { FB_MGR_INIT_COMMON(x), \
    .timeout_us= x->liTimeout_ms == -1 ? -1 :(1000 * x->liTimeout_ms),\
    .retries=x->liRetries,\
    .sUsername=x->sUsername,\
    .szUsername=sizeof(x->sUsername),\
    .typSecLevel=&(x->typSecLevel),\
    .typAuthProt=&(x->typAuthProt),\
    .sAuthPass=x->sAuthPass,\
    .szAuthPass=sizeof(x->sAuthPass),\
    .typPrivProt=&(x->typPrivProt),\
    .sPrivPass=x->sPrivPass,\
    .szPrivPass=sizeof(x->sPrivPass)}

#define FB_V3_INFORM_INIT(x) { FB_INFORM_INIT_COMMON(x), \
    .sEngineId=x->sEngineID,\
    .szEngineId=sizeof(x->sEngineID),\
    .sUsername=x->sUsername,\
    .szUsername=sizeof(x->sUsername),\
    .typSecLevel=&(x->typSecLevel),\
    .typAuthProt=&(x->typAuthProt),\
    .sAuthPass=x->sAuthPass,\
    .szAuthPass=sizeof(x->sAuthPass),\
    .typPrivProt=&(x->typPrivProt),\
    .sPrivPass=x->sPrivPass,\
    .szPrivPass=sizeof(x->sPrivPass)}

#define DUPLICATE_MEM(p,d,m,r) if(p->s##m!=NULL){d->s##m=CAL_SysMemAllocData(COMPONENT_NAME, p->sz##m, r);d->s##m=memcpy(d->s##m,p->s##m,p->sz##m);}
#define RESUME_MEM(p,d,m) if((p->s##m!=NULL)&&(d->s##m!=NULL)){p->s##m=memcpy(p->s##m,d->s##m,p->sz##m);}


#endif /* TSCSNMP_H_ */
//---- End of source file ------------------------------------------------------
