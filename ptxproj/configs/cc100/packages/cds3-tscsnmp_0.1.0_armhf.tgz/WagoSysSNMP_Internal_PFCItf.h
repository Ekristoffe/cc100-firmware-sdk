 /**
 * <interfacename>WagoSysSNMP_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSSNMP_INTERNAL_PFCITF_H_
#define _WAGOSYSSNMP_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>snmp_dint_to_tlv</description>
 */
typedef struct tagsnmp_dint_to_tlv_struct
{
	RTS_IEC_DINT diInput;				/* VAR_INPUT */	/* Input-Value */
	RTS_IEC_INT typDatatype;			/* VAR_INPUT, Enum: ESNMP_TLV_DATATYPE */
	typSNMP_TLV *typData;				/* VAR_IN_OUT */	/* Container for TLV */
	RTS_IEC_DINT SNMP_DINT_TO_TLV;		/* VAR_OUTPUT */	
} snmp_dint_to_tlv_struct;

void CDECL CDECL_EXT snmp_dint_to_tlv(snmp_dint_to_tlv_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_DINT_TO_TLV_IEC) (snmp_dint_to_tlv_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_DINT_TO_TLV_NOTIMPLEMENTED)
	#define USE_snmp_dint_to_tlv
	#define EXT_snmp_dint_to_tlv
	#define GET_snmp_dint_to_tlv(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_dint_to_tlv(p0) 
	#define CHK_snmp_dint_to_tlv  FALSE
	#define EXP_snmp_dint_to_tlv  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_dint_to_tlv
	#define EXT_snmp_dint_to_tlv
	#define GET_snmp_dint_to_tlv(fl)  CAL_CMGETAPI( "snmp_dint_to_tlv" ) 
	#define CAL_snmp_dint_to_tlv  snmp_dint_to_tlv
	#define CHK_snmp_dint_to_tlv  TRUE
	#define EXP_snmp_dint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_dint_to_tlv", (RTS_UINTPTR)snmp_dint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200) 
	#define EXTREF_ITF_snmp_dint_to_tlv {(RTS_VOID_FCTPTR)snmp_dint_to_tlv, "snmp_dint_to_tlv", RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_dint_to_tlv
	#define EXT_snmp_dint_to_tlv
	#define GET_snmp_dint_to_tlv(fl)  CAL_CMGETAPI( "snmp_dint_to_tlv" ) 
	#define CAL_snmp_dint_to_tlv  snmp_dint_to_tlv
	#define CHK_snmp_dint_to_tlv  TRUE
	#define EXP_snmp_dint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_dint_to_tlv", (RTS_UINTPTR)snmp_dint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_dint_to_tlv
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_dint_to_tlv
	#define GET_WagoSysSNMP_Internal_PFCsnmp_dint_to_tlv  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_dint_to_tlv  snmp_dint_to_tlv
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_dint_to_tlv  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_dint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_dint_to_tlv", (RTS_UINTPTR)snmp_dint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_dint_to_tlv
	#define EXT_snmp_dint_to_tlv
	#define GET_snmp_dint_to_tlv(fl)  CAL_CMGETAPI( "snmp_dint_to_tlv" ) 
	#define CAL_snmp_dint_to_tlv  snmp_dint_to_tlv
	#define CHK_snmp_dint_to_tlv  TRUE
	#define EXP_snmp_dint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_dint_to_tlv", (RTS_UINTPTR)snmp_dint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_dint_to_tlv  PFSNMP_DINT_TO_TLV_IEC pfsnmp_dint_to_tlv;
	#define EXT_snmp_dint_to_tlv  extern PFSNMP_DINT_TO_TLV_IEC pfsnmp_dint_to_tlv;
	#define GET_snmp_dint_to_tlv(fl)  s_pfCMGetAPI2( "snmp_dint_to_tlv", (RTS_VOID_FCTPTR *)&pfsnmp_dint_to_tlv, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200)
	#define CAL_snmp_dint_to_tlv  pfsnmp_dint_to_tlv
	#define CHK_snmp_dint_to_tlv  (pfsnmp_dint_to_tlv != NULL)
	#define EXP_snmp_dint_to_tlv   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_dint_to_tlv", (RTS_UINTPTR)snmp_dint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200) 
#endif


/**
 * <description>snmp_get__main</description>
 */
typedef struct tagsnmp_get_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of SNMP_GET */

	RTS_IEC_BOOL xExecute;				/* VAR_INPUT */	/* Enable SNMP-request */
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) of requested data, e.g. '1.3.6.1.2.1.1.6.0' for "sysLocation" */
	RTS_IEC_STRING sCommunity[64];		/* VAR_INPUT */	/* Community string typical: "public" */
	RTS_IEC_LINT liTimeout_ms;			/* VAR_INPUT */	/* Request timeout in milliseconds */
	RTS_IEC_LINT liRetries;				/* VAR_INPUT */	/* Number of retries until timeout is reported. Total timeout = uiTimeout_ms * (uiReties + 1) */
	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Function block has done its work an outgoing data can be used */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Function block is already Busy */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	/* Function block is in error state */
	RTS_IEC_DINT diStatus;				/* VAR_OUTPUT */	/* Return-Code */
	typSNMP_TLV typData;				/* VAR_OUTPUT */	/* Structured response data in Type-Length-Value(TLV) format */
	RTS_IEC_BOOL xOldEnable;			/* Local variable */	
	RTS_IEC_DINT *diData;				/* Local variable */	
	RTS_IEC_HANDLE diSyncHandle;		/* Local variable */	
} snmp_get_struct;

/**
 * <description>snmp_get_main</description>
 */
typedef struct tagsnmp_get_main_struct
{
	snmp_get_struct *pInstance;			/* VAR_INPUT */	
} snmp_get_main_struct;

void CDECL CDECL_EXT snmp_get__main(snmp_get_main_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET__MAIN_IEC) (snmp_get_main_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET__MAIN_NOTIMPLEMENTED)
	#define USE_snmp_get__main
	#define EXT_snmp_get__main
	#define GET_snmp_get__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get__main(p0) 
	#define CHK_snmp_get__main  FALSE
	#define EXP_snmp_get__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get__main
	#define EXT_snmp_get__main
	#define GET_snmp_get__main(fl)  CAL_CMGETAPI( "snmp_get__main" ) 
	#define CAL_snmp_get__main  snmp_get__main
	#define CHK_snmp_get__main  TRUE
	#define EXP_snmp_get__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__main", (RTS_UINTPTR)snmp_get__main, 1, RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200) 
	#define EXTREF_ITF_snmp_get__main {(RTS_VOID_FCTPTR)snmp_get__main, "snmp_get__main", RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get__main
	#define EXT_snmp_get__main
	#define GET_snmp_get__main(fl)  CAL_CMGETAPI( "snmp_get__main" ) 
	#define CAL_snmp_get__main  snmp_get__main
	#define CHK_snmp_get__main  TRUE
	#define EXP_snmp_get__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__main", (RTS_UINTPTR)snmp_get__main, 1, RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get__main
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get__main
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get__main  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get__main  snmp_get__main
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get__main  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__main", (RTS_UINTPTR)snmp_get__main, 1, RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get__main
	#define EXT_snmp_get__main
	#define GET_snmp_get__main(fl)  CAL_CMGETAPI( "snmp_get__main" ) 
	#define CAL_snmp_get__main  snmp_get__main
	#define CHK_snmp_get__main  TRUE
	#define EXP_snmp_get__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__main", (RTS_UINTPTR)snmp_get__main, 1, RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get__main  PFSNMP_GET__MAIN_IEC pfsnmp_get__main;
	#define EXT_snmp_get__main  extern PFSNMP_GET__MAIN_IEC pfsnmp_get__main;
	#define GET_snmp_get__main(fl)  s_pfCMGetAPI2( "snmp_get__main", (RTS_VOID_FCTPTR *)&pfsnmp_get__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200)
	#define CAL_snmp_get__main  pfsnmp_get__main
	#define CHK_snmp_get__main  (pfsnmp_get__main != NULL)
	#define EXP_snmp_get__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__main", (RTS_UINTPTR)snmp_get__main, 1, RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200) 
#endif


/**
 * <description>snmp_get_fb_init</description>
 */
typedef struct tagsnmp_get_fb_init_struct
{
	snmp_get_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} snmp_get_fb_init_struct;

void CDECL CDECL_EXT snmp_get__fb_init(snmp_get_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET__FB_INIT_IEC) (snmp_get_fb_init_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET__FB_INIT_NOTIMPLEMENTED)
	#define USE_snmp_get__fb_init
	#define EXT_snmp_get__fb_init
	#define GET_snmp_get__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get__fb_init(p0) 
	#define CHK_snmp_get__fb_init  FALSE
	#define EXP_snmp_get__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get__fb_init
	#define EXT_snmp_get__fb_init
	#define GET_snmp_get__fb_init(fl)  CAL_CMGETAPI( "snmp_get__fb_init" ) 
	#define CAL_snmp_get__fb_init  snmp_get__fb_init
	#define CHK_snmp_get__fb_init  TRUE
	#define EXP_snmp_get__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_init", (RTS_UINTPTR)snmp_get__fb_init, 1, RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200) 
	#define EXTREF_ITF_snmp_get__fb_init {(RTS_VOID_FCTPTR)snmp_get__fb_init, "snmp_get__fb_init", RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get__fb_init
	#define EXT_snmp_get__fb_init
	#define GET_snmp_get__fb_init(fl)  CAL_CMGETAPI( "snmp_get__fb_init" ) 
	#define CAL_snmp_get__fb_init  snmp_get__fb_init
	#define CHK_snmp_get__fb_init  TRUE
	#define EXP_snmp_get__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_init", (RTS_UINTPTR)snmp_get__fb_init, 1, RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get__fb_init
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get__fb_init
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get__fb_init  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get__fb_init  snmp_get__fb_init
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get__fb_init  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_init", (RTS_UINTPTR)snmp_get__fb_init, 1, RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get__fb_init
	#define EXT_snmp_get__fb_init
	#define GET_snmp_get__fb_init(fl)  CAL_CMGETAPI( "snmp_get__fb_init" ) 
	#define CAL_snmp_get__fb_init  snmp_get__fb_init
	#define CHK_snmp_get__fb_init  TRUE
	#define EXP_snmp_get__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_init", (RTS_UINTPTR)snmp_get__fb_init, 1, RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get__fb_init  PFSNMP_GET__FB_INIT_IEC pfsnmp_get__fb_init;
	#define EXT_snmp_get__fb_init  extern PFSNMP_GET__FB_INIT_IEC pfsnmp_get__fb_init;
	#define GET_snmp_get__fb_init(fl)  s_pfCMGetAPI2( "snmp_get__fb_init", (RTS_VOID_FCTPTR *)&pfsnmp_get__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200)
	#define CAL_snmp_get__fb_init  pfsnmp_get__fb_init
	#define CHK_snmp_get__fb_init  (pfsnmp_get__fb_init != NULL)
	#define EXP_snmp_get__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_init", (RTS_UINTPTR)snmp_get__fb_init, 1, RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200) 
#endif


/**
 * <description>snmp_get_fb_exit</description>
 */
typedef struct tagsnmp_get_fb_exit_struct
{
	snmp_get_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} snmp_get_fb_exit_struct;

void CDECL CDECL_EXT snmp_get__fb_exit(snmp_get_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET__FB_EXIT_IEC) (snmp_get_fb_exit_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET__FB_EXIT_NOTIMPLEMENTED)
	#define USE_snmp_get__fb_exit
	#define EXT_snmp_get__fb_exit
	#define GET_snmp_get__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get__fb_exit(p0) 
	#define CHK_snmp_get__fb_exit  FALSE
	#define EXP_snmp_get__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get__fb_exit
	#define EXT_snmp_get__fb_exit
	#define GET_snmp_get__fb_exit(fl)  CAL_CMGETAPI( "snmp_get__fb_exit" ) 
	#define CAL_snmp_get__fb_exit  snmp_get__fb_exit
	#define CHK_snmp_get__fb_exit  TRUE
	#define EXP_snmp_get__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_exit", (RTS_UINTPTR)snmp_get__fb_exit, 1, RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200) 
	#define EXTREF_ITF_snmp_get__fb_exit {(RTS_VOID_FCTPTR)snmp_get__fb_exit, "snmp_get__fb_exit", RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get__fb_exit
	#define EXT_snmp_get__fb_exit
	#define GET_snmp_get__fb_exit(fl)  CAL_CMGETAPI( "snmp_get__fb_exit" ) 
	#define CAL_snmp_get__fb_exit  snmp_get__fb_exit
	#define CHK_snmp_get__fb_exit  TRUE
	#define EXP_snmp_get__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_exit", (RTS_UINTPTR)snmp_get__fb_exit, 1, RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get__fb_exit
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get__fb_exit
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get__fb_exit  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get__fb_exit  snmp_get__fb_exit
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get__fb_exit  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_exit", (RTS_UINTPTR)snmp_get__fb_exit, 1, RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get__fb_exit
	#define EXT_snmp_get__fb_exit
	#define GET_snmp_get__fb_exit(fl)  CAL_CMGETAPI( "snmp_get__fb_exit" ) 
	#define CAL_snmp_get__fb_exit  snmp_get__fb_exit
	#define CHK_snmp_get__fb_exit  TRUE
	#define EXP_snmp_get__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_exit", (RTS_UINTPTR)snmp_get__fb_exit, 1, RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get__fb_exit  PFSNMP_GET__FB_EXIT_IEC pfsnmp_get__fb_exit;
	#define EXT_snmp_get__fb_exit  extern PFSNMP_GET__FB_EXIT_IEC pfsnmp_get__fb_exit;
	#define GET_snmp_get__fb_exit(fl)  s_pfCMGetAPI2( "snmp_get__fb_exit", (RTS_VOID_FCTPTR *)&pfsnmp_get__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200)
	#define CAL_snmp_get__fb_exit  pfsnmp_get__fb_exit
	#define CHK_snmp_get__fb_exit  (pfsnmp_get__fb_exit != NULL)
	#define EXP_snmp_get__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get__fb_exit", (RTS_UINTPTR)snmp_get__fb_exit, 1, RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200) 
#endif


/**
 * <description>snmp_get_custom_oid_value</description>
 */
typedef struct tagsnmp_get_custom_oid_value_struct
{
	RTS_IEC_STRING sOID[129];			/* VAR_INPUT */	
	typSNMP_TLV *typData;				/* VAR_IN_OUT */	
	RTS_IEC_DINT SNMP_GET_CUSTOM_OID_VALUE;	/* VAR_OUTPUT */	
} snmp_get_custom_oid_value_struct;

void CDECL CDECL_EXT snmp_get_custom_oid_value(snmp_get_custom_oid_value_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET_CUSTOM_OID_VALUE_IEC) (snmp_get_custom_oid_value_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET_CUSTOM_OID_VALUE_NOTIMPLEMENTED)
	#define USE_snmp_get_custom_oid_value
	#define EXT_snmp_get_custom_oid_value
	#define GET_snmp_get_custom_oid_value(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get_custom_oid_value(p0) 
	#define CHK_snmp_get_custom_oid_value  FALSE
	#define EXP_snmp_get_custom_oid_value  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get_custom_oid_value
	#define EXT_snmp_get_custom_oid_value
	#define GET_snmp_get_custom_oid_value(fl)  CAL_CMGETAPI( "snmp_get_custom_oid_value" ) 
	#define CAL_snmp_get_custom_oid_value  snmp_get_custom_oid_value
	#define CHK_snmp_get_custom_oid_value  TRUE
	#define EXP_snmp_get_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_custom_oid_value", (RTS_UINTPTR)snmp_get_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200) 
	#define EXTREF_ITF_snmp_get_custom_oid_value {(RTS_VOID_FCTPTR)snmp_get_custom_oid_value, "snmp_get_custom_oid_value", RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get_custom_oid_value
	#define EXT_snmp_get_custom_oid_value
	#define GET_snmp_get_custom_oid_value(fl)  CAL_CMGETAPI( "snmp_get_custom_oid_value" ) 
	#define CAL_snmp_get_custom_oid_value  snmp_get_custom_oid_value
	#define CHK_snmp_get_custom_oid_value  TRUE
	#define EXP_snmp_get_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_custom_oid_value", (RTS_UINTPTR)snmp_get_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get_custom_oid_value
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get_custom_oid_value
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get_custom_oid_value  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get_custom_oid_value  snmp_get_custom_oid_value
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get_custom_oid_value  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_custom_oid_value", (RTS_UINTPTR)snmp_get_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get_custom_oid_value
	#define EXT_snmp_get_custom_oid_value
	#define GET_snmp_get_custom_oid_value(fl)  CAL_CMGETAPI( "snmp_get_custom_oid_value" ) 
	#define CAL_snmp_get_custom_oid_value  snmp_get_custom_oid_value
	#define CHK_snmp_get_custom_oid_value  TRUE
	#define EXP_snmp_get_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_custom_oid_value", (RTS_UINTPTR)snmp_get_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get_custom_oid_value  PFSNMP_GET_CUSTOM_OID_VALUE_IEC pfsnmp_get_custom_oid_value;
	#define EXT_snmp_get_custom_oid_value  extern PFSNMP_GET_CUSTOM_OID_VALUE_IEC pfsnmp_get_custom_oid_value;
	#define GET_snmp_get_custom_oid_value(fl)  s_pfCMGetAPI2( "snmp_get_custom_oid_value", (RTS_VOID_FCTPTR *)&pfsnmp_get_custom_oid_value, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200)
	#define CAL_snmp_get_custom_oid_value  pfsnmp_get_custom_oid_value
	#define CHK_snmp_get_custom_oid_value  (pfsnmp_get_custom_oid_value != NULL)
	#define EXP_snmp_get_custom_oid_value   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_custom_oid_value", (RTS_UINTPTR)snmp_get_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200) 
#endif


/**
 * <description>snmp_get_error_string</description>
 */
typedef struct tagsnmp_get_error_string_struct
{
	RTS_IEC_DINT diErrorCode;			/* VAR_INPUT */	
	RTS_IEC_DINT SNMP_GET_ERROR_STRING;	/* VAR_OUTPUT */	
	RTS_IEC_STRING sString[81];			/* VAR_OUTPUT */	
} snmp_get_error_string_struct;

void CDECL CDECL_EXT snmp_get_error_string(snmp_get_error_string_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET_ERROR_STRING_IEC) (snmp_get_error_string_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET_ERROR_STRING_NOTIMPLEMENTED)
	#define USE_snmp_get_error_string
	#define EXT_snmp_get_error_string
	#define GET_snmp_get_error_string(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get_error_string(p0) 
	#define CHK_snmp_get_error_string  FALSE
	#define EXP_snmp_get_error_string  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get_error_string
	#define EXT_snmp_get_error_string
	#define GET_snmp_get_error_string(fl)  CAL_CMGETAPI( "snmp_get_error_string" ) 
	#define CAL_snmp_get_error_string  snmp_get_error_string
	#define CHK_snmp_get_error_string  TRUE
	#define EXP_snmp_get_error_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_error_string", (RTS_UINTPTR)snmp_get_error_string, 1, 0x5B86A025, 0x01020200) 
	#define EXTREF_ITF_snmp_get_error_string {(RTS_VOID_FCTPTR)snmp_get_error_string, "snmp_get_error_string", 0x5B86A025, 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get_error_string
	#define EXT_snmp_get_error_string
	#define GET_snmp_get_error_string(fl)  CAL_CMGETAPI( "snmp_get_error_string" ) 
	#define CAL_snmp_get_error_string  snmp_get_error_string
	#define CHK_snmp_get_error_string  TRUE
	#define EXP_snmp_get_error_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_error_string", (RTS_UINTPTR)snmp_get_error_string, 1, 0x5B86A025, 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get_error_string
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get_error_string
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get_error_string  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get_error_string  snmp_get_error_string
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get_error_string  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get_error_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_error_string", (RTS_UINTPTR)snmp_get_error_string, 1, 0x5B86A025, 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get_error_string
	#define EXT_snmp_get_error_string
	#define GET_snmp_get_error_string(fl)  CAL_CMGETAPI( "snmp_get_error_string" ) 
	#define CAL_snmp_get_error_string  snmp_get_error_string
	#define CHK_snmp_get_error_string  TRUE
	#define EXP_snmp_get_error_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_error_string", (RTS_UINTPTR)snmp_get_error_string, 1, 0x5B86A025, 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get_error_string  PFSNMP_GET_ERROR_STRING_IEC pfsnmp_get_error_string;
	#define EXT_snmp_get_error_string  extern PFSNMP_GET_ERROR_STRING_IEC pfsnmp_get_error_string;
	#define GET_snmp_get_error_string(fl)  s_pfCMGetAPI2( "snmp_get_error_string", (RTS_VOID_FCTPTR *)&pfsnmp_get_error_string, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5B86A025, 0x01020200)
	#define CAL_snmp_get_error_string  pfsnmp_get_error_string
	#define CHK_snmp_get_error_string  (pfsnmp_get_error_string != NULL)
	#define EXP_snmp_get_error_string   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_error_string", (RTS_UINTPTR)snmp_get_error_string, 1, 0x5B86A025, 0x01020200) 
#endif


/**
 * <description>snmp_get_v3__main</description>
 */
typedef struct tagsnmp_get_v3_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of SNMP_GET_V3 */

	RTS_IEC_BOOL xExecute;				/* VAR_INPUT */	/* Enable SNMP-request */
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) of requested data, e.g. '1.3.6.1.2.1.1.6.0' for "sysLocation" */
	RTS_IEC_STRING sUsername[128];		/* VAR_INPUT */	/* SNMP-Username. */
	RTS_IEC_INT typSecLevel;			/* VAR_INPUT, Enum: ESNMP_SECURITYLEVEL */
	RTS_IEC_INT typAuthProt;			/* VAR_INPUT, Enum: ESNMP_AUTHENTICATIONPROTOCOL */
	RTS_IEC_STRING sAuthPass[128];		/* VAR_INPUT */	/* Password for the given username */
	RTS_IEC_INT typPrivProt;			/* VAR_INPUT, Enum: ESNMP_PRIVACYPROTOCOL */
	RTS_IEC_STRING sPrivPass[128];		/* VAR_INPUT */	/* Passphrase for the given encryption type and username */
	RTS_IEC_LINT liTimeout_ms;			/* VAR_INPUT */	/* Request timeout in milliseconds */
	RTS_IEC_LINT liRetries;				/* VAR_INPUT */	/* Number of retries until timeout is reported. Total timeout = uiTimeout_ms * (uiReties + 1) */
	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Function block has done its work an outgoing data can be used */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Function block is already busy */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	/* Function block has an error */
	RTS_IEC_DINT diStatus;				/* VAR_OUTPUT */	/* Return-code */
	typSNMP_TLV typData;				/* VAR_OUTPUT */	/* Structured response data in Type-Length-Value (TLV) format */
	RTS_IEC_BOOL xOldEnable;			/* Local variable */	
	RTS_IEC_DINT *diData;				/* Local variable */	
	RTS_IEC_HANDLE diSyncHandle;		/* Local variable */	
} snmp_get_v3_struct;

/**
 * <description>snmp_get_v3_main</description>
 */
typedef struct tagsnmp_get_v3_main_struct
{
	snmp_get_v3_struct *pInstance;		/* VAR_INPUT */	
} snmp_get_v3_main_struct;

void CDECL CDECL_EXT snmp_get_v3__main(snmp_get_v3_main_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET_V3__MAIN_IEC) (snmp_get_v3_main_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET_V3__MAIN_NOTIMPLEMENTED)
	#define USE_snmp_get_v3__main
	#define EXT_snmp_get_v3__main
	#define GET_snmp_get_v3__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get_v3__main(p0) 
	#define CHK_snmp_get_v3__main  FALSE
	#define EXP_snmp_get_v3__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get_v3__main
	#define EXT_snmp_get_v3__main
	#define GET_snmp_get_v3__main(fl)  CAL_CMGETAPI( "snmp_get_v3__main" ) 
	#define CAL_snmp_get_v3__main  snmp_get_v3__main
	#define CHK_snmp_get_v3__main  TRUE
	#define EXP_snmp_get_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__main", (RTS_UINTPTR)snmp_get_v3__main, 1, RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200) 
	#define EXTREF_ITF_snmp_get_v3__main {(RTS_VOID_FCTPTR)snmp_get_v3__main, "snmp_get_v3__main", RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get_v3__main
	#define EXT_snmp_get_v3__main
	#define GET_snmp_get_v3__main(fl)  CAL_CMGETAPI( "snmp_get_v3__main" ) 
	#define CAL_snmp_get_v3__main  snmp_get_v3__main
	#define CHK_snmp_get_v3__main  TRUE
	#define EXP_snmp_get_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__main", (RTS_UINTPTR)snmp_get_v3__main, 1, RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get_v3__main
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get_v3__main
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get_v3__main  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get_v3__main  snmp_get_v3__main
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get_v3__main  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__main", (RTS_UINTPTR)snmp_get_v3__main, 1, RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get_v3__main
	#define EXT_snmp_get_v3__main
	#define GET_snmp_get_v3__main(fl)  CAL_CMGETAPI( "snmp_get_v3__main" ) 
	#define CAL_snmp_get_v3__main  snmp_get_v3__main
	#define CHK_snmp_get_v3__main  TRUE
	#define EXP_snmp_get_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__main", (RTS_UINTPTR)snmp_get_v3__main, 1, RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get_v3__main  PFSNMP_GET_V3__MAIN_IEC pfsnmp_get_v3__main;
	#define EXT_snmp_get_v3__main  extern PFSNMP_GET_V3__MAIN_IEC pfsnmp_get_v3__main;
	#define GET_snmp_get_v3__main(fl)  s_pfCMGetAPI2( "snmp_get_v3__main", (RTS_VOID_FCTPTR *)&pfsnmp_get_v3__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200)
	#define CAL_snmp_get_v3__main  pfsnmp_get_v3__main
	#define CHK_snmp_get_v3__main  (pfsnmp_get_v3__main != NULL)
	#define EXP_snmp_get_v3__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__main", (RTS_UINTPTR)snmp_get_v3__main, 1, RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200) 
#endif


/**
 * <description>snmp_get_v3_fb_init</description>
 */
typedef struct tagsnmp_get_v3_fb_init_struct
{
	snmp_get_v3_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} snmp_get_v3_fb_init_struct;

void CDECL CDECL_EXT snmp_get_v3__fb_init(snmp_get_v3_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET_V3__FB_INIT_IEC) (snmp_get_v3_fb_init_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET_V3__FB_INIT_NOTIMPLEMENTED)
	#define USE_snmp_get_v3__fb_init
	#define EXT_snmp_get_v3__fb_init
	#define GET_snmp_get_v3__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get_v3__fb_init(p0) 
	#define CHK_snmp_get_v3__fb_init  FALSE
	#define EXP_snmp_get_v3__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get_v3__fb_init
	#define EXT_snmp_get_v3__fb_init
	#define GET_snmp_get_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_get_v3__fb_init" ) 
	#define CAL_snmp_get_v3__fb_init  snmp_get_v3__fb_init
	#define CHK_snmp_get_v3__fb_init  TRUE
	#define EXP_snmp_get_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_init", (RTS_UINTPTR)snmp_get_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200) 
	#define EXTREF_ITF_snmp_get_v3__fb_init {(RTS_VOID_FCTPTR)snmp_get_v3__fb_init, "snmp_get_v3__fb_init", RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get_v3__fb_init
	#define EXT_snmp_get_v3__fb_init
	#define GET_snmp_get_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_get_v3__fb_init" ) 
	#define CAL_snmp_get_v3__fb_init  snmp_get_v3__fb_init
	#define CHK_snmp_get_v3__fb_init  TRUE
	#define EXP_snmp_get_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_init", (RTS_UINTPTR)snmp_get_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_init
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_init
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_init  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_init  snmp_get_v3__fb_init
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_init  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_init", (RTS_UINTPTR)snmp_get_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get_v3__fb_init
	#define EXT_snmp_get_v3__fb_init
	#define GET_snmp_get_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_get_v3__fb_init" ) 
	#define CAL_snmp_get_v3__fb_init  snmp_get_v3__fb_init
	#define CHK_snmp_get_v3__fb_init  TRUE
	#define EXP_snmp_get_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_init", (RTS_UINTPTR)snmp_get_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get_v3__fb_init  PFSNMP_GET_V3__FB_INIT_IEC pfsnmp_get_v3__fb_init;
	#define EXT_snmp_get_v3__fb_init  extern PFSNMP_GET_V3__FB_INIT_IEC pfsnmp_get_v3__fb_init;
	#define GET_snmp_get_v3__fb_init(fl)  s_pfCMGetAPI2( "snmp_get_v3__fb_init", (RTS_VOID_FCTPTR *)&pfsnmp_get_v3__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200)
	#define CAL_snmp_get_v3__fb_init  pfsnmp_get_v3__fb_init
	#define CHK_snmp_get_v3__fb_init  (pfsnmp_get_v3__fb_init != NULL)
	#define EXP_snmp_get_v3__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_init", (RTS_UINTPTR)snmp_get_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200) 
#endif


/**
 * <description>snmp_get_v3_fb_exit</description>
 */
typedef struct tagsnmp_get_v3_fb_exit_struct
{
	snmp_get_v3_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} snmp_get_v3_fb_exit_struct;

void CDECL CDECL_EXT snmp_get_v3__fb_exit(snmp_get_v3_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_GET_V3__FB_EXIT_IEC) (snmp_get_v3_fb_exit_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_GET_V3__FB_EXIT_NOTIMPLEMENTED)
	#define USE_snmp_get_v3__fb_exit
	#define EXT_snmp_get_v3__fb_exit
	#define GET_snmp_get_v3__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_get_v3__fb_exit(p0) 
	#define CHK_snmp_get_v3__fb_exit  FALSE
	#define EXP_snmp_get_v3__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_get_v3__fb_exit
	#define EXT_snmp_get_v3__fb_exit
	#define GET_snmp_get_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_get_v3__fb_exit" ) 
	#define CAL_snmp_get_v3__fb_exit  snmp_get_v3__fb_exit
	#define CHK_snmp_get_v3__fb_exit  TRUE
	#define EXP_snmp_get_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_exit", (RTS_UINTPTR)snmp_get_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200) 
	#define EXTREF_ITF_snmp_get_v3__fb_exit {(RTS_VOID_FCTPTR)snmp_get_v3__fb_exit, "snmp_get_v3__fb_exit", RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_get_v3__fb_exit
	#define EXT_snmp_get_v3__fb_exit
	#define GET_snmp_get_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_get_v3__fb_exit" ) 
	#define CAL_snmp_get_v3__fb_exit  snmp_get_v3__fb_exit
	#define CHK_snmp_get_v3__fb_exit  TRUE
	#define EXP_snmp_get_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_exit", (RTS_UINTPTR)snmp_get_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_exit
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_exit
	#define GET_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_exit  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_exit  snmp_get_v3__fb_exit
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_exit  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_get_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_exit", (RTS_UINTPTR)snmp_get_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_get_v3__fb_exit
	#define EXT_snmp_get_v3__fb_exit
	#define GET_snmp_get_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_get_v3__fb_exit" ) 
	#define CAL_snmp_get_v3__fb_exit  snmp_get_v3__fb_exit
	#define CHK_snmp_get_v3__fb_exit  TRUE
	#define EXP_snmp_get_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_exit", (RTS_UINTPTR)snmp_get_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_get_v3__fb_exit  PFSNMP_GET_V3__FB_EXIT_IEC pfsnmp_get_v3__fb_exit;
	#define EXT_snmp_get_v3__fb_exit  extern PFSNMP_GET_V3__FB_EXIT_IEC pfsnmp_get_v3__fb_exit;
	#define GET_snmp_get_v3__fb_exit(fl)  s_pfCMGetAPI2( "snmp_get_v3__fb_exit", (RTS_VOID_FCTPTR *)&pfsnmp_get_v3__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200)
	#define CAL_snmp_get_v3__fb_exit  pfsnmp_get_v3__fb_exit
	#define CHK_snmp_get_v3__fb_exit  (pfsnmp_get_v3__fb_exit != NULL)
	#define EXP_snmp_get_v3__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_get_v3__fb_exit", (RTS_UINTPTR)snmp_get_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200) 
#endif


/**
 * <description>snmp_null_to_tlv</description>
 */
typedef struct tagsnmp_null_to_tlv_struct
{
	typSNMP_TLV *typData;				/* VAR_IN_OUT */	/* Container for TLV */
	RTS_IEC_DINT SNMP_NULL_TO_TLV;		/* VAR_OUTPUT */	
} snmp_null_to_tlv_struct;

void CDECL CDECL_EXT snmp_null_to_tlv(snmp_null_to_tlv_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_NULL_TO_TLV_IEC) (snmp_null_to_tlv_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_NULL_TO_TLV_NOTIMPLEMENTED)
	#define USE_snmp_null_to_tlv
	#define EXT_snmp_null_to_tlv
	#define GET_snmp_null_to_tlv(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_null_to_tlv(p0) 
	#define CHK_snmp_null_to_tlv  FALSE
	#define EXP_snmp_null_to_tlv  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_null_to_tlv
	#define EXT_snmp_null_to_tlv
	#define GET_snmp_null_to_tlv(fl)  CAL_CMGETAPI( "snmp_null_to_tlv" ) 
	#define CAL_snmp_null_to_tlv  snmp_null_to_tlv
	#define CHK_snmp_null_to_tlv  TRUE
	#define EXP_snmp_null_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_null_to_tlv", (RTS_UINTPTR)snmp_null_to_tlv, 1, RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200) 
	#define EXTREF_ITF_snmp_null_to_tlv {(RTS_VOID_FCTPTR)snmp_null_to_tlv, "snmp_null_to_tlv", RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_null_to_tlv
	#define EXT_snmp_null_to_tlv
	#define GET_snmp_null_to_tlv(fl)  CAL_CMGETAPI( "snmp_null_to_tlv" ) 
	#define CAL_snmp_null_to_tlv  snmp_null_to_tlv
	#define CHK_snmp_null_to_tlv  TRUE
	#define EXP_snmp_null_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_null_to_tlv", (RTS_UINTPTR)snmp_null_to_tlv, 1, RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_null_to_tlv
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_null_to_tlv
	#define GET_WagoSysSNMP_Internal_PFCsnmp_null_to_tlv  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_null_to_tlv  snmp_null_to_tlv
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_null_to_tlv  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_null_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_null_to_tlv", (RTS_UINTPTR)snmp_null_to_tlv, 1, RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_null_to_tlv
	#define EXT_snmp_null_to_tlv
	#define GET_snmp_null_to_tlv(fl)  CAL_CMGETAPI( "snmp_null_to_tlv" ) 
	#define CAL_snmp_null_to_tlv  snmp_null_to_tlv
	#define CHK_snmp_null_to_tlv  TRUE
	#define EXP_snmp_null_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_null_to_tlv", (RTS_UINTPTR)snmp_null_to_tlv, 1, RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_null_to_tlv  PFSNMP_NULL_TO_TLV_IEC pfsnmp_null_to_tlv;
	#define EXT_snmp_null_to_tlv  extern PFSNMP_NULL_TO_TLV_IEC pfsnmp_null_to_tlv;
	#define GET_snmp_null_to_tlv(fl)  s_pfCMGetAPI2( "snmp_null_to_tlv", (RTS_VOID_FCTPTR *)&pfsnmp_null_to_tlv, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200)
	#define CAL_snmp_null_to_tlv  pfsnmp_null_to_tlv
	#define CHK_snmp_null_to_tlv  (pfsnmp_null_to_tlv != NULL)
	#define EXP_snmp_null_to_tlv   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_null_to_tlv", (RTS_UINTPTR)snmp_null_to_tlv, 1, RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200) 
#endif


/**
 * <description>snmp_register_custom_oid</description>
 */
typedef struct tagsnmp_register_custom_oid_struct
{
	RTS_IEC_STRING sOID[129];			/* VAR_INPUT */	
	typSNMP_TLV typDefaultData;			/* VAR_INPUT */	
	RTS_IEC_BOOL xReadOnly;				/* VAR_INPUT */	
	RTS_IEC_DINT SNMP_REGISTER_CUSTOM_OID;	/* VAR_OUTPUT */	
} snmp_register_custom_oid_struct;

void CDECL CDECL_EXT snmp_register_custom_oid(snmp_register_custom_oid_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_REGISTER_CUSTOM_OID_IEC) (snmp_register_custom_oid_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_REGISTER_CUSTOM_OID_NOTIMPLEMENTED)
	#define USE_snmp_register_custom_oid
	#define EXT_snmp_register_custom_oid
	#define GET_snmp_register_custom_oid(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_register_custom_oid(p0) 
	#define CHK_snmp_register_custom_oid  FALSE
	#define EXP_snmp_register_custom_oid  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_register_custom_oid
	#define EXT_snmp_register_custom_oid
	#define GET_snmp_register_custom_oid(fl)  CAL_CMGETAPI( "snmp_register_custom_oid" ) 
	#define CAL_snmp_register_custom_oid  snmp_register_custom_oid
	#define CHK_snmp_register_custom_oid  TRUE
	#define EXP_snmp_register_custom_oid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_register_custom_oid", (RTS_UINTPTR)snmp_register_custom_oid, 1, RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200) 
	#define EXTREF_ITF_snmp_register_custom_oid {(RTS_VOID_FCTPTR)snmp_register_custom_oid, "snmp_register_custom_oid", RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_register_custom_oid
	#define EXT_snmp_register_custom_oid
	#define GET_snmp_register_custom_oid(fl)  CAL_CMGETAPI( "snmp_register_custom_oid" ) 
	#define CAL_snmp_register_custom_oid  snmp_register_custom_oid
	#define CHK_snmp_register_custom_oid  TRUE
	#define EXP_snmp_register_custom_oid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_register_custom_oid", (RTS_UINTPTR)snmp_register_custom_oid, 1, RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_register_custom_oid
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_register_custom_oid
	#define GET_WagoSysSNMP_Internal_PFCsnmp_register_custom_oid  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_register_custom_oid  snmp_register_custom_oid
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_register_custom_oid  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_register_custom_oid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_register_custom_oid", (RTS_UINTPTR)snmp_register_custom_oid, 1, RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_register_custom_oid
	#define EXT_snmp_register_custom_oid
	#define GET_snmp_register_custom_oid(fl)  CAL_CMGETAPI( "snmp_register_custom_oid" ) 
	#define CAL_snmp_register_custom_oid  snmp_register_custom_oid
	#define CHK_snmp_register_custom_oid  TRUE
	#define EXP_snmp_register_custom_oid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_register_custom_oid", (RTS_UINTPTR)snmp_register_custom_oid, 1, RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_register_custom_oid  PFSNMP_REGISTER_CUSTOM_OID_IEC pfsnmp_register_custom_oid;
	#define EXT_snmp_register_custom_oid  extern PFSNMP_REGISTER_CUSTOM_OID_IEC pfsnmp_register_custom_oid;
	#define GET_snmp_register_custom_oid(fl)  s_pfCMGetAPI2( "snmp_register_custom_oid", (RTS_VOID_FCTPTR *)&pfsnmp_register_custom_oid, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200)
	#define CAL_snmp_register_custom_oid  pfsnmp_register_custom_oid
	#define CHK_snmp_register_custom_oid  (pfsnmp_register_custom_oid != NULL)
	#define EXP_snmp_register_custom_oid   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_register_custom_oid", (RTS_UINTPTR)snmp_register_custom_oid, 1, RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200) 
#endif


/**
 * <description>snmp_send_ent_trap</description>
 */
typedef struct tagsnmp_send_ent_trap_struct
{
	RTS_IEC_WORD wTrap;					/* VAR_INPUT */	/* Enterprise trap number */
	RTS_IEC_DINT SNMP_SEND_ENT_TRAP;	/* VAR_OUTPUT */	
} snmp_send_ent_trap_struct;

void CDECL CDECL_EXT snmp_send_ent_trap(snmp_send_ent_trap_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_ENT_TRAP_IEC) (snmp_send_ent_trap_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_ENT_TRAP_NOTIMPLEMENTED)
	#define USE_snmp_send_ent_trap
	#define EXT_snmp_send_ent_trap
	#define GET_snmp_send_ent_trap(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_ent_trap(p0) 
	#define CHK_snmp_send_ent_trap  FALSE
	#define EXP_snmp_send_ent_trap  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_ent_trap
	#define EXT_snmp_send_ent_trap
	#define GET_snmp_send_ent_trap(fl)  CAL_CMGETAPI( "snmp_send_ent_trap" ) 
	#define CAL_snmp_send_ent_trap  snmp_send_ent_trap
	#define CHK_snmp_send_ent_trap  TRUE
	#define EXP_snmp_send_ent_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_ent_trap", (RTS_UINTPTR)snmp_send_ent_trap, 1, 0xDAFE8EA0, 0x01020200) 
	#define EXTREF_ITF_snmp_send_ent_trap {(RTS_VOID_FCTPTR)snmp_send_ent_trap, "snmp_send_ent_trap", 0xDAFE8EA0, 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_ent_trap
	#define EXT_snmp_send_ent_trap
	#define GET_snmp_send_ent_trap(fl)  CAL_CMGETAPI( "snmp_send_ent_trap" ) 
	#define CAL_snmp_send_ent_trap  snmp_send_ent_trap
	#define CHK_snmp_send_ent_trap  TRUE
	#define EXP_snmp_send_ent_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_ent_trap", (RTS_UINTPTR)snmp_send_ent_trap, 1, 0xDAFE8EA0, 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_ent_trap
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_ent_trap
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_ent_trap  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_ent_trap  snmp_send_ent_trap
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_ent_trap  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_ent_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_ent_trap", (RTS_UINTPTR)snmp_send_ent_trap, 1, 0xDAFE8EA0, 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_ent_trap
	#define EXT_snmp_send_ent_trap
	#define GET_snmp_send_ent_trap(fl)  CAL_CMGETAPI( "snmp_send_ent_trap" ) 
	#define CAL_snmp_send_ent_trap  snmp_send_ent_trap
	#define CHK_snmp_send_ent_trap  TRUE
	#define EXP_snmp_send_ent_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_ent_trap", (RTS_UINTPTR)snmp_send_ent_trap, 1, 0xDAFE8EA0, 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_ent_trap  PFSNMP_SEND_ENT_TRAP_IEC pfsnmp_send_ent_trap;
	#define EXT_snmp_send_ent_trap  extern PFSNMP_SEND_ENT_TRAP_IEC pfsnmp_send_ent_trap;
	#define GET_snmp_send_ent_trap(fl)  s_pfCMGetAPI2( "snmp_send_ent_trap", (RTS_VOID_FCTPTR *)&pfsnmp_send_ent_trap, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDAFE8EA0, 0x01020200)
	#define CAL_snmp_send_ent_trap  pfsnmp_send_ent_trap
	#define CHK_snmp_send_ent_trap  (pfsnmp_send_ent_trap != NULL)
	#define EXP_snmp_send_ent_trap   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_ent_trap", (RTS_UINTPTR)snmp_send_ent_trap, 1, 0xDAFE8EA0, 0x01020200) 
#endif


/**
 * <description>snmp_send_inform_to_adr__main</description>
 */
typedef struct tagsnmp_send_inform_to_adr_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of SNMP_SEND_INFORM_TO_ADR */

	RTS_IEC_BOOL xExecute;				/* VAR_INPUT */	/* Enable SNMP-request */
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sEnterprise[128];	/* VAR_INPUT */	/* SNMP unique object identifier(OID) of trap sender e.g.: 1.3.6.1.4.1.13576.1 */
	RTS_IEC_STRING sCommunity[64];		/* VAR_INPUT */	/* Community string typical: "public" */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) used for sending a additional value withe the trap. sy ''for only sending the trap */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Send a specific variable with the trap. */
	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Function block has done its work an outgoing data can be used */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Function block is already Busy */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	
	RTS_IEC_DINT diStatus;				/* VAR_OUTPUT */	/* Return-code */
	RTS_IEC_BOOL xOldEnable;			/* Local variable */	
	RTS_IEC_DINT *diData;				/* Local variable */	
	RTS_IEC_HANDLE diSyncHandle;		/* Local variable */	
} snmp_send_inform_to_adr_struct;

/**
 * <description>snmp_send_inform_to_adr_main</description>
 */
typedef struct tagsnmp_send_inform_to_adr_main_struct
{
	snmp_send_inform_to_adr_struct *pInstance;	/* VAR_INPUT */	
} snmp_send_inform_to_adr_main_struct;

void CDECL CDECL_EXT snmp_send_inform_to_adr__main(snmp_send_inform_to_adr_main_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_INFORM_TO_ADR__MAIN_IEC) (snmp_send_inform_to_adr_main_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_INFORM_TO_ADR__MAIN_NOTIMPLEMENTED)
	#define USE_snmp_send_inform_to_adr__main
	#define EXT_snmp_send_inform_to_adr__main
	#define GET_snmp_send_inform_to_adr__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_inform_to_adr__main(p0) 
	#define CHK_snmp_send_inform_to_adr__main  FALSE
	#define EXP_snmp_send_inform_to_adr__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_inform_to_adr__main
	#define EXT_snmp_send_inform_to_adr__main
	#define GET_snmp_send_inform_to_adr__main(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__main" ) 
	#define CAL_snmp_send_inform_to_adr__main  snmp_send_inform_to_adr__main
	#define CHK_snmp_send_inform_to_adr__main  TRUE
	#define EXP_snmp_send_inform_to_adr__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__main", (RTS_UINTPTR)snmp_send_inform_to_adr__main, 1, RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200) 
	#define EXTREF_ITF_snmp_send_inform_to_adr__main {(RTS_VOID_FCTPTR)snmp_send_inform_to_adr__main, "snmp_send_inform_to_adr__main", RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_inform_to_adr__main
	#define EXT_snmp_send_inform_to_adr__main
	#define GET_snmp_send_inform_to_adr__main(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__main" ) 
	#define CAL_snmp_send_inform_to_adr__main  snmp_send_inform_to_adr__main
	#define CHK_snmp_send_inform_to_adr__main  TRUE
	#define EXP_snmp_send_inform_to_adr__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__main", (RTS_UINTPTR)snmp_send_inform_to_adr__main, 1, RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__main
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__main
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__main  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__main  snmp_send_inform_to_adr__main
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__main  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__main", (RTS_UINTPTR)snmp_send_inform_to_adr__main, 1, RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_inform_to_adr__main
	#define EXT_snmp_send_inform_to_adr__main
	#define GET_snmp_send_inform_to_adr__main(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__main" ) 
	#define CAL_snmp_send_inform_to_adr__main  snmp_send_inform_to_adr__main
	#define CHK_snmp_send_inform_to_adr__main  TRUE
	#define EXP_snmp_send_inform_to_adr__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__main", (RTS_UINTPTR)snmp_send_inform_to_adr__main, 1, RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_inform_to_adr__main  PFSNMP_SEND_INFORM_TO_ADR__MAIN_IEC pfsnmp_send_inform_to_adr__main;
	#define EXT_snmp_send_inform_to_adr__main  extern PFSNMP_SEND_INFORM_TO_ADR__MAIN_IEC pfsnmp_send_inform_to_adr__main;
	#define GET_snmp_send_inform_to_adr__main(fl)  s_pfCMGetAPI2( "snmp_send_inform_to_adr__main", (RTS_VOID_FCTPTR *)&pfsnmp_send_inform_to_adr__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200)
	#define CAL_snmp_send_inform_to_adr__main  pfsnmp_send_inform_to_adr__main
	#define CHK_snmp_send_inform_to_adr__main  (pfsnmp_send_inform_to_adr__main != NULL)
	#define EXP_snmp_send_inform_to_adr__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__main", (RTS_UINTPTR)snmp_send_inform_to_adr__main, 1, RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200) 
#endif


/**
 * <description>snmp_send_inform_to_adr_fb_init</description>
 */
typedef struct tagsnmp_send_inform_to_adr_fb_init_struct
{
	snmp_send_inform_to_adr_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} snmp_send_inform_to_adr_fb_init_struct;

void CDECL CDECL_EXT snmp_send_inform_to_adr__fb_init(snmp_send_inform_to_adr_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_INFORM_TO_ADR__FB_INIT_IEC) (snmp_send_inform_to_adr_fb_init_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_INFORM_TO_ADR__FB_INIT_NOTIMPLEMENTED)
	#define USE_snmp_send_inform_to_adr__fb_init
	#define EXT_snmp_send_inform_to_adr__fb_init
	#define GET_snmp_send_inform_to_adr__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_inform_to_adr__fb_init(p0) 
	#define CHK_snmp_send_inform_to_adr__fb_init  FALSE
	#define EXP_snmp_send_inform_to_adr__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_inform_to_adr__fb_init
	#define EXT_snmp_send_inform_to_adr__fb_init
	#define GET_snmp_send_inform_to_adr__fb_init(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__fb_init" ) 
	#define CAL_snmp_send_inform_to_adr__fb_init  snmp_send_inform_to_adr__fb_init
	#define CHK_snmp_send_inform_to_adr__fb_init  TRUE
	#define EXP_snmp_send_inform_to_adr__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_init, 1, RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200) 
	#define EXTREF_ITF_snmp_send_inform_to_adr__fb_init {(RTS_VOID_FCTPTR)snmp_send_inform_to_adr__fb_init, "snmp_send_inform_to_adr__fb_init", RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_inform_to_adr__fb_init
	#define EXT_snmp_send_inform_to_adr__fb_init
	#define GET_snmp_send_inform_to_adr__fb_init(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__fb_init" ) 
	#define CAL_snmp_send_inform_to_adr__fb_init  snmp_send_inform_to_adr__fb_init
	#define CHK_snmp_send_inform_to_adr__fb_init  TRUE
	#define EXP_snmp_send_inform_to_adr__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_init, 1, RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_init
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_init
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_init  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_init  snmp_send_inform_to_adr__fb_init
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_init  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_init, 1, RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_inform_to_adr__fb_init
	#define EXT_snmp_send_inform_to_adr__fb_init
	#define GET_snmp_send_inform_to_adr__fb_init(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__fb_init" ) 
	#define CAL_snmp_send_inform_to_adr__fb_init  snmp_send_inform_to_adr__fb_init
	#define CHK_snmp_send_inform_to_adr__fb_init  TRUE
	#define EXP_snmp_send_inform_to_adr__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_init, 1, RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_inform_to_adr__fb_init  PFSNMP_SEND_INFORM_TO_ADR__FB_INIT_IEC pfsnmp_send_inform_to_adr__fb_init;
	#define EXT_snmp_send_inform_to_adr__fb_init  extern PFSNMP_SEND_INFORM_TO_ADR__FB_INIT_IEC pfsnmp_send_inform_to_adr__fb_init;
	#define GET_snmp_send_inform_to_adr__fb_init(fl)  s_pfCMGetAPI2( "snmp_send_inform_to_adr__fb_init", (RTS_VOID_FCTPTR *)&pfsnmp_send_inform_to_adr__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200)
	#define CAL_snmp_send_inform_to_adr__fb_init  pfsnmp_send_inform_to_adr__fb_init
	#define CHK_snmp_send_inform_to_adr__fb_init  (pfsnmp_send_inform_to_adr__fb_init != NULL)
	#define EXP_snmp_send_inform_to_adr__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_init, 1, RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200) 
#endif


/**
 * <description>snmp_send_inform_to_adr_fb_exit</description>
 */
typedef struct tagsnmp_send_inform_to_adr_fb_exit_struct
{
	snmp_send_inform_to_adr_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} snmp_send_inform_to_adr_fb_exit_struct;

void CDECL CDECL_EXT snmp_send_inform_to_adr__fb_exit(snmp_send_inform_to_adr_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_INFORM_TO_ADR__FB_EXIT_IEC) (snmp_send_inform_to_adr_fb_exit_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_INFORM_TO_ADR__FB_EXIT_NOTIMPLEMENTED)
	#define USE_snmp_send_inform_to_adr__fb_exit
	#define EXT_snmp_send_inform_to_adr__fb_exit
	#define GET_snmp_send_inform_to_adr__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_inform_to_adr__fb_exit(p0) 
	#define CHK_snmp_send_inform_to_adr__fb_exit  FALSE
	#define EXP_snmp_send_inform_to_adr__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_inform_to_adr__fb_exit
	#define EXT_snmp_send_inform_to_adr__fb_exit
	#define GET_snmp_send_inform_to_adr__fb_exit(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__fb_exit" ) 
	#define CAL_snmp_send_inform_to_adr__fb_exit  snmp_send_inform_to_adr__fb_exit
	#define CHK_snmp_send_inform_to_adr__fb_exit  TRUE
	#define EXP_snmp_send_inform_to_adr__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_exit, 1, RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200) 
	#define EXTREF_ITF_snmp_send_inform_to_adr__fb_exit {(RTS_VOID_FCTPTR)snmp_send_inform_to_adr__fb_exit, "snmp_send_inform_to_adr__fb_exit", RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_inform_to_adr__fb_exit
	#define EXT_snmp_send_inform_to_adr__fb_exit
	#define GET_snmp_send_inform_to_adr__fb_exit(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__fb_exit" ) 
	#define CAL_snmp_send_inform_to_adr__fb_exit  snmp_send_inform_to_adr__fb_exit
	#define CHK_snmp_send_inform_to_adr__fb_exit  TRUE
	#define EXP_snmp_send_inform_to_adr__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_exit, 1, RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_exit
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_exit
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_exit  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_exit  snmp_send_inform_to_adr__fb_exit
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_exit  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_exit, 1, RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_inform_to_adr__fb_exit
	#define EXT_snmp_send_inform_to_adr__fb_exit
	#define GET_snmp_send_inform_to_adr__fb_exit(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr__fb_exit" ) 
	#define CAL_snmp_send_inform_to_adr__fb_exit  snmp_send_inform_to_adr__fb_exit
	#define CHK_snmp_send_inform_to_adr__fb_exit  TRUE
	#define EXP_snmp_send_inform_to_adr__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_exit, 1, RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_inform_to_adr__fb_exit  PFSNMP_SEND_INFORM_TO_ADR__FB_EXIT_IEC pfsnmp_send_inform_to_adr__fb_exit;
	#define EXT_snmp_send_inform_to_adr__fb_exit  extern PFSNMP_SEND_INFORM_TO_ADR__FB_EXIT_IEC pfsnmp_send_inform_to_adr__fb_exit;
	#define GET_snmp_send_inform_to_adr__fb_exit(fl)  s_pfCMGetAPI2( "snmp_send_inform_to_adr__fb_exit", (RTS_VOID_FCTPTR *)&pfsnmp_send_inform_to_adr__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200)
	#define CAL_snmp_send_inform_to_adr__fb_exit  pfsnmp_send_inform_to_adr__fb_exit
	#define CHK_snmp_send_inform_to_adr__fb_exit  (pfsnmp_send_inform_to_adr__fb_exit != NULL)
	#define EXP_snmp_send_inform_to_adr__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr__fb_exit, 1, RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200) 
#endif


/**
 * <description>snmp_send_inform_to_adr_v3__main</description>
 */
typedef struct tagsnmp_send_inform_to_adr_v3_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of SNMP_SEND_INFORM_TO_ADR_V3 */

	RTS_IEC_BOOL xExecute;				/* VAR_INPUT */	/* Enable SNMP-request */
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sEnterprise[128];	/* VAR_INPUT */	/* SNMP unique object identifier(OID) of trap sender  e.g. 1.3.6.1.4.1.13576.1 */
	RTS_IEC_STRING sEngineID[128];		/* VAR_INPUT */	
	RTS_IEC_STRING sUsername[128];		/* VAR_INPUT */	/* SNMP-Username. */
	RTS_IEC_INT typSecLevel;			/* VAR_INPUT, Enum: ESNMP_SECURITYLEVEL */
	RTS_IEC_INT typAuthProt;			/* VAR_INPUT, Enum: ESNMP_AUTHENTICATIONPROTOCOL */
	RTS_IEC_STRING sAuthPass[128];		/* VAR_INPUT */	/* Password for the given username */
	RTS_IEC_INT typPrivProt;			/* VAR_INPUT, Enum: ESNMP_PRIVACYPROTOCOL */
	RTS_IEC_STRING sPrivPass[128];		/* VAR_INPUT */	/* Passphrase for the given encryption type and username */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) used for sending an additional value with the trap. Give an empty string '' for only sending the trap */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Send a specific variable with the trap */
	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Function block has done its work an outgoing data can be used */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Function block is already Busy */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	
	RTS_IEC_DINT diStatus;				/* VAR_OUTPUT */	/* Return-code */
	RTS_IEC_BOOL xOldEnable;			/* Local variable */	
	RTS_IEC_DINT *diData;				/* Local variable */	
	RTS_IEC_HANDLE diSyncHandle;		/* Local variable */	
} snmp_send_inform_to_adr_v3_struct;

/**
 * <description>snmp_send_inform_to_adr_v3_main</description>
 */
typedef struct tagsnmp_send_inform_to_adr_v3_main_struct
{
	snmp_send_inform_to_adr_v3_struct *pInstance;	/* VAR_INPUT */	
} snmp_send_inform_to_adr_v3_main_struct;

void CDECL CDECL_EXT snmp_send_inform_to_adr_v3__main(snmp_send_inform_to_adr_v3_main_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_INFORM_TO_ADR_V3__MAIN_IEC) (snmp_send_inform_to_adr_v3_main_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_INFORM_TO_ADR_V3__MAIN_NOTIMPLEMENTED)
	#define USE_snmp_send_inform_to_adr_v3__main
	#define EXT_snmp_send_inform_to_adr_v3__main
	#define GET_snmp_send_inform_to_adr_v3__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_inform_to_adr_v3__main(p0) 
	#define CHK_snmp_send_inform_to_adr_v3__main  FALSE
	#define EXP_snmp_send_inform_to_adr_v3__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_inform_to_adr_v3__main
	#define EXT_snmp_send_inform_to_adr_v3__main
	#define GET_snmp_send_inform_to_adr_v3__main(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__main" ) 
	#define CAL_snmp_send_inform_to_adr_v3__main  snmp_send_inform_to_adr_v3__main
	#define CHK_snmp_send_inform_to_adr_v3__main  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__main", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__main, 1, RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200) 
	#define EXTREF_ITF_snmp_send_inform_to_adr_v3__main {(RTS_VOID_FCTPTR)snmp_send_inform_to_adr_v3__main, "snmp_send_inform_to_adr_v3__main", RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_inform_to_adr_v3__main
	#define EXT_snmp_send_inform_to_adr_v3__main
	#define GET_snmp_send_inform_to_adr_v3__main(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__main" ) 
	#define CAL_snmp_send_inform_to_adr_v3__main  snmp_send_inform_to_adr_v3__main
	#define CHK_snmp_send_inform_to_adr_v3__main  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__main", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__main, 1, RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__main
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__main
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__main  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__main  snmp_send_inform_to_adr_v3__main
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__main  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__main", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__main, 1, RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_inform_to_adr_v3__main
	#define EXT_snmp_send_inform_to_adr_v3__main
	#define GET_snmp_send_inform_to_adr_v3__main(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__main" ) 
	#define CAL_snmp_send_inform_to_adr_v3__main  snmp_send_inform_to_adr_v3__main
	#define CHK_snmp_send_inform_to_adr_v3__main  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__main", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__main, 1, RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_inform_to_adr_v3__main  PFSNMP_SEND_INFORM_TO_ADR_V3__MAIN_IEC pfsnmp_send_inform_to_adr_v3__main;
	#define EXT_snmp_send_inform_to_adr_v3__main  extern PFSNMP_SEND_INFORM_TO_ADR_V3__MAIN_IEC pfsnmp_send_inform_to_adr_v3__main;
	#define GET_snmp_send_inform_to_adr_v3__main(fl)  s_pfCMGetAPI2( "snmp_send_inform_to_adr_v3__main", (RTS_VOID_FCTPTR *)&pfsnmp_send_inform_to_adr_v3__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200)
	#define CAL_snmp_send_inform_to_adr_v3__main  pfsnmp_send_inform_to_adr_v3__main
	#define CHK_snmp_send_inform_to_adr_v3__main  (pfsnmp_send_inform_to_adr_v3__main != NULL)
	#define EXP_snmp_send_inform_to_adr_v3__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__main", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__main, 1, RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200) 
#endif


/**
 * <description>snmp_send_inform_to_adr_v3_fb_init</description>
 */
typedef struct tagsnmp_send_inform_to_adr_v3_fb_init_struct
{
	snmp_send_inform_to_adr_v3_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} snmp_send_inform_to_adr_v3_fb_init_struct;

void CDECL CDECL_EXT snmp_send_inform_to_adr_v3__fb_init(snmp_send_inform_to_adr_v3_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_INFORM_TO_ADR_V3__FB_INIT_IEC) (snmp_send_inform_to_adr_v3_fb_init_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_INFORM_TO_ADR_V3__FB_INIT_NOTIMPLEMENTED)
	#define USE_snmp_send_inform_to_adr_v3__fb_init
	#define EXT_snmp_send_inform_to_adr_v3__fb_init
	#define GET_snmp_send_inform_to_adr_v3__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_inform_to_adr_v3__fb_init(p0) 
	#define CHK_snmp_send_inform_to_adr_v3__fb_init  FALSE
	#define EXP_snmp_send_inform_to_adr_v3__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_inform_to_adr_v3__fb_init
	#define EXT_snmp_send_inform_to_adr_v3__fb_init
	#define GET_snmp_send_inform_to_adr_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__fb_init" ) 
	#define CAL_snmp_send_inform_to_adr_v3__fb_init  snmp_send_inform_to_adr_v3__fb_init
	#define CHK_snmp_send_inform_to_adr_v3__fb_init  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200) 
	#define EXTREF_ITF_snmp_send_inform_to_adr_v3__fb_init {(RTS_VOID_FCTPTR)snmp_send_inform_to_adr_v3__fb_init, "snmp_send_inform_to_adr_v3__fb_init", RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_inform_to_adr_v3__fb_init
	#define EXT_snmp_send_inform_to_adr_v3__fb_init
	#define GET_snmp_send_inform_to_adr_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__fb_init" ) 
	#define CAL_snmp_send_inform_to_adr_v3__fb_init  snmp_send_inform_to_adr_v3__fb_init
	#define CHK_snmp_send_inform_to_adr_v3__fb_init  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_init
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_init
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_init  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_init  snmp_send_inform_to_adr_v3__fb_init
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_init  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_inform_to_adr_v3__fb_init
	#define EXT_snmp_send_inform_to_adr_v3__fb_init
	#define GET_snmp_send_inform_to_adr_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__fb_init" ) 
	#define CAL_snmp_send_inform_to_adr_v3__fb_init  snmp_send_inform_to_adr_v3__fb_init
	#define CHK_snmp_send_inform_to_adr_v3__fb_init  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_inform_to_adr_v3__fb_init  PFSNMP_SEND_INFORM_TO_ADR_V3__FB_INIT_IEC pfsnmp_send_inform_to_adr_v3__fb_init;
	#define EXT_snmp_send_inform_to_adr_v3__fb_init  extern PFSNMP_SEND_INFORM_TO_ADR_V3__FB_INIT_IEC pfsnmp_send_inform_to_adr_v3__fb_init;
	#define GET_snmp_send_inform_to_adr_v3__fb_init(fl)  s_pfCMGetAPI2( "snmp_send_inform_to_adr_v3__fb_init", (RTS_VOID_FCTPTR *)&pfsnmp_send_inform_to_adr_v3__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200)
	#define CAL_snmp_send_inform_to_adr_v3__fb_init  pfsnmp_send_inform_to_adr_v3__fb_init
	#define CHK_snmp_send_inform_to_adr_v3__fb_init  (pfsnmp_send_inform_to_adr_v3__fb_init != NULL)
	#define EXP_snmp_send_inform_to_adr_v3__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_init", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200) 
#endif


/**
 * <description>snmp_send_inform_to_adr_v3_fb_exit</description>
 */
typedef struct tagsnmp_send_inform_to_adr_v3_fb_exit_struct
{
	snmp_send_inform_to_adr_v3_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} snmp_send_inform_to_adr_v3_fb_exit_struct;

void CDECL CDECL_EXT snmp_send_inform_to_adr_v3__fb_exit(snmp_send_inform_to_adr_v3_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_INFORM_TO_ADR_V3__FB_EXIT_IEC) (snmp_send_inform_to_adr_v3_fb_exit_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_INFORM_TO_ADR_V3__FB_EXIT_NOTIMPLEMENTED)
	#define USE_snmp_send_inform_to_adr_v3__fb_exit
	#define EXT_snmp_send_inform_to_adr_v3__fb_exit
	#define GET_snmp_send_inform_to_adr_v3__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_inform_to_adr_v3__fb_exit(p0) 
	#define CHK_snmp_send_inform_to_adr_v3__fb_exit  FALSE
	#define EXP_snmp_send_inform_to_adr_v3__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_inform_to_adr_v3__fb_exit
	#define EXT_snmp_send_inform_to_adr_v3__fb_exit
	#define GET_snmp_send_inform_to_adr_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__fb_exit" ) 
	#define CAL_snmp_send_inform_to_adr_v3__fb_exit  snmp_send_inform_to_adr_v3__fb_exit
	#define CHK_snmp_send_inform_to_adr_v3__fb_exit  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200) 
	#define EXTREF_ITF_snmp_send_inform_to_adr_v3__fb_exit {(RTS_VOID_FCTPTR)snmp_send_inform_to_adr_v3__fb_exit, "snmp_send_inform_to_adr_v3__fb_exit", RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_inform_to_adr_v3__fb_exit
	#define EXT_snmp_send_inform_to_adr_v3__fb_exit
	#define GET_snmp_send_inform_to_adr_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__fb_exit" ) 
	#define CAL_snmp_send_inform_to_adr_v3__fb_exit  snmp_send_inform_to_adr_v3__fb_exit
	#define CHK_snmp_send_inform_to_adr_v3__fb_exit  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_exit
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_exit
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_exit  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_exit  snmp_send_inform_to_adr_v3__fb_exit
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_exit  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_inform_to_adr_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_inform_to_adr_v3__fb_exit
	#define EXT_snmp_send_inform_to_adr_v3__fb_exit
	#define GET_snmp_send_inform_to_adr_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_send_inform_to_adr_v3__fb_exit" ) 
	#define CAL_snmp_send_inform_to_adr_v3__fb_exit  snmp_send_inform_to_adr_v3__fb_exit
	#define CHK_snmp_send_inform_to_adr_v3__fb_exit  TRUE
	#define EXP_snmp_send_inform_to_adr_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_inform_to_adr_v3__fb_exit  PFSNMP_SEND_INFORM_TO_ADR_V3__FB_EXIT_IEC pfsnmp_send_inform_to_adr_v3__fb_exit;
	#define EXT_snmp_send_inform_to_adr_v3__fb_exit  extern PFSNMP_SEND_INFORM_TO_ADR_V3__FB_EXIT_IEC pfsnmp_send_inform_to_adr_v3__fb_exit;
	#define GET_snmp_send_inform_to_adr_v3__fb_exit(fl)  s_pfCMGetAPI2( "snmp_send_inform_to_adr_v3__fb_exit", (RTS_VOID_FCTPTR *)&pfsnmp_send_inform_to_adr_v3__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200)
	#define CAL_snmp_send_inform_to_adr_v3__fb_exit  pfsnmp_send_inform_to_adr_v3__fb_exit
	#define CHK_snmp_send_inform_to_adr_v3__fb_exit  (pfsnmp_send_inform_to_adr_v3__fb_exit != NULL)
	#define EXP_snmp_send_inform_to_adr_v3__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_inform_to_adr_v3__fb_exit", (RTS_UINTPTR)snmp_send_inform_to_adr_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200) 
#endif


/**
 * <description>snmp_send_trap</description>
 */
typedef struct tagsnmp_send_trap_struct
{
	RTS_IEC_STRING sEnterprise[128];	/* VAR_INPUT */	/* SNMP unique object identifier(OID) of trap sender e.g. 1.3.6.1.4.1.13576.1 */
	RTS_IEC_INT typTrapType;			/* VAR_INPUT, Enum: ESNMP_TRAP_TYPE */
	RTS_IEC_WORD wSpecificType;			/* VAR_INPUT */	/* define specific trap-type */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) used for sending an additional value with the trap. Give an empty string '' for only sending the trap */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Send a specific variable with the trap */
	RTS_IEC_DINT SNMP_SEND_TRAP;		/* VAR_OUTPUT */	
} snmp_send_trap_struct;

void CDECL CDECL_EXT snmp_send_trap(snmp_send_trap_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_TRAP_IEC) (snmp_send_trap_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_TRAP_NOTIMPLEMENTED)
	#define USE_snmp_send_trap
	#define EXT_snmp_send_trap
	#define GET_snmp_send_trap(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_trap(p0) 
	#define CHK_snmp_send_trap  FALSE
	#define EXP_snmp_send_trap  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_trap
	#define EXT_snmp_send_trap
	#define GET_snmp_send_trap(fl)  CAL_CMGETAPI( "snmp_send_trap" ) 
	#define CAL_snmp_send_trap  snmp_send_trap
	#define CHK_snmp_send_trap  TRUE
	#define EXP_snmp_send_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap", (RTS_UINTPTR)snmp_send_trap, 1, RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200) 
	#define EXTREF_ITF_snmp_send_trap {(RTS_VOID_FCTPTR)snmp_send_trap, "snmp_send_trap", RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_trap
	#define EXT_snmp_send_trap
	#define GET_snmp_send_trap(fl)  CAL_CMGETAPI( "snmp_send_trap" ) 
	#define CAL_snmp_send_trap  snmp_send_trap
	#define CHK_snmp_send_trap  TRUE
	#define EXP_snmp_send_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap", (RTS_UINTPTR)snmp_send_trap, 1, RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_trap
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_trap
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_trap  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_trap  snmp_send_trap
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_trap  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap", (RTS_UINTPTR)snmp_send_trap, 1, RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_trap
	#define EXT_snmp_send_trap
	#define GET_snmp_send_trap(fl)  CAL_CMGETAPI( "snmp_send_trap" ) 
	#define CAL_snmp_send_trap  snmp_send_trap
	#define CHK_snmp_send_trap  TRUE
	#define EXP_snmp_send_trap  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap", (RTS_UINTPTR)snmp_send_trap, 1, RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_trap  PFSNMP_SEND_TRAP_IEC pfsnmp_send_trap;
	#define EXT_snmp_send_trap  extern PFSNMP_SEND_TRAP_IEC pfsnmp_send_trap;
	#define GET_snmp_send_trap(fl)  s_pfCMGetAPI2( "snmp_send_trap", (RTS_VOID_FCTPTR *)&pfsnmp_send_trap, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200)
	#define CAL_snmp_send_trap  pfsnmp_send_trap
	#define CHK_snmp_send_trap  (pfsnmp_send_trap != NULL)
	#define EXP_snmp_send_trap   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap", (RTS_UINTPTR)snmp_send_trap, 1, RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200) 
#endif


/**
 * <description>snmp_send_trap_to_adr_v1</description>
 */
typedef struct tagsnmp_send_trap_to_adr_v1_struct
{
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sEnterprise[128];	/* VAR_INPUT */	/* SNMP unique object identifier(OID) of trap sender e.g. 1.3.6.1.4.1.13576.1 */
	RTS_IEC_STRING sCommunity[64];		/* VAR_INPUT */	/* Community string typical: "public" */
	RTS_IEC_INT typTrapType;			/* VAR_INPUT, Enum: ESNMP_TRAP_TYPE */
	RTS_IEC_WORD wSpecificType;			/* VAR_INPUT */	/* define specific trap-type */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) used for sending an additional value with the trap. Give an empty string '' for only sending the trap */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Send a specific variable with the trap */
	RTS_IEC_DINT SNMP_SEND_TRAP_TO_ADR_V1;	/* VAR_OUTPUT */	
} snmp_send_trap_to_adr_v1_struct;

void CDECL CDECL_EXT snmp_send_trap_to_adr_v1(snmp_send_trap_to_adr_v1_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_TRAP_TO_ADR_V1_IEC) (snmp_send_trap_to_adr_v1_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_TRAP_TO_ADR_V1_NOTIMPLEMENTED)
	#define USE_snmp_send_trap_to_adr_v1
	#define EXT_snmp_send_trap_to_adr_v1
	#define GET_snmp_send_trap_to_adr_v1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_trap_to_adr_v1(p0) 
	#define CHK_snmp_send_trap_to_adr_v1  FALSE
	#define EXP_snmp_send_trap_to_adr_v1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_trap_to_adr_v1
	#define EXT_snmp_send_trap_to_adr_v1
	#define GET_snmp_send_trap_to_adr_v1(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v1" ) 
	#define CAL_snmp_send_trap_to_adr_v1  snmp_send_trap_to_adr_v1
	#define CHK_snmp_send_trap_to_adr_v1  TRUE
	#define EXP_snmp_send_trap_to_adr_v1  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v1", (RTS_UINTPTR)snmp_send_trap_to_adr_v1, 1, RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200) 
	#define EXTREF_ITF_snmp_send_trap_to_adr_v1 {(RTS_VOID_FCTPTR)snmp_send_trap_to_adr_v1, "snmp_send_trap_to_adr_v1", RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_trap_to_adr_v1
	#define EXT_snmp_send_trap_to_adr_v1
	#define GET_snmp_send_trap_to_adr_v1(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v1" ) 
	#define CAL_snmp_send_trap_to_adr_v1  snmp_send_trap_to_adr_v1
	#define CHK_snmp_send_trap_to_adr_v1  TRUE
	#define EXP_snmp_send_trap_to_adr_v1  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v1", (RTS_UINTPTR)snmp_send_trap_to_adr_v1, 1, RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v1
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v1
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v1  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v1  snmp_send_trap_to_adr_v1
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v1  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v1  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v1", (RTS_UINTPTR)snmp_send_trap_to_adr_v1, 1, RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_trap_to_adr_v1
	#define EXT_snmp_send_trap_to_adr_v1
	#define GET_snmp_send_trap_to_adr_v1(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v1" ) 
	#define CAL_snmp_send_trap_to_adr_v1  snmp_send_trap_to_adr_v1
	#define CHK_snmp_send_trap_to_adr_v1  TRUE
	#define EXP_snmp_send_trap_to_adr_v1  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v1", (RTS_UINTPTR)snmp_send_trap_to_adr_v1, 1, RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_trap_to_adr_v1  PFSNMP_SEND_TRAP_TO_ADR_V1_IEC pfsnmp_send_trap_to_adr_v1;
	#define EXT_snmp_send_trap_to_adr_v1  extern PFSNMP_SEND_TRAP_TO_ADR_V1_IEC pfsnmp_send_trap_to_adr_v1;
	#define GET_snmp_send_trap_to_adr_v1(fl)  s_pfCMGetAPI2( "snmp_send_trap_to_adr_v1", (RTS_VOID_FCTPTR *)&pfsnmp_send_trap_to_adr_v1, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200)
	#define CAL_snmp_send_trap_to_adr_v1  pfsnmp_send_trap_to_adr_v1
	#define CHK_snmp_send_trap_to_adr_v1  (pfsnmp_send_trap_to_adr_v1 != NULL)
	#define EXP_snmp_send_trap_to_adr_v1   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v1", (RTS_UINTPTR)snmp_send_trap_to_adr_v1, 1, RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200) 
#endif


/**
 * <description>snmp_send_trap_to_adr_v2c</description>
 */
typedef struct tagsnmp_send_trap_to_adr_v2c_struct
{
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or Ip-address in "dotted decimal format" */
	RTS_IEC_STRING sEnterprise[128];	/* VAR_INPUT */	/* SNMP unique object identifier(OID) of trap sender e.g. 1.3.6.1.4.1.13576.1 */
	RTS_IEC_STRING sCommunity[64];		/* VAR_INPUT */	/* Community string typical: "public" */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) used for sending an additional value with the trap. Give an empty string '' for only sending the trap */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Send a specific variable with the trap */
	RTS_IEC_DINT SNMP_SEND_TRAP_TO_ADR_V2C;	/* VAR_OUTPUT */	
} snmp_send_trap_to_adr_v2c_struct;

void CDECL CDECL_EXT snmp_send_trap_to_adr_v2c(snmp_send_trap_to_adr_v2c_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_TRAP_TO_ADR_V2C_IEC) (snmp_send_trap_to_adr_v2c_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_TRAP_TO_ADR_V2C_NOTIMPLEMENTED)
	#define USE_snmp_send_trap_to_adr_v2c
	#define EXT_snmp_send_trap_to_adr_v2c
	#define GET_snmp_send_trap_to_adr_v2c(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_trap_to_adr_v2c(p0) 
	#define CHK_snmp_send_trap_to_adr_v2c  FALSE
	#define EXP_snmp_send_trap_to_adr_v2c  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_trap_to_adr_v2c
	#define EXT_snmp_send_trap_to_adr_v2c
	#define GET_snmp_send_trap_to_adr_v2c(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v2c" ) 
	#define CAL_snmp_send_trap_to_adr_v2c  snmp_send_trap_to_adr_v2c
	#define CHK_snmp_send_trap_to_adr_v2c  TRUE
	#define EXP_snmp_send_trap_to_adr_v2c  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v2c", (RTS_UINTPTR)snmp_send_trap_to_adr_v2c, 1, RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200) 
	#define EXTREF_ITF_snmp_send_trap_to_adr_v2c {(RTS_VOID_FCTPTR)snmp_send_trap_to_adr_v2c, "snmp_send_trap_to_adr_v2c", RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_trap_to_adr_v2c
	#define EXT_snmp_send_trap_to_adr_v2c
	#define GET_snmp_send_trap_to_adr_v2c(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v2c" ) 
	#define CAL_snmp_send_trap_to_adr_v2c  snmp_send_trap_to_adr_v2c
	#define CHK_snmp_send_trap_to_adr_v2c  TRUE
	#define EXP_snmp_send_trap_to_adr_v2c  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v2c", (RTS_UINTPTR)snmp_send_trap_to_adr_v2c, 1, RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v2c
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v2c
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v2c  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v2c  snmp_send_trap_to_adr_v2c
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v2c  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v2c  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v2c", (RTS_UINTPTR)snmp_send_trap_to_adr_v2c, 1, RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_trap_to_adr_v2c
	#define EXT_snmp_send_trap_to_adr_v2c
	#define GET_snmp_send_trap_to_adr_v2c(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v2c" ) 
	#define CAL_snmp_send_trap_to_adr_v2c  snmp_send_trap_to_adr_v2c
	#define CHK_snmp_send_trap_to_adr_v2c  TRUE
	#define EXP_snmp_send_trap_to_adr_v2c  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v2c", (RTS_UINTPTR)snmp_send_trap_to_adr_v2c, 1, RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_trap_to_adr_v2c  PFSNMP_SEND_TRAP_TO_ADR_V2C_IEC pfsnmp_send_trap_to_adr_v2c;
	#define EXT_snmp_send_trap_to_adr_v2c  extern PFSNMP_SEND_TRAP_TO_ADR_V2C_IEC pfsnmp_send_trap_to_adr_v2c;
	#define GET_snmp_send_trap_to_adr_v2c(fl)  s_pfCMGetAPI2( "snmp_send_trap_to_adr_v2c", (RTS_VOID_FCTPTR *)&pfsnmp_send_trap_to_adr_v2c, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200)
	#define CAL_snmp_send_trap_to_adr_v2c  pfsnmp_send_trap_to_adr_v2c
	#define CHK_snmp_send_trap_to_adr_v2c  (pfsnmp_send_trap_to_adr_v2c != NULL)
	#define EXP_snmp_send_trap_to_adr_v2c   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v2c", (RTS_UINTPTR)snmp_send_trap_to_adr_v2c, 1, RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200) 
#endif


/**
 * <description>snmp_send_trap_to_adr_v3</description>
 */
typedef struct tagsnmp_send_trap_to_adr_v3_struct
{
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sEnterprise[128];	/* VAR_INPUT */	/* SNMP unique object identifier(OID) of trap sender e.g. 1.3.6.1.4.1.13576.1 */
	RTS_IEC_STRING sEngineID[128];		/* VAR_INPUT */	
	RTS_IEC_STRING sUsername[128];		/* VAR_INPUT */	/* SNMP-Username. */
	RTS_IEC_INT typSecLevel;			/* VAR_INPUT, Enum: ESNMP_SECURITYLEVEL */
	RTS_IEC_INT typAuthProt;			/* VAR_INPUT, Enum: ESNMP_AUTHENTICATIONPROTOCOL */
	RTS_IEC_STRING sAuthPass[128];		/* VAR_INPUT */	/* Password for the given username */
	RTS_IEC_INT typPrivProt;			/* VAR_INPUT, Enum: ESNMP_PRIVACYPROTOCOL */
	RTS_IEC_STRING sPrivPass[128];		/* VAR_INPUT */	/* Passphrase for the given encryption type and username */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) used for sending an additional value with the trap. Give an empty string '' for only sending the trap */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Send a specific variable with the trap */
	RTS_IEC_DINT SNMP_SEND_TRAP_TO_ADR_V3;	/* VAR_OUTPUT */	
} snmp_send_trap_to_adr_v3_struct;

void CDECL CDECL_EXT snmp_send_trap_to_adr_v3(snmp_send_trap_to_adr_v3_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SEND_TRAP_TO_ADR_V3_IEC) (snmp_send_trap_to_adr_v3_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SEND_TRAP_TO_ADR_V3_NOTIMPLEMENTED)
	#define USE_snmp_send_trap_to_adr_v3
	#define EXT_snmp_send_trap_to_adr_v3
	#define GET_snmp_send_trap_to_adr_v3(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_send_trap_to_adr_v3(p0) 
	#define CHK_snmp_send_trap_to_adr_v3  FALSE
	#define EXP_snmp_send_trap_to_adr_v3  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_send_trap_to_adr_v3
	#define EXT_snmp_send_trap_to_adr_v3
	#define GET_snmp_send_trap_to_adr_v3(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v3" ) 
	#define CAL_snmp_send_trap_to_adr_v3  snmp_send_trap_to_adr_v3
	#define CHK_snmp_send_trap_to_adr_v3  TRUE
	#define EXP_snmp_send_trap_to_adr_v3  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v3", (RTS_UINTPTR)snmp_send_trap_to_adr_v3, 1, RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200) 
	#define EXTREF_ITF_snmp_send_trap_to_adr_v3 {(RTS_VOID_FCTPTR)snmp_send_trap_to_adr_v3, "snmp_send_trap_to_adr_v3", RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_send_trap_to_adr_v3
	#define EXT_snmp_send_trap_to_adr_v3
	#define GET_snmp_send_trap_to_adr_v3(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v3" ) 
	#define CAL_snmp_send_trap_to_adr_v3  snmp_send_trap_to_adr_v3
	#define CHK_snmp_send_trap_to_adr_v3  TRUE
	#define EXP_snmp_send_trap_to_adr_v3  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v3", (RTS_UINTPTR)snmp_send_trap_to_adr_v3, 1, RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v3
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v3
	#define GET_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v3  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v3  snmp_send_trap_to_adr_v3
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v3  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_send_trap_to_adr_v3  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v3", (RTS_UINTPTR)snmp_send_trap_to_adr_v3, 1, RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_send_trap_to_adr_v3
	#define EXT_snmp_send_trap_to_adr_v3
	#define GET_snmp_send_trap_to_adr_v3(fl)  CAL_CMGETAPI( "snmp_send_trap_to_adr_v3" ) 
	#define CAL_snmp_send_trap_to_adr_v3  snmp_send_trap_to_adr_v3
	#define CHK_snmp_send_trap_to_adr_v3  TRUE
	#define EXP_snmp_send_trap_to_adr_v3  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v3", (RTS_UINTPTR)snmp_send_trap_to_adr_v3, 1, RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_send_trap_to_adr_v3  PFSNMP_SEND_TRAP_TO_ADR_V3_IEC pfsnmp_send_trap_to_adr_v3;
	#define EXT_snmp_send_trap_to_adr_v3  extern PFSNMP_SEND_TRAP_TO_ADR_V3_IEC pfsnmp_send_trap_to_adr_v3;
	#define GET_snmp_send_trap_to_adr_v3(fl)  s_pfCMGetAPI2( "snmp_send_trap_to_adr_v3", (RTS_VOID_FCTPTR *)&pfsnmp_send_trap_to_adr_v3, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200)
	#define CAL_snmp_send_trap_to_adr_v3  pfsnmp_send_trap_to_adr_v3
	#define CHK_snmp_send_trap_to_adr_v3  (pfsnmp_send_trap_to_adr_v3 != NULL)
	#define EXP_snmp_send_trap_to_adr_v3   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_send_trap_to_adr_v3", (RTS_UINTPTR)snmp_send_trap_to_adr_v3, 1, RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200) 
#endif


/**
 * <description>snmp_set__main</description>
 */
typedef struct tagsnmp_set_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of SNMP_SET */

	RTS_IEC_BOOL xExecute;				/* VAR_INPUT */	/* Enable SNMP-request */
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) of requested data, e.g. '1.3.6.1.2.1.1.6.0' for "sysLocation" */
	RTS_IEC_STRING sCommunity[64];		/* VAR_INPUT */	/* Community string typical: "public" */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Structured response data in Type-Length-Value(TLV) format */
	RTS_IEC_LINT liTimeout_ms;			/* VAR_INPUT */	/* Request timeout in milliseconds */
	RTS_IEC_LINT liRetries;				/* VAR_INPUT */	/* Number of retries until timeout is reported. Total timeout = uiTimeout_ms * (uiReties + 1) */
	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Function block has done its work an outgoing data can be used */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Function block is already busy */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	/* Function block is already busy */
	RTS_IEC_DINT diStatus;				/* VAR_OUTPUT */	/* Return-code */
	RTS_IEC_BOOL xOldEnable;			/* Local variable */	
	RTS_IEC_DINT *diData;				/* Local variable */	
	RTS_IEC_HANDLE diSyncHandle;		/* Local variable */	
} snmp_set_struct;

/**
 * <description>snmp_set_main</description>
 */
typedef struct tagsnmp_set_main_struct
{
	snmp_set_struct *pInstance;			/* VAR_INPUT */	
} snmp_set_main_struct;

void CDECL CDECL_EXT snmp_set__main(snmp_set_main_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET__MAIN_IEC) (snmp_set_main_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET__MAIN_NOTIMPLEMENTED)
	#define USE_snmp_set__main
	#define EXT_snmp_set__main
	#define GET_snmp_set__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set__main(p0) 
	#define CHK_snmp_set__main  FALSE
	#define EXP_snmp_set__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set__main
	#define EXT_snmp_set__main
	#define GET_snmp_set__main(fl)  CAL_CMGETAPI( "snmp_set__main" ) 
	#define CAL_snmp_set__main  snmp_set__main
	#define CHK_snmp_set__main  TRUE
	#define EXP_snmp_set__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__main", (RTS_UINTPTR)snmp_set__main, 1, RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200) 
	#define EXTREF_ITF_snmp_set__main {(RTS_VOID_FCTPTR)snmp_set__main, "snmp_set__main", RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set__main
	#define EXT_snmp_set__main
	#define GET_snmp_set__main(fl)  CAL_CMGETAPI( "snmp_set__main" ) 
	#define CAL_snmp_set__main  snmp_set__main
	#define CHK_snmp_set__main  TRUE
	#define EXP_snmp_set__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__main", (RTS_UINTPTR)snmp_set__main, 1, RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set__main
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set__main
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set__main  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set__main  snmp_set__main
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set__main  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__main", (RTS_UINTPTR)snmp_set__main, 1, RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set__main
	#define EXT_snmp_set__main
	#define GET_snmp_set__main(fl)  CAL_CMGETAPI( "snmp_set__main" ) 
	#define CAL_snmp_set__main  snmp_set__main
	#define CHK_snmp_set__main  TRUE
	#define EXP_snmp_set__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__main", (RTS_UINTPTR)snmp_set__main, 1, RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set__main  PFSNMP_SET__MAIN_IEC pfsnmp_set__main;
	#define EXT_snmp_set__main  extern PFSNMP_SET__MAIN_IEC pfsnmp_set__main;
	#define GET_snmp_set__main(fl)  s_pfCMGetAPI2( "snmp_set__main", (RTS_VOID_FCTPTR *)&pfsnmp_set__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200)
	#define CAL_snmp_set__main  pfsnmp_set__main
	#define CHK_snmp_set__main  (pfsnmp_set__main != NULL)
	#define EXP_snmp_set__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__main", (RTS_UINTPTR)snmp_set__main, 1, RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200) 
#endif


/**
 * <description>snmp_set_fb_init</description>
 */
typedef struct tagsnmp_set_fb_init_struct
{
	snmp_set_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} snmp_set_fb_init_struct;

void CDECL CDECL_EXT snmp_set__fb_init(snmp_set_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET__FB_INIT_IEC) (snmp_set_fb_init_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET__FB_INIT_NOTIMPLEMENTED)
	#define USE_snmp_set__fb_init
	#define EXT_snmp_set__fb_init
	#define GET_snmp_set__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set__fb_init(p0) 
	#define CHK_snmp_set__fb_init  FALSE
	#define EXP_snmp_set__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set__fb_init
	#define EXT_snmp_set__fb_init
	#define GET_snmp_set__fb_init(fl)  CAL_CMGETAPI( "snmp_set__fb_init" ) 
	#define CAL_snmp_set__fb_init  snmp_set__fb_init
	#define CHK_snmp_set__fb_init  TRUE
	#define EXP_snmp_set__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_init", (RTS_UINTPTR)snmp_set__fb_init, 1, RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200) 
	#define EXTREF_ITF_snmp_set__fb_init {(RTS_VOID_FCTPTR)snmp_set__fb_init, "snmp_set__fb_init", RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set__fb_init
	#define EXT_snmp_set__fb_init
	#define GET_snmp_set__fb_init(fl)  CAL_CMGETAPI( "snmp_set__fb_init" ) 
	#define CAL_snmp_set__fb_init  snmp_set__fb_init
	#define CHK_snmp_set__fb_init  TRUE
	#define EXP_snmp_set__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_init", (RTS_UINTPTR)snmp_set__fb_init, 1, RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set__fb_init
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set__fb_init
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set__fb_init  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set__fb_init  snmp_set__fb_init
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set__fb_init  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_init", (RTS_UINTPTR)snmp_set__fb_init, 1, RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set__fb_init
	#define EXT_snmp_set__fb_init
	#define GET_snmp_set__fb_init(fl)  CAL_CMGETAPI( "snmp_set__fb_init" ) 
	#define CAL_snmp_set__fb_init  snmp_set__fb_init
	#define CHK_snmp_set__fb_init  TRUE
	#define EXP_snmp_set__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_init", (RTS_UINTPTR)snmp_set__fb_init, 1, RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set__fb_init  PFSNMP_SET__FB_INIT_IEC pfsnmp_set__fb_init;
	#define EXT_snmp_set__fb_init  extern PFSNMP_SET__FB_INIT_IEC pfsnmp_set__fb_init;
	#define GET_snmp_set__fb_init(fl)  s_pfCMGetAPI2( "snmp_set__fb_init", (RTS_VOID_FCTPTR *)&pfsnmp_set__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200)
	#define CAL_snmp_set__fb_init  pfsnmp_set__fb_init
	#define CHK_snmp_set__fb_init  (pfsnmp_set__fb_init != NULL)
	#define EXP_snmp_set__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_init", (RTS_UINTPTR)snmp_set__fb_init, 1, RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200) 
#endif


/**
 * <description>snmp_set_fb_exit</description>
 */
typedef struct tagsnmp_set_fb_exit_struct
{
	snmp_set_struct *pInstance;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} snmp_set_fb_exit_struct;

void CDECL CDECL_EXT snmp_set__fb_exit(snmp_set_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET__FB_EXIT_IEC) (snmp_set_fb_exit_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET__FB_EXIT_NOTIMPLEMENTED)
	#define USE_snmp_set__fb_exit
	#define EXT_snmp_set__fb_exit
	#define GET_snmp_set__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set__fb_exit(p0) 
	#define CHK_snmp_set__fb_exit  FALSE
	#define EXP_snmp_set__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set__fb_exit
	#define EXT_snmp_set__fb_exit
	#define GET_snmp_set__fb_exit(fl)  CAL_CMGETAPI( "snmp_set__fb_exit" ) 
	#define CAL_snmp_set__fb_exit  snmp_set__fb_exit
	#define CHK_snmp_set__fb_exit  TRUE
	#define EXP_snmp_set__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_exit", (RTS_UINTPTR)snmp_set__fb_exit, 1, RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200) 
	#define EXTREF_ITF_snmp_set__fb_exit {(RTS_VOID_FCTPTR)snmp_set__fb_exit, "snmp_set__fb_exit", RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set__fb_exit
	#define EXT_snmp_set__fb_exit
	#define GET_snmp_set__fb_exit(fl)  CAL_CMGETAPI( "snmp_set__fb_exit" ) 
	#define CAL_snmp_set__fb_exit  snmp_set__fb_exit
	#define CHK_snmp_set__fb_exit  TRUE
	#define EXP_snmp_set__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_exit", (RTS_UINTPTR)snmp_set__fb_exit, 1, RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set__fb_exit
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set__fb_exit
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set__fb_exit  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set__fb_exit  snmp_set__fb_exit
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set__fb_exit  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_exit", (RTS_UINTPTR)snmp_set__fb_exit, 1, RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set__fb_exit
	#define EXT_snmp_set__fb_exit
	#define GET_snmp_set__fb_exit(fl)  CAL_CMGETAPI( "snmp_set__fb_exit" ) 
	#define CAL_snmp_set__fb_exit  snmp_set__fb_exit
	#define CHK_snmp_set__fb_exit  TRUE
	#define EXP_snmp_set__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_exit", (RTS_UINTPTR)snmp_set__fb_exit, 1, RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set__fb_exit  PFSNMP_SET__FB_EXIT_IEC pfsnmp_set__fb_exit;
	#define EXT_snmp_set__fb_exit  extern PFSNMP_SET__FB_EXIT_IEC pfsnmp_set__fb_exit;
	#define GET_snmp_set__fb_exit(fl)  s_pfCMGetAPI2( "snmp_set__fb_exit", (RTS_VOID_FCTPTR *)&pfsnmp_set__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200)
	#define CAL_snmp_set__fb_exit  pfsnmp_set__fb_exit
	#define CHK_snmp_set__fb_exit  (pfsnmp_set__fb_exit != NULL)
	#define EXP_snmp_set__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set__fb_exit", (RTS_UINTPTR)snmp_set__fb_exit, 1, RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200) 
#endif


/**
 * <description>snmp_set_custom_oid_value</description>
 */
typedef struct tagsnmp_set_custom_oid_value_struct
{
	RTS_IEC_STRING sOID[129];			/* VAR_INPUT */	
	typSNMP_TLV typData;				/* VAR_INPUT */	
	RTS_IEC_DINT SNMP_SET_CUSTOM_OID_VALUE;	/* VAR_OUTPUT */	
} snmp_set_custom_oid_value_struct;

void CDECL CDECL_EXT snmp_set_custom_oid_value(snmp_set_custom_oid_value_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET_CUSTOM_OID_VALUE_IEC) (snmp_set_custom_oid_value_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET_CUSTOM_OID_VALUE_NOTIMPLEMENTED)
	#define USE_snmp_set_custom_oid_value
	#define EXT_snmp_set_custom_oid_value
	#define GET_snmp_set_custom_oid_value(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set_custom_oid_value(p0) 
	#define CHK_snmp_set_custom_oid_value  FALSE
	#define EXP_snmp_set_custom_oid_value  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set_custom_oid_value
	#define EXT_snmp_set_custom_oid_value
	#define GET_snmp_set_custom_oid_value(fl)  CAL_CMGETAPI( "snmp_set_custom_oid_value" ) 
	#define CAL_snmp_set_custom_oid_value  snmp_set_custom_oid_value
	#define CHK_snmp_set_custom_oid_value  TRUE
	#define EXP_snmp_set_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_custom_oid_value", (RTS_UINTPTR)snmp_set_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200) 
	#define EXTREF_ITF_snmp_set_custom_oid_value {(RTS_VOID_FCTPTR)snmp_set_custom_oid_value, "snmp_set_custom_oid_value", RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set_custom_oid_value
	#define EXT_snmp_set_custom_oid_value
	#define GET_snmp_set_custom_oid_value(fl)  CAL_CMGETAPI( "snmp_set_custom_oid_value" ) 
	#define CAL_snmp_set_custom_oid_value  snmp_set_custom_oid_value
	#define CHK_snmp_set_custom_oid_value  TRUE
	#define EXP_snmp_set_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_custom_oid_value", (RTS_UINTPTR)snmp_set_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set_custom_oid_value
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set_custom_oid_value
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set_custom_oid_value  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set_custom_oid_value  snmp_set_custom_oid_value
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set_custom_oid_value  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_custom_oid_value", (RTS_UINTPTR)snmp_set_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set_custom_oid_value
	#define EXT_snmp_set_custom_oid_value
	#define GET_snmp_set_custom_oid_value(fl)  CAL_CMGETAPI( "snmp_set_custom_oid_value" ) 
	#define CAL_snmp_set_custom_oid_value  snmp_set_custom_oid_value
	#define CHK_snmp_set_custom_oid_value  TRUE
	#define EXP_snmp_set_custom_oid_value  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_custom_oid_value", (RTS_UINTPTR)snmp_set_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set_custom_oid_value  PFSNMP_SET_CUSTOM_OID_VALUE_IEC pfsnmp_set_custom_oid_value;
	#define EXT_snmp_set_custom_oid_value  extern PFSNMP_SET_CUSTOM_OID_VALUE_IEC pfsnmp_set_custom_oid_value;
	#define GET_snmp_set_custom_oid_value(fl)  s_pfCMGetAPI2( "snmp_set_custom_oid_value", (RTS_VOID_FCTPTR *)&pfsnmp_set_custom_oid_value, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200)
	#define CAL_snmp_set_custom_oid_value  pfsnmp_set_custom_oid_value
	#define CHK_snmp_set_custom_oid_value  (pfsnmp_set_custom_oid_value != NULL)
	#define EXP_snmp_set_custom_oid_value   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_custom_oid_value", (RTS_UINTPTR)snmp_set_custom_oid_value, 1, RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200) 
#endif


/**
 * <description>snmp_set_v3__main</description>
 */
typedef struct tagsnmp_set_v3_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of SNMP_SET_V3 */

	RTS_IEC_BOOL xExecute;				/* VAR_INPUT */	/* Enable SNMP-request */
	RTS_IEC_STRING sHost[128];			/* VAR_INPUT */	/* Hostname or IP-address in "dotted decimal format" */
	RTS_IEC_STRING sOID[128];			/* VAR_INPUT */	/* SNMP unique object identifier(OID) of requested data, e.g. '1.3.6.1.2.1.1.6.0' for "sysLocation" */
	RTS_IEC_STRING sUsername[128];		/* VAR_INPUT */	/* SNMP-username. */
	RTS_IEC_INT typSecLevel;			/* VAR_INPUT, Enum: ESNMP_SECURITYLEVEL */
	RTS_IEC_INT typAuthProt;			/* VAR_INPUT, Enum: ESNMP_AUTHENTICATIONPROTOCOL */
	RTS_IEC_STRING sAuthPass[128];		/* VAR_INPUT */	/* Password for the given username */
	RTS_IEC_INT typPrivProt;			/* VAR_INPUT, Enum: ESNMP_PRIVACYPROTOCOL */
	RTS_IEC_STRING sPrivPass[128];		/* VAR_INPUT */	/* Passphrase for the given encryption type and username */
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Structured response data in Type-Length-Value(TLV) format */
	RTS_IEC_LINT liTimeout_ms;			/* VAR_INPUT */	/* Request timeout in milliseconds */
	RTS_IEC_LINT liRetries;				/* VAR_INPUT */	/* Number of retries until timeout is reported. Total timeout = uiTimeout_ms * (uiReties + 1) */
	RTS_IEC_BOOL xDone;					/* VAR_OUTPUT */	/* Function block has done its work and outgoing data can be used */
	RTS_IEC_BOOL xBusy;					/* VAR_OUTPUT */	/* Function block is already busy */
	RTS_IEC_BOOL xError;				/* VAR_OUTPUT */	/* Function block had an error */
	RTS_IEC_DINT diStatus;				/* VAR_OUTPUT */	/* Return-code */
	RTS_IEC_BOOL xOldEnable;			/* Local variable */	
	RTS_IEC_DINT *diData;				/* Local variable */	
	RTS_IEC_HANDLE diSyncHandle;		/* Local variable */	
} snmp_set_v3_struct;

/**
 * <description>snmp_set_v3_main</description>
 */
typedef struct tagsnmp_set_v3_main_struct
{
	snmp_set_v3_struct *pInstance;		/* VAR_INPUT */	
} snmp_set_v3_main_struct;

void CDECL CDECL_EXT snmp_set_v3__main(snmp_set_v3_main_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET_V3__MAIN_IEC) (snmp_set_v3_main_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET_V3__MAIN_NOTIMPLEMENTED)
	#define USE_snmp_set_v3__main
	#define EXT_snmp_set_v3__main
	#define GET_snmp_set_v3__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set_v3__main(p0) 
	#define CHK_snmp_set_v3__main  FALSE
	#define EXP_snmp_set_v3__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set_v3__main
	#define EXT_snmp_set_v3__main
	#define GET_snmp_set_v3__main(fl)  CAL_CMGETAPI( "snmp_set_v3__main" ) 
	#define CAL_snmp_set_v3__main  snmp_set_v3__main
	#define CHK_snmp_set_v3__main  TRUE
	#define EXP_snmp_set_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__main", (RTS_UINTPTR)snmp_set_v3__main, 1, RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200) 
	#define EXTREF_ITF_snmp_set_v3__main {(RTS_VOID_FCTPTR)snmp_set_v3__main, "snmp_set_v3__main", RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set_v3__main
	#define EXT_snmp_set_v3__main
	#define GET_snmp_set_v3__main(fl)  CAL_CMGETAPI( "snmp_set_v3__main" ) 
	#define CAL_snmp_set_v3__main  snmp_set_v3__main
	#define CHK_snmp_set_v3__main  TRUE
	#define EXP_snmp_set_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__main", (RTS_UINTPTR)snmp_set_v3__main, 1, RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set_v3__main
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set_v3__main
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set_v3__main  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set_v3__main  snmp_set_v3__main
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set_v3__main  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__main", (RTS_UINTPTR)snmp_set_v3__main, 1, RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set_v3__main
	#define EXT_snmp_set_v3__main
	#define GET_snmp_set_v3__main(fl)  CAL_CMGETAPI( "snmp_set_v3__main" ) 
	#define CAL_snmp_set_v3__main  snmp_set_v3__main
	#define CHK_snmp_set_v3__main  TRUE
	#define EXP_snmp_set_v3__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__main", (RTS_UINTPTR)snmp_set_v3__main, 1, RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set_v3__main  PFSNMP_SET_V3__MAIN_IEC pfsnmp_set_v3__main;
	#define EXT_snmp_set_v3__main  extern PFSNMP_SET_V3__MAIN_IEC pfsnmp_set_v3__main;
	#define GET_snmp_set_v3__main(fl)  s_pfCMGetAPI2( "snmp_set_v3__main", (RTS_VOID_FCTPTR *)&pfsnmp_set_v3__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200)
	#define CAL_snmp_set_v3__main  pfsnmp_set_v3__main
	#define CHK_snmp_set_v3__main  (pfsnmp_set_v3__main != NULL)
	#define EXP_snmp_set_v3__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__main", (RTS_UINTPTR)snmp_set_v3__main, 1, RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200) 
#endif


/**
 * <description>snmp_set_v3_fb_init</description>
 */
typedef struct tagsnmp_set_v3_fb_init_struct
{
	snmp_set_v3_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} snmp_set_v3_fb_init_struct;

void CDECL CDECL_EXT snmp_set_v3__fb_init(snmp_set_v3_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET_V3__FB_INIT_IEC) (snmp_set_v3_fb_init_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET_V3__FB_INIT_NOTIMPLEMENTED)
	#define USE_snmp_set_v3__fb_init
	#define EXT_snmp_set_v3__fb_init
	#define GET_snmp_set_v3__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set_v3__fb_init(p0) 
	#define CHK_snmp_set_v3__fb_init  FALSE
	#define EXP_snmp_set_v3__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set_v3__fb_init
	#define EXT_snmp_set_v3__fb_init
	#define GET_snmp_set_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_set_v3__fb_init" ) 
	#define CAL_snmp_set_v3__fb_init  snmp_set_v3__fb_init
	#define CHK_snmp_set_v3__fb_init  TRUE
	#define EXP_snmp_set_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_init", (RTS_UINTPTR)snmp_set_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200) 
	#define EXTREF_ITF_snmp_set_v3__fb_init {(RTS_VOID_FCTPTR)snmp_set_v3__fb_init, "snmp_set_v3__fb_init", RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set_v3__fb_init
	#define EXT_snmp_set_v3__fb_init
	#define GET_snmp_set_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_set_v3__fb_init" ) 
	#define CAL_snmp_set_v3__fb_init  snmp_set_v3__fb_init
	#define CHK_snmp_set_v3__fb_init  TRUE
	#define EXP_snmp_set_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_init", (RTS_UINTPTR)snmp_set_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_init
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_init
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_init  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_init  snmp_set_v3__fb_init
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_init  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_init", (RTS_UINTPTR)snmp_set_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set_v3__fb_init
	#define EXT_snmp_set_v3__fb_init
	#define GET_snmp_set_v3__fb_init(fl)  CAL_CMGETAPI( "snmp_set_v3__fb_init" ) 
	#define CAL_snmp_set_v3__fb_init  snmp_set_v3__fb_init
	#define CHK_snmp_set_v3__fb_init  TRUE
	#define EXP_snmp_set_v3__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_init", (RTS_UINTPTR)snmp_set_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set_v3__fb_init  PFSNMP_SET_V3__FB_INIT_IEC pfsnmp_set_v3__fb_init;
	#define EXT_snmp_set_v3__fb_init  extern PFSNMP_SET_V3__FB_INIT_IEC pfsnmp_set_v3__fb_init;
	#define GET_snmp_set_v3__fb_init(fl)  s_pfCMGetAPI2( "snmp_set_v3__fb_init", (RTS_VOID_FCTPTR *)&pfsnmp_set_v3__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200)
	#define CAL_snmp_set_v3__fb_init  pfsnmp_set_v3__fb_init
	#define CHK_snmp_set_v3__fb_init  (pfsnmp_set_v3__fb_init != NULL)
	#define EXP_snmp_set_v3__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_init", (RTS_UINTPTR)snmp_set_v3__fb_init, 1, RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200) 
#endif


/**
 * <description>snmp_set_v3_fb_exit</description>
 */
typedef struct tagsnmp_set_v3_fb_exit_struct
{
	snmp_set_v3_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} snmp_set_v3_fb_exit_struct;

void CDECL CDECL_EXT snmp_set_v3__fb_exit(snmp_set_v3_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_SET_V3__FB_EXIT_IEC) (snmp_set_v3_fb_exit_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_SET_V3__FB_EXIT_NOTIMPLEMENTED)
	#define USE_snmp_set_v3__fb_exit
	#define EXT_snmp_set_v3__fb_exit
	#define GET_snmp_set_v3__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_set_v3__fb_exit(p0) 
	#define CHK_snmp_set_v3__fb_exit  FALSE
	#define EXP_snmp_set_v3__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_set_v3__fb_exit
	#define EXT_snmp_set_v3__fb_exit
	#define GET_snmp_set_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_set_v3__fb_exit" ) 
	#define CAL_snmp_set_v3__fb_exit  snmp_set_v3__fb_exit
	#define CHK_snmp_set_v3__fb_exit  TRUE
	#define EXP_snmp_set_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_exit", (RTS_UINTPTR)snmp_set_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200) 
	#define EXTREF_ITF_snmp_set_v3__fb_exit {(RTS_VOID_FCTPTR)snmp_set_v3__fb_exit, "snmp_set_v3__fb_exit", RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_set_v3__fb_exit
	#define EXT_snmp_set_v3__fb_exit
	#define GET_snmp_set_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_set_v3__fb_exit" ) 
	#define CAL_snmp_set_v3__fb_exit  snmp_set_v3__fb_exit
	#define CHK_snmp_set_v3__fb_exit  TRUE
	#define EXP_snmp_set_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_exit", (RTS_UINTPTR)snmp_set_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_exit
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_exit
	#define GET_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_exit  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_exit  snmp_set_v3__fb_exit
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_exit  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_set_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_exit", (RTS_UINTPTR)snmp_set_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_set_v3__fb_exit
	#define EXT_snmp_set_v3__fb_exit
	#define GET_snmp_set_v3__fb_exit(fl)  CAL_CMGETAPI( "snmp_set_v3__fb_exit" ) 
	#define CAL_snmp_set_v3__fb_exit  snmp_set_v3__fb_exit
	#define CHK_snmp_set_v3__fb_exit  TRUE
	#define EXP_snmp_set_v3__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_exit", (RTS_UINTPTR)snmp_set_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_set_v3__fb_exit  PFSNMP_SET_V3__FB_EXIT_IEC pfsnmp_set_v3__fb_exit;
	#define EXT_snmp_set_v3__fb_exit  extern PFSNMP_SET_V3__FB_EXIT_IEC pfsnmp_set_v3__fb_exit;
	#define GET_snmp_set_v3__fb_exit(fl)  s_pfCMGetAPI2( "snmp_set_v3__fb_exit", (RTS_VOID_FCTPTR *)&pfsnmp_set_v3__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200)
	#define CAL_snmp_set_v3__fb_exit  pfsnmp_set_v3__fb_exit
	#define CHK_snmp_set_v3__fb_exit  (pfsnmp_set_v3__fb_exit != NULL)
	#define EXP_snmp_set_v3__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_set_v3__fb_exit", (RTS_UINTPTR)snmp_set_v3__fb_exit, 1, RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200) 
#endif


/**
 * <description>snmp_string_to_tlv</description>
 */
typedef struct tagsnmp_string_to_tlv_struct
{
	RTS_IEC_STRING sInput[256];			/* VAR_INPUT */	/* Input-Value */
	RTS_IEC_INT typDatatype;			/* VAR_INPUT, Enum: ESNMP_TLV_DATATYPE */
	typSNMP_TLV *typData;				/* VAR_IN_OUT */	/* Container for TLV */
	RTS_IEC_DINT SNMP_STRING_TO_TLV;	/* VAR_OUTPUT */	
} snmp_string_to_tlv_struct;

void CDECL CDECL_EXT snmp_string_to_tlv(snmp_string_to_tlv_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_STRING_TO_TLV_IEC) (snmp_string_to_tlv_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_STRING_TO_TLV_NOTIMPLEMENTED)
	#define USE_snmp_string_to_tlv
	#define EXT_snmp_string_to_tlv
	#define GET_snmp_string_to_tlv(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_string_to_tlv(p0) 
	#define CHK_snmp_string_to_tlv  FALSE
	#define EXP_snmp_string_to_tlv  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_string_to_tlv
	#define EXT_snmp_string_to_tlv
	#define GET_snmp_string_to_tlv(fl)  CAL_CMGETAPI( "snmp_string_to_tlv" ) 
	#define CAL_snmp_string_to_tlv  snmp_string_to_tlv
	#define CHK_snmp_string_to_tlv  TRUE
	#define EXP_snmp_string_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_string_to_tlv", (RTS_UINTPTR)snmp_string_to_tlv, 1, RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200) 
	#define EXTREF_ITF_snmp_string_to_tlv {(RTS_VOID_FCTPTR)snmp_string_to_tlv, "snmp_string_to_tlv", RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_string_to_tlv
	#define EXT_snmp_string_to_tlv
	#define GET_snmp_string_to_tlv(fl)  CAL_CMGETAPI( "snmp_string_to_tlv" ) 
	#define CAL_snmp_string_to_tlv  snmp_string_to_tlv
	#define CHK_snmp_string_to_tlv  TRUE
	#define EXP_snmp_string_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_string_to_tlv", (RTS_UINTPTR)snmp_string_to_tlv, 1, RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_string_to_tlv
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_string_to_tlv
	#define GET_WagoSysSNMP_Internal_PFCsnmp_string_to_tlv  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_string_to_tlv  snmp_string_to_tlv
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_string_to_tlv  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_string_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_string_to_tlv", (RTS_UINTPTR)snmp_string_to_tlv, 1, RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_string_to_tlv
	#define EXT_snmp_string_to_tlv
	#define GET_snmp_string_to_tlv(fl)  CAL_CMGETAPI( "snmp_string_to_tlv" ) 
	#define CAL_snmp_string_to_tlv  snmp_string_to_tlv
	#define CHK_snmp_string_to_tlv  TRUE
	#define EXP_snmp_string_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_string_to_tlv", (RTS_UINTPTR)snmp_string_to_tlv, 1, RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_string_to_tlv  PFSNMP_STRING_TO_TLV_IEC pfsnmp_string_to_tlv;
	#define EXT_snmp_string_to_tlv  extern PFSNMP_STRING_TO_TLV_IEC pfsnmp_string_to_tlv;
	#define GET_snmp_string_to_tlv(fl)  s_pfCMGetAPI2( "snmp_string_to_tlv", (RTS_VOID_FCTPTR *)&pfsnmp_string_to_tlv, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200)
	#define CAL_snmp_string_to_tlv  pfsnmp_string_to_tlv
	#define CHK_snmp_string_to_tlv  (pfsnmp_string_to_tlv != NULL)
	#define EXP_snmp_string_to_tlv   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_string_to_tlv", (RTS_UINTPTR)snmp_string_to_tlv, 1, RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200) 
#endif


/**
 * <description>snmp_tlv_get_type</description>
 */
typedef struct tagsnmp_tlv_get_type_struct
{
	typSNMP_TLV typData;				/* VAR_INPUT */	
	RTS_IEC_INT SNMP_TLV_GET_TYPE;		/* VAR_OUTPUT, Enum: ESNMP_TLV_DATATYPE */
} snmp_tlv_get_type_struct;

void CDECL CDECL_EXT snmp_tlv_get_type(snmp_tlv_get_type_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_TLV_GET_TYPE_IEC) (snmp_tlv_get_type_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_TLV_GET_TYPE_NOTIMPLEMENTED)
	#define USE_snmp_tlv_get_type
	#define EXT_snmp_tlv_get_type
	#define GET_snmp_tlv_get_type(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_tlv_get_type(p0) 
	#define CHK_snmp_tlv_get_type  FALSE
	#define EXP_snmp_tlv_get_type  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_tlv_get_type
	#define EXT_snmp_tlv_get_type
	#define GET_snmp_tlv_get_type(fl)  CAL_CMGETAPI( "snmp_tlv_get_type" ) 
	#define CAL_snmp_tlv_get_type  snmp_tlv_get_type
	#define CHK_snmp_tlv_get_type  TRUE
	#define EXP_snmp_tlv_get_type  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_get_type", (RTS_UINTPTR)snmp_tlv_get_type, 1, RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200) 
	#define EXTREF_ITF_snmp_tlv_get_type {(RTS_VOID_FCTPTR)snmp_tlv_get_type, "snmp_tlv_get_type", RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_tlv_get_type
	#define EXT_snmp_tlv_get_type
	#define GET_snmp_tlv_get_type(fl)  CAL_CMGETAPI( "snmp_tlv_get_type" ) 
	#define CAL_snmp_tlv_get_type  snmp_tlv_get_type
	#define CHK_snmp_tlv_get_type  TRUE
	#define EXP_snmp_tlv_get_type  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_get_type", (RTS_UINTPTR)snmp_tlv_get_type, 1, RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_tlv_get_type
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_tlv_get_type
	#define GET_WagoSysSNMP_Internal_PFCsnmp_tlv_get_type  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_tlv_get_type  snmp_tlv_get_type
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_tlv_get_type  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_tlv_get_type  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_get_type", (RTS_UINTPTR)snmp_tlv_get_type, 1, RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_tlv_get_type
	#define EXT_snmp_tlv_get_type
	#define GET_snmp_tlv_get_type(fl)  CAL_CMGETAPI( "snmp_tlv_get_type" ) 
	#define CAL_snmp_tlv_get_type  snmp_tlv_get_type
	#define CHK_snmp_tlv_get_type  TRUE
	#define EXP_snmp_tlv_get_type  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_get_type", (RTS_UINTPTR)snmp_tlv_get_type, 1, RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_tlv_get_type  PFSNMP_TLV_GET_TYPE_IEC pfsnmp_tlv_get_type;
	#define EXT_snmp_tlv_get_type  extern PFSNMP_TLV_GET_TYPE_IEC pfsnmp_tlv_get_type;
	#define GET_snmp_tlv_get_type(fl)  s_pfCMGetAPI2( "snmp_tlv_get_type", (RTS_VOID_FCTPTR *)&pfsnmp_tlv_get_type, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200)
	#define CAL_snmp_tlv_get_type  pfsnmp_tlv_get_type
	#define CHK_snmp_tlv_get_type  (pfsnmp_tlv_get_type != NULL)
	#define EXP_snmp_tlv_get_type   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_get_type", (RTS_UINTPTR)snmp_tlv_get_type, 1, RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200) 
#endif


/**
 * <description>snmp_tlv_to_dint</description>
 */
typedef struct tagsnmp_tlv_to_dint_struct
{
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Prefilled TLV-Container */
	RTS_IEC_DINT *diValue;				/* VAR_IN_OUT */	/* container for Output value */
	RTS_IEC_DINT SNMP_TLV_TO_DINT;		/* VAR_OUTPUT */	
} snmp_tlv_to_dint_struct;

void CDECL CDECL_EXT snmp_tlv_to_dint(snmp_tlv_to_dint_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_TLV_TO_DINT_IEC) (snmp_tlv_to_dint_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_TLV_TO_DINT_NOTIMPLEMENTED)
	#define USE_snmp_tlv_to_dint
	#define EXT_snmp_tlv_to_dint
	#define GET_snmp_tlv_to_dint(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_tlv_to_dint(p0) 
	#define CHK_snmp_tlv_to_dint  FALSE
	#define EXP_snmp_tlv_to_dint  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_tlv_to_dint
	#define EXT_snmp_tlv_to_dint
	#define GET_snmp_tlv_to_dint(fl)  CAL_CMGETAPI( "snmp_tlv_to_dint" ) 
	#define CAL_snmp_tlv_to_dint  snmp_tlv_to_dint
	#define CHK_snmp_tlv_to_dint  TRUE
	#define EXP_snmp_tlv_to_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_dint", (RTS_UINTPTR)snmp_tlv_to_dint, 1, RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200) 
	#define EXTREF_ITF_snmp_tlv_to_dint {(RTS_VOID_FCTPTR)snmp_tlv_to_dint, "snmp_tlv_to_dint", RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_tlv_to_dint
	#define EXT_snmp_tlv_to_dint
	#define GET_snmp_tlv_to_dint(fl)  CAL_CMGETAPI( "snmp_tlv_to_dint" ) 
	#define CAL_snmp_tlv_to_dint  snmp_tlv_to_dint
	#define CHK_snmp_tlv_to_dint  TRUE
	#define EXP_snmp_tlv_to_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_dint", (RTS_UINTPTR)snmp_tlv_to_dint, 1, RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_tlv_to_dint
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_tlv_to_dint
	#define GET_WagoSysSNMP_Internal_PFCsnmp_tlv_to_dint  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_tlv_to_dint  snmp_tlv_to_dint
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_tlv_to_dint  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_tlv_to_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_dint", (RTS_UINTPTR)snmp_tlv_to_dint, 1, RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_tlv_to_dint
	#define EXT_snmp_tlv_to_dint
	#define GET_snmp_tlv_to_dint(fl)  CAL_CMGETAPI( "snmp_tlv_to_dint" ) 
	#define CAL_snmp_tlv_to_dint  snmp_tlv_to_dint
	#define CHK_snmp_tlv_to_dint  TRUE
	#define EXP_snmp_tlv_to_dint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_dint", (RTS_UINTPTR)snmp_tlv_to_dint, 1, RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_tlv_to_dint  PFSNMP_TLV_TO_DINT_IEC pfsnmp_tlv_to_dint;
	#define EXT_snmp_tlv_to_dint  extern PFSNMP_TLV_TO_DINT_IEC pfsnmp_tlv_to_dint;
	#define GET_snmp_tlv_to_dint(fl)  s_pfCMGetAPI2( "snmp_tlv_to_dint", (RTS_VOID_FCTPTR *)&pfsnmp_tlv_to_dint, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200)
	#define CAL_snmp_tlv_to_dint  pfsnmp_tlv_to_dint
	#define CHK_snmp_tlv_to_dint  (pfsnmp_tlv_to_dint != NULL)
	#define EXP_snmp_tlv_to_dint   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_dint", (RTS_UINTPTR)snmp_tlv_to_dint, 1, RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200) 
#endif


/**
 * <description>snmp_tlv_to_string</description>
 */
typedef struct tagsnmp_tlv_to_string_struct
{
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Prefilled TLV-Container */
	RTS_IEC_STRING *sValue;				/* VAR_IN_OUT */	/* container for Output value */
	RTS_IEC_DINT SNMP_TLV_TO_STRING;	/* VAR_OUTPUT */	
} snmp_tlv_to_string_struct;

void CDECL CDECL_EXT snmp_tlv_to_string(snmp_tlv_to_string_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_TLV_TO_STRING_IEC) (snmp_tlv_to_string_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_TLV_TO_STRING_NOTIMPLEMENTED)
	#define USE_snmp_tlv_to_string
	#define EXT_snmp_tlv_to_string
	#define GET_snmp_tlv_to_string(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_tlv_to_string(p0) 
	#define CHK_snmp_tlv_to_string  FALSE
	#define EXP_snmp_tlv_to_string  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_tlv_to_string
	#define EXT_snmp_tlv_to_string
	#define GET_snmp_tlv_to_string(fl)  CAL_CMGETAPI( "snmp_tlv_to_string" ) 
	#define CAL_snmp_tlv_to_string  snmp_tlv_to_string
	#define CHK_snmp_tlv_to_string  TRUE
	#define EXP_snmp_tlv_to_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_string", (RTS_UINTPTR)snmp_tlv_to_string, 1, RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200) 
	#define EXTREF_ITF_snmp_tlv_to_string {(RTS_VOID_FCTPTR)snmp_tlv_to_string, "snmp_tlv_to_string", RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_tlv_to_string
	#define EXT_snmp_tlv_to_string
	#define GET_snmp_tlv_to_string(fl)  CAL_CMGETAPI( "snmp_tlv_to_string" ) 
	#define CAL_snmp_tlv_to_string  snmp_tlv_to_string
	#define CHK_snmp_tlv_to_string  TRUE
	#define EXP_snmp_tlv_to_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_string", (RTS_UINTPTR)snmp_tlv_to_string, 1, RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_tlv_to_string
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_tlv_to_string
	#define GET_WagoSysSNMP_Internal_PFCsnmp_tlv_to_string  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_tlv_to_string  snmp_tlv_to_string
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_tlv_to_string  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_tlv_to_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_string", (RTS_UINTPTR)snmp_tlv_to_string, 1, RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_tlv_to_string
	#define EXT_snmp_tlv_to_string
	#define GET_snmp_tlv_to_string(fl)  CAL_CMGETAPI( "snmp_tlv_to_string" ) 
	#define CAL_snmp_tlv_to_string  snmp_tlv_to_string
	#define CHK_snmp_tlv_to_string  TRUE
	#define EXP_snmp_tlv_to_string  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_string", (RTS_UINTPTR)snmp_tlv_to_string, 1, RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_tlv_to_string  PFSNMP_TLV_TO_STRING_IEC pfsnmp_tlv_to_string;
	#define EXT_snmp_tlv_to_string  extern PFSNMP_TLV_TO_STRING_IEC pfsnmp_tlv_to_string;
	#define GET_snmp_tlv_to_string(fl)  s_pfCMGetAPI2( "snmp_tlv_to_string", (RTS_VOID_FCTPTR *)&pfsnmp_tlv_to_string, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200)
	#define CAL_snmp_tlv_to_string  pfsnmp_tlv_to_string
	#define CHK_snmp_tlv_to_string  (pfsnmp_tlv_to_string != NULL)
	#define EXP_snmp_tlv_to_string   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_string", (RTS_UINTPTR)snmp_tlv_to_string, 1, RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200) 
#endif


/**
 * <description>snmp_tlv_to_udint</description>
 */
typedef struct tagsnmp_tlv_to_udint_struct
{
	typSNMP_TLV typData;				/* VAR_INPUT */	/* Prefilled TLV-Container */
	RTS_IEC_UDINT *udiValue;			/* VAR_IN_OUT */	/* container for Output value */
	RTS_IEC_DINT SNMP_TLV_TO_UDINT;		/* VAR_OUTPUT */	
} snmp_tlv_to_udint_struct;

void CDECL CDECL_EXT snmp_tlv_to_udint(snmp_tlv_to_udint_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_TLV_TO_UDINT_IEC) (snmp_tlv_to_udint_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_TLV_TO_UDINT_NOTIMPLEMENTED)
	#define USE_snmp_tlv_to_udint
	#define EXT_snmp_tlv_to_udint
	#define GET_snmp_tlv_to_udint(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_tlv_to_udint(p0) 
	#define CHK_snmp_tlv_to_udint  FALSE
	#define EXP_snmp_tlv_to_udint  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_tlv_to_udint
	#define EXT_snmp_tlv_to_udint
	#define GET_snmp_tlv_to_udint(fl)  CAL_CMGETAPI( "snmp_tlv_to_udint" ) 
	#define CAL_snmp_tlv_to_udint  snmp_tlv_to_udint
	#define CHK_snmp_tlv_to_udint  TRUE
	#define EXP_snmp_tlv_to_udint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_udint", (RTS_UINTPTR)snmp_tlv_to_udint, 1, RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200) 
	#define EXTREF_ITF_snmp_tlv_to_udint {(RTS_VOID_FCTPTR)snmp_tlv_to_udint, "snmp_tlv_to_udint", RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_tlv_to_udint
	#define EXT_snmp_tlv_to_udint
	#define GET_snmp_tlv_to_udint(fl)  CAL_CMGETAPI( "snmp_tlv_to_udint" ) 
	#define CAL_snmp_tlv_to_udint  snmp_tlv_to_udint
	#define CHK_snmp_tlv_to_udint  TRUE
	#define EXP_snmp_tlv_to_udint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_udint", (RTS_UINTPTR)snmp_tlv_to_udint, 1, RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_tlv_to_udint
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_tlv_to_udint
	#define GET_WagoSysSNMP_Internal_PFCsnmp_tlv_to_udint  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_tlv_to_udint  snmp_tlv_to_udint
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_tlv_to_udint  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_tlv_to_udint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_udint", (RTS_UINTPTR)snmp_tlv_to_udint, 1, RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_tlv_to_udint
	#define EXT_snmp_tlv_to_udint
	#define GET_snmp_tlv_to_udint(fl)  CAL_CMGETAPI( "snmp_tlv_to_udint" ) 
	#define CAL_snmp_tlv_to_udint  snmp_tlv_to_udint
	#define CHK_snmp_tlv_to_udint  TRUE
	#define EXP_snmp_tlv_to_udint  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_udint", (RTS_UINTPTR)snmp_tlv_to_udint, 1, RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_tlv_to_udint  PFSNMP_TLV_TO_UDINT_IEC pfsnmp_tlv_to_udint;
	#define EXT_snmp_tlv_to_udint  extern PFSNMP_TLV_TO_UDINT_IEC pfsnmp_tlv_to_udint;
	#define GET_snmp_tlv_to_udint(fl)  s_pfCMGetAPI2( "snmp_tlv_to_udint", (RTS_VOID_FCTPTR *)&pfsnmp_tlv_to_udint, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200)
	#define CAL_snmp_tlv_to_udint  pfsnmp_tlv_to_udint
	#define CHK_snmp_tlv_to_udint  (pfsnmp_tlv_to_udint != NULL)
	#define EXP_snmp_tlv_to_udint   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_tlv_to_udint", (RTS_UINTPTR)snmp_tlv_to_udint, 1, RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200) 
#endif


/**
 * <description>snmp_udint_to_tlv</description>
 */
typedef struct tagsnmp_udint_to_tlv_struct
{
	RTS_IEC_UDINT udiInput;				/* VAR_INPUT */	/* Input-Value */
	RTS_IEC_INT typDatatype;			/* VAR_INPUT, Enum: ESNMP_TLV_DATATYPE */
	typSNMP_TLV *typData;				/* VAR_IN_OUT */	/* Container for TLV */
	RTS_IEC_DINT SNMP_UDINT_TO_TLV;		/* VAR_OUTPUT */	
} snmp_udint_to_tlv_struct;

void CDECL CDECL_EXT snmp_udint_to_tlv(snmp_udint_to_tlv_struct *p);
typedef void (CDECL CDECL_EXT* PFSNMP_UDINT_TO_TLV_IEC) (snmp_udint_to_tlv_struct *p);
#if defined(WAGOSYSSNMP_INTERNAL_PFC_NOTIMPLEMENTED) || defined(SNMP_UDINT_TO_TLV_NOTIMPLEMENTED)
	#define USE_snmp_udint_to_tlv
	#define EXT_snmp_udint_to_tlv
	#define GET_snmp_udint_to_tlv(fl)  ERR_NOTIMPLEMENTED
	#define CAL_snmp_udint_to_tlv(p0) 
	#define CHK_snmp_udint_to_tlv  FALSE
	#define EXP_snmp_udint_to_tlv  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_snmp_udint_to_tlv
	#define EXT_snmp_udint_to_tlv
	#define GET_snmp_udint_to_tlv(fl)  CAL_CMGETAPI( "snmp_udint_to_tlv" ) 
	#define CAL_snmp_udint_to_tlv  snmp_udint_to_tlv
	#define CHK_snmp_udint_to_tlv  TRUE
	#define EXP_snmp_udint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_udint_to_tlv", (RTS_UINTPTR)snmp_udint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200) 
	#define EXTREF_ITF_snmp_udint_to_tlv {(RTS_VOID_FCTPTR)snmp_udint_to_tlv, "snmp_udint_to_tlv", RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSNMP_INTERNAL_PFC_EXTERNAL)
	#define USE_snmp_udint_to_tlv
	#define EXT_snmp_udint_to_tlv
	#define GET_snmp_udint_to_tlv(fl)  CAL_CMGETAPI( "snmp_udint_to_tlv" ) 
	#define CAL_snmp_udint_to_tlv  snmp_udint_to_tlv
	#define CHK_snmp_udint_to_tlv  TRUE
	#define EXP_snmp_udint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_udint_to_tlv", (RTS_UINTPTR)snmp_udint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSNMP_Internal_PFCsnmp_udint_to_tlv
	#define EXT_WagoSysSNMP_Internal_PFCsnmp_udint_to_tlv
	#define GET_WagoSysSNMP_Internal_PFCsnmp_udint_to_tlv  ERR_OK
	#define CAL_WagoSysSNMP_Internal_PFCsnmp_udint_to_tlv  snmp_udint_to_tlv
	#define CHK_WagoSysSNMP_Internal_PFCsnmp_udint_to_tlv  TRUE
	#define EXP_WagoSysSNMP_Internal_PFCsnmp_udint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_udint_to_tlv", (RTS_UINTPTR)snmp_udint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200) 
#elif defined(CPLUSPLUS)
	#define USE_snmp_udint_to_tlv
	#define EXT_snmp_udint_to_tlv
	#define GET_snmp_udint_to_tlv(fl)  CAL_CMGETAPI( "snmp_udint_to_tlv" ) 
	#define CAL_snmp_udint_to_tlv  snmp_udint_to_tlv
	#define CHK_snmp_udint_to_tlv  TRUE
	#define EXP_snmp_udint_to_tlv  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_udint_to_tlv", (RTS_UINTPTR)snmp_udint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200) 
#else /* DYNAMIC_LINK */
	#define USE_snmp_udint_to_tlv  PFSNMP_UDINT_TO_TLV_IEC pfsnmp_udint_to_tlv;
	#define EXT_snmp_udint_to_tlv  extern PFSNMP_UDINT_TO_TLV_IEC pfsnmp_udint_to_tlv;
	#define GET_snmp_udint_to_tlv(fl)  s_pfCMGetAPI2( "snmp_udint_to_tlv", (RTS_VOID_FCTPTR *)&pfsnmp_udint_to_tlv, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200)
	#define CAL_snmp_udint_to_tlv  pfsnmp_udint_to_tlv
	#define CHK_snmp_udint_to_tlv  (pfsnmp_udint_to_tlv != NULL)
	#define EXP_snmp_udint_to_tlv   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"snmp_udint_to_tlv", (RTS_UINTPTR)snmp_udint_to_tlv, 1, RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysSNMP_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysSNMP_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysSNMP_Internal_PFC
		#define ITF_WagoSysSNMP_Internal_PFC static IWagoSysSNMP_Internal_PFC *pIWagoSysSNMP_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysSNMP_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysSNMP_Internal_PFC_C		IWagoSysSNMP_Internal_PFC;
	#ifndef ITF_WagoSysSNMP_Internal_PFC
		#define ITF_WagoSysSNMP_Internal_PFC
	#endif
	#define EXTITF_WagoSysSNMP_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSSNMP_INTERNAL_PFCITF_H_*/
