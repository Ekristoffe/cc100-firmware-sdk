//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     service.hpp
///
///  \brief    Used to access certificates as configuration files
///
///  \author   MLa : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_CERTIFICATE_HPP_
#define INCLUDE_WAGO_CERTIFICATE_HPP_

#include <wago/wdx/base_parameter_provider.hpp>
#include <wago/wdx/linuxos/file/config_file.hpp>

#include <string>
#include <memory>
#include <map>

namespace wago
{

class certificates
{
    certificates(const certificates&) = delete;
    certificates& operator=(const certificates&) = delete;

  private:
    class cert_file
    {
      public:
        std::shared_ptr<wdx::linuxos::file::config_file> file;
        bool is_text;
        cert_file(std::shared_ptr<wdx::linuxos::file::config_file> cf, bool as_text) throw() : file(cf), is_text(as_text) {}
    };
    std::map<wago::wdx::parameter_id_t, std::shared_ptr<cert_file> > cert_files;

  public:
    certificates() {};
    bool add_certificate(std::string path, wdx::parameter_id_t pp_id);
    bool add_private_key(std::string path, wdx::parameter_id_t pp_id);
    bool add_description(std::string path, wdx::parameter_id_t pp_id);
    bool add_certificate_bundle(std::string directory, wdx::parameter_id_t cert_id, wdx::parameter_id_t pkey_id, wdx::parameter_id_t desc_id);

    wdx::set_parameter_response set_value(wdx::parameter_id_t id, const std::vector<uint8_t> &data);

    wdx::value_response get_value(wdx::parameter_id_t id);

    bool is_cert(wdx::parameter_id_t id) const;
};

}

#endif /* INCLUDE_WAGO_PP_SERVICES_CERTIFICATES_HPP_ */
// vim: ts=4 sw=4 expandtab
