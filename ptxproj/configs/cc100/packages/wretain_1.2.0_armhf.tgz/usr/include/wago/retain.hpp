//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
///  \file
///
///  \brief    Retain Variables C++ API.
///
///  \author   WAGO GmbH & Co. KG
///-----------------------------------------------------------------------------


#ifndef WAGO_RETAIN_HPP_
#define WAGO_RETAIN_HPP_


#include <gsl/span>
#include <cstdint>
#include <limits>
#include <memory>
#include <utility>


namespace wago {


///
/// Interface to the retain variables memory framework.
/// Only one instance of this class may exist at the same time.
/// Implementation depends on the underlying, supporting hardware.
///
class retain
{
public:
    ///
    /// Creates retain variables object and automatically initializes it.
    /// Overflowing by a specific size extends the allocated RV memory area
    /// however the overflow area is not persisted and is lost after deinitialization.
    /// @param overflow_size - the amount of bytes by which the RV memory area should be extended.
    ///                        Set to max value of std::size_t to use value set in configuration file.
    /// @param read_only - is set to true then the retain variables will be opened in read-only mode.
    ///                    Read-only mode may be useful on platforms on which RV memory contains metadata and on which
    ///                    this metadata may be modified even if the RV memory itself is not modified by the user.
    ///                    Such behaviour may lead to issues if two parallel accesses to RV memory from two different
    ///                    applications are executed. In such a case one of the applications may select to use read-only
    ///                    access mode, for example just to read-out the size of the RV memory.
    ///                    It is supported only on specific platforms.
    /// @return pointer to opened object
    ///
    static std::unique_ptr<retain> get_retain(std::size_t overflow_size =
                                                            std::numeric_limits<std::size_t>::max(),
                                              bool read_only = false);

    ///
    /// Automatically closes managed retain variables memory area, if opened.
    /// Ignores any potential errors during close procedure.
    ///
    virtual ~retain() = default;

    ///
    /// Closes managed retain variables memory area, if opened.
    /// @return error code if procedure failed.
    ///
    virtual std::error_code close() noexcept = 0;

    ///
    /// Returns retain variables memory area.
    ///
    virtual gsl::span<uint8_t> get() const = 0;

    ///
    /// Returns pointer to retain variables memory area.
    ///
    virtual uint8_t* data() const noexcept = 0;

    ///
    /// Returns size of retain variables memory area, in bytes.
    ///
    virtual std::size_t size() const noexcept = 0;

    ///
    /// Synchronizes retain variables memory state with underlying hardware.
    /// It is normally unnecessary to call the function and it has an effect only in particular
    /// hardware configurations. By default memory should be synchronized automatically.
    ///
    virtual void synchronize() = 0;

    ///
    /// Formats the retain variables memory area.
    /// After the function is called the state of the memory area is identical as after first initializaton.
    ///
    virtual void format() = 0;

    ///
    /// Zeroes the retain variables memory area.
    ///
    virtual void zero() = 0;
};


} // namespace wago


#endif // WAGO_RETAIN_HPP_
