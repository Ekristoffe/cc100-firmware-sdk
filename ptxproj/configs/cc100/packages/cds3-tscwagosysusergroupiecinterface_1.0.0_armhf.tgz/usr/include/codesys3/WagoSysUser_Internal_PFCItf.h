 /**
 * <interfacename>WagoSysUser_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSUSER_INTERNAL_PFCITF_H_
#define _WAGOSYSUSER_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 *
 ***Function**
 *
 *	This function checks whether the specified user 'sUser' belongs to the specified group 'sGroup'.	
 *	
 *	Return true if 'sUser' belongs to 'sGroup'.
 */
typedef struct taguserisingroup_struct
{
	RTS_IEC_STRING sUser[257];			/* VAR_INPUT */	
	RTS_IEC_STRING sGroup[257];			/* VAR_INPUT */	
	RTS_IEC_BOOL UserIsInGroup;			/* VAR_OUTPUT */	
} userisingroup_struct;

void CDECL CDECL_EXT userisingroup(userisingroup_struct *p);
typedef void (CDECL CDECL_EXT* PFUSERISINGROUP_IEC) (userisingroup_struct *p);
#if defined(WAGOSYSUSER_INTERNAL_PFC_NOTIMPLEMENTED) || defined(USERISINGROUP_NOTIMPLEMENTED)
	#define USE_userisingroup
	#define EXT_userisingroup
	#define GET_userisingroup(fl)  ERR_NOTIMPLEMENTED
	#define CAL_userisingroup(p0) 
	#define CHK_userisingroup  FALSE
	#define EXP_userisingroup  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_userisingroup
	#define EXT_userisingroup
	#define GET_userisingroup(fl)  CAL_CMGETAPI( "userisingroup" ) 
	#define CAL_userisingroup  userisingroup
	#define CHK_userisingroup  TRUE
	#define EXP_userisingroup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"userisingroup", (RTS_UINTPTR)userisingroup, 1, 0x0C3D35A3, 0x01000000) 
	#define EXTREF_ITF_userisingroup {(RTS_VOID_FCTPTR)userisingroup, "userisingroup", 0x0C3D35A3, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSUSER_INTERNAL_PFC_EXTERNAL)
	#define USE_userisingroup
	#define EXT_userisingroup
	#define GET_userisingroup(fl)  CAL_CMGETAPI( "userisingroup" ) 
	#define CAL_userisingroup  userisingroup
	#define CHK_userisingroup  TRUE
	#define EXP_userisingroup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"userisingroup", (RTS_UINTPTR)userisingroup, 1, 0x0C3D35A3, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysUser_Internal_PFCuserisingroup
	#define EXT_WagoSysUser_Internal_PFCuserisingroup
	#define GET_WagoSysUser_Internal_PFCuserisingroup  ERR_OK
	#define CAL_WagoSysUser_Internal_PFCuserisingroup  userisingroup
	#define CHK_WagoSysUser_Internal_PFCuserisingroup  TRUE
	#define EXP_WagoSysUser_Internal_PFCuserisingroup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"userisingroup", (RTS_UINTPTR)userisingroup, 1, 0x0C3D35A3, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_userisingroup
	#define EXT_userisingroup
	#define GET_userisingroup(fl)  CAL_CMGETAPI( "userisingroup" ) 
	#define CAL_userisingroup  userisingroup
	#define CHK_userisingroup  TRUE
	#define EXP_userisingroup  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"userisingroup", (RTS_UINTPTR)userisingroup, 1, 0x0C3D35A3, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_userisingroup  PFUSERISINGROUP_IEC pfuserisingroup;
	#define EXT_userisingroup  extern PFUSERISINGROUP_IEC pfuserisingroup;
	#define GET_userisingroup(fl)  s_pfCMGetAPI2( "userisingroup", (RTS_VOID_FCTPTR *)&pfuserisingroup, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0C3D35A3, 0x01000000)
	#define CAL_userisingroup  pfuserisingroup
	#define CHK_userisingroup  (pfuserisingroup != NULL)
	#define EXP_userisingroup   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"userisingroup", (RTS_UINTPTR)userisingroup, 1, 0x0C3D35A3, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysUser_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysUser_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysUser_Internal_PFC
		#define ITF_WagoSysUser_Internal_PFC static IWagoSysUser_Internal_PFC *pIWagoSysUser_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysUser_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysUser_Internal_PFC_C		IWagoSysUser_Internal_PFC;
	#ifndef ITF_WagoSysUser_Internal_PFC
		#define ITF_WagoSysUser_Internal_PFC
	#endif
	#define EXTITF_WagoSysUser_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSUSER_INTERNAL_PFCITF_H_*/
