//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     memorycard_parameter_provider.hpp
///
///  \brief    Parameter Provider interface declaratiuon for memorycard management features
///
///  \author   BA : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef WAGO_PP_MEMORYCARD_MEMORYCARD_PARAMETER_PROVIDER_HPP_
#define WAGO_PP_MEMORYCARD_MEMORYCARD_PARAMETER_PROVIDER_HPP_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>


namespace wago
{
namespace pp_memorycard
{

/// \class activesystem_parameter_provider
/// \brief This parameter providers allows to access active system settings.
class memorycard_parameter_provider final
    : public wago::wdx::base_parameter_provider
{
public:
    memorycard_parameter_provider();
    ~memorycard_parameter_provider() override;
    memorycard_parameter_provider(memorycard_parameter_provider const &) = delete;
    memorycard_parameter_provider& operator=(memorycard_parameter_provider const &) = delete;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    future<wdx::method_invocation_response> invoke_method(
        wdx::parameter_instance_id method_id, std::vector<std::shared_ptr<wdx::parameter_value>> in_args) override;

private:
    class detail;
    detail * d_ptr;
};

} // namespace pp_memorycard
} // namespace wago

#endif /* WAGO_PP_MEMORYCARD_MEMORYCARD_PARAMETER_PROVIDER_HPP_ */

//---- End of source file ------------------------------------------------------

