 //---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     http://svsv01003/svn/repo3/pfc/trunk/wago_intern/codesys3-Component/Include/TscInterfaces/IoDrvKbusSItf.m4 (.h) 
///
/// \version  $Rev$
///
/// \brief    target specific component to support dynamic module configuration; iec- and fw-interface
///
/// \author   u015479 / WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------

	
	
#ifndef _IODRVKBUSSITF_H_
#define _IODRVKBUSSITF_H_

#include "CmpStd.h"

 

 




#include "WagoSysdefines.h"
#include "WagoSysKbusTerminalControl_Internal_CommonItf.h"

#define ITFID_IIoDrvKbusS ADDVENDORID(RTS_VENDORID_WAGO, IODRVKBUSS_ITFID_I)


/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif


/**
 * <description>Function calculates module slot number
 * <p></p>
 * <p>Function calculates module slot number for asynchronous module</p>
 * <p>access. Function uses given configured connector to calculate</p>
 * <p>slot number.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively connector</param>
 * <param name="pConnector" type="IN">pointer to static configured connector of traget KBUS modul</param>
 * <param name="pudiSlotNo" type="OUT">pointer to slot number of traget KBUS modul</param>
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Slot number calculated</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pConnector or pudiSlotNo was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_TYPE_MISMATCH">Connector type not supported</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static configuration found</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_DEVICE">No slot number for current modul available</errorcode>
 */
RTS_IEC_RESULT CDECL FuIoDrvCalculateSlotNumber_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVCALCULATESLOTNUMBER_S) (RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
#if defined(IODRVKBUSS_NOTIMPLEMENTED) || defined(FUIODRVCALCULATESLOTNUMBER_S_NOTIMPLEMENTED)
	#define USE_FuIoDrvCalculateSlotNumber_s
	#define EXT_FuIoDrvCalculateSlotNumber_s
	#define GET_FuIoDrvCalculateSlotNumber_s(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvCalculateSlotNumber_s(p0,p1,p2)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvCalculateSlotNumber_s  FALSE
	#define EXP_FuIoDrvCalculateSlotNumber_s  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvCalculateSlotNumber_s
	#define EXT_FuIoDrvCalculateSlotNumber_s
	#define GET_FuIoDrvCalculateSlotNumber_s(fl)  CAL_CMGETAPI( "FuIoDrvCalculateSlotNumber_s" ) 
	#define CAL_FuIoDrvCalculateSlotNumber_s  FuIoDrvCalculateSlotNumber_s
	#define CHK_FuIoDrvCalculateSlotNumber_s  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_s  CAL_CMEXPAPI( "FuIoDrvCalculateSlotNumber_s" ) 
#elif defined(MIXED_LINK) && !defined(IODRVKBUSS_EXTERNAL)
	#define USE_FuIoDrvCalculateSlotNumber_s
	#define EXT_FuIoDrvCalculateSlotNumber_s
	#define GET_FuIoDrvCalculateSlotNumber_s(fl)  CAL_CMGETAPI( "FuIoDrvCalculateSlotNumber_s" ) 
	#define CAL_FuIoDrvCalculateSlotNumber_s  FuIoDrvCalculateSlotNumber_s
	#define CHK_FuIoDrvCalculateSlotNumber_s  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvCalculateSlotNumber_s", (RTS_UINTPTR)FuIoDrvCalculateSlotNumber_s, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusSFuIoDrvCalculateSlotNumber_s
	#define EXT_IoDrvKbusSFuIoDrvCalculateSlotNumber_s
	#define GET_IoDrvKbusSFuIoDrvCalculateSlotNumber_s  ERR_OK
	#define CAL_IoDrvKbusSFuIoDrvCalculateSlotNumber_s CIoDrvKbusS::IFuIoDrvCalculateSlotNumber_s
	#define CHK_IoDrvKbusSFuIoDrvCalculateSlotNumber_s  TRUE
	#define EXP_IoDrvKbusSFuIoDrvCalculateSlotNumber_s  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvCalculateSlotNumber_s
	#define EXT_FuIoDrvCalculateSlotNumber_s
	#define GET_FuIoDrvCalculateSlotNumber_s(fl)  CAL_CMGETAPI( "FuIoDrvCalculateSlotNumber_s" ) 
	#define CAL_FuIoDrvCalculateSlotNumber_s CIoDrvKbusS::IFuIoDrvCalculateSlotNumber_s
	#define CHK_FuIoDrvCalculateSlotNumber_s  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_s  CAL_CMEXPAPI( "FuIoDrvCalculateSlotNumber_s" ) 
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvCalculateSlotNumber_s  PFFUIODRVCALCULATESLOTNUMBER_S pfFuIoDrvCalculateSlotNumber_s;
	#define EXT_FuIoDrvCalculateSlotNumber_s  extern PFFUIODRVCALCULATESLOTNUMBER_S pfFuIoDrvCalculateSlotNumber_s;
	#define GET_FuIoDrvCalculateSlotNumber_s(fl)  s_pfCMGetAPI2( "FuIoDrvCalculateSlotNumber_s", (RTS_VOID_FCTPTR *)&pfFuIoDrvCalculateSlotNumber_s, (fl), 0, 0)
	#define CAL_FuIoDrvCalculateSlotNumber_s  pfFuIoDrvCalculateSlotNumber_s
	#define CHK_FuIoDrvCalculateSlotNumber_s  (pfFuIoDrvCalculateSlotNumber_s != NULL)
	#define EXP_FuIoDrvCalculateSlotNumber_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvCalculateSlotNumber_s", (RTS_UINTPTR)FuIoDrvCalculateSlotNumber_s, 0, 0) 
#endif




/**
 * <description>Function reads module configuration resp. module data mapping state
 * <p></p>
 * <p>Function reads module configuration state and module data mapping</p>
 * <p>state. Function uses given configured connector to address module.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively connector</param>
 * <param name="pConnector" type="IN">pointer to static configured connector of traget KBUS modul</param>
 * <param name="peCnfSts" type="OUT">pointer to modul configuration state of traget KBUS modul</param>
 * <param name="peMapSts" type="OUT">pointer to modul data mapping state of traget KBUS modul</param>
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Valid state information for current module</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pConnector, eCnfSts or eMapSts was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_TYPE_MISMATCH">Connector type not supported</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static configuration found</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_DEVICE">No state information for current module available</errorcode>
 */
RTS_IEC_RESULT CDECL FuIoDrvGetConfMapState_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVGETCONFMAPSTATE_S) (RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
#if defined(IODRVKBUSS_NOTIMPLEMENTED) || defined(FUIODRVGETCONFMAPSTATE_S_NOTIMPLEMENTED)
	#define USE_FuIoDrvGetConfMapState_s
	#define EXT_FuIoDrvGetConfMapState_s
	#define GET_FuIoDrvGetConfMapState_s(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvGetConfMapState_s(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvGetConfMapState_s  FALSE
	#define EXP_FuIoDrvGetConfMapState_s  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvGetConfMapState_s
	#define EXT_FuIoDrvGetConfMapState_s
	#define GET_FuIoDrvGetConfMapState_s(fl)  CAL_CMGETAPI( "FuIoDrvGetConfMapState_s" ) 
	#define CAL_FuIoDrvGetConfMapState_s  FuIoDrvGetConfMapState_s
	#define CHK_FuIoDrvGetConfMapState_s  TRUE
	#define EXP_FuIoDrvGetConfMapState_s  CAL_CMEXPAPI( "FuIoDrvGetConfMapState_s" ) 
#elif defined(MIXED_LINK) && !defined(IODRVKBUSS_EXTERNAL)
	#define USE_FuIoDrvGetConfMapState_s
	#define EXT_FuIoDrvGetConfMapState_s
	#define GET_FuIoDrvGetConfMapState_s(fl)  CAL_CMGETAPI( "FuIoDrvGetConfMapState_s" ) 
	#define CAL_FuIoDrvGetConfMapState_s  FuIoDrvGetConfMapState_s
	#define CHK_FuIoDrvGetConfMapState_s  TRUE
	#define EXP_FuIoDrvGetConfMapState_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvGetConfMapState_s", (RTS_UINTPTR)FuIoDrvGetConfMapState_s, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusSFuIoDrvGetConfMapState_s
	#define EXT_IoDrvKbusSFuIoDrvGetConfMapState_s
	#define GET_IoDrvKbusSFuIoDrvGetConfMapState_s  ERR_OK
	#define CAL_IoDrvKbusSFuIoDrvGetConfMapState_s CIoDrvKbusS::IFuIoDrvGetConfMapState_s
	#define CHK_IoDrvKbusSFuIoDrvGetConfMapState_s  TRUE
	#define EXP_IoDrvKbusSFuIoDrvGetConfMapState_s  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvGetConfMapState_s
	#define EXT_FuIoDrvGetConfMapState_s
	#define GET_FuIoDrvGetConfMapState_s(fl)  CAL_CMGETAPI( "FuIoDrvGetConfMapState_s" ) 
	#define CAL_FuIoDrvGetConfMapState_s CIoDrvKbusS::IFuIoDrvGetConfMapState_s
	#define CHK_FuIoDrvGetConfMapState_s  TRUE
	#define EXP_FuIoDrvGetConfMapState_s  CAL_CMEXPAPI( "FuIoDrvGetConfMapState_s" ) 
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvGetConfMapState_s  PFFUIODRVGETCONFMAPSTATE_S pfFuIoDrvGetConfMapState_s;
	#define EXT_FuIoDrvGetConfMapState_s  extern PFFUIODRVGETCONFMAPSTATE_S pfFuIoDrvGetConfMapState_s;
	#define GET_FuIoDrvGetConfMapState_s(fl)  s_pfCMGetAPI2( "FuIoDrvGetConfMapState_s", (RTS_VOID_FCTPTR *)&pfFuIoDrvGetConfMapState_s, (fl), 0, 0)
	#define CAL_FuIoDrvGetConfMapState_s  pfFuIoDrvGetConfMapState_s
	#define CHK_FuIoDrvGetConfMapState_s  (pfFuIoDrvGetConfMapState_s != NULL)
	#define EXP_FuIoDrvGetConfMapState_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvGetConfMapState_s", (RTS_UINTPTR)FuIoDrvGetConfMapState_s, 0, 0) 
#endif




/**
 * <description>Function provides dynamic module configuration
 * <p></p>
 * <p>Function extends existing static module configuration.</p>
 * <p>Dynamic added configuration can be dynamic or static</p>
 * <p>removed. Function uses given connector list including</p>
 * <p>target module connector with parameter (4) slot number.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively connector list</param> 
 * <param name="pConnectorList" type="IN">pointer to list of connectors</param> 
 * <param name="nCount" type="IN">number of entries in the connector list</param> 
 * <param name="eCtrl" type="IN">control update configuration</param> 
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Dynamic configuration evaluated</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pConnectorList or nCount was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_TYPE_MISMATCH">At least one connector with unsupported type in list</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static configuration found</errorcode>
 */
RTS_IEC_RESULT CDECL FuIoDrvUpdateConfiguration_dynamic_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVUPDATECONFIGURATION_DYNAMIC_S) (RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
#if defined(IODRVKBUSS_NOTIMPLEMENTED) || defined(FUIODRVUPDATECONFIGURATION_DYNAMIC_S_NOTIMPLEMENTED)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_s
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_s
	#define GET_FuIoDrvUpdateConfiguration_dynamic_s(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_s(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_s  FALSE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_s  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_s
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_s
	#define GET_FuIoDrvUpdateConfiguration_dynamic_s(fl)  CAL_CMGETAPI( "FuIoDrvUpdateConfiguration_dynamic_s" ) 
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_s  FuIoDrvUpdateConfiguration_dynamic_s
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_s  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_s  CAL_CMEXPAPI( "FuIoDrvUpdateConfiguration_dynamic_s" ) 
#elif defined(MIXED_LINK) && !defined(IODRVKBUSS_EXTERNAL)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_s
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_s
	#define GET_FuIoDrvUpdateConfiguration_dynamic_s(fl)  CAL_CMGETAPI( "FuIoDrvUpdateConfiguration_dynamic_s" ) 
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_s  FuIoDrvUpdateConfiguration_dynamic_s
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_s  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvUpdateConfiguration_dynamic_s", (RTS_UINTPTR)FuIoDrvUpdateConfiguration_dynamic_s, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusSFuIoDrvUpdateConfiguration_dynamic_s
	#define EXT_IoDrvKbusSFuIoDrvUpdateConfiguration_dynamic_s
	#define GET_IoDrvKbusSFuIoDrvUpdateConfiguration_dynamic_s  ERR_OK
	#define CAL_IoDrvKbusSFuIoDrvUpdateConfiguration_dynamic_s CIoDrvKbusS::IFuIoDrvUpdateConfiguration_dynamic_s
	#define CHK_IoDrvKbusSFuIoDrvUpdateConfiguration_dynamic_s  TRUE
	#define EXP_IoDrvKbusSFuIoDrvUpdateConfiguration_dynamic_s  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_s
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_s
	#define GET_FuIoDrvUpdateConfiguration_dynamic_s(fl)  CAL_CMGETAPI( "FuIoDrvUpdateConfiguration_dynamic_s" ) 
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_s CIoDrvKbusS::IFuIoDrvUpdateConfiguration_dynamic_s
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_s  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_s  CAL_CMEXPAPI( "FuIoDrvUpdateConfiguration_dynamic_s" ) 
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvUpdateConfiguration_dynamic_s  PFFUIODRVUPDATECONFIGURATION_DYNAMIC_S pfFuIoDrvUpdateConfiguration_dynamic_s;
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_s  extern PFFUIODRVUPDATECONFIGURATION_DYNAMIC_S pfFuIoDrvUpdateConfiguration_dynamic_s;
	#define GET_FuIoDrvUpdateConfiguration_dynamic_s(fl)  s_pfCMGetAPI2( "FuIoDrvUpdateConfiguration_dynamic_s", (RTS_VOID_FCTPTR *)&pfFuIoDrvUpdateConfiguration_dynamic_s, (fl), 0, 0)
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_s  pfFuIoDrvUpdateConfiguration_dynamic_s
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_s  (pfFuIoDrvUpdateConfiguration_dynamic_s != NULL)
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvUpdateConfiguration_dynamic_s", (RTS_UINTPTR)FuIoDrvUpdateConfiguration_dynamic_s, 0, 0) 
#endif




/**
 * <description>Function provides dynamic module mapping
 * <p></p>
 * <p>Function updates unmapped modules. Function uses given</p>
 * <p>task map list including task map for target module.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively task map list</param> 
 * <param name="pTaskMapList" type="IN">pointer to list of task mappings</param>
 * <param name="nCount" type="IN">number of task mappings in list</param> 
 * <param name="eCtrl" type="IN">control update mapping</param> 
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Dynamic mapping evaluated</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pTaskMapList or nCount was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static mapping found</errorcode>
 */
RTS_IEC_RESULT CDECL FuIoDrvUpdateMapping_dynamic_s(RTS_IEC_HANDLE hIoDrv, IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVUPDATEMAPPING_DYNAMIC_S) (RTS_IEC_HANDLE hIoDrv, IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
#if defined(IODRVKBUSS_NOTIMPLEMENTED) || defined(FUIODRVUPDATEMAPPING_DYNAMIC_S_NOTIMPLEMENTED)
	#define USE_FuIoDrvUpdateMapping_dynamic_s
	#define EXT_FuIoDrvUpdateMapping_dynamic_s
	#define GET_FuIoDrvUpdateMapping_dynamic_s(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvUpdateMapping_dynamic_s(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvUpdateMapping_dynamic_s  FALSE
	#define EXP_FuIoDrvUpdateMapping_dynamic_s  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvUpdateMapping_dynamic_s
	#define EXT_FuIoDrvUpdateMapping_dynamic_s
	#define GET_FuIoDrvUpdateMapping_dynamic_s(fl)  CAL_CMGETAPI( "FuIoDrvUpdateMapping_dynamic_s" ) 
	#define CAL_FuIoDrvUpdateMapping_dynamic_s  FuIoDrvUpdateMapping_dynamic_s
	#define CHK_FuIoDrvUpdateMapping_dynamic_s  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_s  CAL_CMEXPAPI( "FuIoDrvUpdateMapping_dynamic_s" ) 
#elif defined(MIXED_LINK) && !defined(IODRVKBUSS_EXTERNAL)
	#define USE_FuIoDrvUpdateMapping_dynamic_s
	#define EXT_FuIoDrvUpdateMapping_dynamic_s
	#define GET_FuIoDrvUpdateMapping_dynamic_s(fl)  CAL_CMGETAPI( "FuIoDrvUpdateMapping_dynamic_s" ) 
	#define CAL_FuIoDrvUpdateMapping_dynamic_s  FuIoDrvUpdateMapping_dynamic_s
	#define CHK_FuIoDrvUpdateMapping_dynamic_s  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvUpdateMapping_dynamic_s", (RTS_UINTPTR)FuIoDrvUpdateMapping_dynamic_s, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusSFuIoDrvUpdateMapping_dynamic_s
	#define EXT_IoDrvKbusSFuIoDrvUpdateMapping_dynamic_s
	#define GET_IoDrvKbusSFuIoDrvUpdateMapping_dynamic_s  ERR_OK
	#define CAL_IoDrvKbusSFuIoDrvUpdateMapping_dynamic_s CIoDrvKbusS::IFuIoDrvUpdateMapping_dynamic_s
	#define CHK_IoDrvKbusSFuIoDrvUpdateMapping_dynamic_s  TRUE
	#define EXP_IoDrvKbusSFuIoDrvUpdateMapping_dynamic_s  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvUpdateMapping_dynamic_s
	#define EXT_FuIoDrvUpdateMapping_dynamic_s
	#define GET_FuIoDrvUpdateMapping_dynamic_s(fl)  CAL_CMGETAPI( "FuIoDrvUpdateMapping_dynamic_s" ) 
	#define CAL_FuIoDrvUpdateMapping_dynamic_s CIoDrvKbusS::IFuIoDrvUpdateMapping_dynamic_s
	#define CHK_FuIoDrvUpdateMapping_dynamic_s  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_s  CAL_CMEXPAPI( "FuIoDrvUpdateMapping_dynamic_s" ) 
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvUpdateMapping_dynamic_s  PFFUIODRVUPDATEMAPPING_DYNAMIC_S pfFuIoDrvUpdateMapping_dynamic_s;
	#define EXT_FuIoDrvUpdateMapping_dynamic_s  extern PFFUIODRVUPDATEMAPPING_DYNAMIC_S pfFuIoDrvUpdateMapping_dynamic_s;
	#define GET_FuIoDrvUpdateMapping_dynamic_s(fl)  s_pfCMGetAPI2( "FuIoDrvUpdateMapping_dynamic_s", (RTS_VOID_FCTPTR *)&pfFuIoDrvUpdateMapping_dynamic_s, (fl), 0, 0)
	#define CAL_FuIoDrvUpdateMapping_dynamic_s  pfFuIoDrvUpdateMapping_dynamic_s
	#define CHK_FuIoDrvUpdateMapping_dynamic_s  (pfFuIoDrvUpdateMapping_dynamic_s != NULL)
	#define EXP_FuIoDrvUpdateMapping_dynamic_s  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"FuIoDrvUpdateMapping_dynamic_s", (RTS_UINTPTR)FuIoDrvUpdateMapping_dynamic_s, 0, 0) 
#endif





#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFFUIODRVCALCULATESLOTNUMBER_S IFuIoDrvCalculateSlotNumber_s;
 	PFFUIODRVGETCONFMAPSTATE_S IFuIoDrvGetConfMapState_s;
 	PFFUIODRVUPDATECONFIGURATION_DYNAMIC_S IFuIoDrvUpdateConfiguration_dynamic_s;
 	PFFUIODRVUPDATEMAPPING_DYNAMIC_S IFuIoDrvUpdateMapping_dynamic_s;
 } IIoDrvKbusS_C;

#ifdef CPLUSPLUS
class IIoDrvKbusS : public IBase
{
	public:
		static RTS_IEC_RESULT CDECL IFuIoDrvCalculateSlotNumber_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
		static RTS_IEC_RESULT CDECL IFuIoDrvGetConfMapState_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
		static RTS_IEC_RESULT CDECL IFuIoDrvUpdateConfiguration_dynamic_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
		static RTS_IEC_RESULT CDECL IFuIoDrvUpdateMapping_dynamic_s(RTS_IEC_HANDLE hIoDrv, IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
};
	#ifndef ITF_IoDrvKbusS
		#define ITF_IoDrvKbusS static IIoDrvKbusS *pIIoDrvKbusS = NULL;
	#endif
	#define EXTITF_IoDrvKbusS
#else	/*CPLUSPLUS*/
	typedef IIoDrvKbusS_C		IIoDrvKbusS;
	#ifndef ITF_IoDrvKbusS
		#define ITF_IoDrvKbusS
	#endif
	#define EXTITF_IoDrvKbusS
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_IODRVKBUSSITF_H_*/
