/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component Dal</name>
 *  <description>
 *  An example on how to implement a component.
 *  This component does no usefull work and it exports no functions
 *  which are intended to be used for anything. Use at your own risk.
 *  </description>
 *  <copyright>
 *  (c) 2003-2004 3S-Smart Software Solutions
 *  </copyright>
 */
#ifndef _IODRVDALDEP_H_
#define _IODRVDALDEP_H_

#define COMPONENT_NAME "IoDrvDal" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_IoDrvDal)
#define COMPONENT_NAME_UNQUOTED IoDrvDal





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_CIoDrvDal   ADDVENDORID(CMP_VENDORID, IODRVDAL_CLASSID_C)
#define CMPID_IoDrvDal      IODRVDAL_CMPID

#define CMP_VERSION         UINT32_C(0x03050300)
#define CMP_VERSION_STRING "3.5.3.0"
#define CMP_VERSION_RC      3,5,3,0
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"


#include "SysMemItf.h"


#include "SysTaskItf.h"


#include "CmpSettingsItf.h"


#include "CMItf.h"


#include "CmpIoMgrItf.h"


#include "CmpEventMgrItf.h"


#include "CmpAppItf.h"


#include "CmpIecTaskItf.h"


/*Obsolete include: CMUtilsItf.m4*/


#include "CmpSupervisorItf.h"


#include "SysTimerItf.h"


#include "SysSemItf.h"


#include "TscExtTaskItf.h"


#include "SysInternalLibItf.h"








/**
 * \file CmpIoDrvItf.h
 */
#include "CmpIoDrvItf.h"

/**
 * \file CmpIoDrvParameterItf.h
 */
#include "CmpIoDrvParameterItf.h"

/**
 * \file CmpDalItf.h
 */
#include "CmpDalItf.h"

/**
 * \file IoDrvKbusSItf.h
 */
#include "IoDrvKbusSItf.h"

/**
 * \file IoDrvKbusCItf.h
 */
#include "IoDrvKbusCItf.h"















#ifdef CDS3_IODRVKBUS
#ifndef RTS_TASKNAME_KBUS_CYCLE_TASK
    #define RTS_TASKNAME_KBUS_CYCLE_TASK           "KBUS_CYCLE_TASK"
#endif
#ifndef RTS_TASKPRIO_KBUS_CYCLE_TASK
    #define RTS_TASKPRIO_KBUS_CYCLE_TASK           TASKPRIO_SYSTEM_BASE
#endif


#endif

        






























































     






























































     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pISysInternalLib == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysInternalLib, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysInternalLib = (ISysInternalLib *)pIBase->QueryInterface(pIBase, ITFID_ISysInternalLib, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pITscExtTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscExtTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscExtTask = (ITscExtTask *)pIBase->QueryInterface(pIBase, ITFID_ITscExtTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysSem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysSem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysSem = (ISysSem *)pIBase->QueryInterface(pIBase, ITFID_ISysSem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTimer == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTimer, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTimer = (ISysTimer *)pIBase->QueryInterface(pIBase, ITFID_ISysTimer, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpSupervisor == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSupervisor, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSupervisor = (ICmpSupervisor *)pIBase->QueryInterface(pIBase, ITFID_ICmpSupervisor, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		  if (pICmpIecTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpIecTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpIecTask = (ICmpIecTask *)pIBase->QueryInterface(pIBase, ITFID_ICmpIecTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpEventMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpEventMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpEventMgr = (ICmpEventMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpEventMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpIoMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpIoMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpIoMgr = (ICmpIoMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpIoMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpSettings == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSettings, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSettings = (ICmpSettings *)pIBase->QueryInterface(pIBase, ITFID_ICmpSettings, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysMem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysMem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysMem = (ISysMem *)pIBase->QueryInterface(pIBase, ITFID_ISysMem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pISysInternalLib = NULL; \
          pITscExtTask = NULL; \
          pISysSem = NULL; \
          pISysTimer = NULL; \
          pICmpSupervisor = NULL; \
          /*Obsolete include CMUtils*/ \
		  pICmpIecTask = NULL; \
          pICmpApp = NULL; \
          pICmpEventMgr = NULL; \
          pICmpIoMgr = NULL; \
          pICM = NULL; \
          pICmpSettings = NULL; \
          pISysTask = NULL; \
          pISysMem = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pISysInternalLib != NULL) \
        { \
            pIBase = (IBase *)pISysInternalLib->QueryInterface(pISysInternalLib, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysInternalLib = NULL; \
            } \
        } \
          if (pITscExtTask != NULL) \
        { \
            pIBase = (IBase *)pITscExtTask->QueryInterface(pITscExtTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscExtTask = NULL; \
            } \
        } \
          if (pISysSem != NULL) \
        { \
            pIBase = (IBase *)pISysSem->QueryInterface(pISysSem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysSem = NULL; \
            } \
        } \
          if (pISysTimer != NULL) \
        { \
            pIBase = (IBase *)pISysTimer->QueryInterface(pISysTimer, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTimer = NULL; \
            } \
        } \
          if (pICmpSupervisor != NULL) \
        { \
            pIBase = (IBase *)pICmpSupervisor->QueryInterface(pICmpSupervisor, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSupervisor = NULL; \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		  if (pICmpIecTask != NULL) \
        { \
            pIBase = (IBase *)pICmpIecTask->QueryInterface(pICmpIecTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpIecTask = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pICmpEventMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpEventMgr->QueryInterface(pICmpEventMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpEventMgr = NULL; \
            } \
        } \
          if (pICmpIoMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpIoMgr->QueryInterface(pICmpIoMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpIoMgr = NULL; \
            } \
        } \
          if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
          if (pICmpSettings != NULL) \
        { \
            pIBase = (IBase *)pICmpSettings->QueryInterface(pICmpSettings, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSettings = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
          if (pISysMem != NULL) \
        { \
            pIBase = (IBase *)pISysMem->QueryInterface(pISysMem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysMem = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_IecTaskGetCurrent(0);\
          if (ERR_OK == importResult ) importResult = GET_IecTaskRegisterSlotCallbacks(0);\
          if (ERR_OK == importResult ) importResult = GET_IecTaskRegisterSlotCallback(0);\
          if (ERR_OK == importResult ) importResult = GET_EventPost(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisteredCallbacks(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallback(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallback(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_EventDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_EventCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_IoDrvDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_IoDrvCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrCopyInputBE(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrCopyOutputBE(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrCopyInputLE(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrCopyOutputLE(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrStartBusCycle(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigResetDiagnosis(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigSetDiagnosis(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetParameterValuePointer(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetParameterValueDword(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetParameterValueWord(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetParameterValueByte(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetNextChild(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetFirstChild(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetNextConnector(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetFirstConnector(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetParameter(0);\
          if (ERR_OK == importResult ) importResult = GET_CMRegisterInstance(0);\
          if (ERR_OK == importResult ) importResult = GET_SupervisorOperationGetEntry(0);\
          if (ERR_OK == importResult ) importResult = GET_SupervisorOperationGetNext(0);\
          if (ERR_OK == importResult ) importResult = GET_SupervisorOperationGetFirst(0);\
          if (ERR_OK == importResult ) importResult = GET_SupervisorOperationGetState2(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetIntValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgSetIntValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgSetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemLeave(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemEnter(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTimeGetUs(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskWaitInterval(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskWaitSleep(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskExit(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnd(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskLeave(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnter(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskResume(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemFreeArea(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemAllocArea(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemFreeData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemAllocData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysGetTypeSize(0);\
          if (ERR_OK == importResult ) importResult = GET_TscExtTaskUnregisterExternalEvent(0);\
          if (ERR_OK == importResult ) importResult = GET_TscExtTaskRegisterExternalEvent(0);\
          if (ERR_OK == importResult ) importResult = GET_TscExtTaskPostExternalEvent(0);\
          /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef IODRVDAL_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
                                                        
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef IODRVDAL_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                                        
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(IODRVDAL_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                    { (RTS_VOID_FCTPTR)Dal_DiagnoseGetDeviceState, "Dal_DiagnoseGetDeviceState", 0, 0 },\
          { (RTS_VOID_FCTPTR)Dal_CallDeviceSpecificFunction, "Dal_CallDeviceSpecificFunction", 0, 0 },\
          { (RTS_VOID_FCTPTR)FuIoDrvUpdateMapping_dynamic_s, "FuIoDrvUpdateMapping_dynamic_s", 0, 0 },\
          { (RTS_VOID_FCTPTR)FuIoDrvUpdateConfiguration_dynamic_s, "FuIoDrvUpdateConfiguration_dynamic_s", 0, 0 },\
          { (RTS_VOID_FCTPTR)FuIoDrvGetConfMapState_s, "FuIoDrvGetConfMapState_s", 0, 0 },\
          { (RTS_VOID_FCTPTR)FuIoDrvCalculateSlotNumber_s, "FuIoDrvCalculateSlotNumber_s", 0, 0 },\
                  \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysMem     \
	ITF_SysTask     \
	ITF_CmpSettings     \
	ITF_CM     \
	ITF_CmpIoMgr     \
	ITF_CmpEventMgr     \
	ITF_CmpApp     \
	ITF_CmpIecTask     \
	/*obsolete entry ITF_CMUtils*/      \
	ITF_CmpSupervisor     \
	ITF_SysTimer     \
	ITF_SysSem     \
	ITF_TscExtTask     \
	ITF_SysInternalLib      \
    /*obsolete USE_LogAdd*/      \
    USE_TscExtTaskPostExternalEvent      \
    USE_TscExtTaskRegisterExternalEvent      \
    USE_TscExtTaskUnregisterExternalEvent      \
    USE_SysGetTypeSize      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_SysMemAllocArea      \
    USE_SysMemFreeArea      \
    USE_SysTaskCreate      \
    USE_SysTaskResume      \
    USE_SysTaskEnter      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskExit      \
    USE_SysTaskWaitSleep      \
    USE_SysTaskWaitInterval      \
    USE_SysTimeGetUs      \
    USE_SysSemCreate      \
    USE_SysSemDelete      \
    USE_SysSemEnter      \
    USE_SysSemLeave      \
    USE_SettgSetStringValue      \
    USE_SettgGetStringValue      \
    USE_SettgSetIntValue      \
    USE_SettgGetIntValue      \
    USE_SupervisorOperationGetState2      \
    USE_SupervisorOperationGetFirst      \
    USE_SupervisorOperationGetNext      \
    USE_SupervisorOperationGetEntry      \
    USE_CMRegisterInstance      \
    USE_IoMgrConfigGetParameter      \
    USE_IoMgrConfigGetFirstConnector      \
    USE_IoMgrConfigGetNextConnector      \
    USE_IoMgrConfigGetFirstChild      \
    USE_IoMgrConfigGetNextChild      \
    USE_IoMgrConfigGetParameterValueByte      \
    USE_IoMgrConfigGetParameterValueWord      \
    USE_IoMgrConfigGetParameterValueDword      \
    USE_IoMgrConfigGetParameterValuePointer      \
    USE_IoMgrConfigSetDiagnosis      \
    USE_IoMgrConfigResetDiagnosis      \
    USE_IoMgrStartBusCycle      \
    USE_IoMgrCopyOutputLE      \
    USE_IoMgrCopyInputLE      \
    USE_IoMgrCopyOutputBE      \
    USE_IoMgrCopyInputBE      \
    USE_IoDrvCreate      \
    USE_IoDrvDelete      \
    USE_EventCreate      \
    USE_EventDelete      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallback      \
    USE_EventUnregisterCallback      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventRegisteredCallbacks      \
    USE_EventPost      \
    USE_IecTaskRegisterSlotCallback      \
    USE_IecTaskRegisterSlotCallbacks      \
    USE_IecTaskGetCurrent      \
    USE_CMUtlSafeStrCpy     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysMem    \
	ITF_SysTask    \
	ITF_CmpSettings    \
	ITF_CM    \
	ITF_CmpIoMgr    \
	ITF_CmpEventMgr    \
	ITF_CmpApp    \
	ITF_CmpIecTask    \
	/*obsolete entry ITF_CMUtils*/     \
	ITF_CmpSupervisor    \
	ITF_SysTimer    \
	ITF_SysSem    \
	ITF_TscExtTask    \
	ITF_SysInternalLib     \
    /*obsolete USE_LogAdd*/      \
    USE_TscExtTaskPostExternalEvent      \
    USE_TscExtTaskRegisterExternalEvent      \
    USE_TscExtTaskUnregisterExternalEvent      \
    USE_SysGetTypeSize      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_SysMemAllocArea      \
    USE_SysMemFreeArea      \
    USE_SysTaskCreate      \
    USE_SysTaskResume      \
    USE_SysTaskEnter      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskExit      \
    USE_SysTaskWaitSleep      \
    USE_SysTaskWaitInterval      \
    USE_SysTimeGetUs      \
    USE_SysSemCreate      \
    USE_SysSemDelete      \
    USE_SysSemEnter      \
    USE_SysSemLeave      \
    USE_SettgSetStringValue      \
    USE_SettgGetStringValue      \
    USE_SettgSetIntValue      \
    USE_SettgGetIntValue      \
    USE_SupervisorOperationGetState2      \
    USE_SupervisorOperationGetFirst      \
    USE_SupervisorOperationGetNext      \
    USE_SupervisorOperationGetEntry      \
    USE_CMRegisterInstance      \
    USE_IoMgrConfigGetParameter      \
    USE_IoMgrConfigGetFirstConnector      \
    USE_IoMgrConfigGetNextConnector      \
    USE_IoMgrConfigGetFirstChild      \
    USE_IoMgrConfigGetNextChild      \
    USE_IoMgrConfigGetParameterValueByte      \
    USE_IoMgrConfigGetParameterValueWord      \
    USE_IoMgrConfigGetParameterValueDword      \
    USE_IoMgrConfigGetParameterValuePointer      \
    USE_IoMgrConfigSetDiagnosis      \
    USE_IoMgrConfigResetDiagnosis      \
    USE_IoMgrStartBusCycle      \
    USE_IoMgrCopyOutputLE      \
    USE_IoMgrCopyInputLE      \
    USE_IoMgrCopyOutputBE      \
    USE_IoMgrCopyInputBE      \
    USE_IoDrvCreate      \
    USE_IoDrvDelete      \
    USE_EventCreate      \
    USE_EventDelete      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallback      \
    USE_EventUnregisterCallback      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventRegisteredCallbacks      \
    USE_EventPost      \
    USE_IecTaskRegisterSlotCallback      \
    USE_IecTaskRegisterSlotCallbacks      \
    USE_IecTaskGetCurrent      \
    USE_CMUtlSafeStrCpy     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysMem    \
	EXTITF_SysTask    \
	EXTITF_CmpSettings    \
	EXTITF_CM    \
	EXTITF_CmpIoMgr    \
	EXTITF_CmpEventMgr    \
	EXTITF_CmpApp    \
	EXTITF_CmpIecTask    \
	/*obsolete entry EXTITF_CMUtils*/     \
	EXTITF_CmpSupervisor    \
	EXTITF_SysTimer    \
	EXTITF_SysSem    \
	EXTITF_TscExtTask    \
	EXTITF_SysInternalLib     \
    /*obsolete EXT_LogAdd*/  \
    EXT_TscExtTaskPostExternalEvent  \
    EXT_TscExtTaskRegisterExternalEvent  \
    EXT_TscExtTaskUnregisterExternalEvent  \
    EXT_SysGetTypeSize  \
    EXT_SysMemAllocData  \
    EXT_SysMemFreeData  \
    EXT_SysMemAllocArea  \
    EXT_SysMemFreeArea  \
    EXT_SysTaskCreate  \
    EXT_SysTaskResume  \
    EXT_SysTaskEnter  \
    EXT_SysTaskLeave  \
    EXT_SysTaskEnd  \
    EXT_SysTaskExit  \
    EXT_SysTaskWaitSleep  \
    EXT_SysTaskWaitInterval  \
    EXT_SysTimeGetUs  \
    EXT_SysSemCreate  \
    EXT_SysSemDelete  \
    EXT_SysSemEnter  \
    EXT_SysSemLeave  \
    EXT_SettgSetStringValue  \
    EXT_SettgGetStringValue  \
    EXT_SettgSetIntValue  \
    EXT_SettgGetIntValue  \
    EXT_SupervisorOperationGetState2  \
    EXT_SupervisorOperationGetFirst  \
    EXT_SupervisorOperationGetNext  \
    EXT_SupervisorOperationGetEntry  \
    EXT_CMRegisterInstance  \
    EXT_IoMgrConfigGetParameter  \
    EXT_IoMgrConfigGetFirstConnector  \
    EXT_IoMgrConfigGetNextConnector  \
    EXT_IoMgrConfigGetFirstChild  \
    EXT_IoMgrConfigGetNextChild  \
    EXT_IoMgrConfigGetParameterValueByte  \
    EXT_IoMgrConfigGetParameterValueWord  \
    EXT_IoMgrConfigGetParameterValueDword  \
    EXT_IoMgrConfigGetParameterValuePointer  \
    EXT_IoMgrConfigSetDiagnosis  \
    EXT_IoMgrConfigResetDiagnosis  \
    EXT_IoMgrStartBusCycle  \
    EXT_IoMgrCopyOutputLE  \
    EXT_IoMgrCopyInputLE  \
    EXT_IoMgrCopyOutputBE  \
    EXT_IoMgrCopyInputBE  \
    EXT_IoDrvCreate  \
    EXT_IoDrvDelete  \
    EXT_EventCreate  \
    EXT_EventDelete  \
    EXT_EventOpen  \
    EXT_EventClose  \
    EXT_EventRegisterCallback  \
    EXT_EventUnregisterCallback  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_EventRegisteredCallbacks  \
    EXT_EventPost  \
    EXT_IecTaskRegisterSlotCallback  \
    EXT_IecTaskRegisterSlotCallbacks  \
    EXT_IecTaskGetCurrent  \
    EXT_CMUtlSafeStrCpy 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry IoDrvDal__Entry
#endif


#ifdef CPLUSPLUS

class CIoDrvDal : public ICmpIoDrv , public ICmpIoDrvParameter , public ICmpDal , public IIoDrvKbusS , public IIoDrvKbusC 
{
    public:
        CIoDrvDal() : hIoDrvDal(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CIoDrvDal()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ICmpIoDrv *)this);            
            else if (iid == ITFID_ICmpIoDrv)
                pItf = dynamic_cast<ICmpIoDrv *>(this); 
            else if (iid == ITFID_ICmpIoDrvParameter)
                pItf = dynamic_cast<ICmpIoDrvParameter *>(this); 
            else if (iid == ITFID_ICmpDal)
                pItf = dynamic_cast<ICmpDal *>(this); 
            else if (iid == ITFID_IIoDrvKbusS)
                pItf = dynamic_cast<IIoDrvKbusS *>(this); 
            else if (iid == ITFID_IIoDrvKbusC)
                pItf = dynamic_cast<IIoDrvKbusC *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }
        virtual RTS_IEC_RESULT CDECL IFuIoDrvCalculateSlotNumber_c(IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
        virtual RTS_IEC_RESULT CDECL IFuIoDrvGetConfMapState_c(IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
        virtual RTS_IEC_RESULT CDECL IFuIoDrvUpdateConfiguration_dynamic_c(IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
        virtual RTS_IEC_RESULT CDECL IFuIoDrvUpdateMapping_dynamic_c(IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
        static RTS_IEC_RESULT CDECL IFuIoDrvCalculateSlotNumber_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
        static RTS_IEC_RESULT CDECL IFuIoDrvGetConfMapState_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
        static RTS_IEC_RESULT CDECL IFuIoDrvUpdateConfiguration_dynamic_s(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
        static RTS_IEC_RESULT CDECL IFuIoDrvUpdateMapping_dynamic_s(RTS_IEC_HANDLE hIoDrv, IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
        static RTS_I32 CDECL IDal_CallDeviceSpecificFunction(const char * fnName, void* retVal, ...);
        static RTS_I32 CDECL IDal_DiagnoseGetDeviceState(const char * deviceName, RTS_UI32 bufferSize, RTS_UI8 *diagnoseBuffer, tBusState *busState);
        virtual RTS_RESULT CDECL IIoDrvReadParameter(IoConfigConnector *pConnector, IoConfigParameter *pParameter, void *pData, RTS_SIZE ulBitSize, RTS_SIZE ulBitOffset);
        virtual RTS_RESULT CDECL IIoDrvWriteParameter(IoConfigConnector *pConnector, IoConfigParameter *pParameter, void *pData, RTS_SIZE ulBitSize, RTS_SIZE ulBitOffset);
        virtual RTS_HANDLE CDECL IIoDrvCreate(RTS_HANDLE hIIoDrv, CLASSID ClassId, int iId, RTS_RESULT *pResult);
        virtual RTS_RESULT CDECL IIoDrvDelete(RTS_HANDLE hIIoDrv);
        virtual RTS_RESULT CDECL IIoDrvGetInfo(IoDrvInfo **ppIoDrv);
        virtual RTS_RESULT CDECL IIoDrvGetModuleDiagnosis(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvIdentify(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvReadInputs(IoConfigConnectorMap *pConnectorMapList, int nCount);
        virtual RTS_RESULT CDECL IIoDrvScanModules(IoConfigConnector *pConnector, IoConfigConnector **ppConnectorList, int *pnCount);
        virtual RTS_RESULT CDECL IIoDrvStartBusCycle(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvUpdateConfiguration(IoConfigConnector *pConnectorList, int nCount);
        virtual RTS_RESULT CDECL IIoDrvUpdateMapping(IoConfigTaskMap *pTaskMapList, int nCount);
        virtual RTS_RESULT CDECL IIoDrvWatchdogTrigger(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvWriteOutputs(IoConfigConnectorMap *pConnectorMapList, int nCount);

    public:
        RTS_HANDLE hIoDrvDal;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
