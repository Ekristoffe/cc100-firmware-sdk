 /**
 * <interfacename>WagoSysCan_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSCAN_INTERNAL_PFCITF_H_
#define _WAGOSYSCAN_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 *
 *   Change state of CANopen device or master
 *   (valid only for own node in slave mode)
 *   Returns: 0 = OK  -1 = fail
 */
typedef struct tagfuchangestate_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	/* NodeId of device */
	RTS_IEC_DWORD eState;				/* VAR_INPUT, Enum: ECANOPENSTATE */
	RTS_IEC_DINT FuChangeState;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fuchangestate_struct;

void CDECL CDECL_EXT fuchangestate(fuchangestate_struct *p);
typedef void (CDECL CDECL_EXT* PFFUCHANGESTATE_IEC) (fuchangestate_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUCHANGESTATE_NOTIMPLEMENTED)
	#define USE_fuchangestate
	#define EXT_fuchangestate
	#define GET_fuchangestate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuchangestate(p0) 
	#define CHK_fuchangestate  FALSE
	#define EXP_fuchangestate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuchangestate
	#define EXT_fuchangestate
	#define GET_fuchangestate(fl)  CAL_CMGETAPI( "fuchangestate" ) 
	#define CAL_fuchangestate  fuchangestate
	#define CHK_fuchangestate  TRUE
	#define EXP_fuchangestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuchangestate", (RTS_UINTPTR)fuchangestate, 1, 0xE669D591, 0x01000100) 
	#define EXTREF_ITF_fuchangestate {(RTS_VOID_FCTPTR)fuchangestate, "fuchangestate", 0xE669D591, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fuchangestate
	#define EXT_fuchangestate
	#define GET_fuchangestate(fl)  CAL_CMGETAPI( "fuchangestate" ) 
	#define CAL_fuchangestate  fuchangestate
	#define CHK_fuchangestate  TRUE
	#define EXP_fuchangestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuchangestate", (RTS_UINTPTR)fuchangestate, 1, 0xE669D591, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuchangestate
	#define EXT_WagoSysCan_Internal_PFCfuchangestate
	#define GET_WagoSysCan_Internal_PFCfuchangestate  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuchangestate  fuchangestate
	#define CHK_WagoSysCan_Internal_PFCfuchangestate  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuchangestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuchangestate", (RTS_UINTPTR)fuchangestate, 1, 0xE669D591, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fuchangestate
	#define EXT_fuchangestate
	#define GET_fuchangestate(fl)  CAL_CMGETAPI( "fuchangestate" ) 
	#define CAL_fuchangestate  fuchangestate
	#define CHK_fuchangestate  TRUE
	#define EXP_fuchangestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuchangestate", (RTS_UINTPTR)fuchangestate, 1, 0xE669D591, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fuchangestate  PFFUCHANGESTATE_IEC pffuchangestate;
	#define EXT_fuchangestate  extern PFFUCHANGESTATE_IEC pffuchangestate;
	#define GET_fuchangestate(fl)  s_pfCMGetAPI2( "fuchangestate", (RTS_VOID_FCTPTR *)&pffuchangestate, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xE669D591, 0x01000100)
	#define CAL_fuchangestate  pffuchangestate
	#define CHK_fuchangestate  (pffuchangestate != NULL)
	#define EXP_fuchangestate   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuchangestate", (RTS_UINTPTR)fuchangestate, 1, 0xE669D591, 0x01000100) 
#endif


/**
 * 
 *   Close CAN Layer2 Device  
 *   Returns:  0 = OK  -1 = fail
 */
typedef struct tagfucloselayer2_struct
{
	RTS_IEC_DINT FuCloseLayer2;			/* VAR_OUTPUT, Enum: ECANDEVICEERROR */
} fucloselayer2_struct;

void CDECL CDECL_EXT fucloselayer2(fucloselayer2_struct *p);
typedef void (CDECL CDECL_EXT* PFFUCLOSELAYER2_IEC) (fucloselayer2_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUCLOSELAYER2_NOTIMPLEMENTED)
	#define USE_fucloselayer2
	#define EXT_fucloselayer2
	#define GET_fucloselayer2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fucloselayer2(p0) 
	#define CHK_fucloselayer2  FALSE
	#define EXP_fucloselayer2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fucloselayer2
	#define EXT_fucloselayer2
	#define GET_fucloselayer2(fl)  CAL_CMGETAPI( "fucloselayer2" ) 
	#define CAL_fucloselayer2  fucloselayer2
	#define CHK_fucloselayer2  TRUE
	#define EXP_fucloselayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucloselayer2", (RTS_UINTPTR)fucloselayer2, 1, 0x90BBADF9, 0x01000100) 
	#define EXTREF_ITF_fucloselayer2 {(RTS_VOID_FCTPTR)fucloselayer2, "fucloselayer2", 0x90BBADF9, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fucloselayer2
	#define EXT_fucloselayer2
	#define GET_fucloselayer2(fl)  CAL_CMGETAPI( "fucloselayer2" ) 
	#define CAL_fucloselayer2  fucloselayer2
	#define CHK_fucloselayer2  TRUE
	#define EXP_fucloselayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucloselayer2", (RTS_UINTPTR)fucloselayer2, 1, 0x90BBADF9, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfucloselayer2
	#define EXT_WagoSysCan_Internal_PFCfucloselayer2
	#define GET_WagoSysCan_Internal_PFCfucloselayer2  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfucloselayer2  fucloselayer2
	#define CHK_WagoSysCan_Internal_PFCfucloselayer2  TRUE
	#define EXP_WagoSysCan_Internal_PFCfucloselayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucloselayer2", (RTS_UINTPTR)fucloselayer2, 1, 0x90BBADF9, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fucloselayer2
	#define EXT_fucloselayer2
	#define GET_fucloselayer2(fl)  CAL_CMGETAPI( "fucloselayer2" ) 
	#define CAL_fucloselayer2  fucloselayer2
	#define CHK_fucloselayer2  TRUE
	#define EXP_fucloselayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucloselayer2", (RTS_UINTPTR)fucloselayer2, 1, 0x90BBADF9, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fucloselayer2  PFFUCLOSELAYER2_IEC pffucloselayer2;
	#define EXT_fucloselayer2  extern PFFUCLOSELAYER2_IEC pffucloselayer2;
	#define GET_fucloselayer2(fl)  s_pfCMGetAPI2( "fucloselayer2", (RTS_VOID_FCTPTR *)&pffucloselayer2, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x90BBADF9, 0x01000100)
	#define CAL_fucloselayer2  pffucloselayer2
	#define CHK_fucloselayer2  (pffucloselayer2 != NULL)
	#define EXP_fucloselayer2   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucloselayer2", (RTS_UINTPTR)fucloselayer2, 1, 0x90BBADF9, 0x01000100) 
#endif


/**
 *
 *    Fill CAN Bus info struct 
 *    Returns:    0: OK  -1: no active CAN device  
 */
typedef struct tagfugetbusinfo_struct
{
	RTS_IEC_UDINT eResetflags;			/* VAR_INPUT, Enum: ECANFLAGRESET */
	typCanBusInfo *typBusInfo;			/* VAR_IN_OUT */	
	RTS_IEC_DINT FuGetBusInfo;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fugetbusinfo_struct;

void CDECL CDECL_EXT fugetbusinfo(fugetbusinfo_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETBUSINFO_IEC) (fugetbusinfo_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETBUSINFO_NOTIMPLEMENTED)
	#define USE_fugetbusinfo
	#define EXT_fugetbusinfo
	#define GET_fugetbusinfo(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetbusinfo(p0) 
	#define CHK_fugetbusinfo  FALSE
	#define EXP_fugetbusinfo  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetbusinfo
	#define EXT_fugetbusinfo
	#define GET_fugetbusinfo(fl)  CAL_CMGETAPI( "fugetbusinfo" ) 
	#define CAL_fugetbusinfo  fugetbusinfo
	#define CHK_fugetbusinfo  TRUE
	#define EXP_fugetbusinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetbusinfo", (RTS_UINTPTR)fugetbusinfo, 1, 0xDA027792, 0x01000100) 
	#define EXTREF_ITF_fugetbusinfo {(RTS_VOID_FCTPTR)fugetbusinfo, "fugetbusinfo", 0xDA027792, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetbusinfo
	#define EXT_fugetbusinfo
	#define GET_fugetbusinfo(fl)  CAL_CMGETAPI( "fugetbusinfo" ) 
	#define CAL_fugetbusinfo  fugetbusinfo
	#define CHK_fugetbusinfo  TRUE
	#define EXP_fugetbusinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetbusinfo", (RTS_UINTPTR)fugetbusinfo, 1, 0xDA027792, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetbusinfo
	#define EXT_WagoSysCan_Internal_PFCfugetbusinfo
	#define GET_WagoSysCan_Internal_PFCfugetbusinfo  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetbusinfo  fugetbusinfo
	#define CHK_WagoSysCan_Internal_PFCfugetbusinfo  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetbusinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetbusinfo", (RTS_UINTPTR)fugetbusinfo, 1, 0xDA027792, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetbusinfo
	#define EXT_fugetbusinfo
	#define GET_fugetbusinfo(fl)  CAL_CMGETAPI( "fugetbusinfo" ) 
	#define CAL_fugetbusinfo  fugetbusinfo
	#define CHK_fugetbusinfo  TRUE
	#define EXP_fugetbusinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetbusinfo", (RTS_UINTPTR)fugetbusinfo, 1, 0xDA027792, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetbusinfo  PFFUGETBUSINFO_IEC pffugetbusinfo;
	#define EXT_fugetbusinfo  extern PFFUGETBUSINFO_IEC pffugetbusinfo;
	#define GET_fugetbusinfo(fl)  s_pfCMGetAPI2( "fugetbusinfo", (RTS_VOID_FCTPTR *)&pffugetbusinfo, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDA027792, 0x01000100)
	#define CAL_fugetbusinfo  pffugetbusinfo
	#define CHK_fugetbusinfo  (pffugetbusinfo != NULL)
	#define EXP_fugetbusinfo   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetbusinfo", (RTS_UINTPTR)fugetbusinfo, 1, 0xDA027792, 0x01000100) 
#endif


/**
 *
 *   Get CAN device operational mode
 *   Returns:  0: not used 1:CANopen Master 2:CANopen Local Device 3:CAN Layer2 Device 
 */
typedef struct tagfugetcanmode_struct
{
	RTS_IEC_UDINT FuGetCanMode;			/* VAR_OUTPUT, Enum: ECANMODE */
} fugetcanmode_struct;

void CDECL CDECL_EXT fugetcanmode(fugetcanmode_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETCANMODE_IEC) (fugetcanmode_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETCANMODE_NOTIMPLEMENTED)
	#define USE_fugetcanmode
	#define EXT_fugetcanmode
	#define GET_fugetcanmode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetcanmode(p0) 
	#define CHK_fugetcanmode  FALSE
	#define EXP_fugetcanmode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetcanmode
	#define EXT_fugetcanmode
	#define GET_fugetcanmode(fl)  CAL_CMGETAPI( "fugetcanmode" ) 
	#define CAL_fugetcanmode  fugetcanmode
	#define CHK_fugetcanmode  TRUE
	#define EXP_fugetcanmode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetcanmode", (RTS_UINTPTR)fugetcanmode, 1, 0x80B510EF, 0x01000100) 
	#define EXTREF_ITF_fugetcanmode {(RTS_VOID_FCTPTR)fugetcanmode, "fugetcanmode", 0x80B510EF, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetcanmode
	#define EXT_fugetcanmode
	#define GET_fugetcanmode(fl)  CAL_CMGETAPI( "fugetcanmode" ) 
	#define CAL_fugetcanmode  fugetcanmode
	#define CHK_fugetcanmode  TRUE
	#define EXP_fugetcanmode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetcanmode", (RTS_UINTPTR)fugetcanmode, 1, 0x80B510EF, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetcanmode
	#define EXT_WagoSysCan_Internal_PFCfugetcanmode
	#define GET_WagoSysCan_Internal_PFCfugetcanmode  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetcanmode  fugetcanmode
	#define CHK_WagoSysCan_Internal_PFCfugetcanmode  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetcanmode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetcanmode", (RTS_UINTPTR)fugetcanmode, 1, 0x80B510EF, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetcanmode
	#define EXT_fugetcanmode
	#define GET_fugetcanmode(fl)  CAL_CMGETAPI( "fugetcanmode" ) 
	#define CAL_fugetcanmode  fugetcanmode
	#define CHK_fugetcanmode  TRUE
	#define EXP_fugetcanmode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetcanmode", (RTS_UINTPTR)fugetcanmode, 1, 0x80B510EF, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetcanmode  PFFUGETCANMODE_IEC pffugetcanmode;
	#define EXT_fugetcanmode  extern PFFUGETCANMODE_IEC pffugetcanmode;
	#define GET_fugetcanmode(fl)  s_pfCMGetAPI2( "fugetcanmode", (RTS_VOID_FCTPTR *)&pffugetcanmode, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x80B510EF, 0x01000100)
	#define CAL_fugetcanmode  pffugetcanmode
	#define CHK_fugetcanmode  (pffugetcanmode != NULL)
	#define EXP_fugetcanmode   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetcanmode", (RTS_UINTPTR)fugetcanmode, 1, 0x80B510EF, 0x01000100) 
#endif


/**
 *
 *    Fill CAN device info struct 
 *    Returns:  0 = OK  
 */
typedef struct tagfugetdeviceinfo_struct
{
	typCanDeviceInfo *typCanInfo;		/* VAR_IN_OUT */	/* device info struct */
	RTS_IEC_DINT FuGetDeviceInfo;		/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fugetdeviceinfo_struct;

void CDECL CDECL_EXT fugetdeviceinfo(fugetdeviceinfo_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETDEVICEINFO_IEC) (fugetdeviceinfo_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETDEVICEINFO_NOTIMPLEMENTED)
	#define USE_fugetdeviceinfo
	#define EXT_fugetdeviceinfo
	#define GET_fugetdeviceinfo(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetdeviceinfo(p0) 
	#define CHK_fugetdeviceinfo  FALSE
	#define EXP_fugetdeviceinfo  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetdeviceinfo
	#define EXT_fugetdeviceinfo
	#define GET_fugetdeviceinfo(fl)  CAL_CMGETAPI( "fugetdeviceinfo" ) 
	#define CAL_fugetdeviceinfo  fugetdeviceinfo
	#define CHK_fugetdeviceinfo  TRUE
	#define EXP_fugetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetdeviceinfo", (RTS_UINTPTR)fugetdeviceinfo, 1, 0x78E8C4E4, 0x01000100) 
	#define EXTREF_ITF_fugetdeviceinfo {(RTS_VOID_FCTPTR)fugetdeviceinfo, "fugetdeviceinfo", 0x78E8C4E4, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetdeviceinfo
	#define EXT_fugetdeviceinfo
	#define GET_fugetdeviceinfo(fl)  CAL_CMGETAPI( "fugetdeviceinfo" ) 
	#define CAL_fugetdeviceinfo  fugetdeviceinfo
	#define CHK_fugetdeviceinfo  TRUE
	#define EXP_fugetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetdeviceinfo", (RTS_UINTPTR)fugetdeviceinfo, 1, 0x78E8C4E4, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetdeviceinfo
	#define EXT_WagoSysCan_Internal_PFCfugetdeviceinfo
	#define GET_WagoSysCan_Internal_PFCfugetdeviceinfo  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetdeviceinfo  fugetdeviceinfo
	#define CHK_WagoSysCan_Internal_PFCfugetdeviceinfo  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetdeviceinfo", (RTS_UINTPTR)fugetdeviceinfo, 1, 0x78E8C4E4, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetdeviceinfo
	#define EXT_fugetdeviceinfo
	#define GET_fugetdeviceinfo(fl)  CAL_CMGETAPI( "fugetdeviceinfo" ) 
	#define CAL_fugetdeviceinfo  fugetdeviceinfo
	#define CHK_fugetdeviceinfo  TRUE
	#define EXP_fugetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetdeviceinfo", (RTS_UINTPTR)fugetdeviceinfo, 1, 0x78E8C4E4, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetdeviceinfo  PFFUGETDEVICEINFO_IEC pffugetdeviceinfo;
	#define EXT_fugetdeviceinfo  extern PFFUGETDEVICEINFO_IEC pffugetdeviceinfo;
	#define GET_fugetdeviceinfo(fl)  s_pfCMGetAPI2( "fugetdeviceinfo", (RTS_VOID_FCTPTR *)&pffugetdeviceinfo, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x78E8C4E4, 0x01000100)
	#define CAL_fugetdeviceinfo  pffugetdeviceinfo
	#define CHK_fugetdeviceinfo  (pffugetdeviceinfo != NULL)
	#define EXP_fugetdeviceinfo   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetdeviceinfo", (RTS_UINTPTR)fugetdeviceinfo, 1, 0x78E8C4E4, 0x01000100) 
#endif


/**
 *
 *   Test for new emergency error on any slave in CANopen Manager Mode
 *   Returns: 0 = no emcy message > 0 node id  -1 failure
 */
typedef struct tagfugetemcy_struct
{
	RTS_IEC_UDINT eRemove;				/* VAR_INPUT, Enum: ECANFLAGRESET */
	RTS_IEC_BYTE **aMsg;				/* VAR_IN_OUT */	/* info of message */
	RTS_IEC_DINT FuGetEmcy;				/* VAR_OUTPUT */	
} fugetemcy_struct;

void CDECL CDECL_EXT fugetemcy(fugetemcy_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETEMCY_IEC) (fugetemcy_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETEMCY_NOTIMPLEMENTED)
	#define USE_fugetemcy
	#define EXT_fugetemcy
	#define GET_fugetemcy(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetemcy(p0) 
	#define CHK_fugetemcy  FALSE
	#define EXP_fugetemcy  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetemcy
	#define EXT_fugetemcy
	#define GET_fugetemcy(fl)  CAL_CMGETAPI( "fugetemcy" ) 
	#define CAL_fugetemcy  fugetemcy
	#define CHK_fugetemcy  TRUE
	#define EXP_fugetemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetemcy", (RTS_UINTPTR)fugetemcy, 1, 0x7A6C44BC, 0x01000100) 
	#define EXTREF_ITF_fugetemcy {(RTS_VOID_FCTPTR)fugetemcy, "fugetemcy", 0x7A6C44BC, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetemcy
	#define EXT_fugetemcy
	#define GET_fugetemcy(fl)  CAL_CMGETAPI( "fugetemcy" ) 
	#define CAL_fugetemcy  fugetemcy
	#define CHK_fugetemcy  TRUE
	#define EXP_fugetemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetemcy", (RTS_UINTPTR)fugetemcy, 1, 0x7A6C44BC, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetemcy
	#define EXT_WagoSysCan_Internal_PFCfugetemcy
	#define GET_WagoSysCan_Internal_PFCfugetemcy  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetemcy  fugetemcy
	#define CHK_WagoSysCan_Internal_PFCfugetemcy  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetemcy", (RTS_UINTPTR)fugetemcy, 1, 0x7A6C44BC, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetemcy
	#define EXT_fugetemcy
	#define GET_fugetemcy(fl)  CAL_CMGETAPI( "fugetemcy" ) 
	#define CAL_fugetemcy  fugetemcy
	#define CHK_fugetemcy  TRUE
	#define EXP_fugetemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetemcy", (RTS_UINTPTR)fugetemcy, 1, 0x7A6C44BC, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetemcy  PFFUGETEMCY_IEC pffugetemcy;
	#define EXT_fugetemcy  extern PFFUGETEMCY_IEC pffugetemcy;
	#define GET_fugetemcy(fl)  s_pfCMGetAPI2( "fugetemcy", (RTS_VOID_FCTPTR *)&pffugetemcy, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7A6C44BC, 0x01000100)
	#define CAL_fugetemcy  pffugetemcy
	#define CHK_fugetemcy  (pffugetemcy != NULL)
	#define EXP_fugetemcy   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetemcy", (RTS_UINTPTR)fugetemcy, 1, 0x7A6C44BC, 0x01000100) 
#endif


/**
 * 
 *  Get layer2 frame from registered Id
 *  Returns:  Dlc of message, 16#10 for RTR call or eCanL2ErrorCode
 */
typedef struct tagfugetframe_struct
{
	RTS_IEC_UDINT udiTimeout;			/* VAR_INPUT */	/* Timeout in ms */
	RTS_IEC_DWORD *dwId;				/* VAR_IN_OUT */	/* CAN Id (updated id RegisterAll(1) was set) */
	RTS_IEC_BYTE **aMsg;				/* VAR_IN_OUT */	/* message buffer */
	RTS_IEC_DINT FuGetFrame;			/* VAR_OUTPUT */	
} fugetframe_struct;

void CDECL CDECL_EXT fugetframe(fugetframe_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETFRAME_IEC) (fugetframe_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETFRAME_NOTIMPLEMENTED)
	#define USE_fugetframe
	#define EXT_fugetframe
	#define GET_fugetframe(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetframe(p0) 
	#define CHK_fugetframe  FALSE
	#define EXP_fugetframe  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetframe
	#define EXT_fugetframe
	#define GET_fugetframe(fl)  CAL_CMGETAPI( "fugetframe" ) 
	#define CAL_fugetframe  fugetframe
	#define CHK_fugetframe  TRUE
	#define EXP_fugetframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframe", (RTS_UINTPTR)fugetframe, 1, 0xC6A41AA7, 0x01000100) 
	#define EXTREF_ITF_fugetframe {(RTS_VOID_FCTPTR)fugetframe, "fugetframe", 0xC6A41AA7, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetframe
	#define EXT_fugetframe
	#define GET_fugetframe(fl)  CAL_CMGETAPI( "fugetframe" ) 
	#define CAL_fugetframe  fugetframe
	#define CHK_fugetframe  TRUE
	#define EXP_fugetframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframe", (RTS_UINTPTR)fugetframe, 1, 0xC6A41AA7, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetframe
	#define EXT_WagoSysCan_Internal_PFCfugetframe
	#define GET_WagoSysCan_Internal_PFCfugetframe  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetframe  fugetframe
	#define CHK_WagoSysCan_Internal_PFCfugetframe  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframe", (RTS_UINTPTR)fugetframe, 1, 0xC6A41AA7, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetframe
	#define EXT_fugetframe
	#define GET_fugetframe(fl)  CAL_CMGETAPI( "fugetframe" ) 
	#define CAL_fugetframe  fugetframe
	#define CHK_fugetframe  TRUE
	#define EXP_fugetframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframe", (RTS_UINTPTR)fugetframe, 1, 0xC6A41AA7, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetframe  PFFUGETFRAME_IEC pffugetframe;
	#define EXT_fugetframe  extern PFFUGETFRAME_IEC pffugetframe;
	#define GET_fugetframe(fl)  s_pfCMGetAPI2( "fugetframe", (RTS_VOID_FCTPTR *)&pffugetframe, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC6A41AA7, 0x01000100)
	#define CAL_fugetframe  pffugetframe
	#define CHK_fugetframe  (pffugetframe != NULL)
	#define EXP_fugetframe   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframe", (RTS_UINTPTR)fugetframe, 1, 0xC6A41AA7, 0x01000100) 
#endif


/**
 *
 *    Get number of frames in buffer from registered Id
 *    Returns: number of frames in buffer (maximum 8) + 0x1000 if buffer overflow 
 *	-1 for error -2 id no index entry
 */
typedef struct tagfugetframebuffer_struct
{
	RTS_IEC_DWORD dwID;					/* VAR_INPUT */	/* CAN Id */
	RTS_IEC_DINT FuGetFrameBuffer;		/* VAR_OUTPUT */	
} fugetframebuffer_struct;

void CDECL CDECL_EXT fugetframebuffer(fugetframebuffer_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETFRAMEBUFFER_IEC) (fugetframebuffer_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETFRAMEBUFFER_NOTIMPLEMENTED)
	#define USE_fugetframebuffer
	#define EXT_fugetframebuffer
	#define GET_fugetframebuffer(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetframebuffer(p0) 
	#define CHK_fugetframebuffer  FALSE
	#define EXP_fugetframebuffer  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetframebuffer
	#define EXT_fugetframebuffer
	#define GET_fugetframebuffer(fl)  CAL_CMGETAPI( "fugetframebuffer" ) 
	#define CAL_fugetframebuffer  fugetframebuffer
	#define CHK_fugetframebuffer  TRUE
	#define EXP_fugetframebuffer  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframebuffer", (RTS_UINTPTR)fugetframebuffer, 1, 0x4E31EF22, 0x01000100) 
	#define EXTREF_ITF_fugetframebuffer {(RTS_VOID_FCTPTR)fugetframebuffer, "fugetframebuffer", 0x4E31EF22, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetframebuffer
	#define EXT_fugetframebuffer
	#define GET_fugetframebuffer(fl)  CAL_CMGETAPI( "fugetframebuffer" ) 
	#define CAL_fugetframebuffer  fugetframebuffer
	#define CHK_fugetframebuffer  TRUE
	#define EXP_fugetframebuffer  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframebuffer", (RTS_UINTPTR)fugetframebuffer, 1, 0x4E31EF22, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetframebuffer
	#define EXT_WagoSysCan_Internal_PFCfugetframebuffer
	#define GET_WagoSysCan_Internal_PFCfugetframebuffer  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetframebuffer  fugetframebuffer
	#define CHK_WagoSysCan_Internal_PFCfugetframebuffer  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetframebuffer  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframebuffer", (RTS_UINTPTR)fugetframebuffer, 1, 0x4E31EF22, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetframebuffer
	#define EXT_fugetframebuffer
	#define GET_fugetframebuffer(fl)  CAL_CMGETAPI( "fugetframebuffer" ) 
	#define CAL_fugetframebuffer  fugetframebuffer
	#define CHK_fugetframebuffer  TRUE
	#define EXP_fugetframebuffer  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframebuffer", (RTS_UINTPTR)fugetframebuffer, 1, 0x4E31EF22, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetframebuffer  PFFUGETFRAMEBUFFER_IEC pffugetframebuffer;
	#define EXT_fugetframebuffer  extern PFFUGETFRAMEBUFFER_IEC pffugetframebuffer;
	#define GET_fugetframebuffer(fl)  s_pfCMGetAPI2( "fugetframebuffer", (RTS_VOID_FCTPTR *)&pffugetframebuffer, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x4E31EF22, 0x01000100)
	#define CAL_fugetframebuffer  pffugetframebuffer
	#define CHK_fugetframebuffer  (pffugetframebuffer != NULL)
	#define EXP_fugetframebuffer   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframebuffer", (RTS_UINTPTR)fugetframebuffer, 1, 0x4E31EF22, 0x01000100) 
#endif


/**
 *
 *    Get layer2 frame counter for registered Id
 *    Returns: 
 *	16 Bit frame counter  -1 for error -2 id no index entry
 */
typedef struct tagfugetframecounter_struct
{
	RTS_IEC_DWORD dwId;					/* VAR_INPUT */	/* CAN Id */
	RTS_IEC_DINT FuGetFrameCounter;		/* VAR_OUTPUT */	
} fugetframecounter_struct;

void CDECL CDECL_EXT fugetframecounter(fugetframecounter_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETFRAMECOUNTER_IEC) (fugetframecounter_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETFRAMECOUNTER_NOTIMPLEMENTED)
	#define USE_fugetframecounter
	#define EXT_fugetframecounter
	#define GET_fugetframecounter(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetframecounter(p0) 
	#define CHK_fugetframecounter  FALSE
	#define EXP_fugetframecounter  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetframecounter
	#define EXT_fugetframecounter
	#define GET_fugetframecounter(fl)  CAL_CMGETAPI( "fugetframecounter" ) 
	#define CAL_fugetframecounter  fugetframecounter
	#define CHK_fugetframecounter  TRUE
	#define EXP_fugetframecounter  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframecounter", (RTS_UINTPTR)fugetframecounter, 1, 0xB942F3CF, 0x01000100) 
	#define EXTREF_ITF_fugetframecounter {(RTS_VOID_FCTPTR)fugetframecounter, "fugetframecounter", 0xB942F3CF, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetframecounter
	#define EXT_fugetframecounter
	#define GET_fugetframecounter(fl)  CAL_CMGETAPI( "fugetframecounter" ) 
	#define CAL_fugetframecounter  fugetframecounter
	#define CHK_fugetframecounter  TRUE
	#define EXP_fugetframecounter  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframecounter", (RTS_UINTPTR)fugetframecounter, 1, 0xB942F3CF, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetframecounter
	#define EXT_WagoSysCan_Internal_PFCfugetframecounter
	#define GET_WagoSysCan_Internal_PFCfugetframecounter  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetframecounter  fugetframecounter
	#define CHK_WagoSysCan_Internal_PFCfugetframecounter  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetframecounter  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframecounter", (RTS_UINTPTR)fugetframecounter, 1, 0xB942F3CF, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetframecounter
	#define EXT_fugetframecounter
	#define GET_fugetframecounter(fl)  CAL_CMGETAPI( "fugetframecounter" ) 
	#define CAL_fugetframecounter  fugetframecounter
	#define CHK_fugetframecounter  TRUE
	#define EXP_fugetframecounter  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframecounter", (RTS_UINTPTR)fugetframecounter, 1, 0xB942F3CF, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetframecounter  PFFUGETFRAMECOUNTER_IEC pffugetframecounter;
	#define EXT_fugetframecounter  extern PFFUGETFRAMECOUNTER_IEC pffugetframecounter;
	#define GET_fugetframecounter(fl)  s_pfCMGetAPI2( "fugetframecounter", (RTS_VOID_FCTPTR *)&pffugetframecounter, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB942F3CF, 0x01000100)
	#define CAL_fugetframecounter  pffugetframecounter
	#define CHK_fugetframecounter  (pffugetframecounter != NULL)
	#define EXP_fugetframecounter   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetframecounter", (RTS_UINTPTR)fugetframecounter, 1, 0xB942F3CF, 0x01000100) 
#endif


/**
 * 
 *   return number of configured node Ids on bus in CANopen Manager Mode or -1 if error
 */
typedef struct tagfugetlastnode_struct
{
	RTS_IEC_DINT FuGetLastNode;			/* VAR_OUTPUT */	
} fugetlastnode_struct;

void CDECL CDECL_EXT fugetlastnode(fugetlastnode_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETLASTNODE_IEC) (fugetlastnode_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETLASTNODE_NOTIMPLEMENTED)
	#define USE_fugetlastnode
	#define EXT_fugetlastnode
	#define GET_fugetlastnode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetlastnode(p0) 
	#define CHK_fugetlastnode  FALSE
	#define EXP_fugetlastnode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetlastnode
	#define EXT_fugetlastnode
	#define GET_fugetlastnode(fl)  CAL_CMGETAPI( "fugetlastnode" ) 
	#define CAL_fugetlastnode  fugetlastnode
	#define CHK_fugetlastnode  TRUE
	#define EXP_fugetlastnode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlastnode", (RTS_UINTPTR)fugetlastnode, 1, 0x88CEB240, 0x01000100) 
	#define EXTREF_ITF_fugetlastnode {(RTS_VOID_FCTPTR)fugetlastnode, "fugetlastnode", 0x88CEB240, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetlastnode
	#define EXT_fugetlastnode
	#define GET_fugetlastnode(fl)  CAL_CMGETAPI( "fugetlastnode" ) 
	#define CAL_fugetlastnode  fugetlastnode
	#define CHK_fugetlastnode  TRUE
	#define EXP_fugetlastnode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlastnode", (RTS_UINTPTR)fugetlastnode, 1, 0x88CEB240, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetlastnode
	#define EXT_WagoSysCan_Internal_PFCfugetlastnode
	#define GET_WagoSysCan_Internal_PFCfugetlastnode  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetlastnode  fugetlastnode
	#define CHK_WagoSysCan_Internal_PFCfugetlastnode  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetlastnode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlastnode", (RTS_UINTPTR)fugetlastnode, 1, 0x88CEB240, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetlastnode
	#define EXT_fugetlastnode
	#define GET_fugetlastnode(fl)  CAL_CMGETAPI( "fugetlastnode" ) 
	#define CAL_fugetlastnode  fugetlastnode
	#define CHK_fugetlastnode  TRUE
	#define EXP_fugetlastnode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlastnode", (RTS_UINTPTR)fugetlastnode, 1, 0x88CEB240, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetlastnode  PFFUGETLASTNODE_IEC pffugetlastnode;
	#define EXT_fugetlastnode  extern PFFUGETLASTNODE_IEC pffugetlastnode;
	#define GET_fugetlastnode(fl)  s_pfCMGetAPI2( "fugetlastnode", (RTS_VOID_FCTPTR *)&pffugetlastnode, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x88CEB240, 0x01000100)
	#define CAL_fugetlastnode  pffugetlastnode
	#define CHK_fugetlastnode  (pffugetlastnode != NULL)
	#define EXP_fugetlastnode   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlastnode", (RTS_UINTPTR)fugetlastnode, 1, 0x88CEB240, 0x01000100) 
#endif


/**
 *
 *   get node diagnostic bits in CANopen Manager Mode
 */
typedef struct tagfugetnodediag_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	
	RTS_IEC_DWORD FuGetNodeDiag;		/* VAR_OUTPUT */	
} fugetnodediag_struct;

void CDECL CDECL_EXT fugetnodediag(fugetnodediag_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETNODEDIAG_IEC) (fugetnodediag_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETNODEDIAG_NOTIMPLEMENTED)
	#define USE_fugetnodediag
	#define EXT_fugetnodediag
	#define GET_fugetnodediag(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetnodediag(p0) 
	#define CHK_fugetnodediag  FALSE
	#define EXP_fugetnodediag  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetnodediag
	#define EXT_fugetnodediag
	#define GET_fugetnodediag(fl)  CAL_CMGETAPI( "fugetnodediag" ) 
	#define CAL_fugetnodediag  fugetnodediag
	#define CHK_fugetnodediag  TRUE
	#define EXP_fugetnodediag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodediag", (RTS_UINTPTR)fugetnodediag, 1, 0xBCBBFB0A, 0x01000100) 
	#define EXTREF_ITF_fugetnodediag {(RTS_VOID_FCTPTR)fugetnodediag, "fugetnodediag", 0xBCBBFB0A, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetnodediag
	#define EXT_fugetnodediag
	#define GET_fugetnodediag(fl)  CAL_CMGETAPI( "fugetnodediag" ) 
	#define CAL_fugetnodediag  fugetnodediag
	#define CHK_fugetnodediag  TRUE
	#define EXP_fugetnodediag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodediag", (RTS_UINTPTR)fugetnodediag, 1, 0xBCBBFB0A, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetnodediag
	#define EXT_WagoSysCan_Internal_PFCfugetnodediag
	#define GET_WagoSysCan_Internal_PFCfugetnodediag  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetnodediag  fugetnodediag
	#define CHK_WagoSysCan_Internal_PFCfugetnodediag  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetnodediag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodediag", (RTS_UINTPTR)fugetnodediag, 1, 0xBCBBFB0A, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetnodediag
	#define EXT_fugetnodediag
	#define GET_fugetnodediag(fl)  CAL_CMGETAPI( "fugetnodediag" ) 
	#define CAL_fugetnodediag  fugetnodediag
	#define CHK_fugetnodediag  TRUE
	#define EXP_fugetnodediag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodediag", (RTS_UINTPTR)fugetnodediag, 1, 0xBCBBFB0A, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetnodediag  PFFUGETNODEDIAG_IEC pffugetnodediag;
	#define EXT_fugetnodediag  extern PFFUGETNODEDIAG_IEC pffugetnodediag;
	#define GET_fugetnodediag(fl)  s_pfCMGetAPI2( "fugetnodediag", (RTS_VOID_FCTPTR *)&pffugetnodediag, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xBCBBFB0A, 0x01000100)
	#define CAL_fugetnodediag  pffugetnodediag
	#define CHK_fugetnodediag  (pffugetnodediag != NULL)
	#define EXP_fugetnodediag   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodediag", (RTS_UINTPTR)fugetnodediag, 1, 0xBCBBFB0A, 0x01000100) 
#endif


/**
 *
 *   Test for Emcy message from node in CANopen Manager Mode
 *   Returns: 0 = no emcy message 1 = message present -1 failure
 */
typedef struct tagfugetnodeemcy_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	/* node Id */
	RTS_IEC_UDINT eRemove;				/* VAR_INPUT, Enum: ECANFLAGRESET */
	RTS_IEC_BYTE **aMsg;				/* VAR_IN_OUT */	
	RTS_IEC_DINT FuGetNodeEmcy;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fugetnodeemcy_struct;

void CDECL CDECL_EXT fugetnodeemcy(fugetnodeemcy_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETNODEEMCY_IEC) (fugetnodeemcy_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETNODEEMCY_NOTIMPLEMENTED)
	#define USE_fugetnodeemcy
	#define EXT_fugetnodeemcy
	#define GET_fugetnodeemcy(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetnodeemcy(p0) 
	#define CHK_fugetnodeemcy  FALSE
	#define EXP_fugetnodeemcy  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetnodeemcy
	#define EXT_fugetnodeemcy
	#define GET_fugetnodeemcy(fl)  CAL_CMGETAPI( "fugetnodeemcy" ) 
	#define CAL_fugetnodeemcy  fugetnodeemcy
	#define CHK_fugetnodeemcy  TRUE
	#define EXP_fugetnodeemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeemcy", (RTS_UINTPTR)fugetnodeemcy, 1, 0xD2CBB8BB, 0x01000100) 
	#define EXTREF_ITF_fugetnodeemcy {(RTS_VOID_FCTPTR)fugetnodeemcy, "fugetnodeemcy", 0xD2CBB8BB, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetnodeemcy
	#define EXT_fugetnodeemcy
	#define GET_fugetnodeemcy(fl)  CAL_CMGETAPI( "fugetnodeemcy" ) 
	#define CAL_fugetnodeemcy  fugetnodeemcy
	#define CHK_fugetnodeemcy  TRUE
	#define EXP_fugetnodeemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeemcy", (RTS_UINTPTR)fugetnodeemcy, 1, 0xD2CBB8BB, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetnodeemcy
	#define EXT_WagoSysCan_Internal_PFCfugetnodeemcy
	#define GET_WagoSysCan_Internal_PFCfugetnodeemcy  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetnodeemcy  fugetnodeemcy
	#define CHK_WagoSysCan_Internal_PFCfugetnodeemcy  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetnodeemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeemcy", (RTS_UINTPTR)fugetnodeemcy, 1, 0xD2CBB8BB, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetnodeemcy
	#define EXT_fugetnodeemcy
	#define GET_fugetnodeemcy(fl)  CAL_CMGETAPI( "fugetnodeemcy" ) 
	#define CAL_fugetnodeemcy  fugetnodeemcy
	#define CHK_fugetnodeemcy  TRUE
	#define EXP_fugetnodeemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeemcy", (RTS_UINTPTR)fugetnodeemcy, 1, 0xD2CBB8BB, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetnodeemcy  PFFUGETNODEEMCY_IEC pffugetnodeemcy;
	#define EXT_fugetnodeemcy  extern PFFUGETNODEEMCY_IEC pffugetnodeemcy;
	#define GET_fugetnodeemcy(fl)  s_pfCMGetAPI2( "fugetnodeemcy", (RTS_VOID_FCTPTR *)&pffugetnodeemcy, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD2CBB8BB, 0x01000100)
	#define CAL_fugetnodeemcy  pffugetnodeemcy
	#define CHK_fugetnodeemcy  (pffugetnodeemcy != NULL)
	#define EXP_fugetnodeemcy   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeemcy", (RTS_UINTPTR)fugetnodeemcy, 1, 0xD2CBB8BB, 0x01000100) 
#endif


/**
 *
 *    get own node Id of can device
 */
typedef struct tagfugetnodeid_struct
{
	RTS_IEC_DINT FuGetNodeId;			/* VAR_OUTPUT */	/* get own node Id of device */
} fugetnodeid_struct;

void CDECL CDECL_EXT fugetnodeid(fugetnodeid_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETNODEID_IEC) (fugetnodeid_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETNODEID_NOTIMPLEMENTED)
	#define USE_fugetnodeid
	#define EXT_fugetnodeid
	#define GET_fugetnodeid(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetnodeid(p0) 
	#define CHK_fugetnodeid  FALSE
	#define EXP_fugetnodeid  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetnodeid
	#define EXT_fugetnodeid
	#define GET_fugetnodeid(fl)  CAL_CMGETAPI( "fugetnodeid" ) 
	#define CAL_fugetnodeid  fugetnodeid
	#define CHK_fugetnodeid  TRUE
	#define EXP_fugetnodeid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeid", (RTS_UINTPTR)fugetnodeid, 1, 0x3602BC4E, 0x01000100) 
	#define EXTREF_ITF_fugetnodeid {(RTS_VOID_FCTPTR)fugetnodeid, "fugetnodeid", 0x3602BC4E, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetnodeid
	#define EXT_fugetnodeid
	#define GET_fugetnodeid(fl)  CAL_CMGETAPI( "fugetnodeid" ) 
	#define CAL_fugetnodeid  fugetnodeid
	#define CHK_fugetnodeid  TRUE
	#define EXP_fugetnodeid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeid", (RTS_UINTPTR)fugetnodeid, 1, 0x3602BC4E, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugetnodeid
	#define EXT_WagoSysCan_Internal_PFCfugetnodeid
	#define GET_WagoSysCan_Internal_PFCfugetnodeid  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugetnodeid  fugetnodeid
	#define CHK_WagoSysCan_Internal_PFCfugetnodeid  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugetnodeid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeid", (RTS_UINTPTR)fugetnodeid, 1, 0x3602BC4E, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugetnodeid
	#define EXT_fugetnodeid
	#define GET_fugetnodeid(fl)  CAL_CMGETAPI( "fugetnodeid" ) 
	#define CAL_fugetnodeid  fugetnodeid
	#define CHK_fugetnodeid  TRUE
	#define EXP_fugetnodeid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeid", (RTS_UINTPTR)fugetnodeid, 1, 0x3602BC4E, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugetnodeid  PFFUGETNODEID_IEC pffugetnodeid;
	#define EXT_fugetnodeid  extern PFFUGETNODEID_IEC pffugetnodeid;
	#define GET_fugetnodeid(fl)  s_pfCMGetAPI2( "fugetnodeid", (RTS_VOID_FCTPTR *)&pffugetnodeid, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3602BC4E, 0x01000100)
	#define CAL_fugetnodeid  pffugetnodeid
	#define CHK_fugetnodeid  (pffugetnodeid != NULL)
	#define EXP_fugetnodeid   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetnodeid", (RTS_UINTPTR)fugetnodeid, 1, 0x3602BC4E, 0x01000100) 
#endif


/**
 *
 *  Get last timestamp 
 *  Returns: 0 = OK  -1 = fail
 */
typedef struct tagfugettimestamp_struct
{
	typCanTimestamp *typTimestamp;		/* VAR_IN_OUT */	
	RTS_IEC_DINT FuGetTimestamp;		/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fugettimestamp_struct;

void CDECL CDECL_EXT fugettimestamp(fugettimestamp_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETTIMESTAMP_IEC) (fugettimestamp_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETTIMESTAMP_NOTIMPLEMENTED)
	#define USE_fugettimestamp
	#define EXT_fugettimestamp
	#define GET_fugettimestamp(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugettimestamp(p0) 
	#define CHK_fugettimestamp  FALSE
	#define EXP_fugettimestamp  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugettimestamp
	#define EXT_fugettimestamp
	#define GET_fugettimestamp(fl)  CAL_CMGETAPI( "fugettimestamp" ) 
	#define CAL_fugettimestamp  fugettimestamp
	#define CHK_fugettimestamp  TRUE
	#define EXP_fugettimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugettimestamp", (RTS_UINTPTR)fugettimestamp, 1, 0x5513B97F, 0x01000100) 
	#define EXTREF_ITF_fugettimestamp {(RTS_VOID_FCTPTR)fugettimestamp, "fugettimestamp", 0x5513B97F, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fugettimestamp
	#define EXT_fugettimestamp
	#define GET_fugettimestamp(fl)  CAL_CMGETAPI( "fugettimestamp" ) 
	#define CAL_fugettimestamp  fugettimestamp
	#define CHK_fugettimestamp  TRUE
	#define EXP_fugettimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugettimestamp", (RTS_UINTPTR)fugettimestamp, 1, 0x5513B97F, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfugettimestamp
	#define EXT_WagoSysCan_Internal_PFCfugettimestamp
	#define GET_WagoSysCan_Internal_PFCfugettimestamp  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfugettimestamp  fugettimestamp
	#define CHK_WagoSysCan_Internal_PFCfugettimestamp  TRUE
	#define EXP_WagoSysCan_Internal_PFCfugettimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugettimestamp", (RTS_UINTPTR)fugettimestamp, 1, 0x5513B97F, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fugettimestamp
	#define EXT_fugettimestamp
	#define GET_fugettimestamp(fl)  CAL_CMGETAPI( "fugettimestamp" ) 
	#define CAL_fugettimestamp  fugettimestamp
	#define CHK_fugettimestamp  TRUE
	#define EXP_fugettimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugettimestamp", (RTS_UINTPTR)fugettimestamp, 1, 0x5513B97F, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fugettimestamp  PFFUGETTIMESTAMP_IEC pffugettimestamp;
	#define EXT_fugettimestamp  extern PFFUGETTIMESTAMP_IEC pffugettimestamp;
	#define GET_fugettimestamp(fl)  s_pfCMGetAPI2( "fugettimestamp", (RTS_VOID_FCTPTR *)&pffugettimestamp, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5513B97F, 0x01000100)
	#define CAL_fugettimestamp  pffugettimestamp
	#define CHK_fugettimestamp  (pffugettimestamp != NULL)
	#define EXP_fugettimestamp   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugettimestamp", (RTS_UINTPTR)fugettimestamp, 1, 0x5513B97F, 0x01000100) 
#endif


/**
 *
 *  Test for guarding error on any slave
 *  (only tests own node in slave mode)
 *  Returns: node Id of node with guarding error  0: no error -1 failure
 */
typedef struct tagfuguarderror_struct
{
	RTS_IEC_DINT FuGuardError;			/* VAR_OUTPUT */	
} fuguarderror_struct;

void CDECL CDECL_EXT fuguarderror(fuguarderror_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGUARDERROR_IEC) (fuguarderror_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGUARDERROR_NOTIMPLEMENTED)
	#define USE_fuguarderror
	#define EXT_fuguarderror
	#define GET_fuguarderror(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuguarderror(p0) 
	#define CHK_fuguarderror  FALSE
	#define EXP_fuguarderror  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuguarderror
	#define EXT_fuguarderror
	#define GET_fuguarderror(fl)  CAL_CMGETAPI( "fuguarderror" ) 
	#define CAL_fuguarderror  fuguarderror
	#define CHK_fuguarderror  TRUE
	#define EXP_fuguarderror  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderror", (RTS_UINTPTR)fuguarderror, 1, 0x6EE20B18, 0x01000100) 
	#define EXTREF_ITF_fuguarderror {(RTS_VOID_FCTPTR)fuguarderror, "fuguarderror", 0x6EE20B18, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fuguarderror
	#define EXT_fuguarderror
	#define GET_fuguarderror(fl)  CAL_CMGETAPI( "fuguarderror" ) 
	#define CAL_fuguarderror  fuguarderror
	#define CHK_fuguarderror  TRUE
	#define EXP_fuguarderror  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderror", (RTS_UINTPTR)fuguarderror, 1, 0x6EE20B18, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuguarderror
	#define EXT_WagoSysCan_Internal_PFCfuguarderror
	#define GET_WagoSysCan_Internal_PFCfuguarderror  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuguarderror  fuguarderror
	#define CHK_WagoSysCan_Internal_PFCfuguarderror  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuguarderror  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderror", (RTS_UINTPTR)fuguarderror, 1, 0x6EE20B18, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fuguarderror
	#define EXT_fuguarderror
	#define GET_fuguarderror(fl)  CAL_CMGETAPI( "fuguarderror" ) 
	#define CAL_fuguarderror  fuguarderror
	#define CHK_fuguarderror  TRUE
	#define EXP_fuguarderror  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderror", (RTS_UINTPTR)fuguarderror, 1, 0x6EE20B18, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fuguarderror  PFFUGUARDERROR_IEC pffuguarderror;
	#define EXT_fuguarderror  extern PFFUGUARDERROR_IEC pffuguarderror;
	#define GET_fuguarderror(fl)  s_pfCMGetAPI2( "fuguarderror", (RTS_VOID_FCTPTR *)&pffuguarderror, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6EE20B18, 0x01000100)
	#define CAL_fuguarderror  pffuguarderror
	#define CHK_fuguarderror  (pffuguarderror != NULL)
	#define EXP_fuguarderror   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderror", (RTS_UINTPTR)fuguarderror, 1, 0x6EE20B18, 0x01000100) 
#endif


/**
 *
 *  Test for guarding error message from slave in CANopen Manager Mode
 *  Returns:  0 = no guarding error message  1 = guarding error message from slave -1 = failure
 */
typedef struct tagfuguarderrornode_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	
	RTS_IEC_DINT FuGuardErrorNode;		/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fuguarderrornode_struct;

void CDECL CDECL_EXT fuguarderrornode(fuguarderrornode_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGUARDERRORNODE_IEC) (fuguarderrornode_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGUARDERRORNODE_NOTIMPLEMENTED)
	#define USE_fuguarderrornode
	#define EXT_fuguarderrornode
	#define GET_fuguarderrornode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuguarderrornode(p0) 
	#define CHK_fuguarderrornode  FALSE
	#define EXP_fuguarderrornode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuguarderrornode
	#define EXT_fuguarderrornode
	#define GET_fuguarderrornode(fl)  CAL_CMGETAPI( "fuguarderrornode" ) 
	#define CAL_fuguarderrornode  fuguarderrornode
	#define CHK_fuguarderrornode  TRUE
	#define EXP_fuguarderrornode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderrornode", (RTS_UINTPTR)fuguarderrornode, 1, 0x5E0A6790, 0x01000100) 
	#define EXTREF_ITF_fuguarderrornode {(RTS_VOID_FCTPTR)fuguarderrornode, "fuguarderrornode", 0x5E0A6790, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fuguarderrornode
	#define EXT_fuguarderrornode
	#define GET_fuguarderrornode(fl)  CAL_CMGETAPI( "fuguarderrornode" ) 
	#define CAL_fuguarderrornode  fuguarderrornode
	#define CHK_fuguarderrornode  TRUE
	#define EXP_fuguarderrornode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderrornode", (RTS_UINTPTR)fuguarderrornode, 1, 0x5E0A6790, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuguarderrornode
	#define EXT_WagoSysCan_Internal_PFCfuguarderrornode
	#define GET_WagoSysCan_Internal_PFCfuguarderrornode  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuguarderrornode  fuguarderrornode
	#define CHK_WagoSysCan_Internal_PFCfuguarderrornode  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuguarderrornode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderrornode", (RTS_UINTPTR)fuguarderrornode, 1, 0x5E0A6790, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fuguarderrornode
	#define EXT_fuguarderrornode
	#define GET_fuguarderrornode(fl)  CAL_CMGETAPI( "fuguarderrornode" ) 
	#define CAL_fuguarderrornode  fuguarderrornode
	#define CHK_fuguarderrornode  TRUE
	#define EXP_fuguarderrornode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderrornode", (RTS_UINTPTR)fuguarderrornode, 1, 0x5E0A6790, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fuguarderrornode  PFFUGUARDERRORNODE_IEC pffuguarderrornode;
	#define EXT_fuguarderrornode  extern PFFUGUARDERRORNODE_IEC pffuguarderrornode;
	#define GET_fuguarderrornode(fl)  s_pfCMGetAPI2( "fuguarderrornode", (RTS_VOID_FCTPTR *)&pffuguarderrornode, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5E0A6790, 0x01000100)
	#define CAL_fuguarderrornode  pffuguarderrornode
	#define CHK_fuguarderrornode  (pffuguarderrornode != NULL)
	#define EXP_fuguarderrornode   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuguarderrornode", (RTS_UINTPTR)fuguarderrornode, 1, 0x5E0A6790, 0x01000100) 
#endif


/**
 *
 *   return version of library interface in firmware
 */
typedef struct tagfulibversion_struct
{
	RTS_IEC_UDINT FuLibVersion;			/* VAR_OUTPUT */	
} fulibversion_struct;

void CDECL CDECL_EXT fulibversion(fulibversion_struct *p);
typedef void (CDECL CDECL_EXT* PFFULIBVERSION_IEC) (fulibversion_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FULIBVERSION_NOTIMPLEMENTED)
	#define USE_fulibversion
	#define EXT_fulibversion
	#define GET_fulibversion(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fulibversion(p0) 
	#define CHK_fulibversion  FALSE
	#define EXP_fulibversion  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fulibversion
	#define EXT_fulibversion
	#define GET_fulibversion(fl)  CAL_CMGETAPI( "fulibversion" ) 
	#define CAL_fulibversion  fulibversion
	#define CHK_fulibversion  TRUE
	#define EXP_fulibversion  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulibversion", (RTS_UINTPTR)fulibversion, 1, 0x9C09B289, 0x01000100) 
	#define EXTREF_ITF_fulibversion {(RTS_VOID_FCTPTR)fulibversion, "fulibversion", 0x9C09B289, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fulibversion
	#define EXT_fulibversion
	#define GET_fulibversion(fl)  CAL_CMGETAPI( "fulibversion" ) 
	#define CAL_fulibversion  fulibversion
	#define CHK_fulibversion  TRUE
	#define EXP_fulibversion  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulibversion", (RTS_UINTPTR)fulibversion, 1, 0x9C09B289, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfulibversion
	#define EXT_WagoSysCan_Internal_PFCfulibversion
	#define GET_WagoSysCan_Internal_PFCfulibversion  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfulibversion  fulibversion
	#define CHK_WagoSysCan_Internal_PFCfulibversion  TRUE
	#define EXP_WagoSysCan_Internal_PFCfulibversion  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulibversion", (RTS_UINTPTR)fulibversion, 1, 0x9C09B289, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fulibversion
	#define EXT_fulibversion
	#define GET_fulibversion(fl)  CAL_CMGETAPI( "fulibversion" ) 
	#define CAL_fulibversion  fulibversion
	#define CHK_fulibversion  TRUE
	#define EXP_fulibversion  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulibversion", (RTS_UINTPTR)fulibversion, 1, 0x9C09B289, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fulibversion  PFFULIBVERSION_IEC pffulibversion;
	#define EXT_fulibversion  extern PFFULIBVERSION_IEC pffulibversion;
	#define GET_fulibversion(fl)  s_pfCMGetAPI2( "fulibversion", (RTS_VOID_FCTPTR *)&pffulibversion, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9C09B289, 0x01000100)
	#define CAL_fulibversion  pffulibversion
	#define CHK_fulibversion  (pffulibversion != NULL)
	#define EXP_fulibversion   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulibversion", (RTS_UINTPTR)fulibversion, 1, 0x9C09B289, 0x01000100) 
#endif


/**
 *
 *  Open CAN connection in layer2 mode
 *  Returns: 0 = OK  -1 = fail -3 invalid port  -4 invalid baudrate -6 not ready(error)
 */
typedef struct tagfuopenlayer2_struct
{
	RTS_IEC_UDINT udiBaudrate;			/* VAR_INPUT */	/* baudrate in baud valid is 100baud...1Mbaud 0 = auto (if supported) */
	RTS_IEC_DWORD dwFlags;				/* VAR_INPUT */	/* reserved for future use */
	RTS_IEC_UDINT udiBusNr;				/* VAR_INPUT */	/* reserved for future use */
	RTS_IEC_DINT FuOpenLayer2;			/* VAR_OUTPUT, Enum: ECANDEVICEERROR */
} fuopenlayer2_struct;

void CDECL CDECL_EXT fuopenlayer2(fuopenlayer2_struct *p);
typedef void (CDECL CDECL_EXT* PFFUOPENLAYER2_IEC) (fuopenlayer2_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUOPENLAYER2_NOTIMPLEMENTED)
	#define USE_fuopenlayer2
	#define EXT_fuopenlayer2
	#define GET_fuopenlayer2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuopenlayer2(p0) 
	#define CHK_fuopenlayer2  FALSE
	#define EXP_fuopenlayer2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuopenlayer2
	#define EXT_fuopenlayer2
	#define GET_fuopenlayer2(fl)  CAL_CMGETAPI( "fuopenlayer2" ) 
	#define CAL_fuopenlayer2  fuopenlayer2
	#define CHK_fuopenlayer2  TRUE
	#define EXP_fuopenlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenlayer2", (RTS_UINTPTR)fuopenlayer2, 1, 0x82ECA0D4, 0x01000100) 
	#define EXTREF_ITF_fuopenlayer2 {(RTS_VOID_FCTPTR)fuopenlayer2, "fuopenlayer2", 0x82ECA0D4, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fuopenlayer2
	#define EXT_fuopenlayer2
	#define GET_fuopenlayer2(fl)  CAL_CMGETAPI( "fuopenlayer2" ) 
	#define CAL_fuopenlayer2  fuopenlayer2
	#define CHK_fuopenlayer2  TRUE
	#define EXP_fuopenlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenlayer2", (RTS_UINTPTR)fuopenlayer2, 1, 0x82ECA0D4, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuopenlayer2
	#define EXT_WagoSysCan_Internal_PFCfuopenlayer2
	#define GET_WagoSysCan_Internal_PFCfuopenlayer2  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuopenlayer2  fuopenlayer2
	#define CHK_WagoSysCan_Internal_PFCfuopenlayer2  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuopenlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenlayer2", (RTS_UINTPTR)fuopenlayer2, 1, 0x82ECA0D4, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fuopenlayer2
	#define EXT_fuopenlayer2
	#define GET_fuopenlayer2(fl)  CAL_CMGETAPI( "fuopenlayer2" ) 
	#define CAL_fuopenlayer2  fuopenlayer2
	#define CHK_fuopenlayer2  TRUE
	#define EXP_fuopenlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenlayer2", (RTS_UINTPTR)fuopenlayer2, 1, 0x82ECA0D4, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fuopenlayer2  PFFUOPENLAYER2_IEC pffuopenlayer2;
	#define EXT_fuopenlayer2  extern PFFUOPENLAYER2_IEC pffuopenlayer2;
	#define GET_fuopenlayer2(fl)  s_pfCMGetAPI2( "fuopenlayer2", (RTS_VOID_FCTPTR *)&pffuopenlayer2, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x82ECA0D4, 0x01000100)
	#define CAL_fuopenlayer2  pffuopenlayer2
	#define CHK_fuopenlayer2  (pffuopenlayer2 != NULL)
	#define EXP_fuopenlayer2   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenlayer2", (RTS_UINTPTR)fuopenlayer2, 1, 0x82ECA0D4, 0x01000100) 
#endif


/**
 *
 *  Register or unregister all Ids for layer2 rx 
 *  Returns: 0 = OK  -1 = fail
 *  Warning: all incoming messages must be handled by the application 
 */
typedef struct tagfuregisterall_struct
{
	RTS_IEC_UDINT eRegflag;				/* VAR_INPUT, Enum: ECANFLAGREGISTER */
	RTS_IEC_DINT FuRegisterAll;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} furegisterall_struct;

void CDECL CDECL_EXT furegisterall(furegisterall_struct *p);
typedef void (CDECL CDECL_EXT* PFFUREGISTERALL_IEC) (furegisterall_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUREGISTERALL_NOTIMPLEMENTED)
	#define USE_furegisterall
	#define EXT_furegisterall
	#define GET_furegisterall(fl)  ERR_NOTIMPLEMENTED
	#define CAL_furegisterall(p0) 
	#define CHK_furegisterall  FALSE
	#define EXP_furegisterall  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_furegisterall
	#define EXT_furegisterall
	#define GET_furegisterall(fl)  CAL_CMGETAPI( "furegisterall" ) 
	#define CAL_furegisterall  furegisterall
	#define CHK_furegisterall  TRUE
	#define EXP_furegisterall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterall", (RTS_UINTPTR)furegisterall, 1, 0x311E4F14, 0x01000100) 
	#define EXTREF_ITF_furegisterall {(RTS_VOID_FCTPTR)furegisterall, "furegisterall", 0x311E4F14, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_furegisterall
	#define EXT_furegisterall
	#define GET_furegisterall(fl)  CAL_CMGETAPI( "furegisterall" ) 
	#define CAL_furegisterall  furegisterall
	#define CHK_furegisterall  TRUE
	#define EXP_furegisterall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterall", (RTS_UINTPTR)furegisterall, 1, 0x311E4F14, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuregisterall
	#define EXT_WagoSysCan_Internal_PFCfuregisterall
	#define GET_WagoSysCan_Internal_PFCfuregisterall  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuregisterall  furegisterall
	#define CHK_WagoSysCan_Internal_PFCfuregisterall  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuregisterall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterall", (RTS_UINTPTR)furegisterall, 1, 0x311E4F14, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_furegisterall
	#define EXT_furegisterall
	#define GET_furegisterall(fl)  CAL_CMGETAPI( "furegisterall" ) 
	#define CAL_furegisterall  furegisterall
	#define CHK_furegisterall  TRUE
	#define EXP_furegisterall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterall", (RTS_UINTPTR)furegisterall, 1, 0x311E4F14, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_furegisterall  PFFUREGISTERALL_IEC pffuregisterall;
	#define EXT_furegisterall  extern PFFUREGISTERALL_IEC pffuregisterall;
	#define GET_furegisterall(fl)  s_pfCMGetAPI2( "furegisterall", (RTS_VOID_FCTPTR *)&pffuregisterall, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x311E4F14, 0x01000100)
	#define CAL_furegisterall  pffuregisterall
	#define CHK_furegisterall  (pffuregisterall != NULL)
	#define EXP_furegisterall   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterall", (RTS_UINTPTR)furegisterall, 1, 0x311E4F14, 0x01000100) 
#endif


/**
 *
 *   Register or unregister id for layer2 rx 
 *   Returns: 0 = OK  -1 = device fail -2 = no free index in register or no index in unregister
 */
typedef struct tagfuregisterid_struct
{
	RTS_IEC_UDINT eRegflag;				/* VAR_INPUT, Enum: ECANFLAGREGISTER */
	RTS_IEC_DWORD dwId;					/* VAR_INPUT */	/* CAN Id + 16#80000000 if 29Bit Id */
	RTS_IEC_DINT FuRegisterId;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} furegisterid_struct;

void CDECL CDECL_EXT furegisterid(furegisterid_struct *p);
typedef void (CDECL CDECL_EXT* PFFUREGISTERID_IEC) (furegisterid_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUREGISTERID_NOTIMPLEMENTED)
	#define USE_furegisterid
	#define EXT_furegisterid
	#define GET_furegisterid(fl)  ERR_NOTIMPLEMENTED
	#define CAL_furegisterid(p0) 
	#define CHK_furegisterid  FALSE
	#define EXP_furegisterid  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_furegisterid
	#define EXT_furegisterid
	#define GET_furegisterid(fl)  CAL_CMGETAPI( "furegisterid" ) 
	#define CAL_furegisterid  furegisterid
	#define CHK_furegisterid  TRUE
	#define EXP_furegisterid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterid", (RTS_UINTPTR)furegisterid, 1, 0xB124099C, 0x01000100) 
	#define EXTREF_ITF_furegisterid {(RTS_VOID_FCTPTR)furegisterid, "furegisterid", 0xB124099C, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_furegisterid
	#define EXT_furegisterid
	#define GET_furegisterid(fl)  CAL_CMGETAPI( "furegisterid" ) 
	#define CAL_furegisterid  furegisterid
	#define CHK_furegisterid  TRUE
	#define EXP_furegisterid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterid", (RTS_UINTPTR)furegisterid, 1, 0xB124099C, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuregisterid
	#define EXT_WagoSysCan_Internal_PFCfuregisterid
	#define GET_WagoSysCan_Internal_PFCfuregisterid  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuregisterid  furegisterid
	#define CHK_WagoSysCan_Internal_PFCfuregisterid  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuregisterid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterid", (RTS_UINTPTR)furegisterid, 1, 0xB124099C, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_furegisterid
	#define EXT_furegisterid
	#define GET_furegisterid(fl)  CAL_CMGETAPI( "furegisterid" ) 
	#define CAL_furegisterid  furegisterid
	#define CHK_furegisterid  TRUE
	#define EXP_furegisterid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterid", (RTS_UINTPTR)furegisterid, 1, 0xB124099C, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_furegisterid  PFFUREGISTERID_IEC pffuregisterid;
	#define EXT_furegisterid  extern PFFUREGISTERID_IEC pffuregisterid;
	#define GET_furegisterid(fl)  s_pfCMGetAPI2( "furegisterid", (RTS_VOID_FCTPTR *)&pffuregisterid, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB124099C, 0x01000100)
	#define CAL_furegisterid  pffuregisterid
	#define CHK_furegisterid  (pffuregisterid != NULL)
	#define EXP_furegisterid   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furegisterid", (RTS_UINTPTR)furegisterid, 1, 0xB124099C, 0x01000100) 
#endif


/**
 *
 *    Reset and restart CAN communication in layer2 mode 
 *	Returns: 0 = OK  -1 = fail 
 * 
 */
typedef struct tagfuresetlayer2_struct
{
	RTS_IEC_DINT FuResetLayer2;			/* VAR_OUTPUT, Enum: ECANDEVICEERROR */
} furesetlayer2_struct;

void CDECL CDECL_EXT furesetlayer2(furesetlayer2_struct *p);
typedef void (CDECL CDECL_EXT* PFFURESETLAYER2_IEC) (furesetlayer2_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FURESETLAYER2_NOTIMPLEMENTED)
	#define USE_furesetlayer2
	#define EXT_furesetlayer2
	#define GET_furesetlayer2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_furesetlayer2(p0) 
	#define CHK_furesetlayer2  FALSE
	#define EXP_furesetlayer2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_furesetlayer2
	#define EXT_furesetlayer2
	#define GET_furesetlayer2(fl)  CAL_CMGETAPI( "furesetlayer2" ) 
	#define CAL_furesetlayer2  furesetlayer2
	#define CHK_furesetlayer2  TRUE
	#define EXP_furesetlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetlayer2", (RTS_UINTPTR)furesetlayer2, 1, 0x830BB7FB, 0x01000100) 
	#define EXTREF_ITF_furesetlayer2 {(RTS_VOID_FCTPTR)furesetlayer2, "furesetlayer2", 0x830BB7FB, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_furesetlayer2
	#define EXT_furesetlayer2
	#define GET_furesetlayer2(fl)  CAL_CMGETAPI( "furesetlayer2" ) 
	#define CAL_furesetlayer2  furesetlayer2
	#define CHK_furesetlayer2  TRUE
	#define EXP_furesetlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetlayer2", (RTS_UINTPTR)furesetlayer2, 1, 0x830BB7FB, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfuresetlayer2
	#define EXT_WagoSysCan_Internal_PFCfuresetlayer2
	#define GET_WagoSysCan_Internal_PFCfuresetlayer2  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfuresetlayer2  furesetlayer2
	#define CHK_WagoSysCan_Internal_PFCfuresetlayer2  TRUE
	#define EXP_WagoSysCan_Internal_PFCfuresetlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetlayer2", (RTS_UINTPTR)furesetlayer2, 1, 0x830BB7FB, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_furesetlayer2
	#define EXT_furesetlayer2
	#define GET_furesetlayer2(fl)  CAL_CMGETAPI( "furesetlayer2" ) 
	#define CAL_furesetlayer2  furesetlayer2
	#define CHK_furesetlayer2  TRUE
	#define EXP_furesetlayer2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetlayer2", (RTS_UINTPTR)furesetlayer2, 1, 0x830BB7FB, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_furesetlayer2  PFFURESETLAYER2_IEC pffuresetlayer2;
	#define EXT_furesetlayer2  extern PFFURESETLAYER2_IEC pffuresetlayer2;
	#define GET_furesetlayer2(fl)  s_pfCMGetAPI2( "furesetlayer2", (RTS_VOID_FCTPTR *)&pffuresetlayer2, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x830BB7FB, 0x01000100)
	#define CAL_furesetlayer2  pffuresetlayer2
	#define CHK_furesetlayer2  (pffuresetlayer2 != NULL)
	#define EXP_furesetlayer2   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetlayer2", (RTS_UINTPTR)furesetlayer2, 1, 0x830BB7FB, 0x01000100) 
#endif


/**
 *
 *  Function is called to add a User SDO
 *  Returns: 0 = OK  -1 = fail
 */
typedef struct tagfusdoadd_struct
{
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* 16#2000 spezial SDO no subindex size max 1536 byte */
	RTS_IEC_UDINT udiEntrys;			/* VAR_INPUT */	/* requested subindexes */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* datalen in bytes of 1 subindex */
	RTS_IEC_UDINT udiSDOType;			/* VAR_INPUT */	/* data type */
	RTS_IEC_UDINT udiOffset;			/* VAR_INPUT */	/* position in parameter data (8192 Bytes) */
	RTS_IEC_DINT FuSdoAdd;				/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fusdoadd_struct;

void CDECL CDECL_EXT fusdoadd(fusdoadd_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOADD_IEC) (fusdoadd_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOADD_NOTIMPLEMENTED)
	#define USE_fusdoadd
	#define EXT_fusdoadd
	#define GET_fusdoadd(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdoadd(p0) 
	#define CHK_fusdoadd  FALSE
	#define EXP_fusdoadd  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdoadd
	#define EXT_fusdoadd
	#define GET_fusdoadd(fl)  CAL_CMGETAPI( "fusdoadd" ) 
	#define CAL_fusdoadd  fusdoadd
	#define CHK_fusdoadd  TRUE
	#define EXP_fusdoadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoadd", (RTS_UINTPTR)fusdoadd, 1, 0x6C60EC7B, 0x01000100) 
	#define EXTREF_ITF_fusdoadd {(RTS_VOID_FCTPTR)fusdoadd, "fusdoadd", 0x6C60EC7B, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdoadd
	#define EXT_fusdoadd
	#define GET_fusdoadd(fl)  CAL_CMGETAPI( "fusdoadd" ) 
	#define CAL_fusdoadd  fusdoadd
	#define CHK_fusdoadd  TRUE
	#define EXP_fusdoadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoadd", (RTS_UINTPTR)fusdoadd, 1, 0x6C60EC7B, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdoadd
	#define EXT_WagoSysCan_Internal_PFCfusdoadd
	#define GET_WagoSysCan_Internal_PFCfusdoadd  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdoadd  fusdoadd
	#define CHK_WagoSysCan_Internal_PFCfusdoadd  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdoadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoadd", (RTS_UINTPTR)fusdoadd, 1, 0x6C60EC7B, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdoadd
	#define EXT_fusdoadd
	#define GET_fusdoadd(fl)  CAL_CMGETAPI( "fusdoadd" ) 
	#define CAL_fusdoadd  fusdoadd
	#define CHK_fusdoadd  TRUE
	#define EXP_fusdoadd  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoadd", (RTS_UINTPTR)fusdoadd, 1, 0x6C60EC7B, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdoadd  PFFUSDOADD_IEC pffusdoadd;
	#define EXT_fusdoadd  extern PFFUSDOADD_IEC pffusdoadd;
	#define GET_fusdoadd(fl)  s_pfCMGetAPI2( "fusdoadd", (RTS_VOID_FCTPTR *)&pffusdoadd, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6C60EC7B, 0x01000100)
	#define CAL_fusdoadd  pffusdoadd
	#define CHK_fusdoadd  (pffusdoadd != NULL)
	#define EXP_fusdoadd   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoadd", (RTS_UINTPTR)fusdoadd, 1, 0x6C60EC7B, 0x01000100) 
#endif


/**
 * 
 *  read CANopen SDOs without blocking process
 *  returns
 *        < 0       // Error Codes from eCanFnReturn 
 *	   0          // call finished / bytes received
 *	   > 16#10000 // SDO abort code
 */
typedef struct tagfusdoreadasync_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	/* node id */
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* sdo index */
	RTS_IEC_UDINT udiSubindex;			/* VAR_INPUT */	/* sdo subindex */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* sdo bytes (0 = all) */
	RTS_IEC_UDINT udiTimeout;			/* VAR_INPUT */	/* timeout in ms */
	RTS_IEC_UDINT udiChannel;			/* VAR_INPUT */	/* channel number for parallel transfers (0...15) */
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* sdo data */
	RTS_IEC_DINT FuSdoReadAsync;		/* VAR_OUTPUT */	
} fusdoreadasync_struct;

void CDECL CDECL_EXT fusdoreadasync(fusdoreadasync_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOREADASYNC_IEC) (fusdoreadasync_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOREADASYNC_NOTIMPLEMENTED)
	#define USE_fusdoreadasync
	#define EXT_fusdoreadasync
	#define GET_fusdoreadasync(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdoreadasync(p0) 
	#define CHK_fusdoreadasync  FALSE
	#define EXP_fusdoreadasync  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdoreadasync
	#define EXT_fusdoreadasync
	#define GET_fusdoreadasync(fl)  CAL_CMGETAPI( "fusdoreadasync" ) 
	#define CAL_fusdoreadasync  fusdoreadasync
	#define CHK_fusdoreadasync  TRUE
	#define EXP_fusdoreadasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadasync", (RTS_UINTPTR)fusdoreadasync, 1, 0xD9C2B47F, 0x01000100) 
	#define EXTREF_ITF_fusdoreadasync {(RTS_VOID_FCTPTR)fusdoreadasync, "fusdoreadasync", 0xD9C2B47F, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdoreadasync
	#define EXT_fusdoreadasync
	#define GET_fusdoreadasync(fl)  CAL_CMGETAPI( "fusdoreadasync" ) 
	#define CAL_fusdoreadasync  fusdoreadasync
	#define CHK_fusdoreadasync  TRUE
	#define EXP_fusdoreadasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadasync", (RTS_UINTPTR)fusdoreadasync, 1, 0xD9C2B47F, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdoreadasync
	#define EXT_WagoSysCan_Internal_PFCfusdoreadasync
	#define GET_WagoSysCan_Internal_PFCfusdoreadasync  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdoreadasync  fusdoreadasync
	#define CHK_WagoSysCan_Internal_PFCfusdoreadasync  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdoreadasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadasync", (RTS_UINTPTR)fusdoreadasync, 1, 0xD9C2B47F, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdoreadasync
	#define EXT_fusdoreadasync
	#define GET_fusdoreadasync(fl)  CAL_CMGETAPI( "fusdoreadasync" ) 
	#define CAL_fusdoreadasync  fusdoreadasync
	#define CHK_fusdoreadasync  TRUE
	#define EXP_fusdoreadasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadasync", (RTS_UINTPTR)fusdoreadasync, 1, 0xD9C2B47F, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdoreadasync  PFFUSDOREADASYNC_IEC pffusdoreadasync;
	#define EXT_fusdoreadasync  extern PFFUSDOREADASYNC_IEC pffusdoreadasync;
	#define GET_fusdoreadasync(fl)  s_pfCMGetAPI2( "fusdoreadasync", (RTS_VOID_FCTPTR *)&pffusdoreadasync, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD9C2B47F, 0x01000100)
	#define CAL_fusdoreadasync  pffusdoreadasync
	#define CHK_fusdoreadasync  (pffusdoreadasync != NULL)
	#define EXP_fusdoreadasync   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadasync", (RTS_UINTPTR)fusdoreadasync, 1, 0xD9C2B47F, 0x01000100) 
#endif


/**
 * 
 *  read CANopen from process data and parameter data sdos
 *  Returns: 0 = OK  -1 = fail
 */
typedef struct tagfusdoreaddata_struct
{
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* index */
	RTS_IEC_UDINT udiSubindex;			/* VAR_INPUT */	/* subindex */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* datalen */
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* sdo data */
	RTS_IEC_DINT FuSdoReadData;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fusdoreaddata_struct;

void CDECL CDECL_EXT fusdoreaddata(fusdoreaddata_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOREADDATA_IEC) (fusdoreaddata_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOREADDATA_NOTIMPLEMENTED)
	#define USE_fusdoreaddata
	#define EXT_fusdoreaddata
	#define GET_fusdoreaddata(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdoreaddata(p0) 
	#define CHK_fusdoreaddata  FALSE
	#define EXP_fusdoreaddata  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdoreaddata
	#define EXT_fusdoreaddata
	#define GET_fusdoreaddata(fl)  CAL_CMGETAPI( "fusdoreaddata" ) 
	#define CAL_fusdoreaddata  fusdoreaddata
	#define CHK_fusdoreaddata  TRUE
	#define EXP_fusdoreaddata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreaddata", (RTS_UINTPTR)fusdoreaddata, 1, 0x85C7E288, 0x01000100) 
	#define EXTREF_ITF_fusdoreaddata {(RTS_VOID_FCTPTR)fusdoreaddata, "fusdoreaddata", 0x85C7E288, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdoreaddata
	#define EXT_fusdoreaddata
	#define GET_fusdoreaddata(fl)  CAL_CMGETAPI( "fusdoreaddata" ) 
	#define CAL_fusdoreaddata  fusdoreaddata
	#define CHK_fusdoreaddata  TRUE
	#define EXP_fusdoreaddata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreaddata", (RTS_UINTPTR)fusdoreaddata, 1, 0x85C7E288, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdoreaddata
	#define EXT_WagoSysCan_Internal_PFCfusdoreaddata
	#define GET_WagoSysCan_Internal_PFCfusdoreaddata  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdoreaddata  fusdoreaddata
	#define CHK_WagoSysCan_Internal_PFCfusdoreaddata  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdoreaddata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreaddata", (RTS_UINTPTR)fusdoreaddata, 1, 0x85C7E288, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdoreaddata
	#define EXT_fusdoreaddata
	#define GET_fusdoreaddata(fl)  CAL_CMGETAPI( "fusdoreaddata" ) 
	#define CAL_fusdoreaddata  fusdoreaddata
	#define CHK_fusdoreaddata  TRUE
	#define EXP_fusdoreaddata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreaddata", (RTS_UINTPTR)fusdoreaddata, 1, 0x85C7E288, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdoreaddata  PFFUSDOREADDATA_IEC pffusdoreaddata;
	#define EXT_fusdoreaddata  extern PFFUSDOREADDATA_IEC pffusdoreaddata;
	#define GET_fusdoreaddata(fl)  s_pfCMGetAPI2( "fusdoreaddata", (RTS_VOID_FCTPTR *)&pffusdoreaddata, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x85C7E288, 0x01000100)
	#define CAL_fusdoreaddata  pffusdoreaddata
	#define CHK_fusdoreaddata  (pffusdoreaddata != NULL)
	#define EXP_fusdoreaddata   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreaddata", (RTS_UINTPTR)fusdoreaddata, 1, 0x85C7E288, 0x01000100) 
#endif


/**
 * 
 *  read CANopen SDOs with blocking process
 *  returns
 *	   0          // Call finished
 *	   < 0        // Error Codes from eCanFnReturn 
 *	   > 16#10000 // SDO abort code
 */
typedef struct tagfusdoreadsync_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	/* node id */
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* sdo index */
	RTS_IEC_UDINT udiSubindex;			/* VAR_INPUT */	/* sdo subindex */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* sdo bytes */
	RTS_IEC_UDINT udiTimeout;			/* VAR_INPUT */	/* timeout in ms */
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* sdo data */
	RTS_IEC_DINT FuSdoReadSync;			/* VAR_OUTPUT */	
} fusdoreadsync_struct;

void CDECL CDECL_EXT fusdoreadsync(fusdoreadsync_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOREADSYNC_IEC) (fusdoreadsync_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOREADSYNC_NOTIMPLEMENTED)
	#define USE_fusdoreadsync
	#define EXT_fusdoreadsync
	#define GET_fusdoreadsync(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdoreadsync(p0) 
	#define CHK_fusdoreadsync  FALSE
	#define EXP_fusdoreadsync  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdoreadsync
	#define EXT_fusdoreadsync
	#define GET_fusdoreadsync(fl)  CAL_CMGETAPI( "fusdoreadsync" ) 
	#define CAL_fusdoreadsync  fusdoreadsync
	#define CHK_fusdoreadsync  TRUE
	#define EXP_fusdoreadsync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadsync", (RTS_UINTPTR)fusdoreadsync, 1, 0x8D537ACA, 0x01000100) 
	#define EXTREF_ITF_fusdoreadsync {(RTS_VOID_FCTPTR)fusdoreadsync, "fusdoreadsync", 0x8D537ACA, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdoreadsync
	#define EXT_fusdoreadsync
	#define GET_fusdoreadsync(fl)  CAL_CMGETAPI( "fusdoreadsync" ) 
	#define CAL_fusdoreadsync  fusdoreadsync
	#define CHK_fusdoreadsync  TRUE
	#define EXP_fusdoreadsync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadsync", (RTS_UINTPTR)fusdoreadsync, 1, 0x8D537ACA, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdoreadsync
	#define EXT_WagoSysCan_Internal_PFCfusdoreadsync
	#define GET_WagoSysCan_Internal_PFCfusdoreadsync  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdoreadsync  fusdoreadsync
	#define CHK_WagoSysCan_Internal_PFCfusdoreadsync  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdoreadsync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadsync", (RTS_UINTPTR)fusdoreadsync, 1, 0x8D537ACA, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdoreadsync
	#define EXT_fusdoreadsync
	#define GET_fusdoreadsync(fl)  CAL_CMGETAPI( "fusdoreadsync" ) 
	#define CAL_fusdoreadsync  fusdoreadsync
	#define CHK_fusdoreadsync  TRUE
	#define EXP_fusdoreadsync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadsync", (RTS_UINTPTR)fusdoreadsync, 1, 0x8D537ACA, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdoreadsync  PFFUSDOREADSYNC_IEC pffusdoreadsync;
	#define EXT_fusdoreadsync  extern PFFUSDOREADSYNC_IEC pffusdoreadsync;
	#define GET_fusdoreadsync(fl)  s_pfCMGetAPI2( "fusdoreadsync", (RTS_VOID_FCTPTR *)&pffusdoreadsync, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8D537ACA, 0x01000100)
	#define CAL_fusdoreadsync  pffusdoreadsync
	#define CHK_fusdoreadsync  (pffusdoreadsync != NULL)
	#define EXP_fusdoreadsync   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdoreadsync", (RTS_UINTPTR)fusdoreadsync, 1, 0x8D537ACA, 0x01000100) 
#endif


/**
 * 
 *  send CANopen SDOs without blocking process
 *  returns
 *        < 0        // Error Codes from eCanFnReturn 
 *	    0          // Call finished
 *	   > 16#10000  // SDO abort code
 */
typedef struct tagfusdowriteasync_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	/* node id */
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* sdo index */
	RTS_IEC_UDINT udiSubindex;			/* VAR_INPUT */	/* sdo subindex */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* sdo bytes */
	RTS_IEC_UDINT udiTimeout;			/* VAR_INPUT */	/* timeout in ms */
	RTS_IEC_UDINT udiChannel;			/* VAR_INPUT */	/* channel number for parallel transfers (0...15) */
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* sdo data */
	RTS_IEC_DINT FuSdoWriteAsync;		/* VAR_OUTPUT */	
} fusdowriteasync_struct;

void CDECL CDECL_EXT fusdowriteasync(fusdowriteasync_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOWRITEASYNC_IEC) (fusdowriteasync_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOWRITEASYNC_NOTIMPLEMENTED)
	#define USE_fusdowriteasync
	#define EXT_fusdowriteasync
	#define GET_fusdowriteasync(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdowriteasync(p0) 
	#define CHK_fusdowriteasync  FALSE
	#define EXP_fusdowriteasync  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdowriteasync
	#define EXT_fusdowriteasync
	#define GET_fusdowriteasync(fl)  CAL_CMGETAPI( "fusdowriteasync" ) 
	#define CAL_fusdowriteasync  fusdowriteasync
	#define CHK_fusdowriteasync  TRUE
	#define EXP_fusdowriteasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowriteasync", (RTS_UINTPTR)fusdowriteasync, 1, 0x9D2AC1AA, 0x01000100) 
	#define EXTREF_ITF_fusdowriteasync {(RTS_VOID_FCTPTR)fusdowriteasync, "fusdowriteasync", 0x9D2AC1AA, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdowriteasync
	#define EXT_fusdowriteasync
	#define GET_fusdowriteasync(fl)  CAL_CMGETAPI( "fusdowriteasync" ) 
	#define CAL_fusdowriteasync  fusdowriteasync
	#define CHK_fusdowriteasync  TRUE
	#define EXP_fusdowriteasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowriteasync", (RTS_UINTPTR)fusdowriteasync, 1, 0x9D2AC1AA, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdowriteasync
	#define EXT_WagoSysCan_Internal_PFCfusdowriteasync
	#define GET_WagoSysCan_Internal_PFCfusdowriteasync  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdowriteasync  fusdowriteasync
	#define CHK_WagoSysCan_Internal_PFCfusdowriteasync  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdowriteasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowriteasync", (RTS_UINTPTR)fusdowriteasync, 1, 0x9D2AC1AA, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdowriteasync
	#define EXT_fusdowriteasync
	#define GET_fusdowriteasync(fl)  CAL_CMGETAPI( "fusdowriteasync" ) 
	#define CAL_fusdowriteasync  fusdowriteasync
	#define CHK_fusdowriteasync  TRUE
	#define EXP_fusdowriteasync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowriteasync", (RTS_UINTPTR)fusdowriteasync, 1, 0x9D2AC1AA, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdowriteasync  PFFUSDOWRITEASYNC_IEC pffusdowriteasync;
	#define EXT_fusdowriteasync  extern PFFUSDOWRITEASYNC_IEC pffusdowriteasync;
	#define GET_fusdowriteasync(fl)  s_pfCMGetAPI2( "fusdowriteasync", (RTS_VOID_FCTPTR *)&pffusdowriteasync, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9D2AC1AA, 0x01000100)
	#define CAL_fusdowriteasync  pffusdowriteasync
	#define CHK_fusdowriteasync  (pffusdowriteasync != NULL)
	#define EXP_fusdowriteasync   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowriteasync", (RTS_UINTPTR)fusdowriteasync, 1, 0x9D2AC1AA, 0x01000100) 
#endif


/**
 * 
 *  write to CANopen process data and parameter data sdos
 *  Returns: 0 = OK  -1 = fail
 */
typedef struct tagfusdowritedata_struct
{
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* sdo index */
	RTS_IEC_UDINT udiSubindex;			/* VAR_INPUT */	/* sdo index */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* sdo bytes */
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* sdo data */
	RTS_IEC_DINT FuSdoWriteData;		/* VAR_OUTPUT */	
} fusdowritedata_struct;

void CDECL CDECL_EXT fusdowritedata(fusdowritedata_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOWRITEDATA_IEC) (fusdowritedata_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOWRITEDATA_NOTIMPLEMENTED)
	#define USE_fusdowritedata
	#define EXT_fusdowritedata
	#define GET_fusdowritedata(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdowritedata(p0) 
	#define CHK_fusdowritedata  FALSE
	#define EXP_fusdowritedata  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdowritedata
	#define EXT_fusdowritedata
	#define GET_fusdowritedata(fl)  CAL_CMGETAPI( "fusdowritedata" ) 
	#define CAL_fusdowritedata  fusdowritedata
	#define CHK_fusdowritedata  TRUE
	#define EXP_fusdowritedata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritedata", (RTS_UINTPTR)fusdowritedata, 1, 0xC661E226, 0x01000100) 
	#define EXTREF_ITF_fusdowritedata {(RTS_VOID_FCTPTR)fusdowritedata, "fusdowritedata", 0xC661E226, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdowritedata
	#define EXT_fusdowritedata
	#define GET_fusdowritedata(fl)  CAL_CMGETAPI( "fusdowritedata" ) 
	#define CAL_fusdowritedata  fusdowritedata
	#define CHK_fusdowritedata  TRUE
	#define EXP_fusdowritedata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritedata", (RTS_UINTPTR)fusdowritedata, 1, 0xC661E226, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdowritedata
	#define EXT_WagoSysCan_Internal_PFCfusdowritedata
	#define GET_WagoSysCan_Internal_PFCfusdowritedata  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdowritedata  fusdowritedata
	#define CHK_WagoSysCan_Internal_PFCfusdowritedata  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdowritedata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritedata", (RTS_UINTPTR)fusdowritedata, 1, 0xC661E226, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdowritedata
	#define EXT_fusdowritedata
	#define GET_fusdowritedata(fl)  CAL_CMGETAPI( "fusdowritedata" ) 
	#define CAL_fusdowritedata  fusdowritedata
	#define CHK_fusdowritedata  TRUE
	#define EXP_fusdowritedata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritedata", (RTS_UINTPTR)fusdowritedata, 1, 0xC661E226, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdowritedata  PFFUSDOWRITEDATA_IEC pffusdowritedata;
	#define EXT_fusdowritedata  extern PFFUSDOWRITEDATA_IEC pffusdowritedata;
	#define GET_fusdowritedata(fl)  s_pfCMGetAPI2( "fusdowritedata", (RTS_VOID_FCTPTR *)&pffusdowritedata, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC661E226, 0x01000100)
	#define CAL_fusdowritedata  pffusdowritedata
	#define CHK_fusdowritedata  (pffusdowritedata != NULL)
	#define EXP_fusdowritedata   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritedata", (RTS_UINTPTR)fusdowritedata, 1, 0xC661E226, 0x01000100) 
#endif


/**
 * 
 *  read CANopen SDOs with blocking process
 *  returns
 *	   0          // Call finished
 *	   < 0        // Error Codes from eCanFnReturn 
 *	   > 16#10000 // SDO abort code  
 */
typedef struct tagfusdowritesync_struct
{
	RTS_IEC_UDINT udiNodeId;			/* VAR_INPUT */	/* node id */
	RTS_IEC_UDINT udiIndex;				/* VAR_INPUT */	/* sdo index */
	RTS_IEC_UDINT udiSubindex;			/* VAR_INPUT */	/* sdo subindex */
	RTS_IEC_UDINT udiBytes;				/* VAR_INPUT */	/* sdo bytes */
	RTS_IEC_UDINT udiTimeout;			/* VAR_INPUT */	/* timeout in ms */
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* sdo data */
	RTS_IEC_DINT FuSdoWriteSync;		/* VAR_OUTPUT */	
} fusdowritesync_struct;

void CDECL CDECL_EXT fusdowritesync(fusdowritesync_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSDOWRITESYNC_IEC) (fusdowritesync_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSDOWRITESYNC_NOTIMPLEMENTED)
	#define USE_fusdowritesync
	#define EXT_fusdowritesync
	#define GET_fusdowritesync(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusdowritesync(p0) 
	#define CHK_fusdowritesync  FALSE
	#define EXP_fusdowritesync  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusdowritesync
	#define EXT_fusdowritesync
	#define GET_fusdowritesync(fl)  CAL_CMGETAPI( "fusdowritesync" ) 
	#define CAL_fusdowritesync  fusdowritesync
	#define CHK_fusdowritesync  TRUE
	#define EXP_fusdowritesync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritesync", (RTS_UINTPTR)fusdowritesync, 1, 0x1A10820B, 0x01000100) 
	#define EXTREF_ITF_fusdowritesync {(RTS_VOID_FCTPTR)fusdowritesync, "fusdowritesync", 0x1A10820B, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusdowritesync
	#define EXT_fusdowritesync
	#define GET_fusdowritesync(fl)  CAL_CMGETAPI( "fusdowritesync" ) 
	#define CAL_fusdowritesync  fusdowritesync
	#define CHK_fusdowritesync  TRUE
	#define EXP_fusdowritesync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritesync", (RTS_UINTPTR)fusdowritesync, 1, 0x1A10820B, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusdowritesync
	#define EXT_WagoSysCan_Internal_PFCfusdowritesync
	#define GET_WagoSysCan_Internal_PFCfusdowritesync  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusdowritesync  fusdowritesync
	#define CHK_WagoSysCan_Internal_PFCfusdowritesync  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusdowritesync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritesync", (RTS_UINTPTR)fusdowritesync, 1, 0x1A10820B, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusdowritesync
	#define EXT_fusdowritesync
	#define GET_fusdowritesync(fl)  CAL_CMGETAPI( "fusdowritesync" ) 
	#define CAL_fusdowritesync  fusdowritesync
	#define CHK_fusdowritesync  TRUE
	#define EXP_fusdowritesync  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritesync", (RTS_UINTPTR)fusdowritesync, 1, 0x1A10820B, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusdowritesync  PFFUSDOWRITESYNC_IEC pffusdowritesync;
	#define EXT_fusdowritesync  extern PFFUSDOWRITESYNC_IEC pffusdowritesync;
	#define GET_fusdowritesync(fl)  s_pfCMGetAPI2( "fusdowritesync", (RTS_VOID_FCTPTR *)&pffusdowritesync, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1A10820B, 0x01000100)
	#define CAL_fusdowritesync  pffusdowritesync
	#define CHK_fusdowritesync  (pffusdowritesync != NULL)
	#define EXP_fusdowritesync   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusdowritesync", (RTS_UINTPTR)fusdowritesync, 1, 0x1A10820B, 0x01000100) 
#endif


/**
 *
 *   send emc message 
 *   Returns: 0 = OK -1 = Error  -2 = inhibit time not expired 
 */
typedef struct tagfusendemcy_struct
{
	RTS_IEC_DWORD dwCode;				/* VAR_INPUT */	/* EMC error code */
	RTS_IEC_DWORD dwRegister;			/* VAR_INPUT */	/* register 1001 */
	RTS_IEC_BYTE aMfsCode[5];			/* VAR_INPUT */	/* manufacture spec. error field */
	RTS_IEC_DINT FuSendEmcy;			/* VAR_OUTPUT */	
} fusendemcy_struct;

void CDECL CDECL_EXT fusendemcy(fusendemcy_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSENDEMCY_IEC) (fusendemcy_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSENDEMCY_NOTIMPLEMENTED)
	#define USE_fusendemcy
	#define EXT_fusendemcy
	#define GET_fusendemcy(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusendemcy(p0) 
	#define CHK_fusendemcy  FALSE
	#define EXP_fusendemcy  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusendemcy
	#define EXT_fusendemcy
	#define GET_fusendemcy(fl)  CAL_CMGETAPI( "fusendemcy" ) 
	#define CAL_fusendemcy  fusendemcy
	#define CHK_fusendemcy  TRUE
	#define EXP_fusendemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendemcy", (RTS_UINTPTR)fusendemcy, 1, 0xA31BDF57, 0x01000100) 
	#define EXTREF_ITF_fusendemcy {(RTS_VOID_FCTPTR)fusendemcy, "fusendemcy", 0xA31BDF57, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusendemcy
	#define EXT_fusendemcy
	#define GET_fusendemcy(fl)  CAL_CMGETAPI( "fusendemcy" ) 
	#define CAL_fusendemcy  fusendemcy
	#define CHK_fusendemcy  TRUE
	#define EXP_fusendemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendemcy", (RTS_UINTPTR)fusendemcy, 1, 0xA31BDF57, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusendemcy
	#define EXT_WagoSysCan_Internal_PFCfusendemcy
	#define GET_WagoSysCan_Internal_PFCfusendemcy  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusendemcy  fusendemcy
	#define CHK_WagoSysCan_Internal_PFCfusendemcy  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusendemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendemcy", (RTS_UINTPTR)fusendemcy, 1, 0xA31BDF57, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusendemcy
	#define EXT_fusendemcy
	#define GET_fusendemcy(fl)  CAL_CMGETAPI( "fusendemcy" ) 
	#define CAL_fusendemcy  fusendemcy
	#define CHK_fusendemcy  TRUE
	#define EXP_fusendemcy  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendemcy", (RTS_UINTPTR)fusendemcy, 1, 0xA31BDF57, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusendemcy  PFFUSENDEMCY_IEC pffusendemcy;
	#define EXT_fusendemcy  extern PFFUSENDEMCY_IEC pffusendemcy;
	#define GET_fusendemcy(fl)  s_pfCMGetAPI2( "fusendemcy", (RTS_VOID_FCTPTR *)&pffusendemcy, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA31BDF57, 0x01000100)
	#define CAL_fusendemcy  pffusendemcy
	#define CHK_fusendemcy  (pffusendemcy != NULL)
	#define EXP_fusendemcy   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendemcy", (RTS_UINTPTR)fusendemcy, 1, 0xA31BDF57, 0x01000100) 
#endif


/**
 * 
 *  Send layer2 frame
 *  Returns: 0: OK -1: no active CAN device -5: bus 0ff or buffer full 
 */
typedef struct tagfusendframe_struct
{
	RTS_IEC_DWORD dwId;					/* VAR_INPUT */	/* CAN Id + 16#80000000 if 29Bit Adress */
	RTS_IEC_DWORD dwDlc;				/* VAR_INPUT */	/* CAN Dlc or 16#10 for RTR Call */
	RTS_IEC_UDINT udiTimeout;			/* VAR_INPUT */	/* timeout in ms (not used in layer2 device) */
	RTS_IEC_BYTE aMsg[8];				/* VAR_INPUT */	/* message */
	RTS_IEC_DINT FuSendFrame;			/* VAR_OUTPUT */	/* send layer 2 telegramm */
} fusendframe_struct;

void CDECL CDECL_EXT fusendframe(fusendframe_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSENDFRAME_IEC) (fusendframe_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSENDFRAME_NOTIMPLEMENTED)
	#define USE_fusendframe
	#define EXT_fusendframe
	#define GET_fusendframe(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusendframe(p0) 
	#define CHK_fusendframe  FALSE
	#define EXP_fusendframe  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusendframe
	#define EXT_fusendframe
	#define GET_fusendframe(fl)  CAL_CMGETAPI( "fusendframe" ) 
	#define CAL_fusendframe  fusendframe
	#define CHK_fusendframe  TRUE
	#define EXP_fusendframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendframe", (RTS_UINTPTR)fusendframe, 1, 0xEB340615, 0x01000100) 
	#define EXTREF_ITF_fusendframe {(RTS_VOID_FCTPTR)fusendframe, "fusendframe", 0xEB340615, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusendframe
	#define EXT_fusendframe
	#define GET_fusendframe(fl)  CAL_CMGETAPI( "fusendframe" ) 
	#define CAL_fusendframe  fusendframe
	#define CHK_fusendframe  TRUE
	#define EXP_fusendframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendframe", (RTS_UINTPTR)fusendframe, 1, 0xEB340615, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusendframe
	#define EXT_WagoSysCan_Internal_PFCfusendframe
	#define GET_WagoSysCan_Internal_PFCfusendframe  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusendframe  fusendframe
	#define CHK_WagoSysCan_Internal_PFCfusendframe  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusendframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendframe", (RTS_UINTPTR)fusendframe, 1, 0xEB340615, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusendframe
	#define EXT_fusendframe
	#define GET_fusendframe(fl)  CAL_CMGETAPI( "fusendframe" ) 
	#define CAL_fusendframe  fusendframe
	#define CHK_fusendframe  TRUE
	#define EXP_fusendframe  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendframe", (RTS_UINTPTR)fusendframe, 1, 0xEB340615, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusendframe  PFFUSENDFRAME_IEC pffusendframe;
	#define EXT_fusendframe  extern PFFUSENDFRAME_IEC pffusendframe;
	#define GET_fusendframe(fl)  s_pfCMGetAPI2( "fusendframe", (RTS_VOID_FCTPTR *)&pffusendframe, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xEB340615, 0x01000100)
	#define CAL_fusendframe  pffusendframe
	#define CHK_fusendframe  (pffusendframe != NULL)
	#define EXP_fusendframe   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendframe", (RTS_UINTPTR)fusendframe, 1, 0xEB340615, 0x01000100) 
#endif


/**
 *
 *  Send timestamp 
 *  wDay = 0 then system time is used
 *  Returns: 0 = OK  -1 = fail
 */
typedef struct tagfusendtimestamp_struct
{
	typCanTimestamp typTimestamp;		/* VAR_INPUT */	
	RTS_IEC_DINT FuSendTimestamp;		/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fusendtimestamp_struct;

void CDECL CDECL_EXT fusendtimestamp(fusendtimestamp_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSENDTIMESTAMP_IEC) (fusendtimestamp_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSENDTIMESTAMP_NOTIMPLEMENTED)
	#define USE_fusendtimestamp
	#define EXT_fusendtimestamp
	#define GET_fusendtimestamp(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusendtimestamp(p0) 
	#define CHK_fusendtimestamp  FALSE
	#define EXP_fusendtimestamp  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusendtimestamp
	#define EXT_fusendtimestamp
	#define GET_fusendtimestamp(fl)  CAL_CMGETAPI( "fusendtimestamp" ) 
	#define CAL_fusendtimestamp  fusendtimestamp
	#define CHK_fusendtimestamp  TRUE
	#define EXP_fusendtimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendtimestamp", (RTS_UINTPTR)fusendtimestamp, 1, 0xB662E864, 0x01000100) 
	#define EXTREF_ITF_fusendtimestamp {(RTS_VOID_FCTPTR)fusendtimestamp, "fusendtimestamp", 0xB662E864, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusendtimestamp
	#define EXT_fusendtimestamp
	#define GET_fusendtimestamp(fl)  CAL_CMGETAPI( "fusendtimestamp" ) 
	#define CAL_fusendtimestamp  fusendtimestamp
	#define CHK_fusendtimestamp  TRUE
	#define EXP_fusendtimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendtimestamp", (RTS_UINTPTR)fusendtimestamp, 1, 0xB662E864, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusendtimestamp
	#define EXT_WagoSysCan_Internal_PFCfusendtimestamp
	#define GET_WagoSysCan_Internal_PFCfusendtimestamp  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusendtimestamp  fusendtimestamp
	#define CHK_WagoSysCan_Internal_PFCfusendtimestamp  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusendtimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendtimestamp", (RTS_UINTPTR)fusendtimestamp, 1, 0xB662E864, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusendtimestamp
	#define EXT_fusendtimestamp
	#define GET_fusendtimestamp(fl)  CAL_CMGETAPI( "fusendtimestamp" ) 
	#define CAL_fusendtimestamp  fusendtimestamp
	#define CHK_fusendtimestamp  TRUE
	#define EXP_fusendtimestamp  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendtimestamp", (RTS_UINTPTR)fusendtimestamp, 1, 0xB662E864, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusendtimestamp  PFFUSENDTIMESTAMP_IEC pffusendtimestamp;
	#define EXT_fusendtimestamp  extern PFFUSENDTIMESTAMP_IEC pffusendtimestamp;
	#define GET_fusendtimestamp(fl)  s_pfCMGetAPI2( "fusendtimestamp", (RTS_VOID_FCTPTR *)&pffusendtimestamp, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB662E864, 0x01000100)
	#define CAL_fusendtimestamp  pffusendtimestamp
	#define CHK_fusendtimestamp  (pffusendtimestamp != NULL)
	#define EXP_fusendtimestamp   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusendtimestamp", (RTS_UINTPTR)fusendtimestamp, 1, 0xB662E864, 0x01000100) 
#endif


/**
 * 
 *   Set CAN LED
 *   Returns: 0 = OK  -1 = fail
 */
typedef struct tagfusetcanled_struct
{
	RTS_IEC_UDINT eMode;				/* VAR_INPUT, Enum: ECANLEDMODE */
	RTS_IEC_DINT FuSetCanLed;			/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fusetcanled_struct;

void CDECL CDECL_EXT fusetcanled(fusetcanled_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSETCANLED_IEC) (fusetcanled_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSETCANLED_NOTIMPLEMENTED)
	#define USE_fusetcanled
	#define EXT_fusetcanled
	#define GET_fusetcanled(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusetcanled(p0) 
	#define CHK_fusetcanled  FALSE
	#define EXP_fusetcanled  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusetcanled
	#define EXT_fusetcanled
	#define GET_fusetcanled(fl)  CAL_CMGETAPI( "fusetcanled" ) 
	#define CAL_fusetcanled  fusetcanled
	#define CHK_fusetcanled  TRUE
	#define EXP_fusetcanled  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetcanled", (RTS_UINTPTR)fusetcanled, 1, 0x5D91571F, 0x01000100) 
	#define EXTREF_ITF_fusetcanled {(RTS_VOID_FCTPTR)fusetcanled, "fusetcanled", 0x5D91571F, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusetcanled
	#define EXT_fusetcanled
	#define GET_fusetcanled(fl)  CAL_CMGETAPI( "fusetcanled" ) 
	#define CAL_fusetcanled  fusetcanled
	#define CHK_fusetcanled  TRUE
	#define EXP_fusetcanled  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetcanled", (RTS_UINTPTR)fusetcanled, 1, 0x5D91571F, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusetcanled
	#define EXT_WagoSysCan_Internal_PFCfusetcanled
	#define GET_WagoSysCan_Internal_PFCfusetcanled  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusetcanled  fusetcanled
	#define CHK_WagoSysCan_Internal_PFCfusetcanled  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusetcanled  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetcanled", (RTS_UINTPTR)fusetcanled, 1, 0x5D91571F, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusetcanled
	#define EXT_fusetcanled
	#define GET_fusetcanled(fl)  CAL_CMGETAPI( "fusetcanled" ) 
	#define CAL_fusetcanled  fusetcanled
	#define CHK_fusetcanled  TRUE
	#define EXP_fusetcanled  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetcanled", (RTS_UINTPTR)fusetcanled, 1, 0x5D91571F, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusetcanled  PFFUSETCANLED_IEC pffusetcanled;
	#define EXT_fusetcanled  extern PFFUSETCANLED_IEC pffusetcanled;
	#define GET_fusetcanled(fl)  s_pfCMGetAPI2( "fusetcanled", (RTS_VOID_FCTPTR *)&pffusetcanled, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5D91571F, 0x01000100)
	#define CAL_fusetcanled  pffusetcanled
	#define CHK_fusetcanled  (pffusetcanled != NULL)
	#define EXP_fusetcanled   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetcanled", (RTS_UINTPTR)fusetcanled, 1, 0x5D91571F, 0x01000100) 
#endif


/**
 *
 *    Set/Reset DeviceLock in CAN device info struct 
 *    Returns: 0 
 */
typedef struct tagfusetdeviceinfo_struct
{
	typCanDeviceInfo *typCanInfo;		/* VAR_IN_OUT */	
	RTS_IEC_DINT FuSetDeviceInfo;		/* VAR_OUTPUT, Enum: ECANFNRETURN */
} fusetdeviceinfo_struct;

void CDECL CDECL_EXT fusetdeviceinfo(fusetdeviceinfo_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSETDEVICEINFO_IEC) (fusetdeviceinfo_struct *p);
#if defined(WAGOSYSCAN_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSETDEVICEINFO_NOTIMPLEMENTED)
	#define USE_fusetdeviceinfo
	#define EXT_fusetdeviceinfo
	#define GET_fusetdeviceinfo(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusetdeviceinfo(p0) 
	#define CHK_fusetdeviceinfo  FALSE
	#define EXP_fusetdeviceinfo  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusetdeviceinfo
	#define EXT_fusetdeviceinfo
	#define GET_fusetdeviceinfo(fl)  CAL_CMGETAPI( "fusetdeviceinfo" ) 
	#define CAL_fusetdeviceinfo  fusetdeviceinfo
	#define CHK_fusetdeviceinfo  TRUE
	#define EXP_fusetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetdeviceinfo", (RTS_UINTPTR)fusetdeviceinfo, 1, 0x9E9948F7, 0x01000100) 
	#define EXTREF_ITF_fusetdeviceinfo {(RTS_VOID_FCTPTR)fusetdeviceinfo, "fusetdeviceinfo", 0x9E9948F7, 0x01000100}
#elif defined(MIXED_LINK) && !defined(WAGOSYSCAN_INTERNAL_PFC_EXTERNAL)
	#define USE_fusetdeviceinfo
	#define EXT_fusetdeviceinfo
	#define GET_fusetdeviceinfo(fl)  CAL_CMGETAPI( "fusetdeviceinfo" ) 
	#define CAL_fusetdeviceinfo  fusetdeviceinfo
	#define CHK_fusetdeviceinfo  TRUE
	#define EXP_fusetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetdeviceinfo", (RTS_UINTPTR)fusetdeviceinfo, 1, 0x9E9948F7, 0x01000100) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysCan_Internal_PFCfusetdeviceinfo
	#define EXT_WagoSysCan_Internal_PFCfusetdeviceinfo
	#define GET_WagoSysCan_Internal_PFCfusetdeviceinfo  ERR_OK
	#define CAL_WagoSysCan_Internal_PFCfusetdeviceinfo  fusetdeviceinfo
	#define CHK_WagoSysCan_Internal_PFCfusetdeviceinfo  TRUE
	#define EXP_WagoSysCan_Internal_PFCfusetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetdeviceinfo", (RTS_UINTPTR)fusetdeviceinfo, 1, 0x9E9948F7, 0x01000100) 
#elif defined(CPLUSPLUS)
	#define USE_fusetdeviceinfo
	#define EXT_fusetdeviceinfo
	#define GET_fusetdeviceinfo(fl)  CAL_CMGETAPI( "fusetdeviceinfo" ) 
	#define CAL_fusetdeviceinfo  fusetdeviceinfo
	#define CHK_fusetdeviceinfo  TRUE
	#define EXP_fusetdeviceinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetdeviceinfo", (RTS_UINTPTR)fusetdeviceinfo, 1, 0x9E9948F7, 0x01000100) 
#else /* DYNAMIC_LINK */
	#define USE_fusetdeviceinfo  PFFUSETDEVICEINFO_IEC pffusetdeviceinfo;
	#define EXT_fusetdeviceinfo  extern PFFUSETDEVICEINFO_IEC pffusetdeviceinfo;
	#define GET_fusetdeviceinfo(fl)  s_pfCMGetAPI2( "fusetdeviceinfo", (RTS_VOID_FCTPTR *)&pffusetdeviceinfo, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9E9948F7, 0x01000100)
	#define CAL_fusetdeviceinfo  pffusetdeviceinfo
	#define CHK_fusetdeviceinfo  (pffusetdeviceinfo != NULL)
	#define EXP_fusetdeviceinfo   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusetdeviceinfo", (RTS_UINTPTR)fusetdeviceinfo, 1, 0x9E9948F7, 0x01000100) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysCan_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysCan_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysCan_Internal_PFC
		#define ITF_WagoSysCan_Internal_PFC static IWagoSysCan_Internal_PFC *pIWagoSysCan_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysCan_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysCan_Internal_PFC_C		IWagoSysCan_Internal_PFC;
	#ifndef ITF_WagoSysCan_Internal_PFC
		#define ITF_WagoSysCan_Internal_PFC
	#endif
	#define EXTITF_WagoSysCan_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSCAN_INTERNAL_PFCITF_H_*/
