 /**
 * <interfacename>WagoTypesCan</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOTYPESCANITF_H_
#define _WAGOTYPESCANITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eCanDeviceError</description>
 */
#define ECANDEVICEERROR_CANDEVICEOK    0	/* standard return */
#define ECANDEVICEERROR_CANDEVICEISLOCKED    -1	/* device in in use */
#define ECANDEVICEERROR_CANDEVICEINVALIDMODE    -2	/* invalid operation mode requested */
#define ECANDEVICEERROR_CANDEVICEINVALIDPORT    -3	/* invalid operation port requested */
#define ECANDEVICEERROR_CANDEVICEINVALIDBAUDRATE    -4	/* invalid baudrate requested */
#define ECANDEVICEERROR_CANDEVICEINVALIDINTERFACE    -5	/* invalid interface or port requested */
#define ECANDEVICEERROR_CANDEVICENOTREADY    -6	/* device not ready */
/* Typed enum definition */
#define ECANDEVICEERROR    RTS_IEC_DINT

/**
 * <description>Enum: eCanFlagRegister</description>
 */
#define ECANFLAGREGISTER_CANCLEARID    0	/* same als FALSE */
#define ECANFLAGREGISTER_CANREGISTERID    1	/* same as TRUE */
/* Typed enum definition */
#define ECANFLAGREGISTER    RTS_IEC_UDINT

/**
 * <description>Enum: eCanFlagReset</description>
 */
#define ECANFLAGRESET_CANNORESET    0	/* same als FALSE */
#define ECANFLAGRESET_CANDORESET    1	/* same as TRUE */
/* Typed enum definition */
#define ECANFLAGRESET    RTS_IEC_UDINT

/**
 * <description>Enum: eCanFnReturn</description>
 */
#define ECANFNRETURN_CANFNWORKING    2	/* function is still working (no error) */
#define ECANFNRETURN_CANFNDATA    1	/* function has new data */
#define ECANFNRETURN_CANFNOK    0	/* standard return */
#define ECANFNRETURN_CANFNERROR    -1	/* unspecific error */
#define ECANFNRETURN_CANNOIDX    -2	/* no free index in register or no index in unregister */
#define ECANFNRETURN_CANTIMEOUT    -3	/* timeout on layer2 operation */
#define ECANFNRETURN_CANNODATA    -4	/* no data in read operation */
#define ECANFNRETURN_CANTXOVERFLOW    -5	/* data was not transmitted because tx overflow */
#define ECANFNRETURN_CANNOTREADY    -6	/* funktion not ready (error) */
#define ECANFNRETURN_CANSDOWAITING    -7	/* SDO call waiting */
#define ECANFNRETURN_CANSDOTIMEOUT    -8	/* SDO call timeout */
#define ECANFNRETURN_CANSDOERRORLEN    -9	/* Data array to small in SDO read */
/* Typed enum definition */
#define ECANFNRETURN    RTS_IEC_DINT

/**
 * <description>Enum: eCanInternalState</description>
 */
#define ECANINTERNALSTATE_CANSTATEINIT    0x0	/* no initialization */
#define ECANINTERNALSTATE_CANSTATERESETREQUEST    0x1	/* reset has been requested */
#define ECANINTERNALSTATE_CANSTATEBAUDRATETEST    0x4	/* baudrate test running */
#define ECANINTERNALSTATE_CANSTATEMASTERRESET    0x40	/* after successful initialization */
#define ECANINTERNALSTATE_CANSTATESLAVESTOPPED    0x41	/* slave mode: stopped */
#define ECANINTERNALSTATE_CANSTATESLAVEPREOP    0x42	/* slave mode: preoperational */
#define ECANINTERNALSTATE_CANSTATESLAVEOP    0x43	/* slave mode: operational */
#define ECANINTERNALSTATE_CANSTATEPRENETINIT    0x60	/* states of the configuration procedure */
#define ECANINTERNALSTATE_CANSTATENTWRESET    0x61	/* reset communication all nodes */
#define ECANINTERNALSTATE_CANSTATENTWWAIT    0x62	/* wait state */
#define ECANINTERNALSTATE_CANSTATEBOOTCONF    0x64	/* bootup configuration mode */
#define ECANINTERNALSTATE_CANSTATEBOOTMISSING    0x70	/* network has been scanned but there are missing mandatory nodes */
#define ECANINTERNALSTATE_CANSTATECLEAR    0x80	/* configuration matches */
#define ECANINTERNALSTATE_CANSTATEFATALERROR    0x90	/* serious configuration mismatch or bus off */
#define ECANINTERNALSTATE_CANSTATERUN    0xA0	/* network is set to operational */
#define ECANINTERNALSTATE_CANSTATESTOP    0xC0	/* network is set to stopped by request */
#define ECANINTERNALSTATE_CANSTATEPREOP    0xE0	/* network is set to preop. by request
 errorinfo bits if CanState > 16#80:
 bit 0 = 1: optional/unexpected node error
 bit 1 = 1: mandatory node error
 bit 2 = 1: at least one slave is operational
 bit 3 = 1: the CANopen Manager is operational
 internal status of CAN Layer2 stack 
 CanStateInit 		:= 16#00, // no initialization
 CanStateRun 			:= 16#A0, // network is operational
 CanStateFatalError 	:= 16#90, // bus off */
/* Typed enum definition */
#define ECANINTERNALSTATE    RTS_IEC_DWORD

/**
 * <description>Enum: eCanLedMode</description>
 */
#define ECANLEDMODE_LEDAUTO    0	/* handle LED by CANopen/CANLayer2 stack */
#define ECANLEDMODE_LEDOFF    1	/* unconfigured                   off */
#define ECANLEDMODE_LEDCONFIG    2	/* configuration running          red   50ms  - green 50ms */
#define ECANLEDMODE_LEDCONFIGERROR    3	/* configuration fault            red   200ms - green 200ms */
#define ECANLEDMODE_LEDSTOPPED    4	/* stopped / init OK              green 200ms - off   800ms */
#define ECANLEDMODE_LEDPREOP    5	/* preoperational / no error      green 200ms - off   200ms */
#define ECANLEDMODE_LEDPREOPERROR1    6	/* preopertional / warning level  1 * (red 200ms - off 200ms) - 2 * (green 200ms - off 200ms) */
#define ECANLEDMODE_LEDPREOPERROR2    7	/* preopertional / guard error    2 * (red 200ms - off 200ms) - 2 * (green 200ms - off 200ms) */
#define ECANLEDMODE_LEDPREOPERROR3    8	/* preopertional / sync error     3 * (red 200ms - off 200ms) - 2 * (green 200ms - off 200ms) */
#define ECANLEDMODE_LEDOPERATIONAL    9	/* operational / no error         green */
#define ECANLEDMODE_LEDOPERROR1    10	/* opertional / warning level     1 * (red 200ms - green 200ms) - green 800ms */
#define ECANLEDMODE_LEDOPERROR2    11	/* opertional / guard error       2 * (red 200ms - green 200ms) - green 800ms */
#define ECANLEDMODE_LEDOPERROR3    12	/* opertional / sync error        3 * (red 200ms - green 200ms) - green 800ms */
#define ECANLEDMODE_LEDERROR    13	/* bus off                        red */
#define ECANLEDMODE_LEDFATALERROR    14	/* fatal error                    red  200ms - off  200ms */
/* Typed enum definition */
#define ECANLEDMODE    RTS_IEC_UDINT

/**
 * <description>Enum: eCanMode</description>
 */
#define ECANMODE_NONE    0	/* CAN not used */
#define ECANMODE_CANMASTER    1	/* CANopen Master */
#define ECANMODE_CANSLAVE    2	/* CANopen Local Device (Slave) */
#define ECANMODE_CANLAYER2    3	/* CAN Layer2 Device */
#define ECANMODE_CANKBUSGATEWAY    4	/* CAN Gateway on KBus */
/* Typed enum definition */
#define ECANMODE    RTS_IEC_UDINT

/**
 * <description>Enum: eCanOpenState</description>
 */
#define ECANOPENSTATE_CANSTOPNODE    0x4	/* stop node */
#define ECANOPENSTATE_CANSTARTNODE    0x5	/* start node */
#define ECANOPENSTATE_CANRESETNODE    0x6	/* reset node */
#define ECANOPENSTATE_CANRESETCOM    0x7	/* reset communication */
#define ECANOPENSTATE_CANPREOP    0x7F	/* pre-operational */
/* Typed enum definition */
#define ECANOPENSTATE    RTS_IEC_DWORD

/**
 * <description>typCanBusInfo</description>
 */
typedef struct tagtypCanBusInfo
{
	RTS_IEC_WORD wInternalState;		/* eCanInternalState / internal status of CAN stack */
	RTS_IEC_WORD wBusDiag;		/* Bus diagnostic bits */
	RTS_IEC_UINT uiRxL2Overflows;		/* Rx CAN Layer2 overflow counter */
	RTS_IEC_UINT uiTxL2Overflows;		/* Tx CAN Layer2 overflow counter */
	RTS_IEC_UINT uiTxL2Timeouts;		/* Tx CAN Layer2 Timeout counter */
	RTS_IEC_UINT uiRxOverflows;		/* Rx overflow counter */
	RTS_IEC_UINT uiMsgTimeouts;		/* Msg Timeout counter */
	RTS_IEC_UINT uiBusOffs;		/* Bus off counter */
	RTS_IEC_UINT uiBusWarnings;		/* Bus warning counter */
	RTS_IEC_UINT uiBitErrors;		/* Bus bit error counter */
} typCanBusInfo;

/**
 * <description>typCanDeviceInfo</description>
 */
typedef struct tagtypCanDeviceInfo
{
	RTS_IEC_UINT udiDeviceLock;		/* device is in use */
	RTS_IEC_UINT udiDeviceMode;		/* eCanMode as UDINT */
	RTS_IEC_UINT udiInitMode;		/* 0:not initialised 1: init OK */
	RTS_IEC_UINT udiInterface;		/* interface used */
	RTS_IEC_UDINT udiBaudrate;		/* actual baudrate used */
	RTS_IEC_DWORD dwFlags;		/* extra flags i.e. mapped or transparent Mode */
	RTS_IEC_UDINT udiBusNr;		/* reserved for future use */
	RTS_IEC_DWORD dwiExtraInfo;		/* reserved for future use */
} typCanDeviceInfo;

/**
 * <description>typCanTimestamp</description>
 */
typedef struct tagtypCanTimestamp
{
	RTS_IEC_UDINT dwTime;		/* ms after midnight */
	RTS_IEC_UINT wDay;		/* days FROM 1.January 1984 */
	RTS_IEC_WORD wFlags;		/* number of received timestamp messages after last read */
} typCanTimestamp;

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoTypesCan_C;

#ifdef CPLUSPLUS
class IWagoTypesCan : public IBase
{
	public:
};
	#ifndef ITF_WagoTypesCan
		#define ITF_WagoTypesCan static IWagoTypesCan *pIWagoTypesCan = NULL;
	#endif
	#define EXTITF_WagoTypesCan
#else	/*CPLUSPLUS*/
	typedef IWagoTypesCan_C		IWagoTypesCan;
	#ifndef ITF_WagoTypesCan
		#define ITF_WagoTypesCan
	#endif
	#define EXTITF_WagoTypesCan
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOTYPESCANITF_H_*/
