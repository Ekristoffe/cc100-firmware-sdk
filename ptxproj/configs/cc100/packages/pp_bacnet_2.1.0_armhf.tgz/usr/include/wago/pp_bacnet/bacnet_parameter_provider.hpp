//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     bacnet_parameter_provider.hpp
///
///  \brief    Parameter Provider for BACnet configuration
///
///  \author   AHi : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_PP_BACNET_BACNET_PARAMETER_PROVIDER_HPP_
#define INCLUDE_WAGO_PP_BACNET_BACNET_PARAMETER_PROVIDER_HPP_

#include <wago/wdx/base_parameter_provider.hpp>
#include <wago/wdx/parameter_service_backend_i.hpp>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
namespace wago::wdx::linuxos::file {
class file_parameter_handler;
}

namespace wago::pp_bacnet
{
  using namespace wago;
  using namespace wago::wdx;

  class bacnet_parameter;
  class bacnet_file_provider;

  class bacnet_parameter_provider final : public base_parameter_provider
  {
    public:
      bacnet_parameter_provider();
      bacnet_parameter_provider(parameter_service_backend_i * backend);
      ~bacnet_parameter_provider() override;

      std::string display_name() override;

      parameter_selector_response get_provided_parameters() override;

      /// \copydoc ::wago::wdx::parameter_provider_i::get_parameter_values()
      future<std::vector<value_response>> get_parameter_values(
        std::vector<parameter_instance_id> const parameter_ids) override;

      /// \copydoc ::wago::wdx::parameter_provider_i::set_parameter_values()
      future<std::vector<set_parameter_response>> set_parameter_values(
        std::vector<value_request> const value_requests) override;

      /// \copydoc ::wago::wdx::parameter_provider_i::invoke_method()
      wago::future<wdx::method_invocation_response> invoke_method(
          wdx::parameter_instance_id method_id, std::vector<std::shared_ptr<wdx::parameter_value>> in_args) override;

      future<wdx::file_id_response> create_parameter_upload_id(
        wdx::parameter_id_t context) override;

      future<wdx::response> remove_parameter_upload_id(
        wdx::file_id id, wdx::parameter_id_t context) override;

    private:
      parameter_service_backend_i * _backend;
      std::unique_ptr<bacnet_parameter> _param;
      std::unique_ptr<wdx::linuxos::file::file_parameter_handler> _handler;
  };


}// namespace wago::pp_bacnet

#endif /* INCLUDE_WAGO_PP_BACNET_BACNET_PARAMETER_PROVIDER_HPP_ */
//---- End of source file ------------------------------------------------------

