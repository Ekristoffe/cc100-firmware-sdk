//----------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All manufacturing, reproduction, use and 
// sales rights pertaining to this subject matter are governed by the license agreement. The recipient of this software 
// implicitly accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
///---------------------------------------------------------------------------------------------------------------------
///  \file
///
///  \brief    Mock class for WAGO system library.
///
///  \author   LHe : WAGO GmbH & Co. KG
///---------------------------------------------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_SYSTEM_PROCESS_MOCK_HPP_
#define INCLUDE_WAGO_SYSTEM_PROCESS_MOCK_HPP_

#include <gmock/gmock.h>
#include <wago/system/process_i.hpp>

namespace wago
{
namespace system
{

class process_mock : public process_i
{

  public:
    MOCK_METHOD3(execute, int (const std::string& command, const std::vector<std::string>& args, std::string& result_text));
    MOCK_METHOD3(execute_multiline_output, int (const std::string& command, const std::vector<std::string>& args, std::string& result_text));
    MOCK_METHOD2(execute, int (const std::string& command, const std::vector<std::string>& args));
};

}
} // namespace wago

#endif // INCLUDE_WAGO_SYSTEM_PROCESS_MOCK_HPP_

