//----------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All manufacturing, reproduction, use and 
// sales rights pertaining to this subject matter are governed by the license agreement. The recipient of this software 
// implicitly accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
///---------------------------------------------------------------------------------------------------------------------
///  \file
///
///  \brief    A WAGO library that executes a system command with boost::child. This library includes an interface,
///            implementation and mock class.
///
///  \author   LHe : WAGO GmbH & Co. KG
///---------------------------------------------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_SYSTEM_PROCESS_I_HPP_
#define INCLUDE_WAGO_SYSTEM_PROCESS_I_HPP_

#include <string>
#include <vector>

namespace wago
{
namespace system
{

class process_i
{

public:

  virtual ~process_i() = default;

  /**
   * Calls given command with args as arguments. If command has a result text, you can find it in result_text.
   * Return code will be returned.
   * https://www.boost.org/doc/libs/1_64_0/doc/html/boost_process/tutorial.html
   * @param command Command to process. Better use absolute path.
   * @param args Arguments for command to execute.
   * @param result_text Output text of command, if any.
   * @return Returns integer from the exit code of given command.
   */
  virtual int execute(const std::string& command, const std::vector<std::string>& args, std::string& result_text) = 0;
  virtual int execute(const std::string& command, const std::vector<std::string>& args = {}) = 0;
  virtual int execute_multiline_output(const std::string& command, const std::vector<std::string>& args, std::string& result_text) = 0;
};

} // namespace system
} // namespace wago

#endif // INCLUDE_WAGO_SYSTEM_PROCESS_I_HPP_

