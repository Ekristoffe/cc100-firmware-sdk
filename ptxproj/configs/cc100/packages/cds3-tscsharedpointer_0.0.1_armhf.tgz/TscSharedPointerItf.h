 /**
 * <interfacename>TscSharedPointer</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCSHAREDPOINTERITF_H_
#define _TSCSHAREDPOINTERITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

typedef struct
{
    RTS_I32 refCount;
    void * instance;
    void (*freeFunction)(void *);
} SHAREDPOINTER_INSTANCY;

#ifdef __cplusplus
extern "C" {
#endif


SHAREDPOINTER_INSTANCY* CDECL TscSharedPointerNew(void *instance,void (*freeFunction)(void *),RTS_RESULT* result);
typedef SHAREDPOINTER_INSTANCY* (CDECL * PFTSCSHAREDPOINTERNEW) (void *instance,void (*freeFunction)(void *),RTS_RESULT* result);
#if defined(TSCSHAREDPOINTER_NOTIMPLEMENTED) || defined(TSCSHAREDPOINTERNEW_NOTIMPLEMENTED)
	#define USE_TscSharedPointerNew
	#define EXT_TscSharedPointerNew
	#define GET_TscSharedPointerNew(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscSharedPointerNew(p0,p1,p2)  (SHAREDPOINTER_INSTANCY*)ERR_NOTIMPLEMENTED
	#define CHK_TscSharedPointerNew  FALSE
	#define EXP_TscSharedPointerNew  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscSharedPointerNew
	#define EXT_TscSharedPointerNew
	#define GET_TscSharedPointerNew(fl)  CAL_CMGETAPI( "TscSharedPointerNew" ) 
	#define CAL_TscSharedPointerNew  TscSharedPointerNew
	#define CHK_TscSharedPointerNew  TRUE
	#define EXP_TscSharedPointerNew  CAL_CMEXPAPI( "TscSharedPointerNew" ) 
#elif defined(MIXED_LINK) && !defined(TSCSHAREDPOINTER_EXTERNAL)
	#define USE_TscSharedPointerNew
	#define EXT_TscSharedPointerNew
	#define GET_TscSharedPointerNew(fl)  CAL_CMGETAPI( "TscSharedPointerNew" ) 
	#define CAL_TscSharedPointerNew  TscSharedPointerNew
	#define CHK_TscSharedPointerNew  TRUE
	#define EXP_TscSharedPointerNew  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerNew", (RTS_UINTPTR)TscSharedPointerNew, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscSharedPointerTscSharedPointerNew
	#define EXT_TscSharedPointerTscSharedPointerNew
	#define GET_TscSharedPointerTscSharedPointerNew  ERR_OK
	#define CAL_TscSharedPointerTscSharedPointerNew pITscSharedPointer->ITscSharedPointerNew
	#define CHK_TscSharedPointerTscSharedPointerNew (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerTscSharedPointerNew  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscSharedPointerNew
	#define EXT_TscSharedPointerNew
	#define GET_TscSharedPointerNew(fl)  CAL_CMGETAPI( "TscSharedPointerNew" ) 
	#define CAL_TscSharedPointerNew pITscSharedPointer->ITscSharedPointerNew
	#define CHK_TscSharedPointerNew (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerNew  CAL_CMEXPAPI( "TscSharedPointerNew" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscSharedPointerNew  PFTSCSHAREDPOINTERNEW pfTscSharedPointerNew;
	#define EXT_TscSharedPointerNew  extern PFTSCSHAREDPOINTERNEW pfTscSharedPointerNew;
	#define GET_TscSharedPointerNew(fl)  s_pfCMGetAPI2( "TscSharedPointerNew", (RTS_VOID_FCTPTR *)&pfTscSharedPointerNew, (fl), 0, 0)
	#define CAL_TscSharedPointerNew  pfTscSharedPointerNew
	#define CHK_TscSharedPointerNew  (pfTscSharedPointerNew != NULL)
	#define EXP_TscSharedPointerNew  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerNew", (RTS_UINTPTR)TscSharedPointerNew, 0, 0) 
#endif



SHAREDPOINTER_INSTANCY* CDECL TscSharedPointerCopy(SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
typedef SHAREDPOINTER_INSTANCY* (CDECL * PFTSCSHAREDPOINTERCOPY) (SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
#if defined(TSCSHAREDPOINTER_NOTIMPLEMENTED) || defined(TSCSHAREDPOINTERCOPY_NOTIMPLEMENTED)
	#define USE_TscSharedPointerCopy
	#define EXT_TscSharedPointerCopy
	#define GET_TscSharedPointerCopy(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscSharedPointerCopy(p0,p1)  (SHAREDPOINTER_INSTANCY*)ERR_NOTIMPLEMENTED
	#define CHK_TscSharedPointerCopy  FALSE
	#define EXP_TscSharedPointerCopy  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscSharedPointerCopy
	#define EXT_TscSharedPointerCopy
	#define GET_TscSharedPointerCopy(fl)  CAL_CMGETAPI( "TscSharedPointerCopy" ) 
	#define CAL_TscSharedPointerCopy  TscSharedPointerCopy
	#define CHK_TscSharedPointerCopy  TRUE
	#define EXP_TscSharedPointerCopy  CAL_CMEXPAPI( "TscSharedPointerCopy" ) 
#elif defined(MIXED_LINK) && !defined(TSCSHAREDPOINTER_EXTERNAL)
	#define USE_TscSharedPointerCopy
	#define EXT_TscSharedPointerCopy
	#define GET_TscSharedPointerCopy(fl)  CAL_CMGETAPI( "TscSharedPointerCopy" ) 
	#define CAL_TscSharedPointerCopy  TscSharedPointerCopy
	#define CHK_TscSharedPointerCopy  TRUE
	#define EXP_TscSharedPointerCopy  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerCopy", (RTS_UINTPTR)TscSharedPointerCopy, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscSharedPointerTscSharedPointerCopy
	#define EXT_TscSharedPointerTscSharedPointerCopy
	#define GET_TscSharedPointerTscSharedPointerCopy  ERR_OK
	#define CAL_TscSharedPointerTscSharedPointerCopy pITscSharedPointer->ITscSharedPointerCopy
	#define CHK_TscSharedPointerTscSharedPointerCopy (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerTscSharedPointerCopy  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscSharedPointerCopy
	#define EXT_TscSharedPointerCopy
	#define GET_TscSharedPointerCopy(fl)  CAL_CMGETAPI( "TscSharedPointerCopy" ) 
	#define CAL_TscSharedPointerCopy pITscSharedPointer->ITscSharedPointerCopy
	#define CHK_TscSharedPointerCopy (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerCopy  CAL_CMEXPAPI( "TscSharedPointerCopy" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscSharedPointerCopy  PFTSCSHAREDPOINTERCOPY pfTscSharedPointerCopy;
	#define EXT_TscSharedPointerCopy  extern PFTSCSHAREDPOINTERCOPY pfTscSharedPointerCopy;
	#define GET_TscSharedPointerCopy(fl)  s_pfCMGetAPI2( "TscSharedPointerCopy", (RTS_VOID_FCTPTR *)&pfTscSharedPointerCopy, (fl), 0, 0)
	#define CAL_TscSharedPointerCopy  pfTscSharedPointerCopy
	#define CHK_TscSharedPointerCopy  (pfTscSharedPointerCopy != NULL)
	#define EXP_TscSharedPointerCopy  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerCopy", (RTS_UINTPTR)TscSharedPointerCopy, 0, 0) 
#endif



void * CDECL TscSharedPointerGetInstance(SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
typedef void * (CDECL * PFTSCSHAREDPOINTERGETINSTANCE) (SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
#if defined(TSCSHAREDPOINTER_NOTIMPLEMENTED) || defined(TSCSHAREDPOINTERGETINSTANCE_NOTIMPLEMENTED)
	#define USE_TscSharedPointerGetInstance
	#define EXT_TscSharedPointerGetInstance
	#define GET_TscSharedPointerGetInstance(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscSharedPointerGetInstance(p0,p1)  (void *)(RTS_SIZE)ERR_NOTIMPLEMENTED
	#define CHK_TscSharedPointerGetInstance  FALSE
	#define EXP_TscSharedPointerGetInstance  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscSharedPointerGetInstance
	#define EXT_TscSharedPointerGetInstance
	#define GET_TscSharedPointerGetInstance(fl)  CAL_CMGETAPI( "TscSharedPointerGetInstance" ) 
	#define CAL_TscSharedPointerGetInstance  TscSharedPointerGetInstance
	#define CHK_TscSharedPointerGetInstance  TRUE
	#define EXP_TscSharedPointerGetInstance  CAL_CMEXPAPI( "TscSharedPointerGetInstance" ) 
#elif defined(MIXED_LINK) && !defined(TSCSHAREDPOINTER_EXTERNAL)
	#define USE_TscSharedPointerGetInstance
	#define EXT_TscSharedPointerGetInstance
	#define GET_TscSharedPointerGetInstance(fl)  CAL_CMGETAPI( "TscSharedPointerGetInstance" ) 
	#define CAL_TscSharedPointerGetInstance  TscSharedPointerGetInstance
	#define CHK_TscSharedPointerGetInstance  TRUE
	#define EXP_TscSharedPointerGetInstance  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerGetInstance", (RTS_UINTPTR)TscSharedPointerGetInstance, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscSharedPointerTscSharedPointerGetInstance
	#define EXT_TscSharedPointerTscSharedPointerGetInstance
	#define GET_TscSharedPointerTscSharedPointerGetInstance  ERR_OK
	#define CAL_TscSharedPointerTscSharedPointerGetInstance pITscSharedPointer->ITscSharedPointerGetInstance
	#define CHK_TscSharedPointerTscSharedPointerGetInstance (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerTscSharedPointerGetInstance  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscSharedPointerGetInstance
	#define EXT_TscSharedPointerGetInstance
	#define GET_TscSharedPointerGetInstance(fl)  CAL_CMGETAPI( "TscSharedPointerGetInstance" ) 
	#define CAL_TscSharedPointerGetInstance pITscSharedPointer->ITscSharedPointerGetInstance
	#define CHK_TscSharedPointerGetInstance (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerGetInstance  CAL_CMEXPAPI( "TscSharedPointerGetInstance" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscSharedPointerGetInstance  PFTSCSHAREDPOINTERGETINSTANCE pfTscSharedPointerGetInstance;
	#define EXT_TscSharedPointerGetInstance  extern PFTSCSHAREDPOINTERGETINSTANCE pfTscSharedPointerGetInstance;
	#define GET_TscSharedPointerGetInstance(fl)  s_pfCMGetAPI2( "TscSharedPointerGetInstance", (RTS_VOID_FCTPTR *)&pfTscSharedPointerGetInstance, (fl), 0, 0)
	#define CAL_TscSharedPointerGetInstance  pfTscSharedPointerGetInstance
	#define CHK_TscSharedPointerGetInstance  (pfTscSharedPointerGetInstance != NULL)
	#define EXP_TscSharedPointerGetInstance  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerGetInstance", (RTS_UINTPTR)TscSharedPointerGetInstance, 0, 0) 
#endif



RTS_I32 CDECL TscSharedPointerGetRefCount(SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
typedef RTS_I32 (CDECL * PFTSCSHAREDPOINTERGETREFCOUNT) (SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
#if defined(TSCSHAREDPOINTER_NOTIMPLEMENTED) || defined(TSCSHAREDPOINTERGETREFCOUNT_NOTIMPLEMENTED)
	#define USE_TscSharedPointerGetRefCount
	#define EXT_TscSharedPointerGetRefCount
	#define GET_TscSharedPointerGetRefCount(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscSharedPointerGetRefCount(p0,p1)  (RTS_I32)ERR_NOTIMPLEMENTED
	#define CHK_TscSharedPointerGetRefCount  FALSE
	#define EXP_TscSharedPointerGetRefCount  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscSharedPointerGetRefCount
	#define EXT_TscSharedPointerGetRefCount
	#define GET_TscSharedPointerGetRefCount(fl)  CAL_CMGETAPI( "TscSharedPointerGetRefCount" ) 
	#define CAL_TscSharedPointerGetRefCount  TscSharedPointerGetRefCount
	#define CHK_TscSharedPointerGetRefCount  TRUE
	#define EXP_TscSharedPointerGetRefCount  CAL_CMEXPAPI( "TscSharedPointerGetRefCount" ) 
#elif defined(MIXED_LINK) && !defined(TSCSHAREDPOINTER_EXTERNAL)
	#define USE_TscSharedPointerGetRefCount
	#define EXT_TscSharedPointerGetRefCount
	#define GET_TscSharedPointerGetRefCount(fl)  CAL_CMGETAPI( "TscSharedPointerGetRefCount" ) 
	#define CAL_TscSharedPointerGetRefCount  TscSharedPointerGetRefCount
	#define CHK_TscSharedPointerGetRefCount  TRUE
	#define EXP_TscSharedPointerGetRefCount  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerGetRefCount", (RTS_UINTPTR)TscSharedPointerGetRefCount, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscSharedPointerTscSharedPointerGetRefCount
	#define EXT_TscSharedPointerTscSharedPointerGetRefCount
	#define GET_TscSharedPointerTscSharedPointerGetRefCount  ERR_OK
	#define CAL_TscSharedPointerTscSharedPointerGetRefCount pITscSharedPointer->ITscSharedPointerGetRefCount
	#define CHK_TscSharedPointerTscSharedPointerGetRefCount (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerTscSharedPointerGetRefCount  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscSharedPointerGetRefCount
	#define EXT_TscSharedPointerGetRefCount
	#define GET_TscSharedPointerGetRefCount(fl)  CAL_CMGETAPI( "TscSharedPointerGetRefCount" ) 
	#define CAL_TscSharedPointerGetRefCount pITscSharedPointer->ITscSharedPointerGetRefCount
	#define CHK_TscSharedPointerGetRefCount (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerGetRefCount  CAL_CMEXPAPI( "TscSharedPointerGetRefCount" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscSharedPointerGetRefCount  PFTSCSHAREDPOINTERGETREFCOUNT pfTscSharedPointerGetRefCount;
	#define EXT_TscSharedPointerGetRefCount  extern PFTSCSHAREDPOINTERGETREFCOUNT pfTscSharedPointerGetRefCount;
	#define GET_TscSharedPointerGetRefCount(fl)  s_pfCMGetAPI2( "TscSharedPointerGetRefCount", (RTS_VOID_FCTPTR *)&pfTscSharedPointerGetRefCount, (fl), 0, 0)
	#define CAL_TscSharedPointerGetRefCount  pfTscSharedPointerGetRefCount
	#define CHK_TscSharedPointerGetRefCount  (pfTscSharedPointerGetRefCount != NULL)
	#define EXP_TscSharedPointerGetRefCount  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerGetRefCount", (RTS_UINTPTR)TscSharedPointerGetRefCount, 0, 0) 
#endif



SHAREDPOINTER_INSTANCY* CDECL TscSharedPointerDeref(SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
typedef SHAREDPOINTER_INSTANCY* (CDECL * PFTSCSHAREDPOINTERDEREF) (SHAREDPOINTER_INSTANCY *pSp,RTS_RESULT* result);
#if defined(TSCSHAREDPOINTER_NOTIMPLEMENTED) || defined(TSCSHAREDPOINTERDEREF_NOTIMPLEMENTED)
	#define USE_TscSharedPointerDeref
	#define EXT_TscSharedPointerDeref
	#define GET_TscSharedPointerDeref(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscSharedPointerDeref(p0,p1)  (SHAREDPOINTER_INSTANCY*)ERR_NOTIMPLEMENTED
	#define CHK_TscSharedPointerDeref  FALSE
	#define EXP_TscSharedPointerDeref  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscSharedPointerDeref
	#define EXT_TscSharedPointerDeref
	#define GET_TscSharedPointerDeref(fl)  CAL_CMGETAPI( "TscSharedPointerDeref" ) 
	#define CAL_TscSharedPointerDeref  TscSharedPointerDeref
	#define CHK_TscSharedPointerDeref  TRUE
	#define EXP_TscSharedPointerDeref  CAL_CMEXPAPI( "TscSharedPointerDeref" ) 
#elif defined(MIXED_LINK) && !defined(TSCSHAREDPOINTER_EXTERNAL)
	#define USE_TscSharedPointerDeref
	#define EXT_TscSharedPointerDeref
	#define GET_TscSharedPointerDeref(fl)  CAL_CMGETAPI( "TscSharedPointerDeref" ) 
	#define CAL_TscSharedPointerDeref  TscSharedPointerDeref
	#define CHK_TscSharedPointerDeref  TRUE
	#define EXP_TscSharedPointerDeref  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerDeref", (RTS_UINTPTR)TscSharedPointerDeref, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscSharedPointerTscSharedPointerDeref
	#define EXT_TscSharedPointerTscSharedPointerDeref
	#define GET_TscSharedPointerTscSharedPointerDeref  ERR_OK
	#define CAL_TscSharedPointerTscSharedPointerDeref pITscSharedPointer->ITscSharedPointerDeref
	#define CHK_TscSharedPointerTscSharedPointerDeref (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerTscSharedPointerDeref  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscSharedPointerDeref
	#define EXT_TscSharedPointerDeref
	#define GET_TscSharedPointerDeref(fl)  CAL_CMGETAPI( "TscSharedPointerDeref" ) 
	#define CAL_TscSharedPointerDeref pITscSharedPointer->ITscSharedPointerDeref
	#define CHK_TscSharedPointerDeref (pITscSharedPointer != NULL)
	#define EXP_TscSharedPointerDeref  CAL_CMEXPAPI( "TscSharedPointerDeref" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscSharedPointerDeref  PFTSCSHAREDPOINTERDEREF pfTscSharedPointerDeref;
	#define EXT_TscSharedPointerDeref  extern PFTSCSHAREDPOINTERDEREF pfTscSharedPointerDeref;
	#define GET_TscSharedPointerDeref(fl)  s_pfCMGetAPI2( "TscSharedPointerDeref", (RTS_VOID_FCTPTR *)&pfTscSharedPointerDeref, (fl), 0, 0)
	#define CAL_TscSharedPointerDeref  pfTscSharedPointerDeref
	#define CHK_TscSharedPointerDeref  (pfTscSharedPointerDeref != NULL)
	#define EXP_TscSharedPointerDeref  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscSharedPointerDeref", (RTS_UINTPTR)TscSharedPointerDeref, 0, 0) 
#endif






#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/


typedef struct
{
	IBase_C *pBase;
	PFTSCSHAREDPOINTERNEW ITscSharedPointerNew;
 	PFTSCSHAREDPOINTERCOPY ITscSharedPointerCopy;
 	PFTSCSHAREDPOINTERGETINSTANCE ITscSharedPointerGetInstance;
 	PFTSCSHAREDPOINTERGETREFCOUNT ITscSharedPointerGetRefCount;
 	PFTSCSHAREDPOINTERDEREF ITscSharedPointerDeref;
 } ITscSharedPointer_C;

#ifdef CPLUSPLUS
class ITscSharedPointer : public IBase
{
	public:
		virtual SHAREDPOINTER_INSTANCY* CDECL ITscSharedPointerNew(void *instance, void (*freeFunction)(void *), RTS_RESULT* result) =0;
		virtual SHAREDPOINTER_INSTANCY* CDECL ITscSharedPointerCopy(SHAREDPOINTER_INSTANCY *pSp, RTS_RESULT* result) =0;
		virtual void * CDECL ITscSharedPointerGetInstance(SHAREDPOINTER_INSTANCY *pSp, RTS_RESULT* result) =0;
		virtual RTS_I32 CDECL ITscSharedPointerGetRefCount(SHAREDPOINTER_INSTANCY *pSp, RTS_RESULT* result) =0;
		virtual SHAREDPOINTER_INSTANCY* CDECL ITscSharedPointerDeref(SHAREDPOINTER_INSTANCY *pSp, RTS_RESULT* result) =0;
};
	#ifndef ITF_TscSharedPointer
		#define ITF_TscSharedPointer static ITscSharedPointer *pITscSharedPointer = NULL;
	#endif
	#define EXTITF_TscSharedPointer
#else	/*CPLUSPLUS*/
	typedef ITscSharedPointer_C		ITscSharedPointer;
	#ifndef ITF_TscSharedPointer
		#define ITF_TscSharedPointer
	#endif
	#define EXTITF_TscSharedPointer
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCSHAREDPOINTERITF_H_*/
