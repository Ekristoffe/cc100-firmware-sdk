/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component SysUtil</name>
 *  <description> 
 *  An example on how to implement a component.
 *  This component does no usefull work and it exports no functions
 *  which are intended to be used for anything. Use at your own risk.
 *  </description>
 *  <copyright>
 *  (c) 2010 elrest Automationssysteme GmbH
 *  </copyright>
 */
#ifndef _SYSUTILDEP_H_
#define _SYSUTILDEP_H_

#define COMPONENT_NAME "SysUtil" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_SysUtil)
#define COMPONENT_NAME_UNQUOTED SysUtil





#define CMP_VERSION         UINT32_C(0x00020010)
#define CMP_VERSION_STRING "0.2.0.16"
#define CMP_VERSION_RC      0,2,0,16
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"	


/* wago target defines for V3 components*/
#include <WagoSysdefines.h>

#define CMPID_SysUtil	SYSUTIL_CMPID
#define CLASSID_SysUtil	ADDVENDORID(CMP_VENDORID, SYSUTIL_CLASSID_C)
#define ITFID_SysUtil		ADDVENDORID(CMP_VENDORID, SYSUTIL_ITFID_C)

/* elrest LogInfo IDs defines */
//#include "Cst_LogInfoIds.h"
#include "CmpErrors.h"






/**
 * \file SysUtilItf.h
 */
#include "SysUtilItf.h"







#include "CMLockItf.h"


#include "SysTargetItf.h"


#include "CmpSettingsItf.h"


/*Obsolete include: CMUtilsItf.m4*/



        



     



     


        




      




      





#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        /*Obsolete include CMUtils*/ \
		  if (pICmpSettings == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSettings, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSettings = (ICmpSettings *)pIBase->QueryInterface(pIBase, ITFID_ICmpSettings, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTarget == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTarget, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTarget = (ISysTarget *)pIBase->QueryInterface(pIBase, ITFID_ISysTarget, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICMLock == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMLock, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMLock = (ICMLock *)pIBase->QueryInterface(pIBase, ITFID_ICMLock, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        /*Obsolete include CMUtils*/ \
		  pICmpSettings = NULL; \
          pISysTarget = NULL; \
          pICMLock = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        /*Obsolete include CMUtils*/ \
		  if (pICmpSettings != NULL) \
        { \
            pIBase = (IBase *)pICmpSettings->QueryInterface(pICmpSettings, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSettings = NULL; \
            } \
        } \
          if (pISysTarget != NULL) \
        { \
            pIBase = (IBase *)pISysTarget->QueryInterface(pISysTarget, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTarget = NULL; \
            } \
        } \
          if (pICMLock != NULL) \
        { \
            pIBase = (IBase *)pICMLock->QueryInterface(pICMLock, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMLock = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) TempResult = GET_LogDelete(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogUnregisterBackend(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogRegisterBackend(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogCreate(CM_IMPORT_OPTIONAL_FUNCTION);\
          /*Obsolete optional include LogAdd*/ \
		  if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetIntValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTargetGetVersion(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTargetGetId(0);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef SYSUTIL_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
                            
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef SYSUTIL_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                            
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(SYSUTIL_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
        { (RTS_VOID_FCTPTR)SysUtilConvUTF8ToString4, "SysUtilConvUTF8ToString4", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvUTF8ToString3, "SysUtilConvUTF8ToString3", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilCreateUUID, "SysUtilCreateUUID", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvStringToUTF83, "SysUtilConvStringToUTF83", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvStringToUTF82, "SysUtilConvStringToUTF82", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvStringToUTF8, "SysUtilConvStringToUTF8", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvUTF8ToString2, "SysUtilConvUTF8ToString2", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvUTF8ToString, "SysUtilConvUTF8ToString", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvUTF8ToWString, "SysUtilConvUTF8ToWString", 0, 0 },\
          { (RTS_VOID_FCTPTR)SysUtilConvWStringToUTF8, "SysUtilConvWStringToUTF8", 0, 0 },\
          \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CMLock     \
	ITF_SysTarget     \
	ITF_CmpSettings     \
	/*obsolete entry ITF_CMUtils*/       \
    USE_SysTargetGetId      \
    USE_SysTargetGetVersion      \
    USE_SettgGetIntValue      \
    USE_CMUtlSafeStrCpy      \
    /*obsolete USE_LogAdd*/      \
    USE_LogCreate      \
    USE_LogRegisterBackend      \
    USE_LogUnregisterBackend      \
    USE_LogDelete     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CMLock    \
	ITF_SysTarget    \
	ITF_CmpSettings    \
	/*obsolete entry ITF_CMUtils*/      \
    USE_SysTargetGetId      \
    USE_SysTargetGetVersion      \
    USE_SettgGetIntValue      \
    USE_CMUtlSafeStrCpy      \
    /*obsolete USE_LogAdd*/      \
    USE_LogCreate      \
    USE_LogRegisterBackend      \
    USE_LogUnregisterBackend      \
    USE_LogDelete     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CMLock    \
	EXTITF_SysTarget    \
	EXTITF_CmpSettings    \
	/*obsolete entry EXTITF_CMUtils*/      \
    EXT_SysTargetGetId  \
    EXT_SysTargetGetVersion  \
    EXT_SettgGetIntValue  \
    EXT_CMUtlSafeStrCpy  \
    /*obsolete EXT_LogAdd*/  \
    EXT_LogCreate  \
    EXT_LogRegisterBackend  \
    EXT_LogUnregisterBackend  \
    EXT_LogDelete 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry SysUtil__Entry
#endif


#ifdef CPLUSPLUS

class CSysUtil : public ISysUtil 
{
    public:
        CSysUtil() : hSysUtil(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CSysUtil()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ISysUtil *)this);            
            else if (iid == ITFID_ISysUtil)
                pItf = dynamic_cast<ISysUtil *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }
        virtual RTS_IEC_RESULT CDECL ISysUtilConvWStringToUTF8(RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
        virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToWString(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_INT* pBytesWritten );
        virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
        virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString2(RTS_IEC_STRING* lpMultiByteStr);
        virtual RTS_IEC_RESULT CDECL ISysUtilConvStringToUTF8(const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
        virtual RTS_IEC_RESULT CDECL ISysUtilConvStringToUTF82(RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
        virtual RTS_IEC_RESULT CDECL ISysUtilConvStringToUTF83(const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
        virtual RTS_IEC_RESULT CDECL ISysUtilCreateUUID(RTS_IEC_STRING* sUUID, RTS_IEC_DWORD* pSize);
        virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString3(RTS_IEC_STRING* lpMultiByteStr);
        virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString4(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );

    public:
        RTS_HANDLE hSysUtil;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
