 /**
 * <interfacename>WagoSysDALI_Internal_CC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSDALI_INTERNAL_CCITF_H_
#define _WAGOSYSDALI_INTERNAL_CCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>
 * {attribute 'conditionalshow'}
 * {attribute 'conditionalshow' := 'SomeText'}
 * {attribute 'hide'}
 * </description>
 * <element name="ERROR_NO_ERROR" type=OUT></element>
 * <element name="ERROR_TIME_OUT" type=OUT></element>
*/
#define ERROR_NO_ERROR    RTS_IEC_INT_C(0x0)
#define ERROR_TIME_OUT    RTS_IEC_INT_C(0x1)
/* Typed enum definition */
#define ERROR    RTS_IEC_INT

/**
 * <description>fbdali_external__main</description>
 */
typedef struct tagfbdali_external_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of FbDali_external */

} fbdali_external_struct;

/**
 * <description>fbdali_external_mbxisready</description>
 */
typedef struct tagfbdali_external_mbxisready_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL MbxIsReady;			/* VAR_OUTPUT */	
} fbdali_external_mbxisready_struct;

void CDECL CDECL_EXT fbdali_external__mbxisready(fbdali_external_mbxisready_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__MBXISREADY_IEC) (fbdali_external_mbxisready_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__MBXISREADY_NOTIMPLEMENTED)
	#define USE_fbdali_external__mbxisready
	#define EXT_fbdali_external__mbxisready
	#define GET_fbdali_external__mbxisready(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__mbxisready(p0) 
	#define CHK_fbdali_external__mbxisready  FALSE
	#define EXP_fbdali_external__mbxisready  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__mbxisready
	#define EXT_fbdali_external__mbxisready
	#define GET_fbdali_external__mbxisready(fl)  CAL_CMGETAPI( "fbdali_external__mbxisready" ) 
	#define CAL_fbdali_external__mbxisready  fbdali_external__mbxisready
	#define CHK_fbdali_external__mbxisready  TRUE
	#define EXP_fbdali_external__mbxisready  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxisready", (RTS_UINTPTR)fbdali_external__mbxisready, 1, 0xB89BBA4A, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__mbxisready {(RTS_VOID_FCTPTR)fbdali_external__mbxisready, "fbdali_external__mbxisready", 0xB89BBA4A, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__mbxisready
	#define EXT_fbdali_external__mbxisready
	#define GET_fbdali_external__mbxisready(fl)  CAL_CMGETAPI( "fbdali_external__mbxisready" ) 
	#define CAL_fbdali_external__mbxisready  fbdali_external__mbxisready
	#define CHK_fbdali_external__mbxisready  TRUE
	#define EXP_fbdali_external__mbxisready  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxisready", (RTS_UINTPTR)fbdali_external__mbxisready, 1, 0xB89BBA4A, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__mbxisready
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__mbxisready
	#define GET_WagoSysDALI_Internal_CCfbdali_external__mbxisready  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__mbxisready  fbdali_external__mbxisready
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__mbxisready  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__mbxisready  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxisready", (RTS_UINTPTR)fbdali_external__mbxisready, 1, 0xB89BBA4A, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__mbxisready
	#define EXT_fbdali_external__mbxisready
	#define GET_fbdali_external__mbxisready(fl)  CAL_CMGETAPI( "fbdali_external__mbxisready" ) 
	#define CAL_fbdali_external__mbxisready  fbdali_external__mbxisready
	#define CHK_fbdali_external__mbxisready  TRUE
	#define EXP_fbdali_external__mbxisready  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxisready", (RTS_UINTPTR)fbdali_external__mbxisready, 1, 0xB89BBA4A, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__mbxisready  PFFBDALI_EXTERNAL__MBXISREADY_IEC pffbdali_external__mbxisready;
	#define EXT_fbdali_external__mbxisready  extern PFFBDALI_EXTERNAL__MBXISREADY_IEC pffbdali_external__mbxisready;
	#define GET_fbdali_external__mbxisready(fl)  s_pfCMGetAPI2( "fbdali_external__mbxisready", (RTS_VOID_FCTPTR *)&pffbdali_external__mbxisready, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB89BBA4A, 0x00000001)
	#define CAL_fbdali_external__mbxisready  pffbdali_external__mbxisready
	#define CHK_fbdali_external__mbxisready  (pffbdali_external__mbxisready != NULL)
	#define EXP_fbdali_external__mbxisready   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxisready", (RTS_UINTPTR)fbdali_external__mbxisready, 1, 0xB89BBA4A, 0x00000001) 
#endif


/**
 * <description>fbdali_external_readregister</description>
 */
typedef struct tagfbdali_external_readregister_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BYTE *cliCallerID;			/* VAR_INPUT */	/* Unique identifier of the caller */
	RTS_IEC_USINT usiChannel;			/* VAR_INPUT */	/* (0..7); the implicit value range check is not available for external methods */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* (0..63); the implicit value range check is not available for external methods */
	RTS_IEC_UINT *uiValue;				/* VAR_IN_OUT */	
	RTS_IEC_INT ReadRegister;			/* VAR_OUTPUT, Enum: ESERVICESTATE */
} fbdali_external_readregister_struct;

void CDECL CDECL_EXT fbdali_external__readregister(fbdali_external_readregister_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__READREGISTER_IEC) (fbdali_external_readregister_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__READREGISTER_NOTIMPLEMENTED)
	#define USE_fbdali_external__readregister
	#define EXT_fbdali_external__readregister
	#define GET_fbdali_external__readregister(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__readregister(p0) 
	#define CHK_fbdali_external__readregister  FALSE
	#define EXP_fbdali_external__readregister  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__readregister
	#define EXT_fbdali_external__readregister
	#define GET_fbdali_external__readregister(fl)  CAL_CMGETAPI( "fbdali_external__readregister" ) 
	#define CAL_fbdali_external__readregister  fbdali_external__readregister
	#define CHK_fbdali_external__readregister  TRUE
	#define EXP_fbdali_external__readregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__readregister", (RTS_UINTPTR)fbdali_external__readregister, 1, 0x78DFA120, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__readregister {(RTS_VOID_FCTPTR)fbdali_external__readregister, "fbdali_external__readregister", 0x78DFA120, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__readregister
	#define EXT_fbdali_external__readregister
	#define GET_fbdali_external__readregister(fl)  CAL_CMGETAPI( "fbdali_external__readregister" ) 
	#define CAL_fbdali_external__readregister  fbdali_external__readregister
	#define CHK_fbdali_external__readregister  TRUE
	#define EXP_fbdali_external__readregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__readregister", (RTS_UINTPTR)fbdali_external__readregister, 1, 0x78DFA120, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__readregister
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__readregister
	#define GET_WagoSysDALI_Internal_CCfbdali_external__readregister  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__readregister  fbdali_external__readregister
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__readregister  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__readregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__readregister", (RTS_UINTPTR)fbdali_external__readregister, 1, 0x78DFA120, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__readregister
	#define EXT_fbdali_external__readregister
	#define GET_fbdali_external__readregister(fl)  CAL_CMGETAPI( "fbdali_external__readregister" ) 
	#define CAL_fbdali_external__readregister  fbdali_external__readregister
	#define CHK_fbdali_external__readregister  TRUE
	#define EXP_fbdali_external__readregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__readregister", (RTS_UINTPTR)fbdali_external__readregister, 1, 0x78DFA120, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__readregister  PFFBDALI_EXTERNAL__READREGISTER_IEC pffbdali_external__readregister;
	#define EXT_fbdali_external__readregister  extern PFFBDALI_EXTERNAL__READREGISTER_IEC pffbdali_external__readregister;
	#define GET_fbdali_external__readregister(fl)  s_pfCMGetAPI2( "fbdali_external__readregister", (RTS_VOID_FCTPTR *)&pffbdali_external__readregister, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x78DFA120, 0x00000001)
	#define CAL_fbdali_external__readregister  pffbdali_external__readregister
	#define CHK_fbdali_external__readregister  (pffbdali_external__readregister != NULL)
	#define EXP_fbdali_external__readregister   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__readregister", (RTS_UINTPTR)fbdali_external__readregister, 1, 0x78DFA120, 0x00000001) 
#endif


/**
 * <description>fbdali_external_writeregister</description>
 */
typedef struct tagfbdali_external_writeregister_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BYTE *cliCallerID;			/* VAR_INPUT */	/* Unique identifier of the caller */
	RTS_IEC_USINT usiChannel;			/* VAR_INPUT */	/* (0..7); the implicit value range check is not available for external methods */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* (0..63); the implicit value range check is not available for external methods */
	RTS_IEC_UINT uiValue;				/* VAR_INPUT */	
	RTS_IEC_INT WriteRegister;			/* VAR_OUTPUT, Enum: ESERVICESTATE */
} fbdali_external_writeregister_struct;

void CDECL CDECL_EXT fbdali_external__writeregister(fbdali_external_writeregister_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__WRITEREGISTER_IEC) (fbdali_external_writeregister_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__WRITEREGISTER_NOTIMPLEMENTED)
	#define USE_fbdali_external__writeregister
	#define EXT_fbdali_external__writeregister
	#define GET_fbdali_external__writeregister(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__writeregister(p0) 
	#define CHK_fbdali_external__writeregister  FALSE
	#define EXP_fbdali_external__writeregister  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__writeregister
	#define EXT_fbdali_external__writeregister
	#define GET_fbdali_external__writeregister(fl)  CAL_CMGETAPI( "fbdali_external__writeregister" ) 
	#define CAL_fbdali_external__writeregister  fbdali_external__writeregister
	#define CHK_fbdali_external__writeregister  TRUE
	#define EXP_fbdali_external__writeregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__writeregister", (RTS_UINTPTR)fbdali_external__writeregister, 1, 0x59F56B7E, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__writeregister {(RTS_VOID_FCTPTR)fbdali_external__writeregister, "fbdali_external__writeregister", 0x59F56B7E, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__writeregister
	#define EXT_fbdali_external__writeregister
	#define GET_fbdali_external__writeregister(fl)  CAL_CMGETAPI( "fbdali_external__writeregister" ) 
	#define CAL_fbdali_external__writeregister  fbdali_external__writeregister
	#define CHK_fbdali_external__writeregister  TRUE
	#define EXP_fbdali_external__writeregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__writeregister", (RTS_UINTPTR)fbdali_external__writeregister, 1, 0x59F56B7E, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__writeregister
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__writeregister
	#define GET_WagoSysDALI_Internal_CCfbdali_external__writeregister  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__writeregister  fbdali_external__writeregister
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__writeregister  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__writeregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__writeregister", (RTS_UINTPTR)fbdali_external__writeregister, 1, 0x59F56B7E, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__writeregister
	#define EXT_fbdali_external__writeregister
	#define GET_fbdali_external__writeregister(fl)  CAL_CMGETAPI( "fbdali_external__writeregister" ) 
	#define CAL_fbdali_external__writeregister  fbdali_external__writeregister
	#define CHK_fbdali_external__writeregister  TRUE
	#define EXP_fbdali_external__writeregister  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__writeregister", (RTS_UINTPTR)fbdali_external__writeregister, 1, 0x59F56B7E, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__writeregister  PFFBDALI_EXTERNAL__WRITEREGISTER_IEC pffbdali_external__writeregister;
	#define EXT_fbdali_external__writeregister  extern PFFBDALI_EXTERNAL__WRITEREGISTER_IEC pffbdali_external__writeregister;
	#define GET_fbdali_external__writeregister(fl)  s_pfCMGetAPI2( "fbdali_external__writeregister", (RTS_VOID_FCTPTR *)&pffbdali_external__writeregister, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x59F56B7E, 0x00000001)
	#define CAL_fbdali_external__writeregister  pffbdali_external__writeregister
	#define CHK_fbdali_external__writeregister  (pffbdali_external__writeregister != NULL)
	#define EXP_fbdali_external__writeregister   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__writeregister", (RTS_UINTPTR)fbdali_external__writeregister, 1, 0x59F56B7E, 0x00000001) 
#endif


/**
 * <description>fbdali_external_mbxreset</description>
 */
typedef struct tagfbdali_external_mbxreset_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
} fbdali_external_mbxreset_struct;

void CDECL CDECL_EXT fbdali_external__mbxreset(fbdali_external_mbxreset_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__MBXRESET_IEC) (fbdali_external_mbxreset_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__MBXRESET_NOTIMPLEMENTED)
	#define USE_fbdali_external__mbxreset
	#define EXT_fbdali_external__mbxreset
	#define GET_fbdali_external__mbxreset(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__mbxreset(p0) 
	#define CHK_fbdali_external__mbxreset  FALSE
	#define EXP_fbdali_external__mbxreset  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__mbxreset
	#define EXT_fbdali_external__mbxreset
	#define GET_fbdali_external__mbxreset(fl)  CAL_CMGETAPI( "fbdali_external__mbxreset" ) 
	#define CAL_fbdali_external__mbxreset  fbdali_external__mbxreset
	#define CHK_fbdali_external__mbxreset  TRUE
	#define EXP_fbdali_external__mbxreset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxreset", (RTS_UINTPTR)fbdali_external__mbxreset, 1, 0xA8C3970F, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__mbxreset {(RTS_VOID_FCTPTR)fbdali_external__mbxreset, "fbdali_external__mbxreset", 0xA8C3970F, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__mbxreset
	#define EXT_fbdali_external__mbxreset
	#define GET_fbdali_external__mbxreset(fl)  CAL_CMGETAPI( "fbdali_external__mbxreset" ) 
	#define CAL_fbdali_external__mbxreset  fbdali_external__mbxreset
	#define CHK_fbdali_external__mbxreset  TRUE
	#define EXP_fbdali_external__mbxreset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxreset", (RTS_UINTPTR)fbdali_external__mbxreset, 1, 0xA8C3970F, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__mbxreset
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__mbxreset
	#define GET_WagoSysDALI_Internal_CCfbdali_external__mbxreset  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__mbxreset  fbdali_external__mbxreset
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__mbxreset  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__mbxreset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxreset", (RTS_UINTPTR)fbdali_external__mbxreset, 1, 0xA8C3970F, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__mbxreset
	#define EXT_fbdali_external__mbxreset
	#define GET_fbdali_external__mbxreset(fl)  CAL_CMGETAPI( "fbdali_external__mbxreset" ) 
	#define CAL_fbdali_external__mbxreset  fbdali_external__mbxreset
	#define CHK_fbdali_external__mbxreset  TRUE
	#define EXP_fbdali_external__mbxreset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxreset", (RTS_UINTPTR)fbdali_external__mbxreset, 1, 0xA8C3970F, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__mbxreset  PFFBDALI_EXTERNAL__MBXRESET_IEC pffbdali_external__mbxreset;
	#define EXT_fbdali_external__mbxreset  extern PFFBDALI_EXTERNAL__MBXRESET_IEC pffbdali_external__mbxreset;
	#define GET_fbdali_external__mbxreset(fl)  s_pfCMGetAPI2( "fbdali_external__mbxreset", (RTS_VOID_FCTPTR *)&pffbdali_external__mbxreset, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA8C3970F, 0x00000001)
	#define CAL_fbdali_external__mbxreset  pffbdali_external__mbxreset
	#define CHK_fbdali_external__mbxreset  (pffbdali_external__mbxreset != NULL)
	#define EXP_fbdali_external__mbxreset   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxreset", (RTS_UINTPTR)fbdali_external__mbxreset, 1, 0xA8C3970F, 0x00000001) 
#endif


/**
 *
 *
 *Write a chunk of data into the FiFo to MBX.
 *
 *If there is too less space in the FIFO the write fails completely without partial writing.
 *	
 *=============  ====================================================================================== 
 ***result codes**
 *----------------------------------------------------------------------------------------------------- 
 *OK  (0)        success
 *FULL           not enough buffer space available for new data.
 *PRM_INVALID    null-pointer or size <2 or size >2G        
 *NOT_READY      MBX is not ready for communication
 *=============  ====================================================================================== 
 *
 */
typedef struct tagfbdali_external_mbxwrite_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BYTE *pData;				/* VAR_INPUT */	/* source of the data */
	RTS_IEC_UDINT udiNdata;				/* VAR_INPUT */	/* how many bytes to write */
	RTS_IEC_UINT MbxWrite;				/* VAR_OUTPUT, Enum: EERRORMBX2 */
} fbdali_external_mbxwrite_struct;

void CDECL CDECL_EXT fbdali_external__mbxwrite(fbdali_external_mbxwrite_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__MBXWRITE_IEC) (fbdali_external_mbxwrite_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__MBXWRITE_NOTIMPLEMENTED)
	#define USE_fbdali_external__mbxwrite
	#define EXT_fbdali_external__mbxwrite
	#define GET_fbdali_external__mbxwrite(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__mbxwrite(p0) 
	#define CHK_fbdali_external__mbxwrite  FALSE
	#define EXP_fbdali_external__mbxwrite  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__mbxwrite
	#define EXT_fbdali_external__mbxwrite
	#define GET_fbdali_external__mbxwrite(fl)  CAL_CMGETAPI( "fbdali_external__mbxwrite" ) 
	#define CAL_fbdali_external__mbxwrite  fbdali_external__mbxwrite
	#define CHK_fbdali_external__mbxwrite  TRUE
	#define EXP_fbdali_external__mbxwrite  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxwrite", (RTS_UINTPTR)fbdali_external__mbxwrite, 1, 0xCF3C1FCD, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__mbxwrite {(RTS_VOID_FCTPTR)fbdali_external__mbxwrite, "fbdali_external__mbxwrite", 0xCF3C1FCD, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__mbxwrite
	#define EXT_fbdali_external__mbxwrite
	#define GET_fbdali_external__mbxwrite(fl)  CAL_CMGETAPI( "fbdali_external__mbxwrite" ) 
	#define CAL_fbdali_external__mbxwrite  fbdali_external__mbxwrite
	#define CHK_fbdali_external__mbxwrite  TRUE
	#define EXP_fbdali_external__mbxwrite  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxwrite", (RTS_UINTPTR)fbdali_external__mbxwrite, 1, 0xCF3C1FCD, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__mbxwrite
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__mbxwrite
	#define GET_WagoSysDALI_Internal_CCfbdali_external__mbxwrite  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__mbxwrite  fbdali_external__mbxwrite
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__mbxwrite  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__mbxwrite  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxwrite", (RTS_UINTPTR)fbdali_external__mbxwrite, 1, 0xCF3C1FCD, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__mbxwrite
	#define EXT_fbdali_external__mbxwrite
	#define GET_fbdali_external__mbxwrite(fl)  CAL_CMGETAPI( "fbdali_external__mbxwrite" ) 
	#define CAL_fbdali_external__mbxwrite  fbdali_external__mbxwrite
	#define CHK_fbdali_external__mbxwrite  TRUE
	#define EXP_fbdali_external__mbxwrite  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxwrite", (RTS_UINTPTR)fbdali_external__mbxwrite, 1, 0xCF3C1FCD, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__mbxwrite  PFFBDALI_EXTERNAL__MBXWRITE_IEC pffbdali_external__mbxwrite;
	#define EXT_fbdali_external__mbxwrite  extern PFFBDALI_EXTERNAL__MBXWRITE_IEC pffbdali_external__mbxwrite;
	#define GET_fbdali_external__mbxwrite(fl)  s_pfCMGetAPI2( "fbdali_external__mbxwrite", (RTS_VOID_FCTPTR *)&pffbdali_external__mbxwrite, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCF3C1FCD, 0x00000001)
	#define CAL_fbdali_external__mbxwrite  pffbdali_external__mbxwrite
	#define CHK_fbdali_external__mbxwrite  (pffbdali_external__mbxwrite != NULL)
	#define EXP_fbdali_external__mbxwrite   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxwrite", (RTS_UINTPTR)fbdali_external__mbxwrite, 1, 0xCF3C1FCD, 0x00000001) 
#endif


/**
 *
 *	returns TRUE if another message is available
 */
typedef struct tagfbdali_external_ismessageavailable_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL IsMessageAvailable;	/* VAR_OUTPUT */	
} fbdali_external_ismessageavailable_struct;

void CDECL CDECL_EXT fbdali_external__ismessageavailable(fbdali_external_ismessageavailable_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__ISMESSAGEAVAILABLE_IEC) (fbdali_external_ismessageavailable_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__ISMESSAGEAVAILABLE_NOTIMPLEMENTED)
	#define USE_fbdali_external__ismessageavailable
	#define EXT_fbdali_external__ismessageavailable
	#define GET_fbdali_external__ismessageavailable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__ismessageavailable(p0) 
	#define CHK_fbdali_external__ismessageavailable  FALSE
	#define EXP_fbdali_external__ismessageavailable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__ismessageavailable
	#define EXT_fbdali_external__ismessageavailable
	#define GET_fbdali_external__ismessageavailable(fl)  CAL_CMGETAPI( "fbdali_external__ismessageavailable" ) 
	#define CAL_fbdali_external__ismessageavailable  fbdali_external__ismessageavailable
	#define CHK_fbdali_external__ismessageavailable  TRUE
	#define EXP_fbdali_external__ismessageavailable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__ismessageavailable", (RTS_UINTPTR)fbdali_external__ismessageavailable, 1, 0x837500EB, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__ismessageavailable {(RTS_VOID_FCTPTR)fbdali_external__ismessageavailable, "fbdali_external__ismessageavailable", 0x837500EB, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__ismessageavailable
	#define EXT_fbdali_external__ismessageavailable
	#define GET_fbdali_external__ismessageavailable(fl)  CAL_CMGETAPI( "fbdali_external__ismessageavailable" ) 
	#define CAL_fbdali_external__ismessageavailable  fbdali_external__ismessageavailable
	#define CHK_fbdali_external__ismessageavailable  TRUE
	#define EXP_fbdali_external__ismessageavailable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__ismessageavailable", (RTS_UINTPTR)fbdali_external__ismessageavailable, 1, 0x837500EB, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__ismessageavailable
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__ismessageavailable
	#define GET_WagoSysDALI_Internal_CCfbdali_external__ismessageavailable  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__ismessageavailable  fbdali_external__ismessageavailable
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__ismessageavailable  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__ismessageavailable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__ismessageavailable", (RTS_UINTPTR)fbdali_external__ismessageavailable, 1, 0x837500EB, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__ismessageavailable
	#define EXT_fbdali_external__ismessageavailable
	#define GET_fbdali_external__ismessageavailable(fl)  CAL_CMGETAPI( "fbdali_external__ismessageavailable" ) 
	#define CAL_fbdali_external__ismessageavailable  fbdali_external__ismessageavailable
	#define CHK_fbdali_external__ismessageavailable  TRUE
	#define EXP_fbdali_external__ismessageavailable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__ismessageavailable", (RTS_UINTPTR)fbdali_external__ismessageavailable, 1, 0x837500EB, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__ismessageavailable  PFFBDALI_EXTERNAL__ISMESSAGEAVAILABLE_IEC pffbdali_external__ismessageavailable;
	#define EXT_fbdali_external__ismessageavailable  extern PFFBDALI_EXTERNAL__ISMESSAGEAVAILABLE_IEC pffbdali_external__ismessageavailable;
	#define GET_fbdali_external__ismessageavailable(fl)  s_pfCMGetAPI2( "fbdali_external__ismessageavailable", (RTS_VOID_FCTPTR *)&pffbdali_external__ismessageavailable, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x837500EB, 0x00000001)
	#define CAL_fbdali_external__ismessageavailable  pffbdali_external__ismessageavailable
	#define CHK_fbdali_external__ismessageavailable  (pffbdali_external__ismessageavailable != NULL)
	#define EXP_fbdali_external__ismessageavailable   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__ismessageavailable", (RTS_UINTPTR)fbdali_external__ismessageavailable, 1, 0x837500EB, 0x00000001) 
#endif


/**
 * <description>fbdali_external_main</description>
 */
typedef struct tagfbdali_external_main_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
} fbdali_external_main_struct;

void CDECL CDECL_EXT fbdali_external__main(fbdali_external_main_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__MAIN_IEC) (fbdali_external_main_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__MAIN_NOTIMPLEMENTED)
	#define USE_fbdali_external__main
	#define EXT_fbdali_external__main
	#define GET_fbdali_external__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__main(p0) 
	#define CHK_fbdali_external__main  FALSE
	#define EXP_fbdali_external__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__main
	#define EXT_fbdali_external__main
	#define GET_fbdali_external__main(fl)  CAL_CMGETAPI( "fbdali_external__main" ) 
	#define CAL_fbdali_external__main  fbdali_external__main
	#define CHK_fbdali_external__main  TRUE
	#define EXP_fbdali_external__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__main", (RTS_UINTPTR)fbdali_external__main, 1, 0xDD9AAE8D, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__main {(RTS_VOID_FCTPTR)fbdali_external__main, "fbdali_external__main", 0xDD9AAE8D, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__main
	#define EXT_fbdali_external__main
	#define GET_fbdali_external__main(fl)  CAL_CMGETAPI( "fbdali_external__main" ) 
	#define CAL_fbdali_external__main  fbdali_external__main
	#define CHK_fbdali_external__main  TRUE
	#define EXP_fbdali_external__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__main", (RTS_UINTPTR)fbdali_external__main, 1, 0xDD9AAE8D, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__main
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__main
	#define GET_WagoSysDALI_Internal_CCfbdali_external__main  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__main  fbdali_external__main
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__main  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__main", (RTS_UINTPTR)fbdali_external__main, 1, 0xDD9AAE8D, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__main
	#define EXT_fbdali_external__main
	#define GET_fbdali_external__main(fl)  CAL_CMGETAPI( "fbdali_external__main" ) 
	#define CAL_fbdali_external__main  fbdali_external__main
	#define CHK_fbdali_external__main  TRUE
	#define EXP_fbdali_external__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__main", (RTS_UINTPTR)fbdali_external__main, 1, 0xDD9AAE8D, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__main  PFFBDALI_EXTERNAL__MAIN_IEC pffbdali_external__main;
	#define EXT_fbdali_external__main  extern PFFBDALI_EXTERNAL__MAIN_IEC pffbdali_external__main;
	#define GET_fbdali_external__main(fl)  s_pfCMGetAPI2( "fbdali_external__main", (RTS_VOID_FCTPTR *)&pffbdali_external__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDD9AAE8D, 0x00000001)
	#define CAL_fbdali_external__main  pffbdali_external__main
	#define CHK_fbdali_external__main  (pffbdali_external__main != NULL)
	#define EXP_fbdali_external__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__main", (RTS_UINTPTR)fbdali_external__main, 1, 0xDD9AAE8D, 0x00000001) 
#endif


/**
 *
 *	returns the protocol-ID of the next message
 *	-1 -> no message available
 *	0  -> no protocol-ID (may be simple header but not must)
 *	otherwise protocol-ID (it must be an extended header)
 */
typedef struct tagfbdali_external_mbxgetnextprotocolid_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_INT MbxGetNextProtocolID;	/* VAR_OUTPUT */	
} fbdali_external_mbxgetnextprotocolid_struct;

void CDECL CDECL_EXT fbdali_external__mbxgetnextprotocolid(fbdali_external_mbxgetnextprotocolid_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__MBXGETNEXTPROTOCOLID_IEC) (fbdali_external_mbxgetnextprotocolid_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__MBXGETNEXTPROTOCOLID_NOTIMPLEMENTED)
	#define USE_fbdali_external__mbxgetnextprotocolid
	#define EXT_fbdali_external__mbxgetnextprotocolid
	#define GET_fbdali_external__mbxgetnextprotocolid(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__mbxgetnextprotocolid(p0) 
	#define CHK_fbdali_external__mbxgetnextprotocolid  FALSE
	#define EXP_fbdali_external__mbxgetnextprotocolid  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__mbxgetnextprotocolid
	#define EXT_fbdali_external__mbxgetnextprotocolid
	#define GET_fbdali_external__mbxgetnextprotocolid(fl)  CAL_CMGETAPI( "fbdali_external__mbxgetnextprotocolid" ) 
	#define CAL_fbdali_external__mbxgetnextprotocolid  fbdali_external__mbxgetnextprotocolid
	#define CHK_fbdali_external__mbxgetnextprotocolid  TRUE
	#define EXP_fbdali_external__mbxgetnextprotocolid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextprotocolid", (RTS_UINTPTR)fbdali_external__mbxgetnextprotocolid, 1, 0x14F9FA26, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__mbxgetnextprotocolid {(RTS_VOID_FCTPTR)fbdali_external__mbxgetnextprotocolid, "fbdali_external__mbxgetnextprotocolid", 0x14F9FA26, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__mbxgetnextprotocolid
	#define EXT_fbdali_external__mbxgetnextprotocolid
	#define GET_fbdali_external__mbxgetnextprotocolid(fl)  CAL_CMGETAPI( "fbdali_external__mbxgetnextprotocolid" ) 
	#define CAL_fbdali_external__mbxgetnextprotocolid  fbdali_external__mbxgetnextprotocolid
	#define CHK_fbdali_external__mbxgetnextprotocolid  TRUE
	#define EXP_fbdali_external__mbxgetnextprotocolid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextprotocolid", (RTS_UINTPTR)fbdali_external__mbxgetnextprotocolid, 1, 0x14F9FA26, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextprotocolid
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextprotocolid
	#define GET_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextprotocolid  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextprotocolid  fbdali_external__mbxgetnextprotocolid
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextprotocolid  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextprotocolid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextprotocolid", (RTS_UINTPTR)fbdali_external__mbxgetnextprotocolid, 1, 0x14F9FA26, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__mbxgetnextprotocolid
	#define EXT_fbdali_external__mbxgetnextprotocolid
	#define GET_fbdali_external__mbxgetnextprotocolid(fl)  CAL_CMGETAPI( "fbdali_external__mbxgetnextprotocolid" ) 
	#define CAL_fbdali_external__mbxgetnextprotocolid  fbdali_external__mbxgetnextprotocolid
	#define CHK_fbdali_external__mbxgetnextprotocolid  TRUE
	#define EXP_fbdali_external__mbxgetnextprotocolid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextprotocolid", (RTS_UINTPTR)fbdali_external__mbxgetnextprotocolid, 1, 0x14F9FA26, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__mbxgetnextprotocolid  PFFBDALI_EXTERNAL__MBXGETNEXTPROTOCOLID_IEC pffbdali_external__mbxgetnextprotocolid;
	#define EXT_fbdali_external__mbxgetnextprotocolid  extern PFFBDALI_EXTERNAL__MBXGETNEXTPROTOCOLID_IEC pffbdali_external__mbxgetnextprotocolid;
	#define GET_fbdali_external__mbxgetnextprotocolid(fl)  s_pfCMGetAPI2( "fbdali_external__mbxgetnextprotocolid", (RTS_VOID_FCTPTR *)&pffbdali_external__mbxgetnextprotocolid, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x14F9FA26, 0x00000001)
	#define CAL_fbdali_external__mbxgetnextprotocolid  pffbdali_external__mbxgetnextprotocolid
	#define CHK_fbdali_external__mbxgetnextprotocolid  (pffbdali_external__mbxgetnextprotocolid != NULL)
	#define EXP_fbdali_external__mbxgetnextprotocolid   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextprotocolid", (RTS_UINTPTR)fbdali_external__mbxgetnextprotocolid, 1, 0x14F9FA26, 0x00000001) 
#endif


/**
 *
 *	Return codes :
 *	OK	
 *	NO_DATA
 *	BUFFER_TO_SMALL	:	buffer not big enough for the next message
 *	PRM_INVALID		:	parameter invalid -> null-pointer
 */
typedef struct tagfbdali_external_mbxgetnextmessage_struct
{
	fbdali_external_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BYTE *pMsgBuffer;			/* VAR_INPUT */	/* pointer to buffer where the wanted message is to place */
	RTS_IEC_UDINT udiMsgBufferSize;		/* VAR_INPUT */	/* size of the message buffer */
	RTS_IEC_UINT MbxGetNextMessage;		/* VAR_OUTPUT, Enum: EERRORMBX2 */
	RTS_IEC_UDINT udiMsgLen;			/* VAR_OUTPUT */	/* len of the message incl. header. */
} fbdali_external_mbxgetnextmessage_struct;

void CDECL CDECL_EXT fbdali_external__mbxgetnextmessage(fbdali_external_mbxgetnextmessage_struct *p);
typedef void (CDECL CDECL_EXT* PFFBDALI_EXTERNAL__MBXGETNEXTMESSAGE_IEC) (fbdali_external_mbxgetnextmessage_struct *p);
#if defined(WAGOSYSDALI_INTERNAL_CC_NOTIMPLEMENTED) || defined(FBDALI_EXTERNAL__MBXGETNEXTMESSAGE_NOTIMPLEMENTED)
	#define USE_fbdali_external__mbxgetnextmessage
	#define EXT_fbdali_external__mbxgetnextmessage
	#define GET_fbdali_external__mbxgetnextmessage(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbdali_external__mbxgetnextmessage(p0) 
	#define CHK_fbdali_external__mbxgetnextmessage  FALSE
	#define EXP_fbdali_external__mbxgetnextmessage  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbdali_external__mbxgetnextmessage
	#define EXT_fbdali_external__mbxgetnextmessage
	#define GET_fbdali_external__mbxgetnextmessage(fl)  CAL_CMGETAPI( "fbdali_external__mbxgetnextmessage" ) 
	#define CAL_fbdali_external__mbxgetnextmessage  fbdali_external__mbxgetnextmessage
	#define CHK_fbdali_external__mbxgetnextmessage  TRUE
	#define EXP_fbdali_external__mbxgetnextmessage  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextmessage", (RTS_UINTPTR)fbdali_external__mbxgetnextmessage, 1, 0xB991B887, 0x00000001) 
	#define EXTREF_ITF_fbdali_external__mbxgetnextmessage {(RTS_VOID_FCTPTR)fbdali_external__mbxgetnextmessage, "fbdali_external__mbxgetnextmessage", 0xB991B887, 0x00000001}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDALI_INTERNAL_CC_EXTERNAL)
	#define USE_fbdali_external__mbxgetnextmessage
	#define EXT_fbdali_external__mbxgetnextmessage
	#define GET_fbdali_external__mbxgetnextmessage(fl)  CAL_CMGETAPI( "fbdali_external__mbxgetnextmessage" ) 
	#define CAL_fbdali_external__mbxgetnextmessage  fbdali_external__mbxgetnextmessage
	#define CHK_fbdali_external__mbxgetnextmessage  TRUE
	#define EXP_fbdali_external__mbxgetnextmessage  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextmessage", (RTS_UINTPTR)fbdali_external__mbxgetnextmessage, 1, 0xB991B887, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextmessage
	#define EXT_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextmessage
	#define GET_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextmessage  ERR_OK
	#define CAL_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextmessage  fbdali_external__mbxgetnextmessage
	#define CHK_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextmessage  TRUE
	#define EXP_WagoSysDALI_Internal_CCfbdali_external__mbxgetnextmessage  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextmessage", (RTS_UINTPTR)fbdali_external__mbxgetnextmessage, 1, 0xB991B887, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fbdali_external__mbxgetnextmessage
	#define EXT_fbdali_external__mbxgetnextmessage
	#define GET_fbdali_external__mbxgetnextmessage(fl)  CAL_CMGETAPI( "fbdali_external__mbxgetnextmessage" ) 
	#define CAL_fbdali_external__mbxgetnextmessage  fbdali_external__mbxgetnextmessage
	#define CHK_fbdali_external__mbxgetnextmessage  TRUE
	#define EXP_fbdali_external__mbxgetnextmessage  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextmessage", (RTS_UINTPTR)fbdali_external__mbxgetnextmessage, 1, 0xB991B887, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fbdali_external__mbxgetnextmessage  PFFBDALI_EXTERNAL__MBXGETNEXTMESSAGE_IEC pffbdali_external__mbxgetnextmessage;
	#define EXT_fbdali_external__mbxgetnextmessage  extern PFFBDALI_EXTERNAL__MBXGETNEXTMESSAGE_IEC pffbdali_external__mbxgetnextmessage;
	#define GET_fbdali_external__mbxgetnextmessage(fl)  s_pfCMGetAPI2( "fbdali_external__mbxgetnextmessage", (RTS_VOID_FCTPTR *)&pffbdali_external__mbxgetnextmessage, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB991B887, 0x00000001)
	#define CAL_fbdali_external__mbxgetnextmessage  pffbdali_external__mbxgetnextmessage
	#define CHK_fbdali_external__mbxgetnextmessage  (pffbdali_external__mbxgetnextmessage != NULL)
	#define EXP_fbdali_external__mbxgetnextmessage   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbdali_external__mbxgetnextmessage", (RTS_UINTPTR)fbdali_external__mbxgetnextmessage, 1, 0xB991B887, 0x00000001) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysDALI_Internal_CC_C;

#ifdef CPLUSPLUS
class IWagoSysDALI_Internal_CC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysDALI_Internal_CC
		#define ITF_WagoSysDALI_Internal_CC static IWagoSysDALI_Internal_CC *pIWagoSysDALI_Internal_CC = NULL;
	#endif
	#define EXTITF_WagoSysDALI_Internal_CC
#else	/*CPLUSPLUS*/
	typedef IWagoSysDALI_Internal_CC_C		IWagoSysDALI_Internal_CC;
	#ifndef ITF_WagoSysDALI_Internal_CC
		#define ITF_WagoSysDALI_Internal_CC
	#endif
	#define EXTITF_WagoSysDALI_Internal_CC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSDALI_INTERNAL_CCITF_H_*/
