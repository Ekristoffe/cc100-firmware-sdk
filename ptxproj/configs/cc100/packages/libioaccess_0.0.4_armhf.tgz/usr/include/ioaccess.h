//------------------------------------------------------------------------------
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
// Copyright (c) 2025 WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
///------------------------------------------------------------------------------
/// \file    ioaccess.h
///
/// \version $Id$
///
/// \brief   Handle IO access to shard memory of cortex-M4 coprocessor
///
/// \author  Martin Essig elrest Automationssysteme GmbH
///------------------------------------------------------------------------------

#ifndef HEADER_IOACCESS
#define HEADER_IOACCESS

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
typedef void* IOA_HANDLE;

// error codes like wago::wda:status_codes from status_codes.hpp
#define IOACCESS_SUCCESS               0U
#define IOACCESS_INTERNAL_ERROR        2U
#define IOACCESS_NOT_IMPLEMENTED       3U
#define IOACCESS_WRONG_PARAMETER       4U
#define IOACCESS_UNKNOWN_PARAMETER_ID 13U
#define IOACCESS_WRONG_VALUE_TYPE     24U
#define IOACCESS_NO_CALIB_FOUND       25U
#define IOACCESS_WRONG_CHANNEL_TYPE   97U // Not a wago::wda:status_codes
#define IOACCESS_ACCESS_DENIED        98U // Not a wago::wda:status_codes

#ifdef __cplusplus
extern "C" {
#endif

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
uint16_t ioaccess_init(void);
uint16_t ioaccess_deinit(void);
uint16_t ioaccess_set_write_permission(uint32_t hPDConnection);
uint16_t ioaccess_clear_write_permission(uint32_t hPDConnection);
bool ioaccess_check_write_permission(uint32_t hPDConnection);
uint16_t ioaccess_configure_channel_by_id(uint16_t nParamID, uint16_t nInstID, uint32_t ulConf);
uint16_t ioaccess_configure_analog_channel_by_id(uint16_t nParamID, uint16_t nInstID, uint32_t ulAvgCalcValue, int32_t lRawLower, int32_t lRawUpper, float fMeasuredLower, float fMeasuredUpper);
uint16_t ioaccess_read_channel_value_by_id(uint16_t nParamID, uint16_t nInstID, uint32_t* pulValue);
uint16_t ioaccess_write_channel_value_by_id(uint16_t nParamID, uint16_t nInstID, uint32_t ulValue);
uint16_t ioaccess_read_channel_conf_by_id(uint16_t nParamID, uint16_t nInstID, uint32_t* pulConf);
uint16_t ioaccess_get_inst_id(uint16_t nCompositionID, uint16_t nChannel, uint16_t* pnInstID);
uint16_t ioaccess_get_inst_id_by_inst_id(uint16_t nInstID, uint16_t* pnInstID);
uint16_t ioaccess_set_mode_by_id(uint16_t nInstID);
uint16_t ioaccess_get_mode_by_id(uint16_t nInstID, bool* pbAltMode);

#ifdef __cplusplus
}
#endif

#endif   //HEADER_IOACCESS
