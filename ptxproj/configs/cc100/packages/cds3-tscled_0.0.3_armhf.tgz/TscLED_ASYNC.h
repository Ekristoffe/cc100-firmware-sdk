//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
/// manufacturing, reproduction, use, and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// \file WagoLed_API.h
///
/// \version $Revision$
///
/// \brief Global Interface to the LED Components of a Coupler
///
/// \author Hans Florian Scholz: Wago
//------------------------------------------------------------------------------

#ifndef TSCLED_ASYNC_H_
#define TSCLED_ASYNC_H_

typedef struct {
    void (*jobFunction)(void *);
    void *arg;
}tAsyncJobMsg;

RTS_RESULT ASYNC_Init(void);
int ASYNC_AddJob(tAsyncJobMsg * job);
int ASYNC_Stop(void);


#endif /* TSCLED_ASYNC_H_ */
