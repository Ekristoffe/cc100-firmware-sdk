//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
///------------------------------------------------------------------------------
/// \file    lioclient.h
///
/// \version $Id$
///
/// \brief   client library for WDx access to configure and handle local IOs.
///
/// \author  Martin Essig, elrest Automationssysteme GmbH
///------------------------------------------------------------------------------

#ifndef HEADER_LIOCLIENT
#define HEADER_LIOCLIENT

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdlib.h>
#include <stdint.h>
#include <float.h>
#include <math.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
typedef void* LIO_HANDLE;

// error codes like wago::wdx:status_codes from status_codes.hpp
#define LIO_SUCCESS               0
#define LIO_INTERNAL_ERROR        2
#define LIO_NOT_IMPLEMENTED       3
#define LIO_UNKNOWN_PARAMETER_ID 13
#define LIO_WRONG_VALUE_TYPE     24
#define LIO_ACCESS_DENIED        98 // Not a wago::wdx:status_codes
#define LIO_TIMEOUT              99 // Not a wago::wdx:status_codes

enum proccess_data_access_levels
{
    realtime_read_write = 1,
    nonrealtime_read,
    nonrealtime_write
};

#ifdef __cplusplus
extern "C" {
#endif



//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
LIO_HANDLE lioclient_init(char* Name, uint32_t ulTimeout);
uint16_t lioclient_deinit(LIO_HANDLE hClient);
uint16_t lioclient_get_int_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, uint32_t* pulValue);
uint16_t lioclient_set_int_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, uint32_t ulValue);
uint16_t lioclient_set_uint8_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, uint8_t Value);
uint16_t lioclient_set_uint16_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, uint16_t Value);
uint16_t lioclient_set_uint32_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, uint32_t Value);
uint16_t lioclient_set_int8_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, int8_t Value);
uint16_t lioclient_set_int16_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, int16_t Value);
uint16_t lioclient_set_int32_value(LIO_HANDLE hClient, uint32_t ulParamID, uint16_t usInstID, int32_t Value);
uint16_t lioclient_set_channel_composition(LIO_HANDLE hClient, uint16_t usInstID, uint16_t ausValues[], int16_t nCount);
uint16_t lioclient_open_process_data_connection(LIO_HANDLE hClient, enum proccess_data_access_levels AccessLevel, LIO_HANDLE* hConnection);
uint16_t lioclient_close_process_data_connection(LIO_HANDLE hClient, LIO_HANDLE hConnection);
//uint16_t lioclient_get_analog_operation_mode(LIO_HANDLE hClient, uint16_t usInstID, int32_t* plRawLower, int32_t* plRawUpper, float_t* pfMeasuredLower, float_t* pfMeasuredUpper);

// functions for realtime process data access
//uint16_t lioclient_read_input_image(LIO_HANDLE hConnection, uint16_t fromIdx, uint16_t noOfElems, uint16_t* pData, uint16_t size);
//uint16_t lioclient_read_output_image(LIO_HANDLE hConnection, uint16_t fromIdx, uint16_t noOfElems, uint16_t* pData, uint16_t size);
//uint16_t lioclient_write_output_image(LIO_HANDLE hConnection, uint16_t fromIdx, uint16_t noOfElems, uint16_t* pData);
uint16_t lioclient_read_process_data_item(LIO_HANDLE hConnection, uint32_t ulParamID, uint16_t usInstID, uint32_t* pulValue);
uint16_t lioclient_write_process_data_item(LIO_HANDLE hConnection, uint32_t ulParamID, uint16_t usInstID, uint32_t ulValue);


#ifdef __cplusplus
}
#endif

#endif   //HEADER_LIOCLIENT
