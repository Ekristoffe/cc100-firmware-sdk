//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material.
// All manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     DStime.h
///
///  \brief    Timer functionality used by DALIService.
///
///  \author   Philipp Hundsdörfer: who Ingenieurgesellschaft mbH für WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef _dstime_h
  #define _dstime_h

  //------------------------------------------------------------------------------
  // include files
  //------------------------------------------------------------------------------

  #include <stdbool.h>
  #include <stdint.h>
  #include <limits.h>
  #include <time.h>

  //------------------------------------------------------------------------------
  // defines, structure, enumeration and type definitions
  //------------------------------------------------------------------------------
  #define NS_PER_US             1000	// Nanoseconds per microsecond
  #define NS_PER_MS          1000000	// Nanoseconds per millisecond
  #define NS_PER_SEC	    1000000000	// Nanoseconds per second
  #define US_PER_MS	            1000	// Microseconds per millisecond
  #define US_PER_SEC         1000000	// Microseconds per second
  #define MS_PER_SEC            1000	// Milliseconds per second
  #define DS_SLEEP_APC_MS	        10  // Sleep time of DALIService APC routine in milliseconds
  #define DS_SLEEP_MS		 	        20  // Sleep time of DALIService in milliseconds
  #define DS_TO_HEARTBEAT_MS     200	// Time out of DALIService heartbeat in milliseconds
  #define DS_TO_LOCK_MS           10	// Time out of DALIService locking mechanism in milliseconds
  #define DS_TSC_TO_LOCK_MS       10	// Time out of TscAppConnector locking mechanism in milliseconds
  #define US_MAX          LONG_MAX
  #define MS_MAX          US_MAX/US_PER_MS

  //------------------------------------------------------------------------------
  // Function prototypes
  //------------------------------------------------------------------------------
  bool timespecSubtract(struct timespec *res, struct timespec *first, struct timespec *second);
  void DSTimerStartMs(struct timespec *timer, uint32_t ms);
  void DSTimerStartUs(struct timespec *timer, uint32_t ms);
  bool DSTimerExpired(struct timespec *timer);
#endif // _dstime_h