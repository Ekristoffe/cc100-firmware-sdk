//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material.
// All manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     DSshm.h
///
///  \brief    Shared memory definitions of DALIService.
///
///  \author   Philipp Hundsdörfer: who Ingenieurgesellschaft mbH für WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef _dsshm_h

  #define _dsshm_h

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------

#include <pthread.h>
#include <DStransfer.h>

//------------------------------------------------------------------------------
// defines, structure, enumeration and type definitions
//------------------------------------------------------------------------------

#define DS_SHM_NAME         "/wago_DALI_Service_shm"
#define DS_SHM_PERMISSIONS  S_IRUSR | S_IWUSR

#define DS_CTRL_MUTEX_NAME	"DSctrl"// Log identifier for mutexDSctrl
#define DS_CMD_MUTEX_NAME	"DScmd"	// Log identifier for mutexDScmd
#define DS_DATA_MUTEX_NAME	"DSdata"// Log identifier for mutexDSdata

enum eDSstate {
	DS_OFFLINE				= 0,	// DALIService is not yet started
	DS_INIT					= 1,    // DALIService initialization
	DS_READY				= 2,	// DALIService ready for action
	DS_RESET				= 3,	// DALIService resets
};

enum eDSCcmd {
	DS_CMD_NONE				= 0,	// DALIService no cmd 
	DS_CMD_RESET			= 1,	// DALIService reset
};

// Structure of shared data of DALIService DALIService module
typedef struct stDSShm {
	pthread_mutex_t 	mutexDSctrl;	// Mutex for DS control access
	int					state;		    // internal DALIService state
	pthread_mutex_t 	mutexDScmd;		// Mutex for DS command access
	int					cmd;			// execute DALIService control cmd
	pthread_mutex_t		mutexDSdata;	// Mutex for DALIService data access
	short unsigned int	version;		// Version id of DALIService module
	tDSFifo				messageIn;		// Fifo control structure for incomming messages
	tDSFifo				messageOut;		// Fifo control structure for outgoing messages
}  tDSShm;

// Control structure for DALIservice shared memory access
typedef struct stShm {
    int         shm_fd;
    size_t      shm_size;
    tDSShm *    shm_mem;
} tShm;

int DSlock(pthread_mutex_t * mutex, char * mutexName);
int DSunlock(pthread_mutex_t * mutex, char * mutexName);

#endif // _dsshm_h