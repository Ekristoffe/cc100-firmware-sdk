//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material.
// All manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     DStransfer.h
///
///  \brief    Fifo functionality for the message queues of the DALIService
///
///  \author   Philipp Hundsdörfer: who Ingenieurgesellschaft mbH für WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef _dstransfer_h

  #define _dstransfer_h

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdbool.h>
#include <stdint.h>
#include <mbx2_intern.h>

//------------------------------------------------------------------------------
// defines, structure, enumeration and type definitions
//------------------------------------------------------------------------------
#define MBX2_MSG_MAX          20	// Maximum number of incoming messages in fifo
#define MBX2_MSG_SIZE         72	// Maximum size of message 
#define MBX2_MSG_BUFFER_SIZE	(MBX2_MSG_MAX * MBX2_MSG_SIZE)

typedef uint8_t tMessage [MBX2_MSG_SIZE];						        // type of messages
typedef uint8_t tMessageFifo [MBX2_MSG_BUFFER_SIZE];		// type of incoming messages fifo

typedef struct DSFifoStructure {
  uint16_t      tail;           // Actual read  index to FIFO entry.
  uint16_t      head;           // Actual write index to FIFO entry.
  bool          full;           // Flag to sign up FIFO full status.
  uint16_t      maxEntries;     // Quantity of FIFO entries.
  uint16_t      bytesPerEntry;  // Quantity of data bytes of one FIFO entry.
  tMessageFifo  buffer;	        // message fifo buffer
} tDSFifo;

//------------------------------------------------------------------------------
// functions
//------------------------------------------------------------------------------
bool evaluateHeader(uint8_t* pMessage, tMBX2_TelegramHeader* pHeader);

void fifoInit (tDSFifo* pFifo);
bool fifoIsEmpty (tDSFifo* pFifo);
bool fifoPeek (tDSFifo* pFifo, void* pMessage);
bool fifoPop (tDSFifo* pFifo, void* pMessage);
bool fifoTryPush (tDSFifo* pFifo, const void* pMessage);

#endif // _dstransfer_h