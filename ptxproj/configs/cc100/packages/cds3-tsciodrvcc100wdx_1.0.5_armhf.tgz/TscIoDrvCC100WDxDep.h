/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component TscIoDrvCC100WDx</name>
 *  <description> 
 *  TscIoDrvCC100WDx onboard io driver
 *  </description>
 *  <copyright>
 *  (c) 2024 elrest Automationssysteme GmbH
 *  </copyright>
 */

#ifndef _TSCIODRVCC100WDXDEP_H_
#define _TSCIODRVCC100WDXDEP_H_

#define COMPONENT_NAME "TscIoDrvCC100WDx" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscIoDrvCC100WDx)
#define COMPONENT_NAME_UNQUOTED TscIoDrvCC100WDx





#define CMP_VERSION         UINT32_C(0x01000005)
#define CMP_VERSION_STRING "1.0.0.5"
#define CMP_VERSION_RC      1,0,0,5
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"				

/* wago target defines for V3 components*/
#include <WagoSysdefines.h>

#define CMPID_TscIoDrvCC100WDx		TSCIODRVCC100WDX_CMPID
#define CLASSID_TscIoDrvCC100WDx	ADDVENDORID(CMP_VENDORID, TSCIODRVCC100WDX_CLASSID_C)
#define ITFID_TscIoDrvCC100WDx		ADDVENDORID(CMP_VENDORID, TSCIODRVCC100WDX_ITFID_C)






/**
 * \file TscIoDrvCC100WDxItf.h
 */
#include "TscIoDrvCC100WDxItf.h"

/**
 * \file CmpIoDrvItf.h
 */
#include "CmpIoDrvItf.h"

/**
 * \file CmpIoDrvParameterItf.h
 */
#include "CmpIoDrvParameterItf.h"











#include "CMLockItf.h"



#include "SysTargetItf.h"


#include "CmpAppItf.h"


#include "CMItf.h"


#include "CmpIoMgrItf.h"


#include "SysCpuHandlingItf.h"


#include "SysMemItf.h"



        



















     



















     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pISysMem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysMem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysMem = (ISysMem *)pIBase->QueryInterface(pIBase, ITFID_ISysMem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysCpuHandling == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysCpuHandling, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysCpuHandling = (ISysCpuHandling *)pIBase->QueryInterface(pIBase, ITFID_ISysCpuHandling, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpIoMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpIoMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpIoMgr = (ICmpIoMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpIoMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTarget == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTarget, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTarget = (ISysTarget *)pIBase->QueryInterface(pIBase, ITFID_ISysTarget, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICMLock == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMLock, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMLock = (ICMLock *)pIBase->QueryInterface(pIBase, ITFID_ICMLock, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pISysMem = NULL; \
          pISysCpuHandling = NULL; \
          pICmpIoMgr = NULL; \
          pICM = NULL; \
          pICmpApp = NULL; \
          pISysTarget = NULL; \
          pICMLock = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pISysMem != NULL) \
        { \
            pIBase = (IBase *)pISysMem->QueryInterface(pISysMem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysMem = NULL; \
            } \
        } \
          if (pISysCpuHandling != NULL) \
        { \
            pIBase = (IBase *)pISysCpuHandling->QueryInterface(pISysCpuHandling, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysCpuHandling = NULL; \
            } \
        } \
          if (pICmpIoMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpIoMgr->QueryInterface(pICmpIoMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpIoMgr = NULL; \
            } \
        } \
          if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pISysTarget != NULL) \
        { \
            pIBase = (IBase *)pISysTarget->QueryInterface(pISysTarget, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTarget = NULL; \
            } \
        } \
          if (pICMLock != NULL) \
        { \
            pIBase = (IBase *)pICMLock->QueryInterface(pICMLock, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMLock = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_SysTargetGetId(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_SysCpuTestAndSetBit(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemFreeData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemAllocData(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrSetDriverProperties(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigSetDiagnosis(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetNextChild(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetFirstChild(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetNextConnector(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetFirstConnector(0);\
          if (ERR_OK == importResult ) importResult = GET_IoMgrConfigGetParameter(0);\
          if (ERR_OK == importResult ) importResult = GET_IoDrvDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_IoDrvCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_CMRegisterInstance(0);\
          /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCIODRVCC100WDX_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)writevaluefun, "writevaluefun", 0xB9AB9E80, 0x03051347 },\
          { (RTS_VOID_FCTPTR)settypefun, "settypefun", 0x93B43421, 0x03051347 },\
          { (RTS_VOID_FCTPTR)setconffun, "setconffun", 0x58ED258D, 0x03051347 },\
          { (RTS_VOID_FCTPTR)calibsettypfn, "calibsettypfn", 0x130B1A6D, 0x03051347 },\
                                      
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCIODRVCC100WDX_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                            
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCIODRVCC100WDX_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                            \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CMLock     \
	ITF_SysTarget     \
	ITF_CmpApp     \
	ITF_CM     \
	ITF_CmpIoMgr     \
	ITF_SysCpuHandling     \
	ITF_SysMem      \
    /*obsolete USE_LogAdd*/      \
    USE_CMRegisterInstance      \
    USE_IoDrvCreate      \
    USE_IoDrvDelete      \
    USE_IoMgrConfigGetParameter      \
    USE_IoMgrConfigGetFirstConnector      \
    USE_IoMgrConfigGetNextConnector      \
    USE_IoMgrConfigGetFirstChild      \
    USE_IoMgrConfigGetNextChild      \
    USE_IoMgrConfigSetDiagnosis      \
    USE_IoMgrSetDriverProperties      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_CMUtlSafeStrCpy      \
    USE_SysCpuTestAndSetBit      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_SysTargetGetId     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CMLock    \
	ITF_SysTarget    \
	ITF_CmpApp    \
	ITF_CM    \
	ITF_CmpIoMgr    \
	ITF_SysCpuHandling    \
	ITF_SysMem     \
    /*obsolete USE_LogAdd*/      \
    USE_CMRegisterInstance      \
    USE_IoDrvCreate      \
    USE_IoDrvDelete      \
    USE_IoMgrConfigGetParameter      \
    USE_IoMgrConfigGetFirstConnector      \
    USE_IoMgrConfigGetNextConnector      \
    USE_IoMgrConfigGetFirstChild      \
    USE_IoMgrConfigGetNextChild      \
    USE_IoMgrConfigSetDiagnosis      \
    USE_IoMgrSetDriverProperties      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_CMUtlSafeStrCpy      \
    USE_SysCpuTestAndSetBit      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_SysTargetGetId     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CMLock    \
	EXTITF_SysTarget    \
	EXTITF_CmpApp    \
	EXTITF_CM    \
	EXTITF_CmpIoMgr    \
	EXTITF_SysCpuHandling    \
	EXTITF_SysMem     \
    /*obsolete EXT_LogAdd*/  \
    EXT_CMRegisterInstance  \
    EXT_IoDrvCreate  \
    EXT_IoDrvDelete  \
    EXT_IoMgrConfigGetParameter  \
    EXT_IoMgrConfigGetFirstConnector  \
    EXT_IoMgrConfigGetNextConnector  \
    EXT_IoMgrConfigGetFirstChild  \
    EXT_IoMgrConfigGetNextChild  \
    EXT_IoMgrConfigSetDiagnosis  \
    EXT_IoMgrSetDriverProperties  \
    EXT_SysMemAllocData  \
    EXT_SysMemFreeData  \
    EXT_CMUtlSafeStrCpy  \
    EXT_SysCpuTestAndSetBit  \
    EXT_EventOpen  \
    EXT_EventClose  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_SysTargetGetId 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscIoDrvCC100WDx__Entry
#endif


#ifdef CPLUSPLUS

class CTscIoDrvCC100WDx : public ITscIoDrvCC100WDx , public ICmpIoDrv , public ICmpIoDrvParameter 
{
    public:
        CTscIoDrvCC100WDx() : hTscIoDrvCC100WDx(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscIoDrvCC100WDx()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ITscIoDrvCC100WDx *)this);            
            else if (iid == ITFID_ITscIoDrvCC100WDx)
                pItf = dynamic_cast<ITscIoDrvCC100WDx *>(this); 
            else if (iid == ITFID_ICmpIoDrv)
                pItf = dynamic_cast<ICmpIoDrv *>(this); 
            else if (iid == ITFID_ICmpIoDrvParameter)
                pItf = dynamic_cast<ICmpIoDrvParameter *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }
        virtual RTS_RESULT CDECL IIoDrvReadParameter(IoConfigConnector *pConnector, IoConfigParameter *pParameter, void *pData, RTS_SIZE ulBitSize, RTS_SIZE ulBitOffset);
        virtual RTS_RESULT CDECL IIoDrvWriteParameter(IoConfigConnector *pConnector, IoConfigParameter *pParameter, void *pData, RTS_SIZE ulBitSize, RTS_SIZE ulBitOffset);
        virtual RTS_HANDLE CDECL IIoDrvCreate(RTS_HANDLE hIIoDrv, CLASSID ClassId, int iId, RTS_RESULT *pResult);
        virtual RTS_RESULT CDECL IIoDrvDelete(RTS_HANDLE hIIoDrv);
        virtual RTS_RESULT CDECL IIoDrvGetInfo(IoDrvInfo **ppIoDrv);
        virtual RTS_RESULT CDECL IIoDrvGetModuleDiagnosis(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvIdentify(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvReadInputs(IoConfigConnectorMap *pConnectorMapList, int nCount);
        virtual RTS_RESULT CDECL IIoDrvScanModules(IoConfigConnector *pConnector, IoConfigConnector **ppConnectorList, int *pnCount);
        virtual RTS_RESULT CDECL IIoDrvStartBusCycle(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvUpdateConfiguration(IoConfigConnector *pConnectorList, int nCount);
        virtual RTS_RESULT CDECL IIoDrvUpdateMapping(IoConfigTaskMap *pTaskMapList, int nCount);
        virtual RTS_RESULT CDECL IIoDrvWatchdogTrigger(IoConfigConnector *pConnector);
        virtual RTS_RESULT CDECL IIoDrvWriteOutputs(IoConfigConnectorMap *pConnectorMapList, int nCount);

    public:
        RTS_HANDLE hTscIoDrvCC100WDx;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
