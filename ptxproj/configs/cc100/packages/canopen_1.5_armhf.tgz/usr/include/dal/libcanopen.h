//-----------------------------------------------------------------------------
//  Copyright (c) WAGO GmbH & Co. KG
//
//  PROPRIETARY RIGHTS are involved in the subject matter of this material.
//  All manufacturing, reproduction, use and sales rights pertaining to this
//  subject matter are governed by the license agreement. The recipient of this
//  software implicitly accepts the terms of the license.
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
///  \file     libcanopen.h
///
///  \version  $Id:
///
///  \brief    fieldbus specific types forfor Library interface
///
///  \author   <wue> : WAGO GmbH & Co. KG
//-----------------------------------------------------------------------------

#ifndef _LIBCANOPEN_H
#define _LIBCANOPEN_H

//-----------------------------------------------------------------------------
// include public types
//-----------------------------------------------------------------------------
#include <inttypes.h>
#include <pthread.h>

#include <dal/sdi_stack_interface.h>

#include "canopen_types.h"

//-----------------------------------------------------------------------------
// global defines for interface
//-----------------------------------------------------------------------------

//#define       CANOPEN_DEBUG           // printf output for testing
//#define       CANOPEN_DEBUG2          // printf PDO output for testing
//#define       CANOPEN_DEBUG_TIMER     // printf timerloop delays
//#define       DEBUG_SDOERROR          // printf SDO write errors
//#define       DEBUG_STARTDELAY        // printf startdelay infos

/* Debug info into syslog */
#define CANOPEN_LOGGING

/* Enable Baudrate scan */
//#define CANOPEN_AUTOBAUD

#define         CANOPEN_PRIO     50     // default prio for stack task  (-51)
#define         CANOPEN_PRIO2    47     // prio for 8215 (-48)
//#define       USR_k_TSK_PRIO_CAN_RX1  51  // CAN Rx Task Prio in ../ixxat2/Target/target.h line 340
//#define       USR_k_TSK_PRIO_CAN_RX2  48  // CAN Rx Task Prio for 8215 in ../ixxat2/Target/target.h line 341
#define         CANOPEN_IRQ_PRIO 84     // set CAN IRQ Prio in led_canopen.c

#define         EOWNERDEAD       130    // owner died for robust mutexes
#define         CANOPEN_WAITTIME 1000   // default waittime in canopen-loop Standard 1000
                                        // minimum 550 for PAC200 Master and PAC200 slave >>  CPU > 60%
                                        // minimum 800 for 1 Slave PAC200 + 3* Slave 750-337 >> CPU > 50%
                                        // default 1000 1 Slave PAC200 + 3* Slave 750-337 >> CPU < 50% Busload 33% @ 1MBit
                                        // save 2000 1 Slave PAC200 + 3* Slave 750-337 >> CPU < 33% Busload 23% @ 1MBit
                                        // Test with comtest with no Speedlimit set in mainloop
                                        // Main looptime = CANOPEN_WAITTIME CANOPEN_PRIO = 70
                                        // MAIN_PRIO = 65 PRIO_CAN_RX = 85 IRQ_Prio = 90
//#define TAR_k_SLEEPTIME       500    // Sleeptime for Rx Task in target.h line 170 Standard 1000

#define         CANOPEN_WAITLOOPS 1000  // timeout counter for 1-2s timeout

#define         CANOPEN_PDSIZE  4096    // see size in COPcfg.h

#define         CAN_MASK_NONE  0xF888   // no entry in mask

#define         CANOPEN_CSDO_CHANNELS 16 // number of channels for parallel communication (COM_k_SDOCMD_INSTANCES in COPcfg.h)

#define         CANOPEN_RX_DELAY 200    // wait time before processing bus in slave mode configuration

//#define         CANOPEN_START_IF_RUN  // wait to set master to operational if plc not in run

#define         CAN_BUSOFF_AUTORESET 200 // timervalue for busoff autoreset in slave or layer2 mode


// defines for control of threads
#define CAN_THREAD_STATE_STOP    0  // thread is not running
#define CAN_THREAD_STATE_INIT    1  // thread is starting
#define CAN_THREAD_STATE_SCAN    2  // baudrate scanning
#define CAN_THREAD_STATE_RX      3  // receiving messages
#define CAN_THREAD_STATE_TX      4  // canopen tx task active
#define CAN_THREAD_STATE_RUN     5  // canopen led task active
#define CAN_THREAD_STATE_KILL    9  // quit thread

#ifndef TRUE
  #define TRUE (1==1)
#endif

#ifndef FALSE
  #define FALSE (1==0)
#endif

#define UNUSED_PARAMETER(x) ((void)x)

//-----------------------------------------------------------------------------
// definitions and Vars for CANopen WAGO DAL
//-----------------------------------------------------------------------------

#define DRV_CAP_FLAG_WANTS_CONFIG    0x01
#define DRV_CAP_FLAG_IS_CANDEVICE    0x04
#define DRV_CAP_FLAG_IS_CONFCONFDEV  0x80
#define DRV_CAP_FLAG_IS_COS          (DRV_CAP_FLAG_IS_CANDEVICE|DRV_CAP_FLAG_IS_CONFCONFDEV)

//-----------------------------------------------------------------------------
//  globals vars from stack_canopen.c
//-----------------------------------------------------------------------------

extern pthread_mutex_t canopen_mutex_read;     // mutex for process data read
extern pthread_mutex_t canopen_mutex_write;    // mutex for process data write
extern pthread_mutex_t canopen_mutex_loop;     // mutex for canopen loop
extern pthread_mutex_t canopen_mutex_usersdo;  // mutex for user sdos
extern pthread_t       canopen_thread_tx;      // canopen tx loop thread

extern uint8_t         canopen_tx_state;       // run info for canopen tx thread
extern uint8_t         canopen_rx_state;       // run info for canopen rx thread
extern uint8_t         canopen_prio;           // priority for canopen thread
extern uint8_t         canopen_newdata;        // flag for newdata in thread
extern uint16_t        canopen_lasterror;      // info for interface
extern uint8_t         canopen_errorstate;     // local copy of communication state
extern uint8_t         canopen_errorstate_old;
extern uint8_t  	   canopen_connection;
extern uint8_t         canopen_baudratescan;
extern uint8_t         canopen_boot_scan;      // scan all node IDs

extern uint8_t         canopen_state;          // local copy of stack state
extern uint8_t         canopen_state_old;
extern uint16_t        canopen_configbits;     // config bits of the stack
extern uint16_t        canopen_configbits_old; // config bits of the stack
extern uint8_t         canopen_guarding_error;  // guarding error found
extern uint8_t         canopen_guarding_error_old;
extern uint8_t         canopen_sync_error;      // sync error found
extern uint8_t         canopen_sync_error_old;
extern uint16_t        canopen_tx_overflows;     // Errorcounter send buffer full
extern uint16_t        canopen_tx_overflows_old;     // Errorcounter send buffer full

extern pthread_mutex_t canopen_mutex_rx_msg;            		// mutex for Layer2 data
extern uint32_t        canopen_rx_mask[CANOPEN_L2_MASK_IDS];    // Layer2 RX id filter
extern uint32_t        canopen_rx_entry[CANOPEN_L2_MASK_IDS][8];// Layer2 RX entrys for id
extern uint32_t        canopen_rx_num[CANOPEN_L2_MASK_IDS];     // Layer2 RX number of entrys
extern uint32_t        canopen_rx_count[CANOPEN_L2_MASK_IDS];   // Layer2 RX counter
extern uint8_t         canopen_rx_dlc[CANOPEN_L2_MESSAGES];     // Layer2 RX length
extern uint8_t         canopen_rx_msg[CANOPEN_L2_MESSAGES][8];  // Buffer for Layer2 messages
extern uint16_t        canopen_rx_l2_overflows;          // Errorcounter Layer2 messages
extern uint16_t        canopen_tx_l2_overflows;          // Errorcounter Layer2 messages
extern uint16_t        canopen_tx_l2_overflows_old;          // Errorcounter Layer2 messages
extern uint16_t        canopen_tx_l2_timeouts;           // Errorcounter Layer2 messages
extern uint32_t        canopen_rx_masks_used;            // filter length

extern uint32_t        canopen_rx_mask_all;              // get all messages on bus
extern uint32_t        canopen_rx_num_all;               // Layer2 RX number of entrys
extern uint32_t        canopen_rx_count_all;             // Layer2 RX counter
extern uint32_t        canopen_rx_id[CANOPEN_L2_MESSAGES];// Layer2 RX id

extern int32_t         canopen_nodes_config; // Nodes with config done
extern int32_t         canopen_last_node;    // Slave nodes
extern int32_t         canopen_config_fail;  // fatal error in configuration
extern int             canopen_restart;      // master restart because of init failed
extern uint16_t        canopen_operational_nodes;// nodes operational*/
extern uint16_t        canopen_configured_nodes; // nodes booted and configured

extern uint16_t        canopen_tpdos;
extern uint16_t        canopen_rpdos;
extern uint16_t        canopen_tpdo_index;
extern uint16_t        canopen_rpdo_index;
extern uint8_t         canopen_node_id;
extern uint8_t         canopen_node_id_config;

extern uint8_t         canopen_plc_control;     // start if plc start and stop if plc stopped
extern uint8_t         canopen_autostart;       // state of the plc start/stop control
extern uint8_t         canopen_dal_failure;     // for dal watchdog

extern uint32_t        canopen_start_delay;       // start rx delay counter
extern uint32_t        canopen_start_delay_set;   // start rx delay start value

extern uint8_t         canopen_startflags;      // entry for object 1F80 to start master
extern uint8_t         canopen_node2ID[128];

extern uint16_t        canopen_busoffs;         // bus-off count
extern uint16_t        canopen_tx_timeouts;     // bus-message acknowledge timeouts
extern uint16_t        canopen_rx_overflows;    // lost message rx
extern uint16_t        canopen_buswarns;        // bus-warning level count
extern uint16_t        canopen_buserrors;       // controler error count

extern uint16_t        canopen_ledcounter;
extern uint32_t        canopen_led_msg;         // actual state of the can led
extern uint32_t        canopen_led_msg_new;     // transfer state of the can led
extern uint16_t        canopen_autoreset;       // Busoff timer for slave or layer2

extern uint8_t         canopen_l2mode;          // only layer 2 communication
extern uint16_t        canopen_l2led;           // set LED via layer 2 lib

extern uint32_t        canopen_time;            // for timestamp object
extern uint16_t        canopen_day;             //
extern uint32_t        canopen_timeflags;       //

extern int32_t         canopen_timestamp_intervall;    // Timecode producer for CANopen

extern uint8_t         canopen_led_panelmode;   // no can led present

extern char  		       canopen_unconfigured;    // temporary invalid configuration
extern char            canopen_cputype;         // 0: for AM3505 (8203,8204,8206) 1: AM335x (8208,8216..)
extern char            canopen_lowprio;         // for profinet priority


extern char            canopen_update_pdos;       // check all Tx PDOs on transition preop to op


//-----------------------------------------------------------------------------
//   prototypes for Library -Interface functions and vars
//-----------------------------------------------------------------------------

extern char   canopen_libmode;    // Init = 0 Master = 1 Slave = 2 Layer2 = 3
extern char   canopen_initmode;   // Init = 0 Config OK = 1
extern char   canopen_libfnlist;  // Function list for device specific funktions
extern uint8_t canopen_inithw;    // Marker for stack hardware state
extern int    canopen_irqset;     // can irq seting control


// node number and IDs infos
extern int32_t canopen_last_node;          // last slave node for master
extern uint8_t canopen_last_guard_error_node;
extern uint16_t canopen_operational_nodes;
extern uint32_t canopen_baudrate;


extern uint8_t canopen_node_id;        // node ID of master or slave
extern uint8_t canopen_mastermode;     // node is running as master
extern int32_t canopen_watchdog_set_ms;// watchdog for CANopen
extern int32_t canopen_watchdog_ms;
extern int32_t canopen_watchdog_sys_ms;// watchdog from Codesys
extern int32_t canopen_watchdog_sys_factor;


// for Object 1F51 Programm control
extern uint8_t  canopen_program_control;
extern uint8_t  canopen_program_old;
extern uint8_t  canopen_program_set;

/* for async SDO handling */
extern uint8_t canopen_async_SDO_state[CANOPEN_CSDO_CHANNELS];

// layer2 stack externals
extern int      canopen_l2stack_rx_state;


//-----------------------------------------------------------------------------
//   globals functions from stack_canopen
//-----------------------------------------------------------------------------

int32_t canopen_sdo_write(uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t * data, uint32_t dw_timeout);
int32_t canopen_sdo_read (uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t * data, uint32_t dw_timeout);
int32_t canopen_sdo_write_async(uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t * data, uint32_t dw_timeout,uint16_t channel);
int32_t canopen_sdo_read_async (uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t * data, uint32_t dw_timeout,uint16_t channel);
int32_t canopen_cmd_state (uint8_t b_com,uint8_t b_para);
int32_t canopen_send_usertimestamp (canopen_device_timestamp * tmstamp);
int32_t canopen_send_timestamp(void);
int32_t canopen_get_timestamp (canopen_device_timestamp * tmstamp);
int32_t canopen_open_stack(uint8_t b_node_id,uint8_t b_baudrate_index,uint8_t b_txprio);
void canopen_reset_stack(void);
void canopen_close_stack(void);
int32_t canopen_init_stack(void);
int32_t canopen_add_dcf(uint8_t l_dcf[],uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t l_data[]);
int32_t canopen_send_emc(uint16_t err_code, uint8_t err_reg, uint8_t * manufac_err);

int32_t canopen_lib_send_frame (uint32_t id, uint8_t data[], uint8_t dlc);
int32_t canopen_lib_send_frame_wait(uint32_t id, uint8_t * data, uint8_t dlc,uint32_t timeout);
int32_t canopen_lib_send_frame_ext(uint32_t id, uint8_t * data, uint8_t dlc);
int32_t canopen_lib_send_frame_ext_wait(uint32_t id, uint8_t * data, uint8_t dlc,uint32_t timeout);

int32_t canopen_lib_get_framecount(uint32_t id);
int32_t canopen_lib_get_framecount_ext(uint32_t id);
int32_t canopen_lib_get_framecounter(uint32_t id);
int32_t canopen_lib_get_framecounter_ext(uint32_t id);

int32_t canopen_lib_get_frame (uint32_t * id, uint8_t data[]);
int32_t canopen_lib_get_frame_ext(uint32_t * id, uint8_t * data);
int32_t canopen_lib_get_frame_wait(uint32_t * id, uint8_t * data,uint32_t timeout);
int32_t canopen_lib_get_frame_ext_wait(uint32_t * id, uint8_t * data,uint32_t timeout);

int32_t canopen_lib_register_id (uint32_t id);
int32_t canopen_lib_register_id_ext (uint32_t id);
int32_t canopen_lib_unregister_id (uint32_t id);
int32_t canopen_lib_unregister_id_ext (uint32_t id);

int32_t canopen_reset_all_TxPDOs(void);
int32_t canopen_reset_TxPDO(uint16_t index);
void    canopen_test_nodes_operational(void);
int32_t	canopen_load_lss(void);
void 	canopen_store_lss(void);
void    canopen_update_lss(char new_nodeid);


// SDO-Interface
int32_t canopen_lib_sdo_write (uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t b_bytes,uint8_t l_data[],uint32_t dw_timeout);
int32_t canopen_lib_sdo_read (uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t * data,uint32_t dw_timeout);

// SDO-Interface Async
int32_t canopen_lib_sdo_write_async (uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t b_bytes,uint8_t l_data[],uint32_t dw_timeout,uint8_t channel);
int32_t canopen_lib_sdo_read_async (uint8_t b_node_id,uint16_t w_index,uint8_t b_sidx,uint16_t w_bytes,uint8_t * data,uint32_t dw_timeout,uint8_t channel);

// SDO_User
extern uint8_t canopen_SDO_User_NewData;
uint32_t canopen_lib_SDO_ReadData(uint16_t index, uint8_t subindex, uint16_t datalen,  uint8_t databytes[]);
uint32_t canopen_lib_SDO_WriteData(uint16_t index, uint8_t subindex, uint16_t datalen, uint8_t databytes[]);

void canopen_lib_SDO_Init(void);
uint32_t canopen_lib_SDO_Add(uint16_t index, uint16_t entrys, uint16_t datalen, uint16_t type, uint16_t offset);

// Command-Interface
int32_t canopen_lib_cmd_state (uint8_t b_com,uint8_t b_para);
int32_t canopen_lib_send_timestamp (canopen_device_timestamp * tmstamp);
int32_t canopen_lib_get_timestamp (canopen_device_timestamp * tmstamp);

// Diagnostic-Interface
int32_t canopen_lib_get_node_diag (uint8_t can_slave_id);
int32_t canopen_lib_get_node_diag_ide (uint8_t can_slave_id);
int32_t canopen_lib_get_node_emc_msg(uint8_t can_slave_id,uint8_t emc_msg[],uint8_t remove);
int32_t canopen_lib_guard_error(void);
int32_t canopen_lib_node_guard_error(uint8_t slave_id);

int32_t canopen_lib_get_emc_msg (uint8_t emc_msg[],uint8_t remove);  // test for new message on any slave
int32_t canopen_lib_send_emc(uint16_t err_code, uint8_t err_reg, uint8_t * manufac_err);


int32_t canopen_lib_read_bit(uint32_t offset, uint8_t *buf);
int32_t canopen_lib_read_bytes(uint32_t offset, uint32_t size, uint8_t *buf);
int32_t canopen_lib_write_bit(uint32_t offset, uint8_t *buf);
int32_t canopen_lib_write_bytes(uint32_t offset, uint32_t size, uint8_t *buf);
int32_t canopen_lib_write_start(void);
int32_t canopen_lib_write_end(void);

int32_t canopen_lib_clear_pi_in(void); // clear input process image

void canopen_lib_update_defaults(canopen_bus_config *canopen_config);// copy config top stack internal config

// led server interface
void canopen_led_update(void);
void canopen_led_configstate(uint8_t error);
void canopen_led_init(void);
void canopen_led_set_direct(void);
void canopen_led_exit(void);
void canopen_led_string(char * logstr);
int  canopen_system(char* inputstring);
int  canopen_find_irq(void);
void *canopen_led_loop(void *ptr);


// stack main loops
void canopen_mainloop(void);
void canopen_timerloop(void);

// layer2 Stack
int32_t canopen_start_l2stack(uint32_t baudrate);
int32_t canopen_reset_l2stack(void);
int32_t canopen_close_l2stack(void);
int32_t canopen_lib_send_frame_l2stack(uint32_t id, uint8_t * data, uint8_t dlc,uint32_t timeout);

// set can (kernel) driver irq thread priority
void canopen_set_irq_thread_priority(void);

//-----------------------------------------------------------------------------
//   prototypes for ADI-Functions
//-----------------------------------------------------------------------------

tFnDescr *canopen_GetDeviceSpecificFnList(void);
tFnDescr *canopen_GetDeviceSpecificFnListNull(void);

//-----------------------------------------------------------------------------
//   prototypes for SDI-Functions
//-----------------------------------------------------------------------------

// init of CANopen master, slave  and layer2 interface
int32_t libcanopenm_open(struct stStackDeviceInterface *device,struct stDalSystemInterface *dal_sys);
int32_t libcanopens_open(struct stStackDeviceInterface *device,struct stDalSystemInterface *dal_sys);
int32_t libcanlayer2_open(struct stStackDeviceInterface *device,struct stDalSystemInterface *dal_sys);

#endif
