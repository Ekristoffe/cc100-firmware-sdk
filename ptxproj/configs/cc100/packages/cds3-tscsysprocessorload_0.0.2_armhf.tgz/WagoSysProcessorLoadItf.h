 /**
 * <interfacename>WagoSysProcessorLoad</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSPROCESSORLOADITF_H_
#define _WAGOSYSPROCESSORLOADITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>fbsysprocessorload__main</description>
 */
typedef struct tagfbsysprocessorload_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of FbSysProcessorLoad */

	RTS_IEC_USINT usiLoad;				/* VAR_OUTPUT */	/* current processor load in percent */
	RTS_IEC_UDINT _udiInterval_us;		/* Local variable */	/* measurement cycle for the cpu load */
	RTS_IEC_USINT _usiThreshold1;		/* Local variable */	/* Threshold1 in percent. */
	RTS_IEC_USINT _usiThreshold2;		/* Local variable */	/* Threshold2 in percent. */
	RTS_IEC_USINT _usiIecShare;			/* Local variable */	/* Max processor load in percent. */
	RTS_IEC_UDINT _udiOverloadTriggerLevel;	/* Local variable */	/* count of measurment cycles before overload action is triggert. */
	RTS_IEC_USINT _usiLoad;				/* Local variable */	
	RTS_IEC_BOOL _bHandleOverloadEvent;	/* Local variable */	
	RTS_IEC_INT _eOverloadAction;		/* Local variable */	/* action in case an overload is detected (i.e. current load is above upper limit) */
	RTS_IEC_INT _eLogLevel;				/* Local variable */	/* specifies how changes to the processor load get logged. */
	RTS_IEC_HANDLE _hTask;				/* Local variable */	/* implementation specifics */
	RTS_IEC_HANDLE _hPrivate;			/* Local variable */	
} fbsysprocessorload_struct;

/**
 * <description>fbsysprocessorload_initload</description>
 */
typedef struct tagfbsysprocessorload_initload_struct
{
	fbsysprocessorload_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	/* if TRUE, the retain variables are initialized (warm start / cold start) */
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* if TRUE, the instance afterwards gets moved into the copy code (online change) */
	RTS_IEC_UDINT udiInterval_us;		/* VAR_INPUT */	/* measurement cycle for the cpu load				[250000 - ... ] */
	RTS_IEC_USINT usiThreshold1;	/* VAR_INPUT */	/* Threshold1 in percent ( 0 <= **usiThreshold1** <= *usiThreshold2* <= *usiIecShare* <= 100) */
	RTS_IEC_USINT usiThreshold2;	/* VAR_INPUT */	/* Threshold2 in percent ( 0 <= *usiThreshold1* <= **usiThreshold2** <= *usiIecShare* <= 100) */
	RTS_IEC_USINT usiIecShare;	/* VAR_INPUT */	/* Max processor load in percent ( 0 <= *usiThreshold1* <= *usiThreshold2* <= **usiIecShare** <= 100) */
	RTS_IEC_UDINT udiOverloadTriggerLevel;	/* VAR_INPUT */	/* count of measurment cycles before overload action is triggered. [0 - ..] */
	RTS_IEC_INT eOverloadAction;		/* VAR_INPUT, Enum: EOVERLOADACTION */
	RTS_IEC_BOOL bHandleOverloadEvent;	/* VAR_INPUT */	
	RTS_IEC_INT eLogLevel;				/* VAR_INPUT, Enum: ELOGLEVEL */
} fbsysprocessorload_initload_struct;

void CDECL CDECL_EXT fbsysprocessorload__initload(fbsysprocessorload_initload_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSYSPROCESSORLOAD__INITLOAD_IEC) (fbsysprocessorload_initload_struct *p);
#if defined(WAGOSYSPROCESSORLOAD_NOTIMPLEMENTED) || defined(FBSYSPROCESSORLOAD__INITLOAD_NOTIMPLEMENTED)
	#define USE_fbsysprocessorload__initload
	#define EXT_fbsysprocessorload__initload
	#define GET_fbsysprocessorload__initload(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbsysprocessorload__initload(p0) 
	#define CHK_fbsysprocessorload__initload  FALSE
	#define EXP_fbsysprocessorload__initload  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbsysprocessorload__initload
	#define EXT_fbsysprocessorload__initload
	#define GET_fbsysprocessorload__initload(fl)  CAL_CMGETAPI( "fbsysprocessorload__initload" ) 
	#define CAL_fbsysprocessorload__initload  fbsysprocessorload__initload
	#define CHK_fbsysprocessorload__initload  TRUE
	#define EXP_fbsysprocessorload__initload  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__initload", (RTS_UINTPTR)fbsysprocessorload__initload, 1, 0x925CF62B, 0x02000102) 
	#define EXTREF_ITF_fbsysprocessorload__initload {(RTS_VOID_FCTPTR)fbsysprocessorload__initload, "fbsysprocessorload__initload", 0x925CF62B, 0x02000102}
#elif defined(MIXED_LINK) && !defined(WAGOSYSPROCESSORLOAD_EXTERNAL)
	#define USE_fbsysprocessorload__initload
	#define EXT_fbsysprocessorload__initload
	#define GET_fbsysprocessorload__initload(fl)  CAL_CMGETAPI( "fbsysprocessorload__initload" ) 
	#define CAL_fbsysprocessorload__initload  fbsysprocessorload__initload
	#define CHK_fbsysprocessorload__initload  TRUE
	#define EXP_fbsysprocessorload__initload  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__initload", (RTS_UINTPTR)fbsysprocessorload__initload, 1, 0x925CF62B, 0x02000102) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysProcessorLoadfbsysprocessorload__initload
	#define EXT_WagoSysProcessorLoadfbsysprocessorload__initload
	#define GET_WagoSysProcessorLoadfbsysprocessorload__initload  ERR_OK
	#define CAL_WagoSysProcessorLoadfbsysprocessorload__initload  fbsysprocessorload__initload
	#define CHK_WagoSysProcessorLoadfbsysprocessorload__initload  TRUE
	#define EXP_WagoSysProcessorLoadfbsysprocessorload__initload  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__initload", (RTS_UINTPTR)fbsysprocessorload__initload, 1, 0x925CF62B, 0x02000102) 
#elif defined(CPLUSPLUS)
	#define USE_fbsysprocessorload__initload
	#define EXT_fbsysprocessorload__initload
	#define GET_fbsysprocessorload__initload(fl)  CAL_CMGETAPI( "fbsysprocessorload__initload" ) 
	#define CAL_fbsysprocessorload__initload  fbsysprocessorload__initload
	#define CHK_fbsysprocessorload__initload  TRUE
	#define EXP_fbsysprocessorload__initload  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__initload", (RTS_UINTPTR)fbsysprocessorload__initload, 1, 0x925CF62B, 0x02000102) 
#else /* DYNAMIC_LINK */
	#define USE_fbsysprocessorload__initload  PFFBSYSPROCESSORLOAD__INITLOAD_IEC pffbsysprocessorload__initload;
	#define EXT_fbsysprocessorload__initload  extern PFFBSYSPROCESSORLOAD__INITLOAD_IEC pffbsysprocessorload__initload;
	#define GET_fbsysprocessorload__initload(fl)  s_pfCMGetAPI2( "fbsysprocessorload__initload", (RTS_VOID_FCTPTR *)&pffbsysprocessorload__initload, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x925CF62B, 0x02000102)
	#define CAL_fbsysprocessorload__initload  pffbsysprocessorload__initload
	#define CHK_fbsysprocessorload__initload  (pffbsysprocessorload__initload != NULL)
	#define EXP_fbsysprocessorload__initload   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__initload", (RTS_UINTPTR)fbsysprocessorload__initload, 1, 0x925CF62B, 0x02000102) 
#endif


/**
 * <description>fbsysprocessorload_fb_exit</description>
 */
typedef struct tagfbsysprocessorload_fb_exit_struct
{
	fbsysprocessorload_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* if TRUE, the exit method is called for exiting an instance that is copied afterwards (online change). */
	RTS_IEC_BOOL FB_exit;				/* VAR_OUTPUT */	
} fbsysprocessorload_fb_exit_struct;

void CDECL CDECL_EXT fbsysprocessorload__fb_exit(fbsysprocessorload_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSYSPROCESSORLOAD__FB_EXIT_IEC) (fbsysprocessorload_fb_exit_struct *p);
#if defined(WAGOSYSPROCESSORLOAD_NOTIMPLEMENTED) || defined(FBSYSPROCESSORLOAD__FB_EXIT_NOTIMPLEMENTED)
	#define USE_fbsysprocessorload__fb_exit
	#define EXT_fbsysprocessorload__fb_exit
	#define GET_fbsysprocessorload__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbsysprocessorload__fb_exit(p0) 
	#define CHK_fbsysprocessorload__fb_exit  FALSE
	#define EXP_fbsysprocessorload__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbsysprocessorload__fb_exit
	#define EXT_fbsysprocessorload__fb_exit
	#define GET_fbsysprocessorload__fb_exit(fl)  CAL_CMGETAPI( "fbsysprocessorload__fb_exit" ) 
	#define CAL_fbsysprocessorload__fb_exit  fbsysprocessorload__fb_exit
	#define CHK_fbsysprocessorload__fb_exit  TRUE
	#define EXP_fbsysprocessorload__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__fb_exit", (RTS_UINTPTR)fbsysprocessorload__fb_exit, 1, 0x3DBBB01D, 0x02000102) 
	#define EXTREF_ITF_fbsysprocessorload__fb_exit {(RTS_VOID_FCTPTR)fbsysprocessorload__fb_exit, "fbsysprocessorload__fb_exit", 0x3DBBB01D, 0x02000102}
#elif defined(MIXED_LINK) && !defined(WAGOSYSPROCESSORLOAD_EXTERNAL)
	#define USE_fbsysprocessorload__fb_exit
	#define EXT_fbsysprocessorload__fb_exit
	#define GET_fbsysprocessorload__fb_exit(fl)  CAL_CMGETAPI( "fbsysprocessorload__fb_exit" ) 
	#define CAL_fbsysprocessorload__fb_exit  fbsysprocessorload__fb_exit
	#define CHK_fbsysprocessorload__fb_exit  TRUE
	#define EXP_fbsysprocessorload__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__fb_exit", (RTS_UINTPTR)fbsysprocessorload__fb_exit, 1, 0x3DBBB01D, 0x02000102) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysProcessorLoadfbsysprocessorload__fb_exit
	#define EXT_WagoSysProcessorLoadfbsysprocessorload__fb_exit
	#define GET_WagoSysProcessorLoadfbsysprocessorload__fb_exit  ERR_OK
	#define CAL_WagoSysProcessorLoadfbsysprocessorload__fb_exit  fbsysprocessorload__fb_exit
	#define CHK_WagoSysProcessorLoadfbsysprocessorload__fb_exit  TRUE
	#define EXP_WagoSysProcessorLoadfbsysprocessorload__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__fb_exit", (RTS_UINTPTR)fbsysprocessorload__fb_exit, 1, 0x3DBBB01D, 0x02000102) 
#elif defined(CPLUSPLUS)
	#define USE_fbsysprocessorload__fb_exit
	#define EXT_fbsysprocessorload__fb_exit
	#define GET_fbsysprocessorload__fb_exit(fl)  CAL_CMGETAPI( "fbsysprocessorload__fb_exit" ) 
	#define CAL_fbsysprocessorload__fb_exit  fbsysprocessorload__fb_exit
	#define CHK_fbsysprocessorload__fb_exit  TRUE
	#define EXP_fbsysprocessorload__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__fb_exit", (RTS_UINTPTR)fbsysprocessorload__fb_exit, 1, 0x3DBBB01D, 0x02000102) 
#else /* DYNAMIC_LINK */
	#define USE_fbsysprocessorload__fb_exit  PFFBSYSPROCESSORLOAD__FB_EXIT_IEC pffbsysprocessorload__fb_exit;
	#define EXT_fbsysprocessorload__fb_exit  extern PFFBSYSPROCESSORLOAD__FB_EXIT_IEC pffbsysprocessorload__fb_exit;
	#define GET_fbsysprocessorload__fb_exit(fl)  s_pfCMGetAPI2( "fbsysprocessorload__fb_exit", (RTS_VOID_FCTPTR *)&pffbsysprocessorload__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3DBBB01D, 0x02000102)
	#define CAL_fbsysprocessorload__fb_exit  pffbsysprocessorload__fb_exit
	#define CHK_fbsysprocessorload__fb_exit  (pffbsysprocessorload__fb_exit != NULL)
	#define EXP_fbsysprocessorload__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__fb_exit", (RTS_UINTPTR)fbsysprocessorload__fb_exit, 1, 0x3DBBB01D, 0x02000102) 
#endif


/**
 * <description>fbsysprocessorload_main</description>
 */
typedef struct tagfbsysprocessorload_main_struct
{
	fbsysprocessorload_struct *pInstance;	/* VAR_INPUT */	
} fbsysprocessorload_main_struct;

void CDECL CDECL_EXT fbsysprocessorload__main(fbsysprocessorload_main_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSYSPROCESSORLOAD__MAIN_IEC) (fbsysprocessorload_main_struct *p);
#if defined(WAGOSYSPROCESSORLOAD_NOTIMPLEMENTED) || defined(FBSYSPROCESSORLOAD__MAIN_NOTIMPLEMENTED)
	#define USE_fbsysprocessorload__main
	#define EXT_fbsysprocessorload__main
	#define GET_fbsysprocessorload__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbsysprocessorload__main(p0) 
	#define CHK_fbsysprocessorload__main  FALSE
	#define EXP_fbsysprocessorload__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbsysprocessorload__main
	#define EXT_fbsysprocessorload__main
	#define GET_fbsysprocessorload__main(fl)  CAL_CMGETAPI( "fbsysprocessorload__main" ) 
	#define CAL_fbsysprocessorload__main  fbsysprocessorload__main
	#define CHK_fbsysprocessorload__main  TRUE
	#define EXP_fbsysprocessorload__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__main", (RTS_UINTPTR)fbsysprocessorload__main, 1, 0x00C0FDA1, 0x02000102) 
	#define EXTREF_ITF_fbsysprocessorload__main {(RTS_VOID_FCTPTR)fbsysprocessorload__main, "fbsysprocessorload__main", 0x00C0FDA1, 0x02000102}
#elif defined(MIXED_LINK) && !defined(WAGOSYSPROCESSORLOAD_EXTERNAL)
	#define USE_fbsysprocessorload__main
	#define EXT_fbsysprocessorload__main
	#define GET_fbsysprocessorload__main(fl)  CAL_CMGETAPI( "fbsysprocessorload__main" ) 
	#define CAL_fbsysprocessorload__main  fbsysprocessorload__main
	#define CHK_fbsysprocessorload__main  TRUE
	#define EXP_fbsysprocessorload__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__main", (RTS_UINTPTR)fbsysprocessorload__main, 1, 0x00C0FDA1, 0x02000102) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysProcessorLoadfbsysprocessorload__main
	#define EXT_WagoSysProcessorLoadfbsysprocessorload__main
	#define GET_WagoSysProcessorLoadfbsysprocessorload__main  ERR_OK
	#define CAL_WagoSysProcessorLoadfbsysprocessorload__main  fbsysprocessorload__main
	#define CHK_WagoSysProcessorLoadfbsysprocessorload__main  TRUE
	#define EXP_WagoSysProcessorLoadfbsysprocessorload__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__main", (RTS_UINTPTR)fbsysprocessorload__main, 1, 0x00C0FDA1, 0x02000102) 
#elif defined(CPLUSPLUS)
	#define USE_fbsysprocessorload__main
	#define EXT_fbsysprocessorload__main
	#define GET_fbsysprocessorload__main(fl)  CAL_CMGETAPI( "fbsysprocessorload__main" ) 
	#define CAL_fbsysprocessorload__main  fbsysprocessorload__main
	#define CHK_fbsysprocessorload__main  TRUE
	#define EXP_fbsysprocessorload__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__main", (RTS_UINTPTR)fbsysprocessorload__main, 1, 0x00C0FDA1, 0x02000102) 
#else /* DYNAMIC_LINK */
	#define USE_fbsysprocessorload__main  PFFBSYSPROCESSORLOAD__MAIN_IEC pffbsysprocessorload__main;
	#define EXT_fbsysprocessorload__main  extern PFFBSYSPROCESSORLOAD__MAIN_IEC pffbsysprocessorload__main;
	#define GET_fbsysprocessorload__main(fl)  s_pfCMGetAPI2( "fbsysprocessorload__main", (RTS_VOID_FCTPTR *)&pffbsysprocessorload__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x00C0FDA1, 0x02000102)
	#define CAL_fbsysprocessorload__main  pffbsysprocessorload__main
	#define CHK_fbsysprocessorload__main  (pffbsysprocessorload__main != NULL)
	#define EXP_fbsysprocessorload__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbsysprocessorload__main", (RTS_UINTPTR)fbsysprocessorload__main, 1, 0x00C0FDA1, 0x02000102) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysProcessorLoad_C;

#ifdef CPLUSPLUS
class IWagoSysProcessorLoad : public IBase
{
	public:
};
	#ifndef ITF_WagoSysProcessorLoad
		#define ITF_WagoSysProcessorLoad static IWagoSysProcessorLoad *pIWagoSysProcessorLoad = NULL;
	#endif
	#define EXTITF_WagoSysProcessorLoad
#else	/*CPLUSPLUS*/
	typedef IWagoSysProcessorLoad_C		IWagoSysProcessorLoad;
	#ifndef ITF_WagoSysProcessorLoad
		#define ITF_WagoSysProcessorLoad
	#endif
	#define EXTITF_WagoSysProcessorLoad
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSPROCESSORLOADITF_H_*/
