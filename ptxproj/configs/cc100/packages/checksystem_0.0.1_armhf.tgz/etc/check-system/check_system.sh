#!/bin/bash

# WAGO GmbH & Co. KG
#
# Analysis script to check various system runtime things.
#######################################################################################################################


# Version
VERSION='2.2'

# Exit code value
EXIT_VALUE='0'

# Treat unset variables as an error when substituting
set -u

# Load configuration script
# Configuration includes services and additional custom tests to check
. /etc/check-system/configuration

# Script functions
#######################################################################################################################

function get_datetime () {
	date -u "+%F %T"
}

function echolog () {
	# Log arguments
	local LOGSTRING=$(echo -e "$@")
	
	if [ -n "$LOG_DIR" ]; then
		mkdir -p "$LOG_DIR"
		echo "$(get_datetime) $LOGSTRING" >> "$LOG_DIR/check-system.log"
	else
		logger -t "check-system" "$LOGSTRING"
	fi

	# Print also to stdout
	echo "$LOGSTRING"
}

function echoerror () {
	if [ "$LOG_LEVEL" -gt "0"  ]; then
		echolog "$@"
	fi
}

function echowarn () {
	if [ "$LOG_LEVEL" -gt "1"  ]; then
		echolog "$@"
	fi
}

function echoinfo () {
	if [ "$LOG_LEVEL" -gt "2"  ]; then
		echolog "$@"
	fi
}

function get_uptime {
	uptime=$(awk -F '.' '{ print $1 }' /proc/uptime)
	echo -n "$uptime"
}

function backup_logs {
	if [ -n "$LOG_BACKUP_DIR" ]; then

		local LOGPATH=$(grep "export LOGPATH=" /etc/init.d/syslog-ng | sed -n 's/export LOGPATH=\"\(.*\)\"/\1/p')
		local curdtime=$(date "+%Y%m%d_%H%M%S")
		local diskavail=$(df $LOG_BACKUP_DIR | awk '/^\/dev/ { print $4 }')

		echoerror "ERROR: collecting log files and system information"
		mkdir -p "$LOG_BACKUP_DIR"
		[ -e "$LOG_BACKUP_DIR/logs.tgz" ] && mv "$LOG_BACKUP_DIR/logs.tgz" "$LOG_BACKUP_DIR/logs.tgz.pre"
		sync

		# Keep all logs if LOG_KEEP_FILES is set to "true" as long as file system
		# has 1 meg free space at least
		if [ "$diskavail" -gt "1000" ]; then
			[ -e "$LOG_BACKUP_DIR/logs.tgz.pre" ] && [ "$LOG_KEEP_FILES" = "true" ] && mv "$LOG_BACKUP_DIR/logs.tgz.pre" "$LOG_BACKUP_DIR/logs.tgz.$curdtime"
		fi
		uname -a > /tmp/sysinfo.log
		cat /etc/REVISIONS >> /tmp/sysinfo.log
		[ -x /etc/config-tools/get_typelabel_value ] && /etc/config-tools/get_typelabel_value -a >> /tmp/sysinfo.log

		ps auxf > /tmp/ps_aux.log
		dmesg > /tmp/dmesg.log
		cat /proc/meminfo > /tmp/meminfo.log
		cat /proc/buddyinfo > /tmp/buddyinfo.log
		cat /proc/pagetypeinfo > /tmp/pagetypeinfo.log
		cat /proc/slabinfo > /tmp/slabinfo.log
		cat /proc/vmallocinfo > /tmp/vmallocinfo.log

		tar czf "$LOG_BACKUP_DIR/logs.tgz" "$LOGPATH" /tmp/*.log
		sync
	fi
}

# wrap config tool to check runtime version currently configured
function get_runtime_status {
    local version=$1
    if [ "$(/etc/config-tools/get_runtime_config running-version)" -eq "$version" ]; then
        echo "enabled"
    else
        echo "disabled"
    fi
}

function fail_exit () {
	backup_logs
	EXIT_VALUE='1'
	if [ "$EXIT_ON_ERROR" -gt "0" ]; then
		echoinfo "### ERROR ABORT $(get_datetime) (UTC) ###"
		echoinfo ""
		exit $EXIT_VALUE
	fi
}

# param: process_name
function get_process_id () {
	# returns pid or 0
	result=$(pidof "$1")
	if [ "$result" = "" ] ; then
		echo -n "0"
	else
		echo -n "$result"
	fi
}

# param: process_name
function is_process_running () {
	pid=$(get_process_id "$1")
	if [ "$pid" = "0" ] ; then
		echo -n "1";
	else
		echo -n "0";
	fi
}

# param: file_name
function get_file_owner () {
	if [ -e "$1" ] ; then
		owner=`ls -alh "$1" |  awk '{ print $3":"$4 }'`
	else
		owner=''
	fi
	echo -n "$owner"
}

# param: file_name, owner
function set_file_owner () {
	if [ -e "$1" ] ; then
		RESULT=`chown "$2" "$1"`
		echo -n $?
	else
		echo -n 0
	fi
}

# param: file_name
function get_file_permission () {
	if [ -e "$1" ] ; then
		perm=`stat -L "$1" |  grep Uid | awk '{ print $2 }' | awk -F '(' '{print $2}' | awk -F '/' '{ print $1 }'`
	else
		perm=''
	fi
	echo -n "$perm"
}

# param: file_name, permissions
function set_file_permission () {
	if [ -e "$1" ] ; then
		RESULT=`chmod "$2" "$1"`
		echo -n $?
	else
		echo -n 0
	fi
}

# If busybox watchdog is running, kill it and retrigger to get 10s runtime
# Depends on /etc/init.d/watchdogbb
function check_kill_watchdog {
	local wdpid=$(pidof watchdog)
	local wdexecpath=$(readlink /proc/$wdpid/exe)

	if [ "$wdexecpath" = "/bin/busybox" ]; then
		kill -9 $wdpid
		while [ -d "/proc/$wdpid" ]; do
			usleep 500000
		done

		# retrigger watchdog timer, gives 10 seconds
		echo "A" > "$WATCHDOGDEV"
		return 0
	fi
	return 1
}

function get_free_mem {
	echo -n `cat /proc/meminfo | grep MemFree | awk '{print $2}'`
}

function get_available_mem {
	echo -n `cat /proc/meminfo | grep MemAvailable | awk '{print $2}'`
}

function check_file () {
	if [ -e "$1" ] ; then
		md5_ist=`md5sum "$1" | awk '{ print $1 }'`
		md5_soll=`md5sum "$2" | awk '{ print $1 }'`
				
		if [ "$md5_ist" = "$md5_soll" ] ; then
			echo -n "0"
		else
			echo -n "1"
		fi
	else
		echo -n "1"
	fi
}

function restore_file () {
	if [ -e "$2" ] ; then
		cp -a "$2" "$1"
		echo -n "$?"
	else
		echo -n "1"
	fi
}

function check_files {
	if [ -n "${FILE[*]}" ]
	then
		last_file=$((${#FILE[@]} / 6))
		declare -a file
		for i in `seq "$last_file"` ; do
	
			file[0]=${FILE[$((i*10+0))]} # file name
			file[1]=${FILE[$((i*10+1))]} # config file path
			file[2]=${FILE[$((i*10+2))]} # should restore 
			file[3]=${FILE[$((i*10+3))]} # backup file path
			file[4]=${FILE[$((i*10+4))]} # file permission
			file[5]=${FILE[$((i*10+5))]} # file owner
	
			# exists backup file?
			if [ -e "${file[3]}" ] ; then
				RESULT=$(check_file "${file[1]}" "${file[3]}")
				if [ "$RESULT" = "0" ] ; then
					# files are equal
					echoinfo "OK: file ${file[1]} is valid"
				else
					# no action, just log!
					echoerror "ERROR: file ${file[1]} is NOT valid"
					
					if [ "${file[2]}" = "1" ] ; then
						RESULT=$(restore_file "${file[1]}" "${file[3]}")
						if [ "$RESULT" = "0" ] ; then
							echoinfo "DONE: config file ${file[1]} restored"
							# set owner and permission
							RESULT=$(set_file_permission "${file[1]}" "${file[4]}")
							RESULT=$(set_file_owner "${file[1]}" "${file[5]}")
							echoinfo "DONE: owner and permission set correctly"
						else
							echoerror "ERROR: error restoring ${file[1]}"
						fi
					fi
				fi
			else
				# backup file does not exist
				if [ "$AUTO_CREATE_BACKUP_FILES" -gt "0" ]; then
					# create backup folder
					mkdir -p "$(dirname ${file[3]})"
					# initially create backup file by copying original file
					RESULT=$(restore_file "${file[3]}" "${file[1]}")
				else
					echoerror "ERROR: backup file ${file[3]} does not exist"
				fi
			fi
		done
	fi
}

function check_services {
	if [ -n "${SERVICE[*]}" ]
	then
		last_service=$((${#SERVICE[@]} / 6))
		declare -a serv
		for i in $(seq "$last_service") ; do
	
			serv[0]=${SERVICE[$((i*10+0))]}
			serv[1]=${SERVICE[$((i*10+1))]}
			serv[2]=${SERVICE[$((i*10+2))]}
			serv[3]=${SERVICE[$((i*10+3))]}
			serv[4]=${SERVICE[$((i*10+4))]}
			serv[5]=${SERVICE[$((i*10+5))]}
	
			serviceconfstate=$(${serv[2]})
			[ "$serviceconfstate" = "disabled" ] && continue
			if [ $(is_process_running "${serv[0]}") != "0" ]; then
				# not running
				echoerror "ERROR: service '${serv[0]}' is not running"
				# should be running?
				case "${serv[1]}" in
				1)	echoinfo " run condition: always"
					# which start strategy to choose?
					case ${serv[4]} in
						0)	echoinfo " action: ignore"
							;;
						1)	echoinfo " action: restart service"
							${serv[5]}
							if [ $(is_process_running "${serv[0]}") = "0" ] ; then
								echoinfo " OK: service '${serv[0]}' is running"
							else
								echoerror " ERROR: service '${serv[0]}' still not running"
							fi
							;;
						2)	echoinfo " action: fail"
							fail_exit
							;;
						*)	echoinfo " unknown start strategy"
							;;
						esac
					;;
	
				2)	echoinfo " run condition: if_configured"
					# check in config if service is enabled
					case "$serviceconfstate" in
						"enabled" )	echoinfo " is configured as enabled"
								# which start strategy to choose?
								case "${serv[4]}" in
									0 )	echoinfo " action: ignore"
										;;
									1 )	echoinfo " action: restart service"
										${serv[5]}
										if [ $(is_process_running "${serv[0]}") = "0" ] ; then
											echoinfo " OK: service '${serv[0]}' is running"
										else
											echoerror " ERROR: service '${serv[0]}' still not running"
										fi
										;;
									2 )	echoinfo " action: fail"
										fail_exit
										;;
									* )	echoinfo " unknown start strategy"
								esac
								;;
						"disabled" )	echoinfo " is configured as disabled -> done"
								;;
						* )		echoinfo " unknown config status '$serviceconfstate'"
						;;
					esac
					;;
				*)	echoinfo " unknown run condition"
				esac
	
			else
				# is running - ok!
				echoinfo "OK: service '${serv[0]}' is running"
			fi
		done
		unset serv
	fi
}

function check_process_states {
	local pid
	local procname
	local logname
	# if watchdog is enabled kernel thread 'gpio-wdt-rt' is normally in D state therefor this thread is excluded from list
	local dproclist=$(ps aux | grep -v 'gpio-wdt-rt' | awk '{ if (index($8, "D")) printf(" %s", $2) }')
	local numdstates=$(echo $dproclist | wc -w)

	# log kernel stack backtrace for processes in state D
	for pid in $dproclist; do
		procname=$(awk '/^Name:/ {print $2}' /proc/$pid/status)
		#kernelthreads are named with "/" inside like "ksoftirqd/0" we need to take care of such names for the log
		procname=${procname/\//_}
		logname=$(printf "/tmp/%s-kstack.log" "$procname")
		cat /proc/$pid/stack > "$logname"
	done

	if [ "$numdstates" -gt "1" ]; then
		echoerror "ERROR: found $numdstates processes with state D - uninterruptible sleep"
		fail_exit
	elif [ "$numdstates" -gt "0" ]; then
		echowarn "WARN: one process in D state"
	else
		echoinfo "OK: no processes in D state"
	fi
}

function check_mem {
	if [ "$MIN_FREE_MEMORY" -ne "0" ]; then
		FREE_MEM=$(get_free_mem)
		if [ "$FREE_MEM" -lt "$MIN_FREE_MEMORY" ]; then
			echoerror "ERROR: free mem ($FREE_MEM kb) below $MIN_FREE_MEMORY kb."
			fail_exit
		else
			echoinfo "OK: free mem ($FREE_MEM kb) is over $MIN_FREE_MEMORY kb"
		fi
	fi
	
	if [ "$MIN_AVAILABLE_MEMORY" -ne "0" ]; then
		AVAILABLE_MEMORY=$(get_available_mem)
		if [ "$AVAILABLE_MEMORY" -lt "$MIN_AVAILABLE_MEMORY" ]; then
			echoerror "ERROR: available mem ($AVAILABLE_MEMORY kb) below $MIN_AVAILABLE_MEMORY kb."
			fail_exit
		else
			echoinfo "OK: available mem ($AVAILABLE_MEMORY kb) is over $MIN_AVAILABLE_MEMORY kb"
		fi
	fi
}

function check_threads {
	# https://askubuntu.com/a/88983
	local thread_count=$(ps -eo nlwp | tail -n +2 | awk '{ num_threads += $1 } END { print num_threads }')
	if [ "$thread_count" -gt "$MAX_THREADS" ]; then
		echoerror "ERROR: maximum number of threads exceeded ($thread_count/$MAX_THREADS running)."
		fail_exit
	else
		echoinfo "OK: number of threads below maximum ($thread_count/$MAX_THREADS running)."
	fi
}

function check_load_average {
	local max_1m=$(awk "BEGIN { printf(\"%i\", 100 * ${MAX_LOAD_AVERAGE_1M}) }")
	local max_5m=$(awk "BEGIN { printf(\"%i\", 100 * ${MAX_LOAD_AVERAGE_5M}) }")
	local max_15m=$(awk "BEGIN { printf(\"%i\", 100 * ${MAX_LOAD_AVERAGE_15M}) }")

	if [  "$max_1m" -gt "0" ] ; then
		local load_avg_1m_float=$(awk '{ printf($1) }' /proc/loadavg )
		local load_avg_1m=$(awk "BEGIN { printf(\"%i\", 100 * ${load_avg_1m_float}) }")
		if [ "$load_avg_1m" -gt "$max_1m" ] ; then
			echoerror "ERROR: maximum load average (1 min.) exceeded ($load_avg_1m_float / $MAX_LOAD_AVERAGE_1M)."
			fail_exit
		else
			echoinfo "OK: load average (1 min.) below maximum ($load_avg_1m_float / $MAX_LOAD_AVERAGE_1M)."
		fi
	fi

	if [  "$max_5m" -gt "0" ] ; then
		local load_avg_5m_float=$(awk '{ printf($2) }' /proc/loadavg )
		local load_avg_5m=$(awk "BEGIN { printf(\"%i\", 100 * ${load_avg_5m_float}) }")
		if [ "$load_avg_5m" -gt "$max_5m" ] ; then
			echoerror "ERROR: maximum load average (5 min.) exceeded  ($load_avg_5m_float / $MAX_LOAD_AVERAGE_5M)."
			fail_exit
		else
			echoinfo "OK: load average (5 min.) below maximum ($load_avg_5m_float / $MAX_LOAD_AVERAGE_5M)."
		fi
	fi

	if [  "$max_15m" -gt "0" ] ; then
		local load_avg_15m_float=$(awk '{ printf($3) }' /proc/loadavg )
		local load_avg_15m=$(awk "BEGIN { printf(\"%i\", 100 * ${load_avg_15m_float}) }")
		if [ "$load_avg_15m" -gt "$max_15m" ] ; then
			echoerror "ERROR: maximum load average (15 min.) exceeded ($load_avg_15m_float / $MAX_LOAD_AVERAGE_15M)."
			fail_exit
		else
			echoinfo "OK: load average (15 min.) below maximum ($load_avg_15m_float / $MAX_LOAD_AVERAGE_15M)."
		fi
	fi
}

function check_custom_tests {
	last_test=$((${#CUSTOM_TEST[@]}))
	local next

	if [ "$last_test" = "0" ]; then
		echoinfo "OK: (no custom test defined)"
	else
		for i in $(seq "$last_test") ; do
			next=${CUSTOM_TEST[$i]}

			if [ -n "$next" ]; then
				customoutput=$($next)
				customresult=$?
				if [ "$customresult" -ne "0" ]; then
					echoerror "$next:\n$customoutput"
					echoerror "ERROR: custom test $next failed"
					fail_exit
				else
					echoinfo "$next:\n$customoutput"
					echoinfo "OK: custom test $next"
				fi
			fi
		done
	fi
}

function check_kernel_oops {
	# Check only last three kernel logs to save time and CPU
	local kernel_log_files=( /var/log/kernel.log.2 /var/log/kernel.log.1 /var/log/kernel.log)

    local ret=$(cat ${kernel_log_files[@]} 2>/dev/null | awk '/Internal error: Oops:.*end trace/ {print "oops"}' FS="\n" RS="")
    [ "$ret" = "oops" ] && fail_exit                                                                         
}



# Main
#######################################################################################################################

[ "$SYSTEMCHECKS" = "disable" ] && exit 0;

echoinfo "### $(get_datetime) (UTC)"
echoinfo "### analyse script (PID=$$) started (version $VERSION)" 
echoinfo "### uptime: $(get_uptime) seconds"

ACTIVE_FILE="/tmp/checksystem-active"
if [ ! -f $ACTIVE_FILE ]; then
	> $ACTIVE_FILE
	echoinfo "SKIP skip checks during first run"
	echoinfo "### DONE $(get_datetime) (UTC) ###"
	echoinfo ""
	exit 0
fi

# Use busybox watchdog as a timeout of this script
WATCHDOGDEV="/dev/watchdog1"
WITHWDOG=""
if check_kill_watchdog; then
	WITHWDOG="true"
fi

if [ "$KERNEL_OOPS_CHECKS" = "enabled" ]; then 
	echoinfo "### CHECK Kernel Oops"
	check_kernel_oops
fi

echoinfo "### CHECK SERVICES"
check_services

echoinfo "### CHECK FILES"
check_files

echoinfo "### CHECK PROCESS STATES"
check_process_states

if [ "$MAX_THREADS" -gt "0" ]; then 
	echoinfo "### CHECK THREAD COUNT"
	check_threads
fi 

if [ "$MAX_LOAD_AVERAGE_1M" != "0" -o "$MAX_LOAD_AVERAGE_5M" != "0" -o "$MAX_LOAD_AVERAGE_15M" != "0" ]; then
	echoinfo "### CHECK LOAD AVERAGE"
	check_load_average
fi

if [ "$(($MIN_FREE_MEMORY + $MIN_AVAILABLE_MEMORY))" -gt "0" ]; then 
	echoinfo "### CHECK MEMORY"
	check_mem
fi 

echoinfo "### CHECK CUSTOM TESTS"
check_custom_tests

[ "$EXIT_VALUE" -ne "0" ] && echoinfo "### ERROR DETECTED $(get_datetime) (UTC) ###"
echoinfo "### DONE $(get_datetime) (UTC) ###"
echoinfo ""
sync

[ "$EXIT_VALUE" -eq "0" ] && [ "$WITHWDOG" ] && /etc/init.d/watchdogbb start
exit $EXIT_VALUE
