#ifndef __eWS_intern_H__
#define __eWS_intern_H__

typedef struct tagCALLBACKSETP_struct
{
   void* pThis;

	RTS_IEC_STRING inPath[256];			// VAR_INPUT
	RTS_IEC_STRING inUser[81];			   // VAR_INPUT
	RTS_IEC_STRING inIP[81];			   // VAR_INPUT
	RTS_IEC_STRING inOldValue[81];		// VAR_INPUT
	RTS_IEC_STRING inNewValue[81];		// VAR_INPUT

	RTS_IEC_RESULT nResult;		         // VAR_OUTPUT
} callbacksetp_struct;

RTS_BOOL    IsLocalClient(char* sIPAddr, RTS_RESULT* pResult);
void        MemFreeWSSocket(struct eWS_SOCKET* pWSSocket);

int         eWS_deinit_server ();

RTS_SSIZE   eWS_send_raw(struct eWS_SOCKET *ews, char *buf, RTS_SSIZE len);

int         eWS_init_header_table(struct eWS_SOCKET *ews);

int         eWS_handshake_request(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET *ews, char **buf, RTS_SIZE len);
int         eWS_handshake_response(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET *ews);

int         eWS_process_ws_packet(struct eWS_SOCKET *ews,	char *buf, RTS_SIZE len);
int         eWS_process_ws_byte(struct eWS_SOCKET *ews, unsigned char c);

char*       eWS_SHA1(const char *d, RTS_SIZE n, char *md);

int         eWS_change_poll(struct eWS_SOCKET *ews, int _and, int _or);
RTS_SSIZE   eWS_receive(struct eWS_SERVER_CONTEXT *context,  struct eWS_SOCKET *ews, char *buf, int len);
int         eWS_server_socket_service(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET **ews, struct eWS_poll *pPoll);




#endif