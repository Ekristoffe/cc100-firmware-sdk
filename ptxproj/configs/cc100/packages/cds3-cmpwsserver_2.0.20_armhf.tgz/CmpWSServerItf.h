 /**
 * <interfacename>CmpWSServer</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _CMPWSSERVERITF_H_
#define _CMPWSSERVERITF_H_

#include "CmpStd.h"

 

 




#include "CmpWebServerItf.h"
#include "WSServerLibItf.h"

#define CMPWSSERVER_eLICENCE_PLACEHOLDER "$eLicence$"

/**
 * <description>WSServer defines.</description>
 */
#define WS_REFRESH_TIME           0 // milliseconds
#define WS_MAXCLINETS             30
#define WS_PINGTIME               5000
#define WS_PINGINTERVAL           1000
#define WS_PINGRETRY              3
#define WS_KATIME                 0UL
#define WS_KAINTERVAL             0UL
#define WS_KARETRY                0UL
#define WS_MAX_LOCALCLIENTS       10
#define WS_TASKPRIORITY			  80
#define	WS_TASKINTERVAL			  10000 /* 10 ms - Task Interval in microseconds*/
#define WS_BUFFERSIZE             200UL // 200kb


/**
 * <category>Settings</category>
 * <description>The WS Server Buffer Size</description>
 */
#define CMPWSSERVER_KEY_BUFFERSIZE	            "BufferSize" //kB
#define CMPWSSERVER_VALUE_BUFFERSIZE_DEFAULT	WS_BUFFERSIZE

/**
 * <category>Settings</category>
 * <description>The WS Server port number</description>
 */
#define CMPWSSERVER_KEY_PORT				            "PortNr"
#define CMPWSSERVER_VALUE_PORT_DEFAULT	            CMPWEBSERVER_VALUE_PORT_DEFAULT

/**
 * <category>Settings</category>
 * <description>The WS Server secure port number</description>
 *
#define CMPWSSERVER_KEY_SECUREPORT				      "SecurePortNr"
#define CMPWSSERVER_VALUE_SECUREPORT_DEFAULT       CMPWEBSERVER_VALUE_SECUREPORT_DEFAULT*/

/**
 * <category>Settings</category>
 * <description>The WS Server connection type</description>
 */
#define CMPWSSERVER_KEY_CONNECTIONTYPE				   "ConnectionType"
#define CMPWSSERVER_VALUE_CONNECTIONTYPE_DEFAULT	CMPWEBSERVER_CONNECTION_TYPE_DEFAULT

/**
 * <category>Settings</category>
 * <description>The WS Server Refresh time.</description>
 */
#define CMPWSSERVER_KEY_REFRESH_TIME		            "RefreshTime"
#define CMPWSSERVER_VALUE_REFRESH_TIME_DEFAULT		WS_REFRESH_TIME


/**
 * <category>Settings</category>
 * <description>The WS Server MaxClients.</description>
 */
#define CMPWSSERVER_KEY_MAX_CLIENTS		            "MaxClients"
#define CMPWSSERVER_VALUE_MAX_CLIENTS_DEFAULT		   WS_MAXCLINETS

/**
 * <category>Settings</category>
 * <description>The WS Server PingTime.</description>
 */
#define CMPWSSERVER_KEY_PING_TIME               "PingTime"
#define CMPWSSERVER_VALUE_PING_TIME_DEFAULT		WS_PINGTIME

/**
 * <category>Settings</category>
 * <description>The WS Server PingInterval.</description>
 */
#define CMPWSSERVER_KEY_PING_INTERVAL               "PingInterval"
#define CMPWSSERVER_VALUE_PING_INTERVAL_DEFAULT		WS_PINGINTERVAL

/**
 * <category>Settings</category>
 * <description>The WS Server PingRetry.</description>
 */
#define CMPWSSERVER_KEY_PING_RETRY               "PingRetry"
#define CMPWSSERVER_VALUE_PING_RETRY_DEFAULT		WS_PINGRETRY

/**
 * <category>Settings</category>
 * <description>The WS Server KATime.</description>
 */
#define CMPWSSERVER_KEY_KA_TIME                     "KATime"
#define CMPWSSERVER_VALUE_KA_TIME_DEFAULT		      WS_KATIME

/**
 * <category>Settings</category>
 * <description>The WS Server KAInterval.</description>
 */
#define CMPWSSERVER_KEY_KA_INTERVAL                 "KAInterval"
#define CMPWSSERVER_VALUE_KA_INTERVAL_DEFAULT		   WS_KAINTERVAL

/**
 * <category>Settings</category>
 * <description>The WS Server KAInterval.</description>
 */
#define CMPWSSERVER_KEY_KA_RETRY                    "KARetry"
#define CMPWSSERVER_VALUE_KA_RETRY_DEFAULT		      WS_KARETRY

/**
 * <category>Settings</category>
 * <description>The WS Server Local Clients.</description>
 */
#define CMPWSSERVER_KEY_LOCAL_CLIENT                    "LocalClient"
#define CMPWSSERVER_VALUE_LOCAL_CLIENT                   ""

/**
 * <category>Settings</category>
 * <description>The WS Server Task Priority</description>
 */
#define CMPWSSERVER_KEY_TASK_PRIORITY					"TaskPriority"
#define CMPWSSERVER_VALUE_TASK_PRIORITY                 WS_TASKPRIORITY

/**
 * <category>Settings</category>
 * <description>The WS Server Task Interval</description>
 */
#define CMPWSSERVER_KEY_TASK_INTERVAL					"TaskInterval"
#define CMPWSSERVER_VALUE_TASK_INTERVAL                 WS_TASKINTERVAL

typedef struct tagrpccallbackC_struct
{
   RTS_IEC_STRING sUser[81];			/* VAR_INPUT */	/* Eingeloggter Benutzer */
	RTS_IEC_BOOL   bLocal;			   /* VAR_INPUT */	/* Aufruf von lokalem Client */
	RTS_IEC_WORD   nParaCount;       /* VAR_INPUT */	/* Anzahl Parameter*/
   RPParaStruct*  pParaList;		   /* VAR_INPUT */	/* Liste der Parameter */
RPParaStruct * pValueList;			/* VAR_INPUT */	/* Liste der Werte */
   RTS_IEC_WORD * ValueCount;			/* VAR_IN_OUT */	/* Anzahl Werte */
	RTS_IEC_RESULT nResult;	
} rpccallbackC_struct;

typedef struct tagrpc2callbackC_struct
{
	RTS_IEC_STRING sUser[81];			/* VAR_INPUT */	/* Eingeloggter Benutzer */
	RTS_IEC_BOOL   bLocal;			   /* VAR_INPUT */	/* Aufruf von lokalem Client */
	RTS_IEC_DWORD  nParaSize;       /* VAR_INPUT */	/* Size of Parameter*/
	RTS_IEC_BYTE*  pParameter;		   /* VAR_INPUT */	/* Parameter buffer (UTF8)*/
	RTS_IEC_BYTE*  pValue;			/* VAR_INPUT */	/* Value buffer*/
	RTS_IEC_DWORD* ValueSize;			/* VAR_IN_OUT */	/* size of the Value buffer*/
	RTS_IEC_RESULT nResult;	
} rpc2callbackC_struct;

/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/* routines for OS specific modules */
RTS_RESULT CmpWSServer_init(void);
RTS_RESULT CmpWSServer_run(void);
RTS_RESULT CmpWSServer_exit(void);

int CDECL WSServerHandlerV3(WebServerSocket* pSocket, char* pszUrlPrefix, char* pszDir, char* pszUrl, char* pszPath, int arg);
typedef int (CDECL * PFWSSERVERHANDLERV3) (WebServerSocket* pSocket, char* pszUrlPrefix, char* pszDir, char* pszUrl, char* pszPath, int arg);
#if defined(CMPWSSERVER_NOTIMPLEMENTED) || defined(WSSERVERHANDLERV3_NOTIMPLEMENTED)
	#define USE_WSServerHandlerV3
	#define EXT_WSServerHandlerV3
	#define GET_WSServerHandlerV3(fl)  ERR_NOTIMPLEMENTED
	#define CAL_WSServerHandlerV3(p0,p1,p2,p3,p4,p5) (int)ERR_NOTIMPLEMENTED
	#define CHK_WSServerHandlerV3  FALSE
	#define EXP_WSServerHandlerV3  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_WSServerHandlerV3
	#define EXT_WSServerHandlerV3
	#define GET_WSServerHandlerV3(fl)  CAL_CMGETAPI( "WSServerHandlerV3" ) 
	#define CAL_WSServerHandlerV3  WSServerHandlerV3
	#define CHK_WSServerHandlerV3  TRUE
	#define EXP_WSServerHandlerV3  CAL_CMEXPAPI( "WSServerHandlerV3" ) 
	#define EXTREF_ITF_WSServerHandlerV3 {(RTS_VOID_FCTPTR)WSServerHandlerV3, "WSServerHandlerV3", 0, 0}
#elif defined(MIXED_LINK) && !defined(CMPWSSERVER_EXTERNAL)
	#define USE_WSServerHandlerV3
	#define EXT_WSServerHandlerV3
	#define GET_WSServerHandlerV3(fl)  CAL_CMGETAPI( "WSServerHandlerV3" ) 
	#define CAL_WSServerHandlerV3  WSServerHandlerV3
	#define CHK_WSServerHandlerV3  TRUE
	#define EXP_WSServerHandlerV3  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"WSServerHandlerV3", (RTS_UINTPTR)WSServerHandlerV3, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpWSServerWSServerHandlerV3
	#define EXT_CmpWSServerWSServerHandlerV3
	#define GET_CmpWSServerWSServerHandlerV3  ERR_OK
	#define CAL_CmpWSServerWSServerHandlerV3  WSServerHandlerV3
	#define CHK_CmpWSServerWSServerHandlerV3  TRUE
	#define EXP_CmpWSServerWSServerHandlerV3  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_WSServerHandlerV3
	#define EXT_WSServerHandlerV3
	#define GET_WSServerHandlerV3(fl)  CAL_CMGETAPI( "WSServerHandlerV3" ) 
	#define CAL_WSServerHandlerV3  WSServerHandlerV3
	#define CHK_WSServerHandlerV3  TRUE
	#define EXP_WSServerHandlerV3  CAL_CMEXPAPI( "WSServerHandlerV3" ) 
#else /* DYNAMIC_LINK */
	#define USE_WSServerHandlerV3  PFWSSERVERHANDLERV3 pfWSServerHandlerV3;
	#define EXT_WSServerHandlerV3  extern PFWSSERVERHANDLERV3 pfWSServerHandlerV3;
	#define GET_WSServerHandlerV3(fl)  s_pfCMGetAPI2( "WSServerHandlerV3", (RTS_VOID_FCTPTR *)&pfWSServerHandlerV3, (fl), 0, 0)
	#define CAL_WSServerHandlerV3  pfWSServerHandlerV3
	#define CHK_WSServerHandlerV3  (pfWSServerHandlerV3 != NULL)
	#define EXP_WSServerHandlerV3   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"WSServerHandlerV3", (RTS_UINTPTR)WSServerHandlerV3, 0, 0) 
#endif

int CDECL MotanWSServerHandlerV3(WebServerSocket* pSocket, char* pszUrlPrefix, char* pszDir, char* pszUrl, char* pszPath, int arg);
typedef int (CDECL * PFMOTANWSSERVERHANDLERV3) (WebServerSocket* pSocket, char* pszUrlPrefix, char* pszDir, char* pszUrl, char* pszPath, int arg);
#if defined(CMPWSSERVER_NOTIMPLEMENTED) || defined(MOTANWSSERVERHANDLERV3_NOTIMPLEMENTED)
	#define USE_MotanWSServerHandlerV3
	#define EXT_MotanWSServerHandlerV3
	#define GET_MotanWSServerHandlerV3(fl)  ERR_NOTIMPLEMENTED
	#define CAL_MotanWSServerHandlerV3(p0,p1,p2,p3,p4,p5) (int)ERR_NOTIMPLEMENTED
	#define CHK_MotanWSServerHandlerV3  FALSE
	#define EXP_MotanWSServerHandlerV3  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_MotanWSServerHandlerV3
	#define EXT_MotanWSServerHandlerV3
	#define GET_MotanWSServerHandlerV3(fl)  CAL_CMGETAPI( "MotanWSServerHandlerV3" ) 
	#define CAL_MotanWSServerHandlerV3  MotanWSServerHandlerV3
	#define CHK_MotanWSServerHandlerV3  TRUE
	#define EXP_MotanWSServerHandlerV3  CAL_CMEXPAPI( "MotanWSServerHandlerV3" ) 
	#define EXTREF_ITF_MotanWSServerHandlerV3 {(RTS_VOID_FCTPTR)MotanWSServerHandlerV3, "MotanWSServerHandlerV3", 0, 0}
#elif defined(MIXED_LINK) && !defined(CMPWSSERVER_EXTERNAL)
	#define USE_MotanWSServerHandlerV3
	#define EXT_MotanWSServerHandlerV3
	#define GET_MotanWSServerHandlerV3(fl)  CAL_CMGETAPI( "MotanWSServerHandlerV3" ) 
	#define CAL_MotanWSServerHandlerV3  MotanWSServerHandlerV3
	#define CHK_MotanWSServerHandlerV3  TRUE
	#define EXP_MotanWSServerHandlerV3  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"MotanWSServerHandlerV3", (RTS_UINTPTR)MotanWSServerHandlerV3, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpWSServerMotanWSServerHandlerV3
	#define EXT_CmpWSServerMotanWSServerHandlerV3
	#define GET_CmpWSServerMotanWSServerHandlerV3  ERR_OK
	#define CAL_CmpWSServerMotanWSServerHandlerV3  MotanWSServerHandlerV3
	#define CHK_CmpWSServerMotanWSServerHandlerV3  TRUE
	#define EXP_CmpWSServerMotanWSServerHandlerV3  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_MotanWSServerHandlerV3
	#define EXT_MotanWSServerHandlerV3
	#define GET_MotanWSServerHandlerV3(fl)  CAL_CMGETAPI( "MotanWSServerHandlerV3" ) 
	#define CAL_MotanWSServerHandlerV3  MotanWSServerHandlerV3
	#define CHK_MotanWSServerHandlerV3  TRUE
	#define EXP_MotanWSServerHandlerV3  CAL_CMEXPAPI( "MotanWSServerHandlerV3" ) 
#else /* DYNAMIC_LINK */
	#define USE_MotanWSServerHandlerV3  PFMOTANWSSERVERHANDLERV3 pfMotanWSServerHandlerV3;
	#define EXT_MotanWSServerHandlerV3  extern PFMOTANWSSERVERHANDLERV3 pfMotanWSServerHandlerV3;
	#define GET_MotanWSServerHandlerV3(fl)  s_pfCMGetAPI2( "MotanWSServerHandlerV3", (RTS_VOID_FCTPTR *)&pfMotanWSServerHandlerV3, (fl), 0, 0)
	#define CAL_MotanWSServerHandlerV3  pfMotanWSServerHandlerV3
	#define CHK_MotanWSServerHandlerV3  (pfMotanWSServerHandlerV3 != NULL)
	#define EXP_MotanWSServerHandlerV3   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"MotanWSServerHandlerV3", (RTS_UINTPTR)MotanWSServerHandlerV3, 0, 0) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ICmpWSServer_C;

#ifdef CPLUSPLUS
class ICmpWSServer : public IBase
{
	public:
};
	#ifndef ITF_CmpWSServer
		#define ITF_CmpWSServer static ICmpWSServer *pICmpWSServer = NULL;
	#endif
	#define EXTITF_CmpWSServer
#else	/*CPLUSPLUS*/
	typedef ICmpWSServer_C		ICmpWSServer;
	#ifndef ITF_CmpWSServer
		#define ITF_CmpWSServer
	#endif
	#define EXTITF_CmpWSServer
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_CMPWSSERVERITF_H_*/
