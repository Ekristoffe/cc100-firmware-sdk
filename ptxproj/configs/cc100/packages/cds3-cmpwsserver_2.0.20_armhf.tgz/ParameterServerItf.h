 /**
 * <interfacename>ParameterServer</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _PARAMETERSERVERITF_H_
#define _PARAMETERSERVERITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: ParameterRightsEnum</description>
 */
#define PARAMETERRIGHTSENUM_PAR_NONE    RTS_IEC_INT_C(0x0)	/* no right to read/write the parameter value */
#define PARAMETERRIGHTSENUM_PAR_READ    RTS_IEC_INT_C(0x1)	/* Right to read the parameter value */
#define PARAMETERRIGHTSENUM_PAR_WRITE    RTS_IEC_INT_C(0x2)	/* Right to write the parameter value */
#define PARAMETERRIGHTSENUM_PAR_READWRITE    RTS_IEC_INT_C(0x3)	/* right to read/write the parameter value */
/* Typed enum definition */
#define PARAMETERRIGHTSENUM    RTS_IEC_INT

/**
 * <description>CallParameterStruct</description>
 */
typedef struct tagCallParameterStruct
{
	RTS_IEC_STRING Name[81];		/* Parameter Name */
	RTS_IEC_STRING Value[81];		/* Parameter Value */
} CallParameterStruct;

/**
 * <description>ServiceParameterStruct</description>
 */
typedef struct tagServiceParameterStruct
{
	RTS_IEC_STRING Name[81];		/* IN - Service Parameter Name */
	RTS_IEC_BYTE *Value;		/* IN/OUT - Pointer to the value of type ValueType */
	RTS_IEC_DWORD Size;		/* IN/OUT - Size in bytes of the buffer Value */
	RTS_IEC_INT ValueType;		/* IN/OUT - Value type */
} ServiceParameterStruct;

/**
 * <description>parameterservercallfun</description>
 */
typedef struct tagparameterservercallfun_struct
{
	RTS_IEC_STRING inNamespace[81];		/* VAR_INPUT */	/* Namespace */
	RTS_IEC_STRING inFunctionName[81];	/* VAR_INPUT */	/* Function name */
	RTS_IEC_WORD inCountOfInputs;		/* VAR_INPUT */	/* Count of input parameters */
	CallParameterStruct *inInputs;		/* VAR_INPUT */	/* Input parameter list as array of objects of type CallParameterStruct */
	RTS_IEC_WORD *inoutCountOfOutputs;	/* VAR_INPUT */	/* in/out-put Count of values which are retuned to the inoutOutputs parameter. */
	CallParameterStruct *inoutOutputs;	/* VAR_INPUT */	/* As input a pointer to an array of outputs paramters */
	RTS_IEC_RESULT ParameterServerCallFun;	/* VAR_OUTPUT */	
} parameterservercallfun_struct;

void CDECL CDECL_EXT parameterservercallfun(parameterservercallfun_struct *p);
typedef void (CDECL CDECL_EXT* PFPARAMETERSERVERCALLFUN_IEC) (parameterservercallfun_struct *p);
#if defined(PARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERCALLFUN_NOTIMPLEMENTED)
	#define USE_parameterservercallfun
	#define EXT_parameterservercallfun
	#define GET_parameterservercallfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_parameterservercallfun(p0) 
	#define CHK_parameterservercallfun  FALSE
	#define EXP_parameterservercallfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_parameterservercallfun
	#define EXT_parameterservercallfun
	#define GET_parameterservercallfun(fl)  CAL_CMGETAPI( "parameterservercallfun" ) 
	#define CAL_parameterservercallfun  parameterservercallfun
	#define CHK_parameterservercallfun  TRUE
	#define EXP_parameterservercallfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservercallfun", (RTS_UINTPTR)parameterservercallfun, 1, 0x03B63BC1, 0x03050F14) 
	#define EXTREF_ITF_parameterservercallfun {(RTS_VOID_FCTPTR)parameterservercallfun, "parameterservercallfun", 0x03B63BC1, 0x03050F14}
#elif defined(MIXED_LINK) && !defined(PARAMETERSERVER_EXTERNAL)
	#define USE_parameterservercallfun
	#define EXT_parameterservercallfun
	#define GET_parameterservercallfun(fl)  CAL_CMGETAPI( "parameterservercallfun" ) 
	#define CAL_parameterservercallfun  parameterservercallfun
	#define CHK_parameterservercallfun  TRUE
	#define EXP_parameterservercallfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservercallfun", (RTS_UINTPTR)parameterservercallfun, 1, 0x03B63BC1, 0x03050F14) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_ParameterServerparameterservercallfun
	#define EXT_ParameterServerparameterservercallfun
	#define GET_ParameterServerparameterservercallfun  ERR_OK
	#define CAL_ParameterServerparameterservercallfun  parameterservercallfun
	#define CHK_ParameterServerparameterservercallfun  TRUE
	#define EXP_ParameterServerparameterservercallfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservercallfun", (RTS_UINTPTR)parameterservercallfun, 1, 0x03B63BC1, 0x03050F14) 
#elif defined(CPLUSPLUS)
	#define USE_parameterservercallfun
	#define EXT_parameterservercallfun
	#define GET_parameterservercallfun(fl)  CAL_CMGETAPI( "parameterservercallfun" ) 
	#define CAL_parameterservercallfun  parameterservercallfun
	#define CHK_parameterservercallfun  TRUE
	#define EXP_parameterservercallfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservercallfun", (RTS_UINTPTR)parameterservercallfun, 1, 0x03B63BC1, 0x03050F14) 
#else /* DYNAMIC_LINK */
	#define USE_parameterservercallfun  PFPARAMETERSERVERCALLFUN_IEC pfparameterservercallfun;
	#define EXT_parameterservercallfun  extern PFPARAMETERSERVERCALLFUN_IEC pfparameterservercallfun;
	#define GET_parameterservercallfun(fl)  s_pfCMGetAPI2( "parameterservercallfun", (RTS_VOID_FCTPTR *)&pfparameterservercallfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x03B63BC1, 0x03050F14)
	#define CAL_parameterservercallfun  pfparameterservercallfun
	#define CHK_parameterservercallfun  (pfparameterservercallfun != NULL)
	#define EXP_parameterservercallfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservercallfun", (RTS_UINTPTR)parameterservercallfun, 1, 0x03B63BC1, 0x03050F14) 
#endif


/**
 *	:return: Returns the count of supportted namespaces.
 */
typedef struct tagparameterservergetcountofnamespacesfun_struct
{
	RTS_IEC_WORD ParameterServerGetCountOfNamespacesFun;	/* VAR_OUTPUT */	
} parameterservergetcountofnamespacesfun_struct;

void CDECL CDECL_EXT parameterservergetcountofnamespacesfun(parameterservergetcountofnamespacesfun_struct *p);
typedef void (CDECL CDECL_EXT* PFPARAMETERSERVERGETCOUNTOFNAMESPACESFUN_IEC) (parameterservergetcountofnamespacesfun_struct *p);
#if defined(PARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETCOUNTOFNAMESPACESFUN_NOTIMPLEMENTED)
	#define USE_parameterservergetcountofnamespacesfun
	#define EXT_parameterservergetcountofnamespacesfun
	#define GET_parameterservergetcountofnamespacesfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_parameterservergetcountofnamespacesfun(p0) 
	#define CHK_parameterservergetcountofnamespacesfun  FALSE
	#define EXP_parameterservergetcountofnamespacesfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_parameterservergetcountofnamespacesfun
	#define EXT_parameterservergetcountofnamespacesfun
	#define GET_parameterservergetcountofnamespacesfun(fl)  CAL_CMGETAPI( "parameterservergetcountofnamespacesfun" ) 
	#define CAL_parameterservergetcountofnamespacesfun  parameterservergetcountofnamespacesfun
	#define CHK_parameterservergetcountofnamespacesfun  TRUE
	#define EXP_parameterservergetcountofnamespacesfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetcountofnamespacesfun", (RTS_UINTPTR)parameterservergetcountofnamespacesfun, 1, 0xFC69C60C, 0x03050F14) 
	#define EXTREF_ITF_parameterservergetcountofnamespacesfun {(RTS_VOID_FCTPTR)parameterservergetcountofnamespacesfun, "parameterservergetcountofnamespacesfun", 0xFC69C60C, 0x03050F14}
#elif defined(MIXED_LINK) && !defined(PARAMETERSERVER_EXTERNAL)
	#define USE_parameterservergetcountofnamespacesfun
	#define EXT_parameterservergetcountofnamespacesfun
	#define GET_parameterservergetcountofnamespacesfun(fl)  CAL_CMGETAPI( "parameterservergetcountofnamespacesfun" ) 
	#define CAL_parameterservergetcountofnamespacesfun  parameterservergetcountofnamespacesfun
	#define CHK_parameterservergetcountofnamespacesfun  TRUE
	#define EXP_parameterservergetcountofnamespacesfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetcountofnamespacesfun", (RTS_UINTPTR)parameterservergetcountofnamespacesfun, 1, 0xFC69C60C, 0x03050F14) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_ParameterServerparameterservergetcountofnamespacesfun
	#define EXT_ParameterServerparameterservergetcountofnamespacesfun
	#define GET_ParameterServerparameterservergetcountofnamespacesfun  ERR_OK
	#define CAL_ParameterServerparameterservergetcountofnamespacesfun  parameterservergetcountofnamespacesfun
	#define CHK_ParameterServerparameterservergetcountofnamespacesfun  TRUE
	#define EXP_ParameterServerparameterservergetcountofnamespacesfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetcountofnamespacesfun", (RTS_UINTPTR)parameterservergetcountofnamespacesfun, 1, 0xFC69C60C, 0x03050F14) 
#elif defined(CPLUSPLUS)
	#define USE_parameterservergetcountofnamespacesfun
	#define EXT_parameterservergetcountofnamespacesfun
	#define GET_parameterservergetcountofnamespacesfun(fl)  CAL_CMGETAPI( "parameterservergetcountofnamespacesfun" ) 
	#define CAL_parameterservergetcountofnamespacesfun  parameterservergetcountofnamespacesfun
	#define CHK_parameterservergetcountofnamespacesfun  TRUE
	#define EXP_parameterservergetcountofnamespacesfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetcountofnamespacesfun", (RTS_UINTPTR)parameterservergetcountofnamespacesfun, 1, 0xFC69C60C, 0x03050F14) 
#else /* DYNAMIC_LINK */
	#define USE_parameterservergetcountofnamespacesfun  PFPARAMETERSERVERGETCOUNTOFNAMESPACESFUN_IEC pfparameterservergetcountofnamespacesfun;
	#define EXT_parameterservergetcountofnamespacesfun  extern PFPARAMETERSERVERGETCOUNTOFNAMESPACESFUN_IEC pfparameterservergetcountofnamespacesfun;
	#define GET_parameterservergetcountofnamespacesfun(fl)  s_pfCMGetAPI2( "parameterservergetcountofnamespacesfun", (RTS_VOID_FCTPTR *)&pfparameterservergetcountofnamespacesfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xFC69C60C, 0x03050F14)
	#define CAL_parameterservergetcountofnamespacesfun  pfparameterservergetcountofnamespacesfun
	#define CHK_parameterservergetcountofnamespacesfun  (pfparameterservergetcountofnamespacesfun != NULL)
	#define EXP_parameterservergetcountofnamespacesfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetcountofnamespacesfun", (RTS_UINTPTR)parameterservergetcountofnamespacesfun, 1, 0xFC69C60C, 0x03050F14) 
#endif


/**
 *Returns the parameters correspondingly to the input parameters inNamespace, inoutParams, inoutNoOfServiceParams.
 *
 ***Example to get all parameters available for the service CS:**
 *
 *	
 * .. code-block:: codesys
 *
 *	VAR
 *		nCountOfParameters: DWORD := 0;
 *		result: RTS_IEC_RESULT := 0;
 *		pParams:POINTER TO ELA_PARAMETERSERVER.ServiceParameterStruct:=NULL;
 *		i:DWORD;
 *	END_VAR
 *
 *	
 * .. code-block:: codesys
 *
 *	IF (nCountOfParameters=0) THEN	
 *		result:=ELA_PARAMETERSERVER.ParameterServerGetFun('CS',NULL, nCountOfParameters);	 
 *		if (result=ELA_SYSERROR.ERR.OK AND nCountOfParameters>0) then
 *			pParams:=SysMemAllocData('MyApp',sizeof(ELA_PARAMETERSERVER.ServiceParameterStruct)*nCountOfParameters, ADR(result));
 *			if (pParams<>NULL) then
 *				FOR i:=0 TO nCountOfParameters-1 DO
 *					pParams[i].Size := 0;
 *					pParams[i].Value := 0;
 *					pParams[i].Name := '';
 *					pParams[i].ValueType := 0;
 *				END_FOR;
 *				result:=ELA_PARAMETERSERVER.ParameterServerGetFun('CS', pParams, nCountOfParameters);
 *				FOR i:=0 TO nCountOfParameters-1 DO
 *					IF (pParams[i].Size > 0) THEN
 *						pParams[i].Value := SysMemAllocData('MyApp', pParams[i].Size, ADR(result));		
 *					END_IF;
 *				END_FOR;
 *				result:=ELA_PARAMETERSERVER.ParameterServerGetFun('CS', pParams, nCountOfParameters);
 *			end_if;
 *		end_if;
 *	end_if;
 *
 *	
 ***Example to get one parameter(NET:MAC_Address1) of the service NET:**
 *
 *	
 * .. code-block:: codesys
 *
 *	VAR
 *		szMACAddr1:STRING:='';
 *		sMACAddr1Par:ELA_PARAMETERSERVER.ServiceParameterStruct:=
 *				(Name:='MAC_Address1', Value:=ADR(szMACAddr1), Size:=SIZEOF(szMACAddr1), ValueType:=TYPE_STRING);
 *	END_VAR
 *
 *	
 * .. code-block:: codesys
 *
 *	nNoOfParams:=1;
 *	result:=ElA_PARAMETERSERVER.ParameterServerGetFun('NET', ADR(sMACAddr1Par), nNoOfParams);
 *
 *	:return: see CmpErrors.library and SysError.library:
 *	+ ERR_OK: succes.
 *	+ ERR_FAILED: internal error.
 *	+ ERR_NO_OBJECT: Namespace not found.
 *	+ ERR_PARAMETER: Function parameter inNamespace is empty.
 *	+ ERR_NOBUFFER: Not enough buffer size for a value.
 *	+ ERR_PARA_NOK: Unexpected value type.
 *	+ ERR_PARA_NOTSUPPORTED: Parameter not supportted.
 *	+ ERR_NOTIMPLEMENTED:  Not implemented.
 */
typedef struct tagparameterservergetfun_struct
{
	RTS_IEC_STRING inNamespace[81];		/* VAR_INPUT */	/* Namespace */
	ServiceParameterStruct *inoutParams;	/* VAR_INPUT */	/* Array of Parameters correspondingly to the inNamespace and inoutNoOfServiceParams.

When ServiceParameterStruct.Size is 0, the function will return the necessary size in bytes for the value and the value type.

Otherwise when the Value is NOT null AND the the value TYPE/size is ok, the FUNCTION will RETURN the value. */
	RTS_IEC_DWORD *inoutNoOfServiceParams;	/* VAR_IN_OUT */	/* As input: the count of parameters entered in the buffer inoutParams.
	
As output: either the count of supported parameters when the input is 0,

		or the same value as input when the input <= count of supported parameters
		
		or the count of supported parameters when the iput is greater than necessary. */
	RTS_IEC_RESULT ParameterServerGetFun;	/* VAR_OUTPUT */	
} parameterservergetfun_struct;

void CDECL CDECL_EXT parameterservergetfun(parameterservergetfun_struct *p);
typedef void (CDECL CDECL_EXT* PFPARAMETERSERVERGETFUN_IEC) (parameterservergetfun_struct *p);
#if defined(PARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETFUN_NOTIMPLEMENTED)
	#define USE_parameterservergetfun
	#define EXT_parameterservergetfun
	#define GET_parameterservergetfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_parameterservergetfun(p0) 
	#define CHK_parameterservergetfun  FALSE
	#define EXP_parameterservergetfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_parameterservergetfun
	#define EXT_parameterservergetfun
	#define GET_parameterservergetfun(fl)  CAL_CMGETAPI( "parameterservergetfun" ) 
	#define CAL_parameterservergetfun  parameterservergetfun
	#define CHK_parameterservergetfun  TRUE
	#define EXP_parameterservergetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetfun", (RTS_UINTPTR)parameterservergetfun, 1, 0x0CFD21A5, 0x03050F14) 
	#define EXTREF_ITF_parameterservergetfun {(RTS_VOID_FCTPTR)parameterservergetfun, "parameterservergetfun", 0x0CFD21A5, 0x03050F14}
#elif defined(MIXED_LINK) && !defined(PARAMETERSERVER_EXTERNAL)
	#define USE_parameterservergetfun
	#define EXT_parameterservergetfun
	#define GET_parameterservergetfun(fl)  CAL_CMGETAPI( "parameterservergetfun" ) 
	#define CAL_parameterservergetfun  parameterservergetfun
	#define CHK_parameterservergetfun  TRUE
	#define EXP_parameterservergetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetfun", (RTS_UINTPTR)parameterservergetfun, 1, 0x0CFD21A5, 0x03050F14) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_ParameterServerparameterservergetfun
	#define EXT_ParameterServerparameterservergetfun
	#define GET_ParameterServerparameterservergetfun  ERR_OK
	#define CAL_ParameterServerparameterservergetfun  parameterservergetfun
	#define CHK_ParameterServerparameterservergetfun  TRUE
	#define EXP_ParameterServerparameterservergetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetfun", (RTS_UINTPTR)parameterservergetfun, 1, 0x0CFD21A5, 0x03050F14) 
#elif defined(CPLUSPLUS)
	#define USE_parameterservergetfun
	#define EXT_parameterservergetfun
	#define GET_parameterservergetfun(fl)  CAL_CMGETAPI( "parameterservergetfun" ) 
	#define CAL_parameterservergetfun  parameterservergetfun
	#define CHK_parameterservergetfun  TRUE
	#define EXP_parameterservergetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetfun", (RTS_UINTPTR)parameterservergetfun, 1, 0x0CFD21A5, 0x03050F14) 
#else /* DYNAMIC_LINK */
	#define USE_parameterservergetfun  PFPARAMETERSERVERGETFUN_IEC pfparameterservergetfun;
	#define EXT_parameterservergetfun  extern PFPARAMETERSERVERGETFUN_IEC pfparameterservergetfun;
	#define GET_parameterservergetfun(fl)  s_pfCMGetAPI2( "parameterservergetfun", (RTS_VOID_FCTPTR *)&pfparameterservergetfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0CFD21A5, 0x03050F14)
	#define CAL_parameterservergetfun  pfparameterservergetfun
	#define CHK_parameterservergetfun  (pfparameterservergetfun != NULL)
	#define EXP_parameterservergetfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetfun", (RTS_UINTPTR)parameterservergetfun, 1, 0x0CFD21A5, 0x03050F14) 
#endif


/**
 *Returns information about a parameter corespondingly to the inNamespace and the inName function input parameters.
 *
 ***Example to get info about the CS-parameter 'TargetVendorName':**
 *
 *	
 * .. code-block:: codesys
 *
 *	VAR
 *		VendorNameRight:ELA_PARAMETERSERVER.ParameterRightsEnum;
 *    	VendorNameType:TypeClass;
 *		VendorNameSize:DWORD:=0;
 *		VendorNameLength:DWORD:=0;
 *		VendorNameMinValue:DWORD:=0;
 *		VendorNameMaxValue:DWORD:=0;
 *		result:RTS_IEC_RESULT;
 *	END_VAR
 *
 *	
 * .. code-block:: codesys
 *
 *	result:=ElA_PARAMETERSERVER.ParameterServerGetInfoFun('CS', 'TargetVendorName', outRights => VendorNameRight, 
 *				outDataType => VendorNameType, outSize=>VendorNameSize, outLength=>VendorNameLength,
 *				outMINValue=>VendorNameMinValue, outMAXValue=>VendorNameMaxValue);
 *
 *	:return: see CmpErrors.library and SysError.library:
 *	+ ERR_OK: succes.
 *	+ ERR_NO_OBJECT: Namespace/parameter not found.
 *	+ ERR_PARAMETER: Function parameter inNamespace is empty.
 */
typedef struct tagparameterservergetinfofun_struct
{
	RTS_IEC_STRING inNamespace[81];		/* VAR_INPUT */	/* Namespace. */
	RTS_IEC_STRING inName[81];			/* VAR_INPUT */	/* Parameter name. */
	RTS_IEC_RESULT ParameterServerGetInfoFun;	/* VAR_OUTPUT */	
	RTS_IEC_INT outRights;				/* VAR_OUTPUT, Enum: PARAMETERRIGHTSENUM */
	RTS_IEC_INT outDataType;			/* VAR_OUTPUT, Enum: TYPECLASS */
	RTS_IEC_DWORD outSize;				/* VAR_OUTPUT */	/* Parameter data size in bytes. */
	RTS_IEC_DWORD outLength;			/* VAR_OUTPUT */	/* String length for parameters of type string. */
	RTS_IEC_DWORD outMINValue;			/* VAR_OUTPUT */	/* The lowest limit for the value. */
	RTS_IEC_DWORD outMAXValue;			/* VAR_OUTPUT */	/* The uppermost limit for the value. */
} parameterservergetinfofun_struct;

void CDECL CDECL_EXT parameterservergetinfofun(parameterservergetinfofun_struct *p);
typedef void (CDECL CDECL_EXT* PFPARAMETERSERVERGETINFOFUN_IEC) (parameterservergetinfofun_struct *p);
#if defined(PARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETINFOFUN_NOTIMPLEMENTED)
	#define USE_parameterservergetinfofun
	#define EXT_parameterservergetinfofun
	#define GET_parameterservergetinfofun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_parameterservergetinfofun(p0) 
	#define CHK_parameterservergetinfofun  FALSE
	#define EXP_parameterservergetinfofun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_parameterservergetinfofun
	#define EXT_parameterservergetinfofun
	#define GET_parameterservergetinfofun(fl)  CAL_CMGETAPI( "parameterservergetinfofun" ) 
	#define CAL_parameterservergetinfofun  parameterservergetinfofun
	#define CHK_parameterservergetinfofun  TRUE
	#define EXP_parameterservergetinfofun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetinfofun", (RTS_UINTPTR)parameterservergetinfofun, 1, 0x82123719, 0x03050F14) 
	#define EXTREF_ITF_parameterservergetinfofun {(RTS_VOID_FCTPTR)parameterservergetinfofun, "parameterservergetinfofun", 0x82123719, 0x03050F14}
#elif defined(MIXED_LINK) && !defined(PARAMETERSERVER_EXTERNAL)
	#define USE_parameterservergetinfofun
	#define EXT_parameterservergetinfofun
	#define GET_parameterservergetinfofun(fl)  CAL_CMGETAPI( "parameterservergetinfofun" ) 
	#define CAL_parameterservergetinfofun  parameterservergetinfofun
	#define CHK_parameterservergetinfofun  TRUE
	#define EXP_parameterservergetinfofun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetinfofun", (RTS_UINTPTR)parameterservergetinfofun, 1, 0x82123719, 0x03050F14) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_ParameterServerparameterservergetinfofun
	#define EXT_ParameterServerparameterservergetinfofun
	#define GET_ParameterServerparameterservergetinfofun  ERR_OK
	#define CAL_ParameterServerparameterservergetinfofun  parameterservergetinfofun
	#define CHK_ParameterServerparameterservergetinfofun  TRUE
	#define EXP_ParameterServerparameterservergetinfofun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetinfofun", (RTS_UINTPTR)parameterservergetinfofun, 1, 0x82123719, 0x03050F14) 
#elif defined(CPLUSPLUS)
	#define USE_parameterservergetinfofun
	#define EXT_parameterservergetinfofun
	#define GET_parameterservergetinfofun(fl)  CAL_CMGETAPI( "parameterservergetinfofun" ) 
	#define CAL_parameterservergetinfofun  parameterservergetinfofun
	#define CHK_parameterservergetinfofun  TRUE
	#define EXP_parameterservergetinfofun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetinfofun", (RTS_UINTPTR)parameterservergetinfofun, 1, 0x82123719, 0x03050F14) 
#else /* DYNAMIC_LINK */
	#define USE_parameterservergetinfofun  PFPARAMETERSERVERGETINFOFUN_IEC pfparameterservergetinfofun;
	#define EXT_parameterservergetinfofun  extern PFPARAMETERSERVERGETINFOFUN_IEC pfparameterservergetinfofun;
	#define GET_parameterservergetinfofun(fl)  s_pfCMGetAPI2( "parameterservergetinfofun", (RTS_VOID_FCTPTR *)&pfparameterservergetinfofun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x82123719, 0x03050F14)
	#define CAL_parameterservergetinfofun  pfparameterservergetinfofun
	#define CHK_parameterservergetinfofun  (pfparameterservergetinfofun != NULL)
	#define EXP_parameterservergetinfofun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetinfofun", (RTS_UINTPTR)parameterservergetinfofun, 1, 0x82123719, 0x03050F14) 
#endif


/**
 *Returns the namespace specified by nIndex; The first Index is 0
 *
 ***Example to get the first 10 supportted namespaces**
 *
 *	
 * .. code-block:: codesys
 *
 *	VAR
 *		nCountOfNamespaces: WORD := 0;
 *		arrayOfNamespaces:ARRAY [0..10] OF STRING;
 *		resultNamespace:RTS_IEC_RESULT:=0;
 *		i:WORD;
 *	END_VAR
 *
 *	
 * .. code-block:: codesys
 *
 *	IF (nCountOfNamespaces=0) THEN
 *		nCountOfNamespaces:= ELA_PARAMETERSERVER.ParameterServerGetCountOfNamespacesFun();
 *		FOR i:=0 TO MIN(nCountOfNamespaces-1, 10) DO
 *			resultNamespace:=ELA_PARAMETERSERVER.ParameterServerGetNamespaceFun(i,sNamespace => arrayOfNamespaces[i]);
 *			IF(resultNamespace<>0) THEN
 *	 			EXIT;
 *			END_IF
 *		END_FOR
 *	END_IF
 *
 *	:return: see CmpErrors.library and SysError.library:
 *	+ ERR_OK: succes.
 *	+ ERR_BUFFERSIZE: sizeof(STRING) not enough for the namespace buffer
 *	+ ERR_NO_OBJECT: No Namespace with the specified index
 */
typedef struct tagparameterservergetnamespacefun_struct
{
	RTS_IEC_WORD nIndex;				/* VAR_INPUT */	
	RTS_IEC_RESULT ParameterServerGetNamespaceFun;	/* VAR_OUTPUT */	
	RTS_IEC_STRING sNamespace[81];		/* VAR_OUTPUT */	
} parameterservergetnamespacefun_struct;

void CDECL CDECL_EXT parameterservergetnamespacefun(parameterservergetnamespacefun_struct *p);
typedef void (CDECL CDECL_EXT* PFPARAMETERSERVERGETNAMESPACEFUN_IEC) (parameterservergetnamespacefun_struct *p);
#if defined(PARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETNAMESPACEFUN_NOTIMPLEMENTED)
	#define USE_parameterservergetnamespacefun
	#define EXT_parameterservergetnamespacefun
	#define GET_parameterservergetnamespacefun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_parameterservergetnamespacefun(p0) 
	#define CHK_parameterservergetnamespacefun  FALSE
	#define EXP_parameterservergetnamespacefun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_parameterservergetnamespacefun
	#define EXT_parameterservergetnamespacefun
	#define GET_parameterservergetnamespacefun(fl)  CAL_CMGETAPI( "parameterservergetnamespacefun" ) 
	#define CAL_parameterservergetnamespacefun  parameterservergetnamespacefun
	#define CHK_parameterservergetnamespacefun  TRUE
	#define EXP_parameterservergetnamespacefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetnamespacefun", (RTS_UINTPTR)parameterservergetnamespacefun, 1, 0x3C0C342E, 0x03050F14) 
	#define EXTREF_ITF_parameterservergetnamespacefun {(RTS_VOID_FCTPTR)parameterservergetnamespacefun, "parameterservergetnamespacefun", 0x3C0C342E, 0x03050F14}
#elif defined(MIXED_LINK) && !defined(PARAMETERSERVER_EXTERNAL)
	#define USE_parameterservergetnamespacefun
	#define EXT_parameterservergetnamespacefun
	#define GET_parameterservergetnamespacefun(fl)  CAL_CMGETAPI( "parameterservergetnamespacefun" ) 
	#define CAL_parameterservergetnamespacefun  parameterservergetnamespacefun
	#define CHK_parameterservergetnamespacefun  TRUE
	#define EXP_parameterservergetnamespacefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetnamespacefun", (RTS_UINTPTR)parameterservergetnamespacefun, 1, 0x3C0C342E, 0x03050F14) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_ParameterServerparameterservergetnamespacefun
	#define EXT_ParameterServerparameterservergetnamespacefun
	#define GET_ParameterServerparameterservergetnamespacefun  ERR_OK
	#define CAL_ParameterServerparameterservergetnamespacefun  parameterservergetnamespacefun
	#define CHK_ParameterServerparameterservergetnamespacefun  TRUE
	#define EXP_ParameterServerparameterservergetnamespacefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetnamespacefun", (RTS_UINTPTR)parameterservergetnamespacefun, 1, 0x3C0C342E, 0x03050F14) 
#elif defined(CPLUSPLUS)
	#define USE_parameterservergetnamespacefun
	#define EXT_parameterservergetnamespacefun
	#define GET_parameterservergetnamespacefun(fl)  CAL_CMGETAPI( "parameterservergetnamespacefun" ) 
	#define CAL_parameterservergetnamespacefun  parameterservergetnamespacefun
	#define CHK_parameterservergetnamespacefun  TRUE
	#define EXP_parameterservergetnamespacefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetnamespacefun", (RTS_UINTPTR)parameterservergetnamespacefun, 1, 0x3C0C342E, 0x03050F14) 
#else /* DYNAMIC_LINK */
	#define USE_parameterservergetnamespacefun  PFPARAMETERSERVERGETNAMESPACEFUN_IEC pfparameterservergetnamespacefun;
	#define EXT_parameterservergetnamespacefun  extern PFPARAMETERSERVERGETNAMESPACEFUN_IEC pfparameterservergetnamespacefun;
	#define GET_parameterservergetnamespacefun(fl)  s_pfCMGetAPI2( "parameterservergetnamespacefun", (RTS_VOID_FCTPTR *)&pfparameterservergetnamespacefun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3C0C342E, 0x03050F14)
	#define CAL_parameterservergetnamespacefun  pfparameterservergetnamespacefun
	#define CHK_parameterservergetnamespacefun  (pfparameterservergetnamespacefun != NULL)
	#define EXP_parameterservergetnamespacefun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterservergetnamespacefun", (RTS_UINTPTR)parameterservergetnamespacefun, 1, 0x3C0C342E, 0x03050F14) 
#endif


/**
 *Sets the value for one or more parameters corespondigly to the inNamepace.
 *
 ***Example to set 'CS:WebServerPortNr' parameter:**
 *
 *	
 * .. code-block:: codesys
 *
 *	VAR
 *		WebServerPortNr:WORD:=80;
 *		WebServerPortNrStruct: ELA_PARAMETERSERVER.ServiceParameterStruct:=
 *			(Name:='WebServerPortNr', ValueType:=TYPE_WORD, Size:=SIZEOF(WORD), Value:=ADR(WebServerPortNr));
 *		resultSet: RTS_IEC_RESULT := 0;
 *	END_VAR
 *
 *	
 * .. code-block:: codesys
 *
 *	resultSet:=ELA_PARAMETERSERVER.ParameterServerSetFun('CS',ADR(WebServerPortNrStruct), 1);
 *
 *	
 *	:return: see CmpErrors.library and SysError.library:
 *	+ ERR_OK: succes.
 *	+ ERR_PARAMETER: Invalid Function input function parameters(inNamespace is empty, inParams is null, inNoOfServiceParams is 0).
 *	+ ERR_NO_OBJECT: Namespace/parameter not found.
 *	+ ERR_NOBUFFER: Not enough buffer size for the value.
 *	+ ERR_PARA_NOK: Unexpected value type.
 *	+ ERR_NO_ACCESS_RIGHTS: no right to write this parameter.
 *	+ ERR_NOTIMPLEMENTED: the functionality is not implemented yet.
 */
typedef struct tagparameterserversetfun_struct
{
	RTS_IEC_STRING inNamespace[81];		/* VAR_INPUT */	/* Namespace */
	ServiceParameterStruct *inParams;	/* VAR_INPUT */	/* Parameters to set */
	RTS_IEC_DWORD inNoOfServiceParams;	/* VAR_INPUT */	/* Count of Parameters in the buffer inParams. */
	RTS_IEC_RESULT ParameterServerSetFun;	/* VAR_OUTPUT */	
	RTS_IEC_DWORD outIndexofError;		/* VAR_OUTPUT */	/* By Error, the index of the parameter in the buffer inParams which failed to be set. */
} parameterserversetfun_struct;

void CDECL CDECL_EXT parameterserversetfun(parameterserversetfun_struct *p);
typedef void (CDECL CDECL_EXT* PFPARAMETERSERVERSETFUN_IEC) (parameterserversetfun_struct *p);
#if defined(PARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERSETFUN_NOTIMPLEMENTED)
	#define USE_parameterserversetfun
	#define EXT_parameterserversetfun
	#define GET_parameterserversetfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_parameterserversetfun(p0) 
	#define CHK_parameterserversetfun  FALSE
	#define EXP_parameterserversetfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_parameterserversetfun
	#define EXT_parameterserversetfun
	#define GET_parameterserversetfun(fl)  CAL_CMGETAPI( "parameterserversetfun" ) 
	#define CAL_parameterserversetfun  parameterserversetfun
	#define CHK_parameterserversetfun  TRUE
	#define EXP_parameterserversetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterserversetfun", (RTS_UINTPTR)parameterserversetfun, 1, 0x553F5268, 0x03050F14) 
	#define EXTREF_ITF_parameterserversetfun {(RTS_VOID_FCTPTR)parameterserversetfun, "parameterserversetfun", 0x553F5268, 0x03050F14}
#elif defined(MIXED_LINK) && !defined(PARAMETERSERVER_EXTERNAL)
	#define USE_parameterserversetfun
	#define EXT_parameterserversetfun
	#define GET_parameterserversetfun(fl)  CAL_CMGETAPI( "parameterserversetfun" ) 
	#define CAL_parameterserversetfun  parameterserversetfun
	#define CHK_parameterserversetfun  TRUE
	#define EXP_parameterserversetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterserversetfun", (RTS_UINTPTR)parameterserversetfun, 1, 0x553F5268, 0x03050F14) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_ParameterServerparameterserversetfun
	#define EXT_ParameterServerparameterserversetfun
	#define GET_ParameterServerparameterserversetfun  ERR_OK
	#define CAL_ParameterServerparameterserversetfun  parameterserversetfun
	#define CHK_ParameterServerparameterserversetfun  TRUE
	#define EXP_ParameterServerparameterserversetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterserversetfun", (RTS_UINTPTR)parameterserversetfun, 1, 0x553F5268, 0x03050F14) 
#elif defined(CPLUSPLUS)
	#define USE_parameterserversetfun
	#define EXT_parameterserversetfun
	#define GET_parameterserversetfun(fl)  CAL_CMGETAPI( "parameterserversetfun" ) 
	#define CAL_parameterserversetfun  parameterserversetfun
	#define CHK_parameterserversetfun  TRUE
	#define EXP_parameterserversetfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterserversetfun", (RTS_UINTPTR)parameterserversetfun, 1, 0x553F5268, 0x03050F14) 
#else /* DYNAMIC_LINK */
	#define USE_parameterserversetfun  PFPARAMETERSERVERSETFUN_IEC pfparameterserversetfun;
	#define EXT_parameterserversetfun  extern PFPARAMETERSERVERSETFUN_IEC pfparameterserversetfun;
	#define GET_parameterserversetfun(fl)  s_pfCMGetAPI2( "parameterserversetfun", (RTS_VOID_FCTPTR *)&pfparameterserversetfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x553F5268, 0x03050F14)
	#define CAL_parameterserversetfun  pfparameterserversetfun
	#define CHK_parameterserversetfun  (pfparameterserversetfun != NULL)
	#define EXP_parameterserversetfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"parameterserversetfun", (RTS_UINTPTR)parameterserversetfun, 1, 0x553F5268, 0x03050F14) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IParameterServer_C;

#ifdef CPLUSPLUS
class IParameterServer : public IBase
{
	public:
};
	#ifndef ITF_ParameterServer
		#define ITF_ParameterServer static IParameterServer *pIParameterServer = NULL;
	#endif
	#define EXTITF_ParameterServer
#else	/*CPLUSPLUS*/
	typedef IParameterServer_C		IParameterServer;
	#ifndef ITF_ParameterServer
		#define ITF_ParameterServer
	#endif
	#define EXTITF_ParameterServer
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_PARAMETERSERVERITF_H_*/
