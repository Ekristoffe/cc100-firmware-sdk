 /**
 * <interfacename>CmpElrestOPCUAClient</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _CMPELRESTOPCUACLIENTITF_H_
#define _CMPELRESTOPCUACLIENTITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

#define eUA_STATUSCODE_BADSESSIONIDINVALID 0x80250000
#define eUA_STATUSCODE_BADCONNECTIONCLOSED 0x80AE0000

//Response timeout in seconds
#define CMPELRESTOPCUACLIENT_KEY_TIMEOUT			"Timeout"
#define CMPELRESTOPCUACLIENT_VALUE_TIMEOUT_DEFAULT	2

typedef enum {
    eUA_NODEIDTYPE_NUMERIC    = 0, /* In the binary encoding, this can also
                                   * become 1 or 2 (two-byte and four-byte
                                   * encoding of small numeric nodeids) */
    eUA_NODEIDTYPE_STRING     = 3,
    eUA_NODEIDTYPE_GUID       = 4,
    eUA_NODEIDTYPE_BYTESTRING = 5
} eUA_NodeIdType;

typedef enum {
    eUA_NODECLASS_UNSPECIFIED = 0,
    eUA_NODECLASS_OBJECT = 1,
    eUA_NODECLASS_VARIABLE = 2,
    eUA_NODECLASS_METHOD = 4,
    eUA_NODECLASS_OBJECTTYPE = 8,
    eUA_NODECLASS_VARIABLETYPE = 16,
    eUA_NODECLASS_REFERENCETYPE = 32,
    eUA_NODECLASS_DATATYPE = 64,
    eUA_NODECLASS_VIEW = 128,
    __eUA_NODECLASS_FORCE32BIT = 0x7fffffff
} eUA_NodeClass;


typedef struct {
    RTS_UI32 data1;
    RTS_UI16 data2;
    RTS_UI16 data3;
    RTS_UI8  data4[8];
} eUA_Guid;

typedef struct {
    RTS_SIZE length; /* The length of the string */
    RTS_UI8 *data; /* The content (not null-terminated) */
} eUA_String;

typedef struct {
    RTS_UI16 namespaceIndex;
    eUA_NodeIdType identifierType;
    union {
        RTS_UI32    numeric;
        eUA_String  string;
        eUA_Guid    guid;
    } identifier;
} eUA_NodeId;

typedef enum {
    eUA_CLIENTSTATE_DISCONNECTED,         /* The client is disconnected */
    eUA_CLIENTSTATE_WAITING_FOR_ACK,      /* The Client has sent HEL and waiting */
    eUA_CLIENTSTATE_CONNECTED,            /* A TCP connection to the server is open */
    eUA_CLIENTSTATE_SECURECHANNEL,        /* A SecureChannel to the server is open */
    eUA_CLIENTSTATE_SESSION,              /* A session with the server is open */
    eUA_CLIENTSTATE_SESSION_DISCONNECTED, /* Disconnected vs renewed? */
    eUA_CLIENTSTATE_SESSION_RENEWED       /* A session with the server is open (renewed) */
} eUA_ClientState;

/**
 * .. _datetime:
 *
 * DateTime
 * ^^^^^^^^
 * An instance in time. A DateTime value is encoded as a 64-bit signed integer
 * which represents the number of 100 nanosecond intervals since January 1, 1601
 * (UTC).
 *
 * The methods providing an interface to the system clock are provided by a
 * "plugin" that is statically linked with the library. */

typedef int64_t eUA_DateTime;

#define eUA_ACCESSLEVELMASK_READ           (0x01u << 0u)
#define eUA_ACCESSLEVELMASK_WRITE          (0x01u << 1u)
#define eUA_ACCESSLEVELMASK_HISTORYREAD    (0x01u << 2u)
#define eUA_ACCESSLEVELMASK_HISTORYWRITE   (0x01u << 3u)
#define eUA_ACCESSLEVELMASK_SEMANTICCHANGE (0x01u << 4u)
#define eUA_ACCESSLEVELMASK_STATUSWRITE    (0x01u << 5u)
#define eUA_ACCESSLEVELMASK_TIMESTAMPWRITE (0x01u << 6u)

typedef void (*eUA_Client_CallbackConnectionState)		(RTS_HANDLE hClient, eUA_ClientState clientState);
typedef void (*eUA_Client_CallbackInactivity)		(RTS_HANDLE hClient);
typedef void (*eUA_Client_CallbackSubscriptionDelete)	(RTS_HANDLE hClient, RTS_UI32 subId, void *subContext);
typedef void (*eUA_Client_CallbackSubscriptionState)	(RTS_HANDLE hClient, RTS_UI32 subId, void *subContext, RTS_HANDLE hStatusNotification);
/* Callback for DataChange notifications */
typedef void (*eUA_Client_CallbackMonitoredItemDataChange)			(RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, void *subContext, RTS_UI32 nMonId, void *monContext, RTS_HANDLE hValue);
/* Callback for the deletion of a MonitoredItem */
typedef void (*eUA_Client_CallbackMonitoredItemDelete)	(RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, void *subContext, RTS_UI32 nMonId, void *monContext);
/* Callback for Browsing*/
typedef RTS_RESULT (*eUA_Client_CallbackBrowse)(void* pContext,
										  const char* sDisplayName, RTS_UI16 nLengthDisplayName,
										  eUA_NodeId* pNodeId,
										  eUA_NodeClass nNodeClass,
										  const char* sTypeName, RTS_UI16 nLengthTypeName,
										  RTS_BOOL bProperty
);
          
/* routines for OS specific modules */
RTS_RESULT CmpElrestOPCUAClient_init3(void);
RTS_RESULT CmpElrestOPCUAClient_run(void);
RTS_RESULT CmpElrestOPCUAClient_exit3(void);

RTS_HANDLE CDECL eUA_Connect(char* URL, char* pszUser, char* pszPassword, eUA_Client_CallbackConnectionState stateCallback, eUA_Client_CallbackInactivity inactivityCallback);
typedef RTS_HANDLE (CDECL * PFEUA_CONNECT) (char* URL, char* pszUser, char* pszPassword, eUA_Client_CallbackConnectionState stateCallback, eUA_Client_CallbackInactivity inactivityCallback);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_CONNECT_NOTIMPLEMENTED)
	#define USE_eUA_Connect
	#define EXT_eUA_Connect
	#define GET_eUA_Connect(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_Connect(p0,p1,p2,p3,p4) (RTS_HANDLE)RTS_INVALID_HANDLE
	#define CHK_eUA_Connect  FALSE
	#define EXP_eUA_Connect  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_Connect
	#define EXT_eUA_Connect
	#define GET_eUA_Connect(fl)  CAL_CMGETAPI( "eUA_Connect" ) 
	#define CAL_eUA_Connect  eUA_Connect
	#define CHK_eUA_Connect  TRUE
	#define EXP_eUA_Connect  CAL_CMEXPAPI( "eUA_Connect" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_Connect
	#define EXT_eUA_Connect
	#define GET_eUA_Connect(fl)  CAL_CMGETAPI( "eUA_Connect" ) 
	#define CAL_eUA_Connect  eUA_Connect
	#define CHK_eUA_Connect  TRUE
	#define EXP_eUA_Connect  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Connect", (RTS_UINTPTR)eUA_Connect, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_Connect
	#define EXT_CmpElrestOPCUAClienteUA_Connect
	#define GET_CmpElrestOPCUAClienteUA_Connect  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_Connect  eUA_Connect
	#define CHK_CmpElrestOPCUAClienteUA_Connect  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_Connect  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_Connect
	#define EXT_eUA_Connect
	#define GET_eUA_Connect(fl)  CAL_CMGETAPI( "eUA_Connect" ) 
	#define CAL_eUA_Connect  eUA_Connect
	#define CHK_eUA_Connect  TRUE
	#define EXP_eUA_Connect  CAL_CMEXPAPI( "eUA_Connect" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_Connect  PFEUA_CONNECT pfeUA_Connect;
	#define EXT_eUA_Connect  extern PFEUA_CONNECT pfeUA_Connect;
	#define GET_eUA_Connect(fl)  s_pfCMGetAPI2( "eUA_Connect", (RTS_VOID_FCTPTR *)&pfeUA_Connect, (fl), 0, 0)
	#define CAL_eUA_Connect  pfeUA_Connect
	#define CHK_eUA_Connect  (pfeUA_Connect != NULL)
	#define EXP_eUA_Connect   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Connect", (RTS_UINTPTR)eUA_Connect, 0, 0) 
#endif

RTS_RESULT CDECL eUA_Disconnect(RTS_HANDLE hClient);
typedef RTS_RESULT (CDECL * PFEUA_DISCONNECT) (RTS_HANDLE hClient);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_DISCONNECT_NOTIMPLEMENTED)
	#define USE_eUA_Disconnect
	#define EXT_eUA_Disconnect
	#define GET_eUA_Disconnect(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_Disconnect(p0) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_Disconnect  FALSE
	#define EXP_eUA_Disconnect  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_Disconnect
	#define EXT_eUA_Disconnect
	#define GET_eUA_Disconnect(fl)  CAL_CMGETAPI( "eUA_Disconnect" ) 
	#define CAL_eUA_Disconnect  eUA_Disconnect
	#define CHK_eUA_Disconnect  TRUE
	#define EXP_eUA_Disconnect  CAL_CMEXPAPI( "eUA_Disconnect" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_Disconnect
	#define EXT_eUA_Disconnect
	#define GET_eUA_Disconnect(fl)  CAL_CMGETAPI( "eUA_Disconnect" ) 
	#define CAL_eUA_Disconnect  eUA_Disconnect
	#define CHK_eUA_Disconnect  TRUE
	#define EXP_eUA_Disconnect  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Disconnect", (RTS_UINTPTR)eUA_Disconnect, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_Disconnect
	#define EXT_CmpElrestOPCUAClienteUA_Disconnect
	#define GET_CmpElrestOPCUAClienteUA_Disconnect  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_Disconnect  eUA_Disconnect
	#define CHK_CmpElrestOPCUAClienteUA_Disconnect  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_Disconnect  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_Disconnect
	#define EXT_eUA_Disconnect
	#define GET_eUA_Disconnect(fl)  CAL_CMGETAPI( "eUA_Disconnect" ) 
	#define CAL_eUA_Disconnect  eUA_Disconnect
	#define CHK_eUA_Disconnect  TRUE
	#define EXP_eUA_Disconnect  CAL_CMEXPAPI( "eUA_Disconnect" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_Disconnect  PFEUA_DISCONNECT pfeUA_Disconnect;
	#define EXT_eUA_Disconnect  extern PFEUA_DISCONNECT pfeUA_Disconnect;
	#define GET_eUA_Disconnect(fl)  s_pfCMGetAPI2( "eUA_Disconnect", (RTS_VOID_FCTPTR *)&pfeUA_Disconnect, (fl), 0, 0)
	#define CAL_eUA_Disconnect  pfeUA_Disconnect
	#define CHK_eUA_Disconnect  (pfeUA_Disconnect != NULL)
	#define EXP_eUA_Disconnect   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Disconnect", (RTS_UINTPTR)eUA_Disconnect, 0, 0) 
#endif

RTS_RESULT CDECL eUA_GetValue(RTS_HANDLE hClient, const char* sPath, RTS_HANDLE* phValue, RTS_UI16* pType, RTS_UI8* pUserAccessLevel, void** pValue);
typedef RTS_RESULT (CDECL * PFEUA_GETVALUE) (RTS_HANDLE hClient, const char* sPath, RTS_HANDLE* phValue, RTS_UI16* pType, RTS_UI8* pUserAccessLevel, void** pValue);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_GETVALUE_NOTIMPLEMENTED)
	#define USE_eUA_GetValue
	#define EXT_eUA_GetValue
	#define GET_eUA_GetValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_GetValue(p0,p1,p2,p3,p4,p5) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_GetValue  FALSE
	#define EXP_eUA_GetValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_GetValue
	#define EXT_eUA_GetValue
	#define GET_eUA_GetValue(fl)  CAL_CMGETAPI( "eUA_GetValue" ) 
	#define CAL_eUA_GetValue  eUA_GetValue
	#define CHK_eUA_GetValue  TRUE
	#define EXP_eUA_GetValue  CAL_CMEXPAPI( "eUA_GetValue" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_GetValue
	#define EXT_eUA_GetValue
	#define GET_eUA_GetValue(fl)  CAL_CMGETAPI( "eUA_GetValue" ) 
	#define CAL_eUA_GetValue  eUA_GetValue
	#define CHK_eUA_GetValue  TRUE
	#define EXP_eUA_GetValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_GetValue", (RTS_UINTPTR)eUA_GetValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_GetValue
	#define EXT_CmpElrestOPCUAClienteUA_GetValue
	#define GET_CmpElrestOPCUAClienteUA_GetValue  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_GetValue  eUA_GetValue
	#define CHK_CmpElrestOPCUAClienteUA_GetValue  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_GetValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_GetValue
	#define EXT_eUA_GetValue
	#define GET_eUA_GetValue(fl)  CAL_CMGETAPI( "eUA_GetValue" ) 
	#define CAL_eUA_GetValue  eUA_GetValue
	#define CHK_eUA_GetValue  TRUE
	#define EXP_eUA_GetValue  CAL_CMEXPAPI( "eUA_GetValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_GetValue  PFEUA_GETVALUE pfeUA_GetValue;
	#define EXT_eUA_GetValue  extern PFEUA_GETVALUE pfeUA_GetValue;
	#define GET_eUA_GetValue(fl)  s_pfCMGetAPI2( "eUA_GetValue", (RTS_VOID_FCTPTR *)&pfeUA_GetValue, (fl), 0, 0)
	#define CAL_eUA_GetValue  pfeUA_GetValue
	#define CHK_eUA_GetValue  (pfeUA_GetValue != NULL)
	#define EXP_eUA_GetValue   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_GetValue", (RTS_UINTPTR)eUA_GetValue, 0, 0) 
#endif

RTS_RESULT CDECL eUA_SetValue(RTS_HANDLE hClient, const char* sPath, RTS_UI16 nType, void* pValue);
typedef RTS_RESULT (CDECL * PFEUA_SETVALUE) (RTS_HANDLE hClient, const char* sPath, RTS_UI16 nType, void* pValue);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_SETVALUE_NOTIMPLEMENTED)
	#define USE_eUA_SetValue
	#define EXT_eUA_SetValue
	#define GET_eUA_SetValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_SetValue(p0,p1,p2,p3) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_SetValue  FALSE
	#define EXP_eUA_SetValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_SetValue
	#define EXT_eUA_SetValue
	#define GET_eUA_SetValue(fl)  CAL_CMGETAPI( "eUA_SetValue" ) 
	#define CAL_eUA_SetValue  eUA_SetValue
	#define CHK_eUA_SetValue  TRUE
	#define EXP_eUA_SetValue  CAL_CMEXPAPI( "eUA_SetValue" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_SetValue
	#define EXT_eUA_SetValue
	#define GET_eUA_SetValue(fl)  CAL_CMGETAPI( "eUA_SetValue" ) 
	#define CAL_eUA_SetValue  eUA_SetValue
	#define CHK_eUA_SetValue  TRUE
	#define EXP_eUA_SetValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_SetValue", (RTS_UINTPTR)eUA_SetValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_SetValue
	#define EXT_CmpElrestOPCUAClienteUA_SetValue
	#define GET_CmpElrestOPCUAClienteUA_SetValue  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_SetValue  eUA_SetValue
	#define CHK_CmpElrestOPCUAClienteUA_SetValue  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_SetValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_SetValue
	#define EXT_eUA_SetValue
	#define GET_eUA_SetValue(fl)  CAL_CMGETAPI( "eUA_SetValue" ) 
	#define CAL_eUA_SetValue  eUA_SetValue
	#define CHK_eUA_SetValue  TRUE
	#define EXP_eUA_SetValue  CAL_CMEXPAPI( "eUA_SetValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_SetValue  PFEUA_SETVALUE pfeUA_SetValue;
	#define EXT_eUA_SetValue  extern PFEUA_SETVALUE pfeUA_SetValue;
	#define GET_eUA_SetValue(fl)  s_pfCMGetAPI2( "eUA_SetValue", (RTS_VOID_FCTPTR *)&pfeUA_SetValue, (fl), 0, 0)
	#define CAL_eUA_SetValue  pfeUA_SetValue
	#define CHK_eUA_SetValue  (pfeUA_SetValue != NULL)
	#define EXP_eUA_SetValue   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_SetValue", (RTS_UINTPTR)eUA_SetValue, 0, 0) 
#endif

/**
 * hClient - Handle to a client connection created via eUA_Connect
 * pPublishingInterval	- [in, out]
 *						 defines how often the server checks if there are notification packages (publish responses) for a Subscription to be sent back to the client. Default: 500 (ms).
 *	 				     Instead of using very small PublishingInterval, consider using a smaller SamplingInterval. The server may also increase the PublishingInterval to a default minimum.
 *						 [in] : the whished Interval; if NULL or 0 [ms] => default: 500 [ms]
 *						 [out]: if not NULL then the accepted interval by server
 * pLifetimeCount		- [in, out]
 *						 The client�s responsibility is to send PublishRequests to the server, in order to enable the server to send PublishResponses back.
 *					     The PublishResponses are used to deliver the notifications: but if there are no PublishRequests, the server cannot send a notification to the client.
 *						 The server will also verify that the client is alive by checking that new PublishRequests are received.
 *						 LifeTimeCount defines the number of PublishingIntervals to wait for a new PublishRequest, before realizing that the client is no longer active. The Subscription is then removed from the server.
 *						 [in] : the wished value; if NULL or 0 [ms] => default: 10 000
 *						 [out]: if not NULL then the accepted interval by server
 * pMaxKeepAliveCount	- [in, out]
 *						 If there is no data to send after the next PublishingInterval, the server will skip it.
 *                       But KeepAlive defines how many intervals may be skipped, before an empty notification is sent anyway: 
 *                       to give the client a hint that the subscription is still alive in the server and that there just has not been any data arriving to the client.				
 *						 [in] : the wished value; if NULL or 0 [ms] => default: 10
 *						 [out]: if not NULL then the accepted interval by server
 * nMaxNotificationsPerPublish - [in]
 *						  Maximum Notifications in a PublishResponse. Default: 0 [unlimited]
 * bPublishingEnabled	- [in]
 *                        Enable/disable the Publishing
 * nPriority			- [in]
 *						  Priority
 * stateCallback		- [in]
 *	                      Callback which will be called when the state of the subscrisption changes
 * deleteCallback		- [i]
 *						  Callback which will be called when the subscription is going to be deleted
 * Return:
 *	ERR_OK - success
 */
RTS_RESULT CDECL eUA_CreateSubscription(RTS_HANDLE hClient, RTS_REAL64* pPublishingInterval, RTS_UI32* pLifetimeCount, RTS_UI32* pMaxKeepAliveCount, RTS_UI32 nMaxNotificationsPerPublish, RTS_BOOL bPublishingEnabled, RTS_UI8 nPriority, void* pContext, eUA_Client_CallbackSubscriptionState stateCallback, eUA_Client_CallbackSubscriptionDelete deleteCallback, RTS_UI32* pSubscriptionId);
typedef RTS_RESULT (CDECL * PFEUA_CREATESUBSCRIPTION) (RTS_HANDLE hClient, RTS_REAL64* pPublishingInterval, RTS_UI32* pLifetimeCount, RTS_UI32* pMaxKeepAliveCount, RTS_UI32 nMaxNotificationsPerPublish, RTS_BOOL bPublishingEnabled, RTS_UI8 nPriority, void* pContext, eUA_Client_CallbackSubscriptionState stateCallback, eUA_Client_CallbackSubscriptionDelete deleteCallback, RTS_UI32* pSubscriptionId);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_CREATESUBSCRIPTION_NOTIMPLEMENTED)
	#define USE_eUA_CreateSubscription
	#define EXT_eUA_CreateSubscription
	#define GET_eUA_CreateSubscription(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_CreateSubscription(p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_CreateSubscription  FALSE
	#define EXP_eUA_CreateSubscription  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_CreateSubscription
	#define EXT_eUA_CreateSubscription
	#define GET_eUA_CreateSubscription(fl)  CAL_CMGETAPI( "eUA_CreateSubscription" ) 
	#define CAL_eUA_CreateSubscription  eUA_CreateSubscription
	#define CHK_eUA_CreateSubscription  TRUE
	#define EXP_eUA_CreateSubscription  CAL_CMEXPAPI( "eUA_CreateSubscription" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_CreateSubscription
	#define EXT_eUA_CreateSubscription
	#define GET_eUA_CreateSubscription(fl)  CAL_CMGETAPI( "eUA_CreateSubscription" ) 
	#define CAL_eUA_CreateSubscription  eUA_CreateSubscription
	#define CHK_eUA_CreateSubscription  TRUE
	#define EXP_eUA_CreateSubscription  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_CreateSubscription", (RTS_UINTPTR)eUA_CreateSubscription, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_CreateSubscription
	#define EXT_CmpElrestOPCUAClienteUA_CreateSubscription
	#define GET_CmpElrestOPCUAClienteUA_CreateSubscription  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_CreateSubscription  eUA_CreateSubscription
	#define CHK_CmpElrestOPCUAClienteUA_CreateSubscription  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_CreateSubscription  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_CreateSubscription
	#define EXT_eUA_CreateSubscription
	#define GET_eUA_CreateSubscription(fl)  CAL_CMGETAPI( "eUA_CreateSubscription" ) 
	#define CAL_eUA_CreateSubscription  eUA_CreateSubscription
	#define CHK_eUA_CreateSubscription  TRUE
	#define EXP_eUA_CreateSubscription  CAL_CMEXPAPI( "eUA_CreateSubscription" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_CreateSubscription  PFEUA_CREATESUBSCRIPTION pfeUA_CreateSubscription;
	#define EXT_eUA_CreateSubscription  extern PFEUA_CREATESUBSCRIPTION pfeUA_CreateSubscription;
	#define GET_eUA_CreateSubscription(fl)  s_pfCMGetAPI2( "eUA_CreateSubscription", (RTS_VOID_FCTPTR *)&pfeUA_CreateSubscription, (fl), 0, 0)
	#define CAL_eUA_CreateSubscription  pfeUA_CreateSubscription
	#define CHK_eUA_CreateSubscription  (pfeUA_CreateSubscription != NULL)
	#define EXP_eUA_CreateSubscription   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_CreateSubscription", (RTS_UINTPTR)eUA_CreateSubscription, 0, 0) 
#endif

RTS_RESULT CDECL eUA_RegValue(RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, const char* sPath, const RTS_UI32 nSamplingInterval, void* pContext, eUA_Client_CallbackMonitoredItemDataChange callbackDataChange, eUA_Client_CallbackMonitoredItemDelete callbackDeleteMonitoredItem, RTS_UI32* pMonId);
typedef RTS_RESULT (CDECL * PFEUA_REGVALUE) (RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, const char* sPath, const RTS_UI32 nSamplingInterval, void* pContext, eUA_Client_CallbackMonitoredItemDataChange callbackDataChange, eUA_Client_CallbackMonitoredItemDelete callbackDeleteMonitoredItem, RTS_UI32* pMonId);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_REGVALUE_NOTIMPLEMENTED)
	#define USE_eUA_RegValue
	#define EXT_eUA_RegValue
	#define GET_eUA_RegValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_RegValue(p0,p1,p2,p3,p4,p5,p6,p7) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_RegValue  FALSE
	#define EXP_eUA_RegValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_RegValue
	#define EXT_eUA_RegValue
	#define GET_eUA_RegValue(fl)  CAL_CMGETAPI( "eUA_RegValue" ) 
	#define CAL_eUA_RegValue  eUA_RegValue
	#define CHK_eUA_RegValue  TRUE
	#define EXP_eUA_RegValue  CAL_CMEXPAPI( "eUA_RegValue" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_RegValue
	#define EXT_eUA_RegValue
	#define GET_eUA_RegValue(fl)  CAL_CMGETAPI( "eUA_RegValue" ) 
	#define CAL_eUA_RegValue  eUA_RegValue
	#define CHK_eUA_RegValue  TRUE
	#define EXP_eUA_RegValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_RegValue", (RTS_UINTPTR)eUA_RegValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_RegValue
	#define EXT_CmpElrestOPCUAClienteUA_RegValue
	#define GET_CmpElrestOPCUAClienteUA_RegValue  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_RegValue  eUA_RegValue
	#define CHK_CmpElrestOPCUAClienteUA_RegValue  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_RegValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_RegValue
	#define EXT_eUA_RegValue
	#define GET_eUA_RegValue(fl)  CAL_CMGETAPI( "eUA_RegValue" ) 
	#define CAL_eUA_RegValue  eUA_RegValue
	#define CHK_eUA_RegValue  TRUE
	#define EXP_eUA_RegValue  CAL_CMEXPAPI( "eUA_RegValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_RegValue  PFEUA_REGVALUE pfeUA_RegValue;
	#define EXT_eUA_RegValue  extern PFEUA_REGVALUE pfeUA_RegValue;
	#define GET_eUA_RegValue(fl)  s_pfCMGetAPI2( "eUA_RegValue", (RTS_VOID_FCTPTR *)&pfeUA_RegValue, (fl), 0, 0)
	#define CAL_eUA_RegValue  pfeUA_RegValue
	#define CHK_eUA_RegValue  (pfeUA_RegValue != NULL)
	#define EXP_eUA_RegValue   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_RegValue", (RTS_UINTPTR)eUA_RegValue, 0, 0) 
#endif

RTS_RESULT CDECL eUA_RegValueChange(RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, const RTS_UI32 nMonId, const RTS_UI32 nSamplingInterval);
typedef RTS_RESULT (CDECL * PFEUA_REGVALUECHANGE) (RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, const RTS_UI32 nMonId, const RTS_UI32 nSamplingInterval);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_REGVALUECHANGE_NOTIMPLEMENTED)
	#define USE_eUA_RegValueChange
	#define EXT_eUA_RegValueChange
	#define GET_eUA_RegValueChange(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_RegValueChange(p0,p1,p2,p3) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_RegValueChange  FALSE
	#define EXP_eUA_RegValueChange  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_RegValueChange
	#define EXT_eUA_RegValueChange
	#define GET_eUA_RegValueChange(fl)  CAL_CMGETAPI( "eUA_RegValueChange" ) 
	#define CAL_eUA_RegValueChange  eUA_RegValueChange
	#define CHK_eUA_RegValueChange  TRUE
	#define EXP_eUA_RegValueChange  CAL_CMEXPAPI( "eUA_RegValueChange" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_RegValueChange
	#define EXT_eUA_RegValueChange
	#define GET_eUA_RegValueChange(fl)  CAL_CMGETAPI( "eUA_RegValueChange" ) 
	#define CAL_eUA_RegValueChange  eUA_RegValueChange
	#define CHK_eUA_RegValueChange  TRUE
	#define EXP_eUA_RegValueChange  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_RegValueChange", (RTS_UINTPTR)eUA_RegValueChange, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_RegValueChange
	#define EXT_CmpElrestOPCUAClienteUA_RegValueChange
	#define GET_CmpElrestOPCUAClienteUA_RegValueChange  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_RegValueChange  eUA_RegValueChange
	#define CHK_CmpElrestOPCUAClienteUA_RegValueChange  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_RegValueChange  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_RegValueChange
	#define EXT_eUA_RegValueChange
	#define GET_eUA_RegValueChange(fl)  CAL_CMGETAPI( "eUA_RegValueChange" ) 
	#define CAL_eUA_RegValueChange  eUA_RegValueChange
	#define CHK_eUA_RegValueChange  TRUE
	#define EXP_eUA_RegValueChange  CAL_CMEXPAPI( "eUA_RegValueChange" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_RegValueChange  PFEUA_REGVALUECHANGE pfeUA_RegValueChange;
	#define EXT_eUA_RegValueChange  extern PFEUA_REGVALUECHANGE pfeUA_RegValueChange;
	#define GET_eUA_RegValueChange(fl)  s_pfCMGetAPI2( "eUA_RegValueChange", (RTS_VOID_FCTPTR *)&pfeUA_RegValueChange, (fl), 0, 0)
	#define CAL_eUA_RegValueChange  pfeUA_RegValueChange
	#define CHK_eUA_RegValueChange  (pfeUA_RegValueChange != NULL)
	#define EXP_eUA_RegValueChange   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_RegValueChange", (RTS_UINTPTR)eUA_RegValueChange, 0, 0) 
#endif

RTS_RESULT CDECL eUA_UnregValue(RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, RTS_UI32 nMonId);
typedef RTS_RESULT (CDECL * PFEUA_UNREGVALUE) (RTS_HANDLE hClient, RTS_UI32 nSubscriptionId, RTS_UI32 nMonId);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_UNREGVALUE_NOTIMPLEMENTED)
	#define USE_eUA_UnregValue
	#define EXT_eUA_UnregValue
	#define GET_eUA_UnregValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_UnregValue(p0,p1,p2) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_UnregValue  FALSE
	#define EXP_eUA_UnregValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_UnregValue
	#define EXT_eUA_UnregValue
	#define GET_eUA_UnregValue(fl)  CAL_CMGETAPI( "eUA_UnregValue" ) 
	#define CAL_eUA_UnregValue  eUA_UnregValue
	#define CHK_eUA_UnregValue  TRUE
	#define EXP_eUA_UnregValue  CAL_CMEXPAPI( "eUA_UnregValue" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_UnregValue
	#define EXT_eUA_UnregValue
	#define GET_eUA_UnregValue(fl)  CAL_CMGETAPI( "eUA_UnregValue" ) 
	#define CAL_eUA_UnregValue  eUA_UnregValue
	#define CHK_eUA_UnregValue  TRUE
	#define EXP_eUA_UnregValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_UnregValue", (RTS_UINTPTR)eUA_UnregValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_UnregValue
	#define EXT_CmpElrestOPCUAClienteUA_UnregValue
	#define GET_CmpElrestOPCUAClienteUA_UnregValue  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_UnregValue  eUA_UnregValue
	#define CHK_CmpElrestOPCUAClienteUA_UnregValue  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_UnregValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_UnregValue
	#define EXT_eUA_UnregValue
	#define GET_eUA_UnregValue(fl)  CAL_CMGETAPI( "eUA_UnregValue" ) 
	#define CAL_eUA_UnregValue  eUA_UnregValue
	#define CHK_eUA_UnregValue  TRUE
	#define EXP_eUA_UnregValue  CAL_CMEXPAPI( "eUA_UnregValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_UnregValue  PFEUA_UNREGVALUE pfeUA_UnregValue;
	#define EXT_eUA_UnregValue  extern PFEUA_UNREGVALUE pfeUA_UnregValue;
	#define GET_eUA_UnregValue(fl)  s_pfCMGetAPI2( "eUA_UnregValue", (RTS_VOID_FCTPTR *)&pfeUA_UnregValue, (fl), 0, 0)
	#define CAL_eUA_UnregValue  pfeUA_UnregValue
	#define CHK_eUA_UnregValue  (pfeUA_UnregValue != NULL)
	#define EXP_eUA_UnregValue   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_UnregValue", (RTS_UINTPTR)eUA_UnregValue, 0, 0) 
#endif

RTS_RESULT CDECL eUA_ClearValue(RTS_HANDLE hValue);
typedef RTS_RESULT (CDECL * PFEUA_CLEARVALUE) (RTS_HANDLE hValue);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_CLEARVALUE_NOTIMPLEMENTED)
	#define USE_eUA_ClearValue
	#define EXT_eUA_ClearValue
	#define GET_eUA_ClearValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_ClearValue(p0) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_ClearValue  FALSE
	#define EXP_eUA_ClearValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_ClearValue
	#define EXT_eUA_ClearValue
	#define GET_eUA_ClearValue(fl)  CAL_CMGETAPI( "eUA_ClearValue" ) 
	#define CAL_eUA_ClearValue  eUA_ClearValue
	#define CHK_eUA_ClearValue  TRUE
	#define EXP_eUA_ClearValue  CAL_CMEXPAPI( "eUA_ClearValue" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_ClearValue
	#define EXT_eUA_ClearValue
	#define GET_eUA_ClearValue(fl)  CAL_CMGETAPI( "eUA_ClearValue" ) 
	#define CAL_eUA_ClearValue  eUA_ClearValue
	#define CHK_eUA_ClearValue  TRUE
	#define EXP_eUA_ClearValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_ClearValue", (RTS_UINTPTR)eUA_ClearValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_ClearValue
	#define EXT_CmpElrestOPCUAClienteUA_ClearValue
	#define GET_CmpElrestOPCUAClienteUA_ClearValue  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_ClearValue  eUA_ClearValue
	#define CHK_CmpElrestOPCUAClienteUA_ClearValue  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_ClearValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_ClearValue
	#define EXT_eUA_ClearValue
	#define GET_eUA_ClearValue(fl)  CAL_CMGETAPI( "eUA_ClearValue" ) 
	#define CAL_eUA_ClearValue  eUA_ClearValue
	#define CHK_eUA_ClearValue  TRUE
	#define EXP_eUA_ClearValue  CAL_CMEXPAPI( "eUA_ClearValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_ClearValue  PFEUA_CLEARVALUE pfeUA_ClearValue;
	#define EXT_eUA_ClearValue  extern PFEUA_CLEARVALUE pfeUA_ClearValue;
	#define GET_eUA_ClearValue(fl)  s_pfCMGetAPI2( "eUA_ClearValue", (RTS_VOID_FCTPTR *)&pfeUA_ClearValue, (fl), 0, 0)
	#define CAL_eUA_ClearValue  pfeUA_ClearValue
	#define CHK_eUA_ClearValue  (pfeUA_ClearValue != NULL)
	#define EXP_eUA_ClearValue   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_ClearValue", (RTS_UINTPTR)eUA_ClearValue, 0, 0) 
#endif

RTS_RESULT CDECL eUA_GetValueAndTypeFromHandle(RTS_HANDLE hValue, void** pValue, RTS_UI16* pValueType);
typedef RTS_RESULT (CDECL * PFEUA_GETVALUEANDTYPEFROMHANDLE) (RTS_HANDLE hValue, void** pValue, RTS_UI16* pValueType);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_GETVALUEANDTYPEFROMHANDLE_NOTIMPLEMENTED)
	#define USE_eUA_GetValueAndTypeFromHandle
	#define EXT_eUA_GetValueAndTypeFromHandle
	#define GET_eUA_GetValueAndTypeFromHandle(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_GetValueAndTypeFromHandle(p0,p1,p2) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_GetValueAndTypeFromHandle  FALSE
	#define EXP_eUA_GetValueAndTypeFromHandle  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_GetValueAndTypeFromHandle
	#define EXT_eUA_GetValueAndTypeFromHandle
	#define GET_eUA_GetValueAndTypeFromHandle(fl)  CAL_CMGETAPI( "eUA_GetValueAndTypeFromHandle" ) 
	#define CAL_eUA_GetValueAndTypeFromHandle  eUA_GetValueAndTypeFromHandle
	#define CHK_eUA_GetValueAndTypeFromHandle  TRUE
	#define EXP_eUA_GetValueAndTypeFromHandle  CAL_CMEXPAPI( "eUA_GetValueAndTypeFromHandle" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_GetValueAndTypeFromHandle
	#define EXT_eUA_GetValueAndTypeFromHandle
	#define GET_eUA_GetValueAndTypeFromHandle(fl)  CAL_CMGETAPI( "eUA_GetValueAndTypeFromHandle" ) 
	#define CAL_eUA_GetValueAndTypeFromHandle  eUA_GetValueAndTypeFromHandle
	#define CHK_eUA_GetValueAndTypeFromHandle  TRUE
	#define EXP_eUA_GetValueAndTypeFromHandle  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_GetValueAndTypeFromHandle", (RTS_UINTPTR)eUA_GetValueAndTypeFromHandle, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_GetValueAndTypeFromHandle
	#define EXT_CmpElrestOPCUAClienteUA_GetValueAndTypeFromHandle
	#define GET_CmpElrestOPCUAClienteUA_GetValueAndTypeFromHandle  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_GetValueAndTypeFromHandle  eUA_GetValueAndTypeFromHandle
	#define CHK_CmpElrestOPCUAClienteUA_GetValueAndTypeFromHandle  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_GetValueAndTypeFromHandle  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_GetValueAndTypeFromHandle
	#define EXT_eUA_GetValueAndTypeFromHandle
	#define GET_eUA_GetValueAndTypeFromHandle(fl)  CAL_CMGETAPI( "eUA_GetValueAndTypeFromHandle" ) 
	#define CAL_eUA_GetValueAndTypeFromHandle  eUA_GetValueAndTypeFromHandle
	#define CHK_eUA_GetValueAndTypeFromHandle  TRUE
	#define EXP_eUA_GetValueAndTypeFromHandle  CAL_CMEXPAPI( "eUA_GetValueAndTypeFromHandle" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_GetValueAndTypeFromHandle  PFEUA_GETVALUEANDTYPEFROMHANDLE pfeUA_GetValueAndTypeFromHandle;
	#define EXT_eUA_GetValueAndTypeFromHandle  extern PFEUA_GETVALUEANDTYPEFROMHANDLE pfeUA_GetValueAndTypeFromHandle;
	#define GET_eUA_GetValueAndTypeFromHandle(fl)  s_pfCMGetAPI2( "eUA_GetValueAndTypeFromHandle", (RTS_VOID_FCTPTR *)&pfeUA_GetValueAndTypeFromHandle, (fl), 0, 0)
	#define CAL_eUA_GetValueAndTypeFromHandle  pfeUA_GetValueAndTypeFromHandle
	#define CHK_eUA_GetValueAndTypeFromHandle  (pfeUA_GetValueAndTypeFromHandle != NULL)
	#define EXP_eUA_GetValueAndTypeFromHandle   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_GetValueAndTypeFromHandle", (RTS_UINTPTR)eUA_GetValueAndTypeFromHandle, 0, 0) 
#endif

RTS_RESULT CDECL eUA_Client_run_iterate(RTS_HANDLE hClient, RTS_UI16 timeout);
typedef RTS_RESULT (CDECL * PFEUA_CLIENT_RUN_ITERATE) (RTS_HANDLE hClient, RTS_UI16 timeout);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_CLIENT_RUN_ITERATE_NOTIMPLEMENTED)
	#define USE_eUA_Client_run_iterate
	#define EXT_eUA_Client_run_iterate
	#define GET_eUA_Client_run_iterate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_Client_run_iterate(p0,p1) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_Client_run_iterate  FALSE
	#define EXP_eUA_Client_run_iterate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_Client_run_iterate
	#define EXT_eUA_Client_run_iterate
	#define GET_eUA_Client_run_iterate(fl)  CAL_CMGETAPI( "eUA_Client_run_iterate" ) 
	#define CAL_eUA_Client_run_iterate  eUA_Client_run_iterate
	#define CHK_eUA_Client_run_iterate  TRUE
	#define EXP_eUA_Client_run_iterate  CAL_CMEXPAPI( "eUA_Client_run_iterate" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_Client_run_iterate
	#define EXT_eUA_Client_run_iterate
	#define GET_eUA_Client_run_iterate(fl)  CAL_CMGETAPI( "eUA_Client_run_iterate" ) 
	#define CAL_eUA_Client_run_iterate  eUA_Client_run_iterate
	#define CHK_eUA_Client_run_iterate  TRUE
	#define EXP_eUA_Client_run_iterate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Client_run_iterate", (RTS_UINTPTR)eUA_Client_run_iterate, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_Client_run_iterate
	#define EXT_CmpElrestOPCUAClienteUA_Client_run_iterate
	#define GET_CmpElrestOPCUAClienteUA_Client_run_iterate  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_Client_run_iterate  eUA_Client_run_iterate
	#define CHK_CmpElrestOPCUAClienteUA_Client_run_iterate  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_Client_run_iterate  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_Client_run_iterate
	#define EXT_eUA_Client_run_iterate
	#define GET_eUA_Client_run_iterate(fl)  CAL_CMGETAPI( "eUA_Client_run_iterate" ) 
	#define CAL_eUA_Client_run_iterate  eUA_Client_run_iterate
	#define CHK_eUA_Client_run_iterate  TRUE
	#define EXP_eUA_Client_run_iterate  CAL_CMEXPAPI( "eUA_Client_run_iterate" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_Client_run_iterate  PFEUA_CLIENT_RUN_ITERATE pfeUA_Client_run_iterate;
	#define EXT_eUA_Client_run_iterate  extern PFEUA_CLIENT_RUN_ITERATE pfeUA_Client_run_iterate;
	#define GET_eUA_Client_run_iterate(fl)  s_pfCMGetAPI2( "eUA_Client_run_iterate", (RTS_VOID_FCTPTR *)&pfeUA_Client_run_iterate, (fl), 0, 0)
	#define CAL_eUA_Client_run_iterate  pfeUA_Client_run_iterate
	#define CHK_eUA_Client_run_iterate  (pfeUA_Client_run_iterate != NULL)
	#define EXP_eUA_Client_run_iterate   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Client_run_iterate", (RTS_UINTPTR)eUA_Client_run_iterate, 0, 0) 
#endif

RTS_RESULT CDECL eUA_Log(RTS_HANDLE hLog);
typedef RTS_RESULT (CDECL * PFEUA_LOG) (RTS_HANDLE hLog);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_LOG_NOTIMPLEMENTED)
	#define USE_eUA_Log
	#define EXT_eUA_Log
	#define GET_eUA_Log(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_Log(p0) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_Log  FALSE
	#define EXP_eUA_Log  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_Log
	#define EXT_eUA_Log
	#define GET_eUA_Log(fl)  CAL_CMGETAPI( "eUA_Log" ) 
	#define CAL_eUA_Log  eUA_Log
	#define CHK_eUA_Log  TRUE
	#define EXP_eUA_Log  CAL_CMEXPAPI( "eUA_Log" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_Log
	#define EXT_eUA_Log
	#define GET_eUA_Log(fl)  CAL_CMGETAPI( "eUA_Log" ) 
	#define CAL_eUA_Log  eUA_Log
	#define CHK_eUA_Log  TRUE
	#define EXP_eUA_Log  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Log", (RTS_UINTPTR)eUA_Log, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_Log
	#define EXT_CmpElrestOPCUAClienteUA_Log
	#define GET_CmpElrestOPCUAClienteUA_Log  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_Log  eUA_Log
	#define CHK_CmpElrestOPCUAClienteUA_Log  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_Log  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_Log
	#define EXT_eUA_Log
	#define GET_eUA_Log(fl)  CAL_CMGETAPI( "eUA_Log" ) 
	#define CAL_eUA_Log  eUA_Log
	#define CHK_eUA_Log  TRUE
	#define EXP_eUA_Log  CAL_CMEXPAPI( "eUA_Log" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_Log  PFEUA_LOG pfeUA_Log;
	#define EXT_eUA_Log  extern PFEUA_LOG pfeUA_Log;
	#define GET_eUA_Log(fl)  s_pfCMGetAPI2( "eUA_Log", (RTS_VOID_FCTPTR *)&pfeUA_Log, (fl), 0, 0)
	#define CAL_eUA_Log  pfeUA_Log
	#define CHK_eUA_Log  (pfeUA_Log != NULL)
	#define EXP_eUA_Log   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Log", (RTS_UINTPTR)eUA_Log, 0, 0) 
#endif

RTS_RESULT CDECL eUA_Browse(RTS_HANDLE hClient, const char* sPath, eUA_Client_CallbackBrowse callbackBrowse, void* pCallbackContext);
typedef RTS_RESULT (CDECL * PFEUA_BROWSE) (RTS_HANDLE hClient, const char* sPath, eUA_Client_CallbackBrowse callbackBrowse, void* pCallbackContext);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_BROWSE_NOTIMPLEMENTED)
	#define USE_eUA_Browse
	#define EXT_eUA_Browse
	#define GET_eUA_Browse(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_Browse(p0,p1,p2,p3) (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_eUA_Browse  FALSE
	#define EXP_eUA_Browse  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_Browse
	#define EXT_eUA_Browse
	#define GET_eUA_Browse(fl)  CAL_CMGETAPI( "eUA_Browse" ) 
	#define CAL_eUA_Browse  eUA_Browse
	#define CHK_eUA_Browse  TRUE
	#define EXP_eUA_Browse  CAL_CMEXPAPI( "eUA_Browse" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_Browse
	#define EXT_eUA_Browse
	#define GET_eUA_Browse(fl)  CAL_CMGETAPI( "eUA_Browse" ) 
	#define CAL_eUA_Browse  eUA_Browse
	#define CHK_eUA_Browse  TRUE
	#define EXP_eUA_Browse  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Browse", (RTS_UINTPTR)eUA_Browse, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_Browse
	#define EXT_CmpElrestOPCUAClienteUA_Browse
	#define GET_CmpElrestOPCUAClienteUA_Browse  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_Browse  eUA_Browse
	#define CHK_CmpElrestOPCUAClienteUA_Browse  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_Browse  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_Browse
	#define EXT_eUA_Browse
	#define GET_eUA_Browse(fl)  CAL_CMGETAPI( "eUA_Browse" ) 
	#define CAL_eUA_Browse  eUA_Browse
	#define CHK_eUA_Browse  TRUE
	#define EXP_eUA_Browse  CAL_CMEXPAPI( "eUA_Browse" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_Browse  PFEUA_BROWSE pfeUA_Browse;
	#define EXT_eUA_Browse  extern PFEUA_BROWSE pfeUA_Browse;
	#define GET_eUA_Browse(fl)  s_pfCMGetAPI2( "eUA_Browse", (RTS_VOID_FCTPTR *)&pfeUA_Browse, (fl), 0, 0)
	#define CAL_eUA_Browse  pfeUA_Browse
	#define CHK_eUA_Browse  (pfeUA_Browse != NULL)
	#define EXP_eUA_Browse   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_Browse", (RTS_UINTPTR)eUA_Browse, 0, 0) 
#endif

eUA_DateTime CDECL eUA_DateTime_toUnixTime(eUA_DateTime nDateTime);
typedef eUA_DateTime (CDECL * PFEUA_DATETIME_TOUNIXTIME) (eUA_DateTime nDateTime);
#if defined(CMPELRESTOPCUACLIENT_NOTIMPLEMENTED) || defined(EUA_DATETIME_TOUNIXTIME_NOTIMPLEMENTED)
	#define USE_eUA_DateTime_toUnixTime
	#define EXT_eUA_DateTime_toUnixTime
	#define GET_eUA_DateTime_toUnixTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_eUA_DateTime_toUnixTime(p0) (eUA_DateTime)ERR_NOTIMPLEMENTED
	#define CHK_eUA_DateTime_toUnixTime  FALSE
	#define EXP_eUA_DateTime_toUnixTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_eUA_DateTime_toUnixTime
	#define EXT_eUA_DateTime_toUnixTime
	#define GET_eUA_DateTime_toUnixTime(fl)  CAL_CMGETAPI( "eUA_DateTime_toUnixTime" ) 
	#define CAL_eUA_DateTime_toUnixTime  eUA_DateTime_toUnixTime
	#define CHK_eUA_DateTime_toUnixTime  TRUE
	#define EXP_eUA_DateTime_toUnixTime  CAL_CMEXPAPI( "eUA_DateTime_toUnixTime" ) 
#elif defined(MIXED_LINK) && !defined(CMPELRESTOPCUACLIENT_EXTERNAL)
	#define USE_eUA_DateTime_toUnixTime
	#define EXT_eUA_DateTime_toUnixTime
	#define GET_eUA_DateTime_toUnixTime(fl)  CAL_CMGETAPI( "eUA_DateTime_toUnixTime" ) 
	#define CAL_eUA_DateTime_toUnixTime  eUA_DateTime_toUnixTime
	#define CHK_eUA_DateTime_toUnixTime  TRUE
	#define EXP_eUA_DateTime_toUnixTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_DateTime_toUnixTime", (RTS_UINTPTR)eUA_DateTime_toUnixTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpElrestOPCUAClienteUA_DateTime_toUnixTime
	#define EXT_CmpElrestOPCUAClienteUA_DateTime_toUnixTime
	#define GET_CmpElrestOPCUAClienteUA_DateTime_toUnixTime  ERR_OK
	#define CAL_CmpElrestOPCUAClienteUA_DateTime_toUnixTime  eUA_DateTime_toUnixTime
	#define CHK_CmpElrestOPCUAClienteUA_DateTime_toUnixTime  TRUE
	#define EXP_CmpElrestOPCUAClienteUA_DateTime_toUnixTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_eUA_DateTime_toUnixTime
	#define EXT_eUA_DateTime_toUnixTime
	#define GET_eUA_DateTime_toUnixTime(fl)  CAL_CMGETAPI( "eUA_DateTime_toUnixTime" ) 
	#define CAL_eUA_DateTime_toUnixTime  eUA_DateTime_toUnixTime
	#define CHK_eUA_DateTime_toUnixTime  TRUE
	#define EXP_eUA_DateTime_toUnixTime  CAL_CMEXPAPI( "eUA_DateTime_toUnixTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_eUA_DateTime_toUnixTime  PFEUA_DATETIME_TOUNIXTIME pfeUA_DateTime_toUnixTime;
	#define EXT_eUA_DateTime_toUnixTime  extern PFEUA_DATETIME_TOUNIXTIME pfeUA_DateTime_toUnixTime;
	#define GET_eUA_DateTime_toUnixTime(fl)  s_pfCMGetAPI2( "eUA_DateTime_toUnixTime", (RTS_VOID_FCTPTR *)&pfeUA_DateTime_toUnixTime, (fl), 0, 0)
	#define CAL_eUA_DateTime_toUnixTime  pfeUA_DateTime_toUnixTime
	#define CHK_eUA_DateTime_toUnixTime  (pfeUA_DateTime_toUnixTime != NULL)
	#define EXP_eUA_DateTime_toUnixTime   s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"eUA_DateTime_toUnixTime", (RTS_UINTPTR)eUA_DateTime_toUnixTime, 0, 0) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ICmpElrestOPCUAClient_C;

#ifdef CPLUSPLUS
class ICmpElrestOPCUAClient : public IBase
{
	public:
};
	#ifndef ITF_CmpElrestOPCUAClient
		#define ITF_CmpElrestOPCUAClient static ICmpElrestOPCUAClient *pICmpElrestOPCUAClient = NULL;
	#endif
	#define EXTITF_CmpElrestOPCUAClient
#else	/*CPLUSPLUS*/
	typedef ICmpElrestOPCUAClient_C		ICmpElrestOPCUAClient;
	#ifndef ITF_CmpElrestOPCUAClient
		#define ITF_CmpElrestOPCUAClient
	#endif
	#define EXTITF_CmpElrestOPCUAClient
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_CMPELRESTOPCUACLIENTITF_H_*/
