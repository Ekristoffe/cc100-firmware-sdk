 /**
 * <interfacename>CmpParameterServer</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _CMPPARAMETERSERVERITF_H_
#define _CMPPARAMETERSERVERITF_H_

#include "CmpStd.h"

 

 




#include "ParameterServerItf.h"
#ifndef WAGO
#include "MotanParameterServerItf.h"
#endif
/**
 * <category>Static defines</category>
 * <description>Maximum number of static allocated namespaces</description>
 */
#ifndef PARAMETERSERVER_NUM_OF_STATIC_NAMESPACES
	#define PARAMETERSERVER_NUM_OF_STATIC_NAMESPACES 20
#endif


/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description> Callback function to get a parameter from a service</description>
 * <param name="pParams" type="IN/OUT">Pointer to an array of Service parameters.</param>
 * <param name="pui32NoOfServiceParams" type="IN/OUT">No of parameters supported by a service.</param>
 * <result></result>
 */
typedef RTS_RESULT (CDECL *PFPARAMETERGETCALLBACKFUNCTION)(RTS_IEC_STRING* sUserName, ServiceParameterStruct *pParams, RTS_IEC_DWORD *pui32NoOfServiceParams);

/**
 * <description> Callback function to set parameters of a service </description>
 * <param name="pParams" type="IN">Pointer to an array of Service parameters.</param>
 * <param name="pui32NoOfServiceParams" type="IN">No of parameters supported by a service.</param>
 * <param name="pui32IndexofError" type="IN">By error, the index in array where the error occurred.</param>
 * <result></result>
 */
typedef RTS_RESULT (CDECL *PFPARAMETERSETCALLBACKFUNCTION)(RTS_IEC_STRING* sUserName, ServiceParameterStruct *pParams, RTS_IEC_DWORD ui32NoOfServiceParams, RTS_IEC_DWORD *pui32IndexofError);

/**
 * <description> Callback function to get info of a service parameter </description>
 * <param name="pEventParam" type="IN">Pointer to the event parameter.</param>
 * <result></result>
 */
typedef RTS_RESULT (CDECL *PFPARAMETERGETINFOCALLBACKFUNCTION)(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szName, RTS_IEC_INT* pRights, RTS_IEC_INT *pType, RTS_IEC_DWORD *pSize,	RTS_IEC_DWORD *pui32Length, RTS_IEC_DWORD *pui32Min, RTS_IEC_DWORD *pui32Max);

/**
 * <description> Callback function to call a function of a service</description>
 * <param name="pEventParam" type="IN">Pointer to the event parameter.</param>
 * <result></result>
 */
typedef RTS_RESULT (CDECL *PFPARAMETERCALLCALLBACKFUNCTION)(RTS_IEC_STRING* sUserName, RTS_IEC_BOOL bLocal, RTS_IEC_STRING* szFunctionName, RTS_IEC_WORD nCountOfInputs, CallParameterStruct* pInputParaList, RTS_IEC_WORD* pCountOfOutputs, CallParameterStruct* pOutputParaList);


/* routines for OS specific modules */
RTS_RESULT CmpParameterServer_init3(void);
RTS_RESULT CmpParameterServer_run(void);
RTS_RESULT CmpParameterServer_exit3(void);

RTS_IEC_RESULT CDECL ParameterServerRegisterNamespace(RTS_IEC_STRING* sNamespace, PFPARAMETERGETCALLBACKFUNCTION pfHandlerGet, PFPARAMETERSETCALLBACKFUNCTION pfHandlerSet, PFPARAMETERGETINFOCALLBACKFUNCTION pfHandlerGetInfo);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERREGISTERNAMESPACE) (RTS_IEC_STRING* sNamespace, PFPARAMETERGETCALLBACKFUNCTION pfHandlerGet, PFPARAMETERSETCALLBACKFUNCTION pfHandlerSet, PFPARAMETERGETINFOCALLBACKFUNCTION pfHandlerGetInfo);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERREGISTERNAMESPACE_NOTIMPLEMENTED)
	#define USE_ParameterServerRegisterNamespace
	#define EXT_ParameterServerRegisterNamespace
	#define GET_ParameterServerRegisterNamespace(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerRegisterNamespace(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerRegisterNamespace  FALSE
	#define EXP_ParameterServerRegisterNamespace  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerRegisterNamespace
	#define EXT_ParameterServerRegisterNamespace
	#define GET_ParameterServerRegisterNamespace(fl)  CAL_CMGETAPI( "ParameterServerRegisterNamespace" ) 
	#define CAL_ParameterServerRegisterNamespace  ParameterServerRegisterNamespace
	#define CHK_ParameterServerRegisterNamespace  TRUE
	#define EXP_ParameterServerRegisterNamespace  CAL_CMEXPAPI( "ParameterServerRegisterNamespace" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerRegisterNamespace
	#define EXT_ParameterServerRegisterNamespace
	#define GET_ParameterServerRegisterNamespace(fl)  CAL_CMGETAPI( "ParameterServerRegisterNamespace" ) 
	#define CAL_ParameterServerRegisterNamespace  ParameterServerRegisterNamespace
	#define CHK_ParameterServerRegisterNamespace  TRUE
	#define EXP_ParameterServerRegisterNamespace  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerRegisterNamespace", (RTS_UINTPTR)ParameterServerRegisterNamespace, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerRegisterNamespace
	#define EXT_CmpParameterServerParameterServerRegisterNamespace
	#define GET_CmpParameterServerParameterServerRegisterNamespace  ERR_OK
	#define CAL_CmpParameterServerParameterServerRegisterNamespace  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerRegisterNamespace
	#define CHK_CmpParameterServerParameterServerRegisterNamespace	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerRegisterNamespace  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerRegisterNamespace
	#define EXT_ParameterServerRegisterNamespace
	#define GET_ParameterServerRegisterNamespace(fl)  CAL_CMGETAPI( "ParameterServerRegisterNamespace" ) 
	#define CAL_ParameterServerRegisterNamespace  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerRegisterNamespace
	#define CHK_ParameterServerRegisterNamespace	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerRegisterNamespace  CAL_CMEXPAPI( "ParameterServerRegisterNamespace" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerRegisterNamespace  PFPARAMETERSERVERREGISTERNAMESPACE pfParameterServerRegisterNamespace;
	#define EXT_ParameterServerRegisterNamespace  extern PFPARAMETERSERVERREGISTERNAMESPACE pfParameterServerRegisterNamespace;
	#define GET_ParameterServerRegisterNamespace(fl)  s_pfCMGetAPI2( "ParameterServerRegisterNamespace", (RTS_VOID_FCTPTR *)&pfParameterServerRegisterNamespace, (fl), 0, 0)
	#define CAL_ParameterServerRegisterNamespace  pfParameterServerRegisterNamespace
	#define CHK_ParameterServerRegisterNamespace  (pfParameterServerRegisterNamespace != NULL)
	#define EXP_ParameterServerRegisterNamespace  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerRegisterNamespace", (RTS_UINTPTR)ParameterServerRegisterNamespace, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerUnregisterNamespace(RTS_IEC_STRING* sNamespace);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERUNREGISTERNAMESPACE) (RTS_IEC_STRING* sNamespace);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERUNREGISTERNAMESPACE_NOTIMPLEMENTED)
	#define USE_ParameterServerUnregisterNamespace
	#define EXT_ParameterServerUnregisterNamespace
	#define GET_ParameterServerUnregisterNamespace(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerUnregisterNamespace(p0)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerUnregisterNamespace  FALSE
	#define EXP_ParameterServerUnregisterNamespace  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerUnregisterNamespace
	#define EXT_ParameterServerUnregisterNamespace
	#define GET_ParameterServerUnregisterNamespace(fl)  CAL_CMGETAPI( "ParameterServerUnregisterNamespace" ) 
	#define CAL_ParameterServerUnregisterNamespace  ParameterServerUnregisterNamespace
	#define CHK_ParameterServerUnregisterNamespace  TRUE
	#define EXP_ParameterServerUnregisterNamespace  CAL_CMEXPAPI( "ParameterServerUnregisterNamespace" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerUnregisterNamespace
	#define EXT_ParameterServerUnregisterNamespace
	#define GET_ParameterServerUnregisterNamespace(fl)  CAL_CMGETAPI( "ParameterServerUnregisterNamespace" ) 
	#define CAL_ParameterServerUnregisterNamespace  ParameterServerUnregisterNamespace
	#define CHK_ParameterServerUnregisterNamespace  TRUE
	#define EXP_ParameterServerUnregisterNamespace  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerUnregisterNamespace", (RTS_UINTPTR)ParameterServerUnregisterNamespace, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerUnregisterNamespace
	#define EXT_CmpParameterServerParameterServerUnregisterNamespace
	#define GET_CmpParameterServerParameterServerUnregisterNamespace  ERR_OK
	#define CAL_CmpParameterServerParameterServerUnregisterNamespace  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerUnregisterNamespace
	#define CHK_CmpParameterServerParameterServerUnregisterNamespace	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerUnregisterNamespace  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerUnregisterNamespace
	#define EXT_ParameterServerUnregisterNamespace
	#define GET_ParameterServerUnregisterNamespace(fl)  CAL_CMGETAPI( "ParameterServerUnregisterNamespace" ) 
	#define CAL_ParameterServerUnregisterNamespace  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerUnregisterNamespace
	#define CHK_ParameterServerUnregisterNamespace	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerUnregisterNamespace  CAL_CMEXPAPI( "ParameterServerUnregisterNamespace" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerUnregisterNamespace  PFPARAMETERSERVERUNREGISTERNAMESPACE pfParameterServerUnregisterNamespace;
	#define EXT_ParameterServerUnregisterNamespace  extern PFPARAMETERSERVERUNREGISTERNAMESPACE pfParameterServerUnregisterNamespace;
	#define GET_ParameterServerUnregisterNamespace(fl)  s_pfCMGetAPI2( "ParameterServerUnregisterNamespace", (RTS_VOID_FCTPTR *)&pfParameterServerUnregisterNamespace, (fl), 0, 0)
	#define CAL_ParameterServerUnregisterNamespace  pfParameterServerUnregisterNamespace
	#define CHK_ParameterServerUnregisterNamespace  (pfParameterServerUnregisterNamespace != NULL)
	#define EXP_ParameterServerUnregisterNamespace  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerUnregisterNamespace", (RTS_UINTPTR)ParameterServerUnregisterNamespace, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerGet(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* sNamespace, ServiceParameterStruct *pParams, RTS_IEC_DWORD *pNoOfServiceParams);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERGET) (RTS_IEC_STRING* sUserName, RTS_IEC_STRING* sNamespace, ServiceParameterStruct *pParams, RTS_IEC_DWORD *pNoOfServiceParams);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGET_NOTIMPLEMENTED)
	#define USE_ParameterServerGet
	#define EXT_ParameterServerGet
	#define GET_ParameterServerGet(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerGet(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerGet  FALSE
	#define EXP_ParameterServerGet  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerGet
	#define EXT_ParameterServerGet
	#define GET_ParameterServerGet(fl)  CAL_CMGETAPI( "ParameterServerGet" ) 
	#define CAL_ParameterServerGet  ParameterServerGet
	#define CHK_ParameterServerGet  TRUE
	#define EXP_ParameterServerGet  CAL_CMEXPAPI( "ParameterServerGet" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerGet
	#define EXT_ParameterServerGet
	#define GET_ParameterServerGet(fl)  CAL_CMGETAPI( "ParameterServerGet" ) 
	#define CAL_ParameterServerGet  ParameterServerGet
	#define CHK_ParameterServerGet  TRUE
	#define EXP_ParameterServerGet  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGet", (RTS_UINTPTR)ParameterServerGet, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerGet
	#define EXT_CmpParameterServerParameterServerGet
	#define GET_CmpParameterServerParameterServerGet  ERR_OK
	#define CAL_CmpParameterServerParameterServerGet  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGet
	#define CHK_CmpParameterServerParameterServerGet	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerGet  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerGet
	#define EXT_ParameterServerGet
	#define GET_ParameterServerGet(fl)  CAL_CMGETAPI( "ParameterServerGet" ) 
	#define CAL_ParameterServerGet  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGet
	#define CHK_ParameterServerGet	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerGet  CAL_CMEXPAPI( "ParameterServerGet" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerGet  PFPARAMETERSERVERGET pfParameterServerGet;
	#define EXT_ParameterServerGet  extern PFPARAMETERSERVERGET pfParameterServerGet;
	#define GET_ParameterServerGet(fl)  s_pfCMGetAPI2( "ParameterServerGet", (RTS_VOID_FCTPTR *)&pfParameterServerGet, (fl), 0, 0)
	#define CAL_ParameterServerGet  pfParameterServerGet
	#define CHK_ParameterServerGet  (pfParameterServerGet != NULL)
	#define EXP_ParameterServerGet  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGet", (RTS_UINTPTR)ParameterServerGet, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerGetInfo(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szNamespace,	RTS_IEC_STRING* szName, RTS_IEC_INT* pRights, RTS_IEC_INT *pType, RTS_IEC_DWORD *pSize, RTS_IEC_DWORD *pui32Length, RTS_IEC_DWORD *pui32Min, RTS_IEC_DWORD *pui32Max);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERGETINFO) (RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szNamespace,	RTS_IEC_STRING* szName, RTS_IEC_INT* pRights, RTS_IEC_INT *pType, RTS_IEC_DWORD *pSize, RTS_IEC_DWORD *pui32Length, RTS_IEC_DWORD *pui32Min, RTS_IEC_DWORD *pui32Max);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETINFO_NOTIMPLEMENTED)
	#define USE_ParameterServerGetInfo
	#define EXT_ParameterServerGetInfo
	#define GET_ParameterServerGetInfo(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerGetInfo(p0,p1,p2,p3,p4,p5,p6,p7,p8)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerGetInfo  FALSE
	#define EXP_ParameterServerGetInfo  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerGetInfo
	#define EXT_ParameterServerGetInfo
	#define GET_ParameterServerGetInfo(fl)  CAL_CMGETAPI( "ParameterServerGetInfo" ) 
	#define CAL_ParameterServerGetInfo  ParameterServerGetInfo
	#define CHK_ParameterServerGetInfo  TRUE
	#define EXP_ParameterServerGetInfo  CAL_CMEXPAPI( "ParameterServerGetInfo" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerGetInfo
	#define EXT_ParameterServerGetInfo
	#define GET_ParameterServerGetInfo(fl)  CAL_CMGETAPI( "ParameterServerGetInfo" ) 
	#define CAL_ParameterServerGetInfo  ParameterServerGetInfo
	#define CHK_ParameterServerGetInfo  TRUE
	#define EXP_ParameterServerGetInfo  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGetInfo", (RTS_UINTPTR)ParameterServerGetInfo, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerGetInfo
	#define EXT_CmpParameterServerParameterServerGetInfo
	#define GET_CmpParameterServerParameterServerGetInfo  ERR_OK
	#define CAL_CmpParameterServerParameterServerGetInfo  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGetInfo
	#define CHK_CmpParameterServerParameterServerGetInfo	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerGetInfo  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerGetInfo
	#define EXT_ParameterServerGetInfo
	#define GET_ParameterServerGetInfo(fl)  CAL_CMGETAPI( "ParameterServerGetInfo" ) 
	#define CAL_ParameterServerGetInfo  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGetInfo
	#define CHK_ParameterServerGetInfo	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerGetInfo  CAL_CMEXPAPI( "ParameterServerGetInfo" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerGetInfo  PFPARAMETERSERVERGETINFO pfParameterServerGetInfo;
	#define EXT_ParameterServerGetInfo  extern PFPARAMETERSERVERGETINFO pfParameterServerGetInfo;
	#define GET_ParameterServerGetInfo(fl)  s_pfCMGetAPI2( "ParameterServerGetInfo", (RTS_VOID_FCTPTR *)&pfParameterServerGetInfo, (fl), 0, 0)
	#define CAL_ParameterServerGetInfo  pfParameterServerGetInfo
	#define CHK_ParameterServerGetInfo  (pfParameterServerGetInfo != NULL)
	#define EXP_ParameterServerGetInfo  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGetInfo", (RTS_UINTPTR)ParameterServerGetInfo, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerSet(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szNamespace, ServiceParameterStruct *pParams, RTS_IEC_DWORD ui32NoOfServiceParams, RTS_IEC_DWORD *pui32IndexofError);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERSET) (RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szNamespace, ServiceParameterStruct *pParams, RTS_IEC_DWORD ui32NoOfServiceParams, RTS_IEC_DWORD *pui32IndexofError);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERSET_NOTIMPLEMENTED)
	#define USE_ParameterServerSet
	#define EXT_ParameterServerSet
	#define GET_ParameterServerSet(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerSet(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerSet  FALSE
	#define EXP_ParameterServerSet  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerSet
	#define EXT_ParameterServerSet
	#define GET_ParameterServerSet(fl)  CAL_CMGETAPI( "ParameterServerSet" ) 
	#define CAL_ParameterServerSet  ParameterServerSet
	#define CHK_ParameterServerSet  TRUE
	#define EXP_ParameterServerSet  CAL_CMEXPAPI( "ParameterServerSet" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerSet
	#define EXT_ParameterServerSet
	#define GET_ParameterServerSet(fl)  CAL_CMGETAPI( "ParameterServerSet" ) 
	#define CAL_ParameterServerSet  ParameterServerSet
	#define CHK_ParameterServerSet  TRUE
	#define EXP_ParameterServerSet  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerSet", (RTS_UINTPTR)ParameterServerSet, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerSet
	#define EXT_CmpParameterServerParameterServerSet
	#define GET_CmpParameterServerParameterServerSet  ERR_OK
	#define CAL_CmpParameterServerParameterServerSet  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerSet
	#define CHK_CmpParameterServerParameterServerSet	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerSet  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerSet
	#define EXT_ParameterServerSet
	#define GET_ParameterServerSet(fl)  CAL_CMGETAPI( "ParameterServerSet" ) 
	#define CAL_ParameterServerSet  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerSet
	#define CHK_ParameterServerSet	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerSet  CAL_CMEXPAPI( "ParameterServerSet" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerSet  PFPARAMETERSERVERSET pfParameterServerSet;
	#define EXT_ParameterServerSet  extern PFPARAMETERSERVERSET pfParameterServerSet;
	#define GET_ParameterServerSet(fl)  s_pfCMGetAPI2( "ParameterServerSet", (RTS_VOID_FCTPTR *)&pfParameterServerSet, (fl), 0, 0)
	#define CAL_ParameterServerSet  pfParameterServerSet
	#define CHK_ParameterServerSet  (pfParameterServerSet != NULL)
	#define EXP_ParameterServerSet  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerSet", (RTS_UINTPTR)ParameterServerSet, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerRegisterNamespace2(RTS_IEC_STRING* sNamespace, PFPARAMETERGETCALLBACKFUNCTION pfHandlerGet, PFPARAMETERSETCALLBACKFUNCTION pfHandlerSet, PFPARAMETERGETINFOCALLBACKFUNCTION pfHandlerGetInfo, PFPARAMETERCALLCALLBACKFUNCTION pfHandlerCall);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERREGISTERNAMESPACE2) (RTS_IEC_STRING* sNamespace, PFPARAMETERGETCALLBACKFUNCTION pfHandlerGet, PFPARAMETERSETCALLBACKFUNCTION pfHandlerSet, PFPARAMETERGETINFOCALLBACKFUNCTION pfHandlerGetInfo, PFPARAMETERCALLCALLBACKFUNCTION pfHandlerCall);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERREGISTERNAMESPACE2_NOTIMPLEMENTED)
	#define USE_ParameterServerRegisterNamespace2
	#define EXT_ParameterServerRegisterNamespace2
	#define GET_ParameterServerRegisterNamespace2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerRegisterNamespace2(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerRegisterNamespace2  FALSE
	#define EXP_ParameterServerRegisterNamespace2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerRegisterNamespace2
	#define EXT_ParameterServerRegisterNamespace2
	#define GET_ParameterServerRegisterNamespace2(fl)  CAL_CMGETAPI( "ParameterServerRegisterNamespace2" ) 
	#define CAL_ParameterServerRegisterNamespace2  ParameterServerRegisterNamespace2
	#define CHK_ParameterServerRegisterNamespace2  TRUE
	#define EXP_ParameterServerRegisterNamespace2  CAL_CMEXPAPI( "ParameterServerRegisterNamespace2" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerRegisterNamespace2
	#define EXT_ParameterServerRegisterNamespace2
	#define GET_ParameterServerRegisterNamespace2(fl)  CAL_CMGETAPI( "ParameterServerRegisterNamespace2" ) 
	#define CAL_ParameterServerRegisterNamespace2  ParameterServerRegisterNamespace2
	#define CHK_ParameterServerRegisterNamespace2  TRUE
	#define EXP_ParameterServerRegisterNamespace2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerRegisterNamespace2", (RTS_UINTPTR)ParameterServerRegisterNamespace2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerRegisterNamespace2
	#define EXT_CmpParameterServerParameterServerRegisterNamespace2
	#define GET_CmpParameterServerParameterServerRegisterNamespace2  ERR_OK
	#define CAL_CmpParameterServerParameterServerRegisterNamespace2  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerRegisterNamespace2
	#define CHK_CmpParameterServerParameterServerRegisterNamespace2	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerRegisterNamespace2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerRegisterNamespace2
	#define EXT_ParameterServerRegisterNamespace2
	#define GET_ParameterServerRegisterNamespace2(fl)  CAL_CMGETAPI( "ParameterServerRegisterNamespace2" ) 
	#define CAL_ParameterServerRegisterNamespace2  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerRegisterNamespace2
	#define CHK_ParameterServerRegisterNamespace2	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerRegisterNamespace2  CAL_CMEXPAPI( "ParameterServerRegisterNamespace2" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerRegisterNamespace2  PFPARAMETERSERVERREGISTERNAMESPACE2 pfParameterServerRegisterNamespace2;
	#define EXT_ParameterServerRegisterNamespace2  extern PFPARAMETERSERVERREGISTERNAMESPACE2 pfParameterServerRegisterNamespace2;
	#define GET_ParameterServerRegisterNamespace2(fl)  s_pfCMGetAPI2( "ParameterServerRegisterNamespace2", (RTS_VOID_FCTPTR *)&pfParameterServerRegisterNamespace2, (fl), 0, 0)
	#define CAL_ParameterServerRegisterNamespace2  pfParameterServerRegisterNamespace2
	#define CHK_ParameterServerRegisterNamespace2  (pfParameterServerRegisterNamespace2 != NULL)
	#define EXP_ParameterServerRegisterNamespace2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerRegisterNamespace2", (RTS_UINTPTR)ParameterServerRegisterNamespace2, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerCall(RTS_IEC_STRING* sUserName, RTS_IEC_BOOL bLocal, RTS_IEC_STRING* szNamespace, RTS_IEC_STRING* szFuntionName, RTS_IEC_WORD nCountOfInputs, CallParameterStruct* pInputParaList, RTS_IEC_WORD* pCountOfOutputs, CallParameterStruct* pOutputParaList);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERCALL) (RTS_IEC_STRING* sUserName, RTS_IEC_BOOL bLocal, RTS_IEC_STRING* szNamespace, RTS_IEC_STRING* szFuntionName, RTS_IEC_WORD nCountOfInputs, CallParameterStruct* pInputParaList, RTS_IEC_WORD* pCountOfOutputs, CallParameterStruct* pOutputParaList);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERCALL_NOTIMPLEMENTED)
	#define USE_ParameterServerCall
	#define EXT_ParameterServerCall
	#define GET_ParameterServerCall(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerCall(p0,p1,p2,p3,p4,p5,p6,p7)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerCall  FALSE
	#define EXP_ParameterServerCall  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerCall
	#define EXT_ParameterServerCall
	#define GET_ParameterServerCall(fl)  CAL_CMGETAPI( "ParameterServerCall" ) 
	#define CAL_ParameterServerCall  ParameterServerCall
	#define CHK_ParameterServerCall  TRUE
	#define EXP_ParameterServerCall  CAL_CMEXPAPI( "ParameterServerCall" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerCall
	#define EXT_ParameterServerCall
	#define GET_ParameterServerCall(fl)  CAL_CMGETAPI( "ParameterServerCall" ) 
	#define CAL_ParameterServerCall  ParameterServerCall
	#define CHK_ParameterServerCall  TRUE
	#define EXP_ParameterServerCall  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerCall", (RTS_UINTPTR)ParameterServerCall, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerCall
	#define EXT_CmpParameterServerParameterServerCall
	#define GET_CmpParameterServerParameterServerCall  ERR_OK
	#define CAL_CmpParameterServerParameterServerCall  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerCall
	#define CHK_CmpParameterServerParameterServerCall	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerCall  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerCall
	#define EXT_ParameterServerCall
	#define GET_ParameterServerCall(fl)  CAL_CMGETAPI( "ParameterServerCall" ) 
	#define CAL_ParameterServerCall  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerCall
	#define CHK_ParameterServerCall	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerCall  CAL_CMEXPAPI( "ParameterServerCall" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerCall  PFPARAMETERSERVERCALL pfParameterServerCall;
	#define EXT_ParameterServerCall  extern PFPARAMETERSERVERCALL pfParameterServerCall;
	#define GET_ParameterServerCall(fl)  s_pfCMGetAPI2( "ParameterServerCall", (RTS_VOID_FCTPTR *)&pfParameterServerCall, (fl), 0, 0)
	#define CAL_ParameterServerCall  pfParameterServerCall
	#define CHK_ParameterServerCall  (pfParameterServerCall != NULL)
	#define EXP_ParameterServerCall  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerCall", (RTS_UINTPTR)ParameterServerCall, 0, 0) 
#endif



RTS_IEC_WORD   CDECL ParameterServerGetCountOfNamespaces();
typedef RTS_IEC_WORD   (CDECL * PFPARAMETERSERVERGETCOUNTOFNAMESPACES) ();
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETCOUNTOFNAMESPACES_NOTIMPLEMENTED)
	#define USE_ParameterServerGetCountOfNamespaces
	#define EXT_ParameterServerGetCountOfNamespaces
	#define GET_ParameterServerGetCountOfNamespaces(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerGetCountOfNamespaces()  (RTS_IEC_WORD  )ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerGetCountOfNamespaces  FALSE
	#define EXP_ParameterServerGetCountOfNamespaces  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerGetCountOfNamespaces
	#define EXT_ParameterServerGetCountOfNamespaces
	#define GET_ParameterServerGetCountOfNamespaces(fl)  CAL_CMGETAPI( "ParameterServerGetCountOfNamespaces" ) 
	#define CAL_ParameterServerGetCountOfNamespaces  ParameterServerGetCountOfNamespaces
	#define CHK_ParameterServerGetCountOfNamespaces  TRUE
	#define EXP_ParameterServerGetCountOfNamespaces  CAL_CMEXPAPI( "ParameterServerGetCountOfNamespaces" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerGetCountOfNamespaces
	#define EXT_ParameterServerGetCountOfNamespaces
	#define GET_ParameterServerGetCountOfNamespaces(fl)  CAL_CMGETAPI( "ParameterServerGetCountOfNamespaces" ) 
	#define CAL_ParameterServerGetCountOfNamespaces  ParameterServerGetCountOfNamespaces
	#define CHK_ParameterServerGetCountOfNamespaces  TRUE
	#define EXP_ParameterServerGetCountOfNamespaces  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGetCountOfNamespaces", (RTS_UINTPTR)ParameterServerGetCountOfNamespaces, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerGetCountOfNamespaces
	#define EXT_CmpParameterServerParameterServerGetCountOfNamespaces
	#define GET_CmpParameterServerParameterServerGetCountOfNamespaces  ERR_OK
	#define CAL_CmpParameterServerParameterServerGetCountOfNamespaces  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGetCountOfNamespaces
	#define CHK_CmpParameterServerParameterServerGetCountOfNamespaces	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerGetCountOfNamespaces  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerGetCountOfNamespaces
	#define EXT_ParameterServerGetCountOfNamespaces
	#define GET_ParameterServerGetCountOfNamespaces(fl)  CAL_CMGETAPI( "ParameterServerGetCountOfNamespaces" ) 
	#define CAL_ParameterServerGetCountOfNamespaces  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGetCountOfNamespaces
	#define CHK_ParameterServerGetCountOfNamespaces	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerGetCountOfNamespaces  CAL_CMEXPAPI( "ParameterServerGetCountOfNamespaces" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerGetCountOfNamespaces  PFPARAMETERSERVERGETCOUNTOFNAMESPACES pfParameterServerGetCountOfNamespaces;
	#define EXT_ParameterServerGetCountOfNamespaces  extern PFPARAMETERSERVERGETCOUNTOFNAMESPACES pfParameterServerGetCountOfNamespaces;
	#define GET_ParameterServerGetCountOfNamespaces(fl)  s_pfCMGetAPI2( "ParameterServerGetCountOfNamespaces", (RTS_VOID_FCTPTR *)&pfParameterServerGetCountOfNamespaces, (fl), 0, 0)
	#define CAL_ParameterServerGetCountOfNamespaces  pfParameterServerGetCountOfNamespaces
	#define CHK_ParameterServerGetCountOfNamespaces  (pfParameterServerGetCountOfNamespaces != NULL)
	#define EXP_ParameterServerGetCountOfNamespaces  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGetCountOfNamespaces", (RTS_UINTPTR)ParameterServerGetCountOfNamespaces, 0, 0) 
#endif



RTS_IEC_RESULT CDECL ParameterServerGetNamespace(RTS_IEC_WORD nIndex/*in*/, char* pNamespace/*out*/, RTS_IEC_WORD* pMaxLength);
typedef RTS_IEC_RESULT (CDECL * PFPARAMETERSERVERGETNAMESPACE) (RTS_IEC_WORD nIndex/*in*/, char* pNamespace/*out*/, RTS_IEC_WORD* pMaxLength);
#if defined(CMPPARAMETERSERVER_NOTIMPLEMENTED) || defined(PARAMETERSERVERGETNAMESPACE_NOTIMPLEMENTED)
	#define USE_ParameterServerGetNamespace
	#define EXT_ParameterServerGetNamespace
	#define GET_ParameterServerGetNamespace(fl)  ERR_NOTIMPLEMENTED
	#define CAL_ParameterServerGetNamespace(p0,p1,p2)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_ParameterServerGetNamespace  FALSE
	#define EXP_ParameterServerGetNamespace  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_ParameterServerGetNamespace
	#define EXT_ParameterServerGetNamespace
	#define GET_ParameterServerGetNamespace(fl)  CAL_CMGETAPI( "ParameterServerGetNamespace" ) 
	#define CAL_ParameterServerGetNamespace  ParameterServerGetNamespace
	#define CHK_ParameterServerGetNamespace  TRUE
	#define EXP_ParameterServerGetNamespace  CAL_CMEXPAPI( "ParameterServerGetNamespace" ) 
#elif defined(MIXED_LINK) && !defined(CMPPARAMETERSERVER_EXTERNAL)
	#define USE_ParameterServerGetNamespace
	#define EXT_ParameterServerGetNamespace
	#define GET_ParameterServerGetNamespace(fl)  CAL_CMGETAPI( "ParameterServerGetNamespace" ) 
	#define CAL_ParameterServerGetNamespace  ParameterServerGetNamespace
	#define CHK_ParameterServerGetNamespace  TRUE
	#define EXP_ParameterServerGetNamespace  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGetNamespace", (RTS_UINTPTR)ParameterServerGetNamespace, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpParameterServerParameterServerGetNamespace
	#define EXT_CmpParameterServerParameterServerGetNamespace
	#define GET_CmpParameterServerParameterServerGetNamespace  ERR_OK
	#define CAL_CmpParameterServerParameterServerGetNamespace  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGetNamespace
	#define CHK_CmpParameterServerParameterServerGetNamespace	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_CmpParameterServerParameterServerGetNamespace  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_ParameterServerGetNamespace
	#define EXT_ParameterServerGetNamespace
	#define GET_ParameterServerGetNamespace(fl)  CAL_CMGETAPI( "ParameterServerGetNamespace" ) 
	#define CAL_ParameterServerGetNamespace  ((ICmpParameterServer*)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, NULL))->IParameterServerGetNamespace
	#define CHK_ParameterServerGetNamespace	(s_pfCMCreateInstance != NULL && pICmpParameterServer != NULL)
	#define EXP_ParameterServerGetNamespace  CAL_CMEXPAPI( "ParameterServerGetNamespace" ) 
#else /* DYNAMIC_LINK */
	#define USE_ParameterServerGetNamespace  PFPARAMETERSERVERGETNAMESPACE pfParameterServerGetNamespace;
	#define EXT_ParameterServerGetNamespace  extern PFPARAMETERSERVERGETNAMESPACE pfParameterServerGetNamespace;
	#define GET_ParameterServerGetNamespace(fl)  s_pfCMGetAPI2( "ParameterServerGetNamespace", (RTS_VOID_FCTPTR *)&pfParameterServerGetNamespace, (fl), 0, 0)
	#define CAL_ParameterServerGetNamespace  pfParameterServerGetNamespace
	#define CHK_ParameterServerGetNamespace  (pfParameterServerGetNamespace != NULL)
	#define EXP_ParameterServerGetNamespace  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"ParameterServerGetNamespace", (RTS_UINTPTR)ParameterServerGetNamespace, 0, 0) 
#endif




#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFPARAMETERSERVERREGISTERNAMESPACE IParameterServerRegisterNamespace;
 	PFPARAMETERSERVERUNREGISTERNAMESPACE IParameterServerUnregisterNamespace;
 	PFPARAMETERSERVERGET IParameterServerGet;
 	PFPARAMETERSERVERGETINFO IParameterServerGetInfo;
 	PFPARAMETERSERVERSET IParameterServerSet;
 	PFPARAMETERSERVERREGISTERNAMESPACE2 IParameterServerRegisterNamespace2;
 	PFPARAMETERSERVERCALL IParameterServerCall;
 	PFPARAMETERSERVERGETCOUNTOFNAMESPACES IParameterServerGetCountOfNamespaces;
 	PFPARAMETERSERVERGETNAMESPACE IParameterServerGetNamespace;
 } ICmpParameterServer_C;

#ifdef CPLUSPLUS
class ICmpParameterServer : public IBase
{
	public:
		virtual RTS_IEC_RESULT CDECL IParameterServerRegisterNamespace(RTS_IEC_STRING* sNamespace, PFPARAMETERGETCALLBACKFUNCTION pfHandlerGet, PFPARAMETERSETCALLBACKFUNCTION pfHandlerSet, PFPARAMETERGETINFOCALLBACKFUNCTION pfHandlerGetInfo) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerUnregisterNamespace(RTS_IEC_STRING* sNamespace) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerGet(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* sNamespace, ServiceParameterStruct *pParams, RTS_IEC_DWORD *pNoOfServiceParams) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerGetInfo(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szNamespace, RTS_IEC_STRING* szName, RTS_IEC_INT* pRights, RTS_IEC_INT *pType, RTS_IEC_DWORD *pSize, RTS_IEC_DWORD *pui32Length, RTS_IEC_DWORD *pui32Min, RTS_IEC_DWORD *pui32Max) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerSet(RTS_IEC_STRING* sUserName, RTS_IEC_STRING* szNamespace, ServiceParameterStruct *pParams, RTS_IEC_DWORD ui32NoOfServiceParams, RTS_IEC_DWORD *pui32IndexofError) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerRegisterNamespace2(RTS_IEC_STRING* sNamespace, PFPARAMETERGETCALLBACKFUNCTION pfHandlerGet, PFPARAMETERSETCALLBACKFUNCTION pfHandlerSet, PFPARAMETERGETINFOCALLBACKFUNCTION pfHandlerGetInfo, PFPARAMETERCALLCALLBACKFUNCTION pfHandlerCall) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerCall(RTS_IEC_STRING* sUserName, RTS_IEC_BOOL bLocal, RTS_IEC_STRING* szNamespace, RTS_IEC_STRING* szFuntionName, RTS_IEC_WORD nCountOfInputs, CallParameterStruct* pInputParaList, RTS_IEC_WORD* pCountOfOutputs, CallParameterStruct* pOutputParaList) =0;
		virtual RTS_IEC_WORD   CDECL IParameterServerGetCountOfNamespaces(void) =0;
		virtual RTS_IEC_RESULT CDECL IParameterServerGetNamespace(RTS_IEC_WORD nIndex/*in*/, char* pNamespace/*out*/, RTS_IEC_WORD* pMaxLength) =0;
};
	#ifndef ITF_CmpParameterServer
		#define ITF_CmpParameterServer static ICmpParameterServer *pICmpParameterServer = NULL;
	#endif
	#define EXTITF_CmpParameterServer
#else	/*CPLUSPLUS*/
	typedef ICmpParameterServer_C		ICmpParameterServer;
	#ifndef ITF_CmpParameterServer
		#define ITF_CmpParameterServer
	#endif
	#define EXTITF_CmpParameterServer
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_CMPPARAMETERSERVERITF_H_*/
