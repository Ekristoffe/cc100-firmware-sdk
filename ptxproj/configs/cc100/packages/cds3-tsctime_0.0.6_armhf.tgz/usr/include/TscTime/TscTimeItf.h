 /**
 * <interfacename>TscTime</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCTIMEITF_H_
#define _TSCTIMEITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>
 * 
 * 
 * The members of the tm structure are:
 * 
 * tm_sec
 * The number of seconds after the minute, normally in the range 0 to 59, but
 * can be up to 60 to allow for leap seconds.
 * 
 * tm_min
 * The number of minutes after the hour, in the range 0 to 59.
 * 
 * tm_hour
 * The number of hours past midnight, in the range 0 to 23.
 * 
 * tm_mday
 * The day of the month, in the range 1 to 31.
 * 
 * tm_mon
 * The number of months since January, in the range 0 to 11.
 * 
 * tm_year
 * The number of years since 1900.
 * 
 * tm_wday
 * The number of days since Sunday, in the range 0 to 6.
 * 
 * tm_yday
 * The number of days since January 1, in the range 0 to 365.
 * 
 * tm_isdst
 * A flag that indicates whether daylight saving time is in effect at the
 * time described. The value is positive if daylight saving time is in effect,
 * zero if it is not, and negative if the information is not available.
 * </description>
 * <element name="tm_sec" type=INOUT>seconds</element>
 * <element name="tm_min" type=INOUT>minutes</element>
 * <element name="tm_hour" type=INOUT>hours</element>
 * <element name="tm_mday" type=INOUT>day OF the month</element>
 * <element name="tm_mon" type=INOUT>month</element>
 * <element name="tm_year" type=INOUT>year</element>
 * <element name="tm_wday" type=INOUT>day OF the week</element>
 * <element name="tm_yday" type=INOUT>day in the year</element>
 * <element name="tm_isdst" type=INOUT>daylight saving TIME</element>
*/
typedef struct tag_typTM
{
	RTS_IEC_INT tm_sec;
	RTS_IEC_INT tm_min;
	RTS_IEC_INT tm_hour;
	RTS_IEC_INT tm_mday;
	RTS_IEC_INT tm_mon;
	RTS_IEC_INT tm_year;
	RTS_IEC_INT tm_wday;
	RTS_IEC_INT tm_yday;
	RTS_IEC_INT tm_isdst;
} _typTM;

/**
 * <description>
 * returns the time zone description which is approriate for a given point in time,
 * 
 * Attn: does not fill the output structure properly.
 * Use _wrapped_WagoTimeGetZoneInfo() instead.
 * 
 * </description>
 * <element name="udiPosixTime" type=IN>seconds from EPOCH</element>
 * <element name="stTimeZoneDescription" type=OUT></element>
*/
typedef struct tagwagotimegetzoneinfo_struct
{
	RTS_IEC_UDINT udiPosixTime;
	typTimeZoneDescription stTimeZoneDescription;
} wagotimegetzoneinfo_struct;

void CDECL CDECL_EXT wagotimegetzoneinfo(wagotimegetzoneinfo_struct *p);
typedef void (CDECL CDECL_EXT* PFWAGOTIMEGETZONEINFO_IEC) (wagotimegetzoneinfo_struct *p);
#if defined(TSCTIME_NOTIMPLEMENTED) || defined(WAGOTIMEGETZONEINFO_NOTIMPLEMENTED)
	#define USE_wagotimegetzoneinfo
	#define EXT_wagotimegetzoneinfo
	#define GET_wagotimegetzoneinfo(fl)  ERR_NOTIMPLEMENTED
	#define CAL_wagotimegetzoneinfo(p0) 
	#define CHK_wagotimegetzoneinfo  FALSE
	#define EXP_wagotimegetzoneinfo  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_wagotimegetzoneinfo
	#define EXT_wagotimegetzoneinfo
	#define GET_wagotimegetzoneinfo(fl)  CAL_CMGETAPI( "wagotimegetzoneinfo" ) 
	#define CAL_wagotimegetzoneinfo  wagotimegetzoneinfo
	#define CHK_wagotimegetzoneinfo  TRUE
	#define EXP_wagotimegetzoneinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimegetzoneinfo", (RTS_UINTPTR)wagotimegetzoneinfo, 1, 0xF30A3DDA, 0x01010005) 
	#define EXTREF_ITF_wagotimegetzoneinfo {(RTS_VOID_FCTPTR)wagotimegetzoneinfo, "wagotimegetzoneinfo", 0xF30A3DDA, 0x01010005}
#elif defined(MIXED_LINK) && !defined(TSCTIME_EXTERNAL)
	#define USE_wagotimegetzoneinfo
	#define EXT_wagotimegetzoneinfo
	#define GET_wagotimegetzoneinfo(fl)  CAL_CMGETAPI( "wagotimegetzoneinfo" ) 
	#define CAL_wagotimegetzoneinfo  wagotimegetzoneinfo
	#define CHK_wagotimegetzoneinfo  TRUE
	#define EXP_wagotimegetzoneinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimegetzoneinfo", (RTS_UINTPTR)wagotimegetzoneinfo, 1, 0xF30A3DDA, 0x01010005) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscTimewagotimegetzoneinfo
	#define EXT_TscTimewagotimegetzoneinfo
	#define GET_TscTimewagotimegetzoneinfo  ERR_OK
	#define CAL_TscTimewagotimegetzoneinfo  wagotimegetzoneinfo
	#define CHK_TscTimewagotimegetzoneinfo  TRUE
	#define EXP_TscTimewagotimegetzoneinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimegetzoneinfo", (RTS_UINTPTR)wagotimegetzoneinfo, 1, 0xF30A3DDA, 0x01010005) 
#elif defined(CPLUSPLUS)
	#define USE_wagotimegetzoneinfo
	#define EXT_wagotimegetzoneinfo
	#define GET_wagotimegetzoneinfo(fl)  CAL_CMGETAPI( "wagotimegetzoneinfo" ) 
	#define CAL_wagotimegetzoneinfo  wagotimegetzoneinfo
	#define CHK_wagotimegetzoneinfo  TRUE
	#define EXP_wagotimegetzoneinfo  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimegetzoneinfo", (RTS_UINTPTR)wagotimegetzoneinfo, 1, 0xF30A3DDA, 0x01010005) 
#else /* DYNAMIC_LINK */
	#define USE_wagotimegetzoneinfo  PFWAGOTIMEGETZONEINFO_IEC pfwagotimegetzoneinfo;
	#define EXT_wagotimegetzoneinfo  extern PFWAGOTIMEGETZONEINFO_IEC pfwagotimegetzoneinfo;
	#define GET_wagotimegetzoneinfo(fl)  s_pfCMGetAPI2( "wagotimegetzoneinfo", (RTS_VOID_FCTPTR *)&pfwagotimegetzoneinfo, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xF30A3DDA, 0x01010005)
	#define CAL_wagotimegetzoneinfo  pfwagotimegetzoneinfo
	#define CHK_wagotimegetzoneinfo  (pfwagotimegetzoneinfo != NULL)
	#define EXP_wagotimegetzoneinfo   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimegetzoneinfo", (RTS_UINTPTR)wagotimegetzoneinfo, 1, 0xF30A3DDA, 0x01010005) 
#endif


/**
 * <description>
 * wraps the POSIX function 'localtime()' yet.
 * </description>
 * <element name="udiPosixTime" type=IN>seconds from EPOCH</element>
 * <element name="buffer" type=INOUT></element>
*/
typedef struct tagwagotimelocaltime_struct
{
	RTS_IEC_UDINT udiPosixTime;
	_typTM *buffer;
} wagotimelocaltime_struct;

void CDECL CDECL_EXT wagotimelocaltime(wagotimelocaltime_struct *p);
typedef void (CDECL CDECL_EXT* PFWAGOTIMELOCALTIME_IEC) (wagotimelocaltime_struct *p);
#if defined(TSCTIME_NOTIMPLEMENTED) || defined(WAGOTIMELOCALTIME_NOTIMPLEMENTED)
	#define USE_wagotimelocaltime
	#define EXT_wagotimelocaltime
	#define GET_wagotimelocaltime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_wagotimelocaltime(p0) 
	#define CHK_wagotimelocaltime  FALSE
	#define EXP_wagotimelocaltime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_wagotimelocaltime
	#define EXT_wagotimelocaltime
	#define GET_wagotimelocaltime(fl)  CAL_CMGETAPI( "wagotimelocaltime" ) 
	#define CAL_wagotimelocaltime  wagotimelocaltime
	#define CHK_wagotimelocaltime  TRUE
	#define EXP_wagotimelocaltime  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimelocaltime", (RTS_UINTPTR)wagotimelocaltime, 1, 0xA06E43A1, 0x01010005) 
	#define EXTREF_ITF_wagotimelocaltime {(RTS_VOID_FCTPTR)wagotimelocaltime, "wagotimelocaltime", 0xA06E43A1, 0x01010005}
#elif defined(MIXED_LINK) && !defined(TSCTIME_EXTERNAL)
	#define USE_wagotimelocaltime
	#define EXT_wagotimelocaltime
	#define GET_wagotimelocaltime(fl)  CAL_CMGETAPI( "wagotimelocaltime" ) 
	#define CAL_wagotimelocaltime  wagotimelocaltime
	#define CHK_wagotimelocaltime  TRUE
	#define EXP_wagotimelocaltime  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimelocaltime", (RTS_UINTPTR)wagotimelocaltime, 1, 0xA06E43A1, 0x01010005) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscTimewagotimelocaltime
	#define EXT_TscTimewagotimelocaltime
	#define GET_TscTimewagotimelocaltime  ERR_OK
	#define CAL_TscTimewagotimelocaltime  wagotimelocaltime
	#define CHK_TscTimewagotimelocaltime  TRUE
	#define EXP_TscTimewagotimelocaltime  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimelocaltime", (RTS_UINTPTR)wagotimelocaltime, 1, 0xA06E43A1, 0x01010005) 
#elif defined(CPLUSPLUS)
	#define USE_wagotimelocaltime
	#define EXT_wagotimelocaltime
	#define GET_wagotimelocaltime(fl)  CAL_CMGETAPI( "wagotimelocaltime" ) 
	#define CAL_wagotimelocaltime  wagotimelocaltime
	#define CHK_wagotimelocaltime  TRUE
	#define EXP_wagotimelocaltime  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimelocaltime", (RTS_UINTPTR)wagotimelocaltime, 1, 0xA06E43A1, 0x01010005) 
#else /* DYNAMIC_LINK */
	#define USE_wagotimelocaltime  PFWAGOTIMELOCALTIME_IEC pfwagotimelocaltime;
	#define EXT_wagotimelocaltime  extern PFWAGOTIMELOCALTIME_IEC pfwagotimelocaltime;
	#define GET_wagotimelocaltime(fl)  s_pfCMGetAPI2( "wagotimelocaltime", (RTS_VOID_FCTPTR *)&pfwagotimelocaltime, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA06E43A1, 0x01010005)
	#define CAL_wagotimelocaltime  pfwagotimelocaltime
	#define CHK_wagotimelocaltime  (pfwagotimelocaltime != NULL)
	#define EXP_wagotimelocaltime   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimelocaltime", (RTS_UINTPTR)wagotimelocaltime, 1, 0xA06E43A1, 0x01010005) 
#endif


/**
 * <description>
 * changes the actual timezone
 * 
 * Some special Keywords are accepted such as 'Berlin' and 'London', and others.
 * It sets some internal fake variables in order to retrieve timezone information at other places.
 * 
 * 
 * This function returns one of the following result codes:
 * 
 * =============  ======================================================================================
 * **result codes**
 * -----------------------------------------------------------------------------------------------------
 * 0              success
 * ENOENT         The database key is unknown to the system
 * ENOSYS         function not implemented
 * =============  ======================================================================================
 * 
 * </description>
 * <element name="WagoTimeSetZone" type=OUT></element>
 * <element name="sDataBaseKey" type=IN>The applied data base key, e.g. 'New Zealand'</element>
*/
typedef struct tagwagotimesetzone_struct
{
	RTS_IEC_STRING sDataBaseKey[81];
	RTS_IEC_WORD WagoTimeSetZone;
} wagotimesetzone_struct;

void CDECL CDECL_EXT wagotimesetzone(wagotimesetzone_struct *p);
typedef void (CDECL CDECL_EXT* PFWAGOTIMESETZONE_IEC) (wagotimesetzone_struct *p);
#if defined(TSCTIME_NOTIMPLEMENTED) || defined(WAGOTIMESETZONE_NOTIMPLEMENTED)
	#define USE_wagotimesetzone
	#define EXT_wagotimesetzone
	#define GET_wagotimesetzone(fl)  ERR_NOTIMPLEMENTED
	#define CAL_wagotimesetzone(p0) 
	#define CHK_wagotimesetzone  FALSE
	#define EXP_wagotimesetzone  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_wagotimesetzone
	#define EXT_wagotimesetzone
	#define GET_wagotimesetzone(fl)  CAL_CMGETAPI( "wagotimesetzone" ) 
	#define CAL_wagotimesetzone  wagotimesetzone
	#define CHK_wagotimesetzone  TRUE
	#define EXP_wagotimesetzone  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzone", (RTS_UINTPTR)wagotimesetzone, 1, 0x09ADAB51, 0x01010005) 
	#define EXTREF_ITF_wagotimesetzone {(RTS_VOID_FCTPTR)wagotimesetzone, "wagotimesetzone", 0x09ADAB51, 0x01010005}
#elif defined(MIXED_LINK) && !defined(TSCTIME_EXTERNAL)
	#define USE_wagotimesetzone
	#define EXT_wagotimesetzone
	#define GET_wagotimesetzone(fl)  CAL_CMGETAPI( "wagotimesetzone" ) 
	#define CAL_wagotimesetzone  wagotimesetzone
	#define CHK_wagotimesetzone  TRUE
	#define EXP_wagotimesetzone  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzone", (RTS_UINTPTR)wagotimesetzone, 1, 0x09ADAB51, 0x01010005) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscTimewagotimesetzone
	#define EXT_TscTimewagotimesetzone
	#define GET_TscTimewagotimesetzone  ERR_OK
	#define CAL_TscTimewagotimesetzone  wagotimesetzone
	#define CHK_TscTimewagotimesetzone  TRUE
	#define EXP_TscTimewagotimesetzone  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzone", (RTS_UINTPTR)wagotimesetzone, 1, 0x09ADAB51, 0x01010005) 
#elif defined(CPLUSPLUS)
	#define USE_wagotimesetzone
	#define EXT_wagotimesetzone
	#define GET_wagotimesetzone(fl)  CAL_CMGETAPI( "wagotimesetzone" ) 
	#define CAL_wagotimesetzone  wagotimesetzone
	#define CHK_wagotimesetzone  TRUE
	#define EXP_wagotimesetzone  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzone", (RTS_UINTPTR)wagotimesetzone, 1, 0x09ADAB51, 0x01010005) 
#else /* DYNAMIC_LINK */
	#define USE_wagotimesetzone  PFWAGOTIMESETZONE_IEC pfwagotimesetzone;
	#define EXT_wagotimesetzone  extern PFWAGOTIMESETZONE_IEC pfwagotimesetzone;
	#define GET_wagotimesetzone(fl)  s_pfCMGetAPI2( "wagotimesetzone", (RTS_VOID_FCTPTR *)&pfwagotimesetzone, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x09ADAB51, 0x01010005)
	#define CAL_wagotimesetzone  pfwagotimesetzone
	#define CHK_wagotimesetzone  (pfwagotimesetzone != NULL)
	#define EXP_wagotimesetzone   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzone", (RTS_UINTPTR)wagotimesetzone, 1, 0x09ADAB51, 0x01010005) 
#endif


/**
 * <description>wagotimesetzoneasync__main</description>
 */
typedef struct tagwagotimesetzoneasync_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of WagoTimesetZoneAsync */

	RTS_IEC_BOOL bEN;					/* VAR_INPUT */	
	RTS_IEC_STRING sDataBaseKey[81];	/* VAR_INPUT */	
	RTS_IEC_BOOL bDone;					/* VAR_OUTPUT */	
	RTS_IEC_BOOL bBusy;					/* VAR_OUTPUT */	
	RTS_IEC_WORD eResult;				/* VAR_OUTPUT, Enum: ERESULTCODE */
	RTS_IEC_BOOL oldEnable;				/* Local variable */	
	RTS_IEC_HANDLE asyncHandle;			/* Local variable */	
	RTS_IEC_BYTE *data;					/* Local variable */	
} wagotimesetzoneasync_struct;

/**
 * <description>wagotimesetzoneasync_main</description>
 */
typedef struct tagwagotimesetzoneasync_main_struct
{
	wagotimesetzoneasync_struct *pInstance;	/* VAR_INPUT */	
} wagotimesetzoneasync_main_struct;

void CDECL CDECL_EXT wagotimesetzoneasync__main(wagotimesetzoneasync_main_struct *p);
typedef void (CDECL CDECL_EXT* PFWAGOTIMESETZONEASYNC__MAIN_IEC) (wagotimesetzoneasync_main_struct *p);
#if defined(TSCTIME_NOTIMPLEMENTED) || defined(WAGOTIMESETZONEASYNC__MAIN_NOTIMPLEMENTED)
	#define USE_wagotimesetzoneasync__main
	#define EXT_wagotimesetzoneasync__main
	#define GET_wagotimesetzoneasync__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_wagotimesetzoneasync__main(p0) 
	#define CHK_wagotimesetzoneasync__main  FALSE
	#define EXP_wagotimesetzoneasync__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_wagotimesetzoneasync__main
	#define EXT_wagotimesetzoneasync__main
	#define GET_wagotimesetzoneasync__main(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__main" ) 
	#define CAL_wagotimesetzoneasync__main  wagotimesetzoneasync__main
	#define CHK_wagotimesetzoneasync__main  TRUE
	#define EXP_wagotimesetzoneasync__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__main", (RTS_UINTPTR)wagotimesetzoneasync__main, 1, 0xA14EDD4A, 0x01010005) 
	#define EXTREF_ITF_wagotimesetzoneasync__main {(RTS_VOID_FCTPTR)wagotimesetzoneasync__main, "wagotimesetzoneasync__main", 0xA14EDD4A, 0x01010005}
#elif defined(MIXED_LINK) && !defined(TSCTIME_EXTERNAL)
	#define USE_wagotimesetzoneasync__main
	#define EXT_wagotimesetzoneasync__main
	#define GET_wagotimesetzoneasync__main(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__main" ) 
	#define CAL_wagotimesetzoneasync__main  wagotimesetzoneasync__main
	#define CHK_wagotimesetzoneasync__main  TRUE
	#define EXP_wagotimesetzoneasync__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__main", (RTS_UINTPTR)wagotimesetzoneasync__main, 1, 0xA14EDD4A, 0x01010005) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscTimewagotimesetzoneasync__main
	#define EXT_TscTimewagotimesetzoneasync__main
	#define GET_TscTimewagotimesetzoneasync__main  ERR_OK
	#define CAL_TscTimewagotimesetzoneasync__main  wagotimesetzoneasync__main
	#define CHK_TscTimewagotimesetzoneasync__main  TRUE
	#define EXP_TscTimewagotimesetzoneasync__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__main", (RTS_UINTPTR)wagotimesetzoneasync__main, 1, 0xA14EDD4A, 0x01010005) 
#elif defined(CPLUSPLUS)
	#define USE_wagotimesetzoneasync__main
	#define EXT_wagotimesetzoneasync__main
	#define GET_wagotimesetzoneasync__main(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__main" ) 
	#define CAL_wagotimesetzoneasync__main  wagotimesetzoneasync__main
	#define CHK_wagotimesetzoneasync__main  TRUE
	#define EXP_wagotimesetzoneasync__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__main", (RTS_UINTPTR)wagotimesetzoneasync__main, 1, 0xA14EDD4A, 0x01010005) 
#else /* DYNAMIC_LINK */
	#define USE_wagotimesetzoneasync__main  PFWAGOTIMESETZONEASYNC__MAIN_IEC pfwagotimesetzoneasync__main;
	#define EXT_wagotimesetzoneasync__main  extern PFWAGOTIMESETZONEASYNC__MAIN_IEC pfwagotimesetzoneasync__main;
	#define GET_wagotimesetzoneasync__main(fl)  s_pfCMGetAPI2( "wagotimesetzoneasync__main", (RTS_VOID_FCTPTR *)&pfwagotimesetzoneasync__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA14EDD4A, 0x01010005)
	#define CAL_wagotimesetzoneasync__main  pfwagotimesetzoneasync__main
	#define CHK_wagotimesetzoneasync__main  (pfwagotimesetzoneasync__main != NULL)
	#define EXP_wagotimesetzoneasync__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__main", (RTS_UINTPTR)wagotimesetzoneasync__main, 1, 0xA14EDD4A, 0x01010005) 
#endif


/**
 * <description>wagotimesetzoneasync_fb_init</description>
 */
typedef struct tagwagotimesetzoneasync_fb_init_struct
{
	wagotimesetzoneasync_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	/* bei TRUE werden die Retain-Variablen initialisiert (Warmstart / Kaltstart) */
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* bei TRUE wird die Instanz anschließend in den Copy-Code kopiert (Online Change) */
	RTS_IEC_BOOL fb_init;				/* VAR_OUTPUT */	
} wagotimesetzoneasync_fb_init_struct;

void CDECL CDECL_EXT wagotimesetzoneasync__fb_init(wagotimesetzoneasync_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFWAGOTIMESETZONEASYNC__FB_INIT_IEC) (wagotimesetzoneasync_fb_init_struct *p);
#if defined(TSCTIME_NOTIMPLEMENTED) || defined(WAGOTIMESETZONEASYNC__FB_INIT_NOTIMPLEMENTED)
	#define USE_wagotimesetzoneasync__fb_init
	#define EXT_wagotimesetzoneasync__fb_init
	#define GET_wagotimesetzoneasync__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_wagotimesetzoneasync__fb_init(p0) 
	#define CHK_wagotimesetzoneasync__fb_init  FALSE
	#define EXP_wagotimesetzoneasync__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_wagotimesetzoneasync__fb_init
	#define EXT_wagotimesetzoneasync__fb_init
	#define GET_wagotimesetzoneasync__fb_init(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__fb_init" ) 
	#define CAL_wagotimesetzoneasync__fb_init  wagotimesetzoneasync__fb_init
	#define CHK_wagotimesetzoneasync__fb_init  TRUE
	#define EXP_wagotimesetzoneasync__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_init", (RTS_UINTPTR)wagotimesetzoneasync__fb_init, 1, 0x8CCEDE30, 0x01010005) 
	#define EXTREF_ITF_wagotimesetzoneasync__fb_init {(RTS_VOID_FCTPTR)wagotimesetzoneasync__fb_init, "wagotimesetzoneasync__fb_init", 0x8CCEDE30, 0x01010005}
#elif defined(MIXED_LINK) && !defined(TSCTIME_EXTERNAL)
	#define USE_wagotimesetzoneasync__fb_init
	#define EXT_wagotimesetzoneasync__fb_init
	#define GET_wagotimesetzoneasync__fb_init(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__fb_init" ) 
	#define CAL_wagotimesetzoneasync__fb_init  wagotimesetzoneasync__fb_init
	#define CHK_wagotimesetzoneasync__fb_init  TRUE
	#define EXP_wagotimesetzoneasync__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_init", (RTS_UINTPTR)wagotimesetzoneasync__fb_init, 1, 0x8CCEDE30, 0x01010005) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscTimewagotimesetzoneasync__fb_init
	#define EXT_TscTimewagotimesetzoneasync__fb_init
	#define GET_TscTimewagotimesetzoneasync__fb_init  ERR_OK
	#define CAL_TscTimewagotimesetzoneasync__fb_init  wagotimesetzoneasync__fb_init
	#define CHK_TscTimewagotimesetzoneasync__fb_init  TRUE
	#define EXP_TscTimewagotimesetzoneasync__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_init", (RTS_UINTPTR)wagotimesetzoneasync__fb_init, 1, 0x8CCEDE30, 0x01010005) 
#elif defined(CPLUSPLUS)
	#define USE_wagotimesetzoneasync__fb_init
	#define EXT_wagotimesetzoneasync__fb_init
	#define GET_wagotimesetzoneasync__fb_init(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__fb_init" ) 
	#define CAL_wagotimesetzoneasync__fb_init  wagotimesetzoneasync__fb_init
	#define CHK_wagotimesetzoneasync__fb_init  TRUE
	#define EXP_wagotimesetzoneasync__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_init", (RTS_UINTPTR)wagotimesetzoneasync__fb_init, 1, 0x8CCEDE30, 0x01010005) 
#else /* DYNAMIC_LINK */
	#define USE_wagotimesetzoneasync__fb_init  PFWAGOTIMESETZONEASYNC__FB_INIT_IEC pfwagotimesetzoneasync__fb_init;
	#define EXT_wagotimesetzoneasync__fb_init  extern PFWAGOTIMESETZONEASYNC__FB_INIT_IEC pfwagotimesetzoneasync__fb_init;
	#define GET_wagotimesetzoneasync__fb_init(fl)  s_pfCMGetAPI2( "wagotimesetzoneasync__fb_init", (RTS_VOID_FCTPTR *)&pfwagotimesetzoneasync__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8CCEDE30, 0x01010005)
	#define CAL_wagotimesetzoneasync__fb_init  pfwagotimesetzoneasync__fb_init
	#define CHK_wagotimesetzoneasync__fb_init  (pfwagotimesetzoneasync__fb_init != NULL)
	#define EXP_wagotimesetzoneasync__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_init", (RTS_UINTPTR)wagotimesetzoneasync__fb_init, 1, 0x8CCEDE30, 0x01010005) 
#endif


/**
 * <description>wagotimesetzoneasync_fb_exit</description>
 */
typedef struct tagwagotimesetzoneasync_fb_exit_struct
{
	wagotimesetzoneasync_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL fb_exit;				/* VAR_OUTPUT */	
} wagotimesetzoneasync_fb_exit_struct;

void CDECL CDECL_EXT wagotimesetzoneasync__fb_exit(wagotimesetzoneasync_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFWAGOTIMESETZONEASYNC__FB_EXIT_IEC) (wagotimesetzoneasync_fb_exit_struct *p);
#if defined(TSCTIME_NOTIMPLEMENTED) || defined(WAGOTIMESETZONEASYNC__FB_EXIT_NOTIMPLEMENTED)
	#define USE_wagotimesetzoneasync__fb_exit
	#define EXT_wagotimesetzoneasync__fb_exit
	#define GET_wagotimesetzoneasync__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_wagotimesetzoneasync__fb_exit(p0) 
	#define CHK_wagotimesetzoneasync__fb_exit  FALSE
	#define EXP_wagotimesetzoneasync__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_wagotimesetzoneasync__fb_exit
	#define EXT_wagotimesetzoneasync__fb_exit
	#define GET_wagotimesetzoneasync__fb_exit(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__fb_exit" ) 
	#define CAL_wagotimesetzoneasync__fb_exit  wagotimesetzoneasync__fb_exit
	#define CHK_wagotimesetzoneasync__fb_exit  TRUE
	#define EXP_wagotimesetzoneasync__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_exit", (RTS_UINTPTR)wagotimesetzoneasync__fb_exit, 1, 0x9D8107F3, 0x01010005) 
	#define EXTREF_ITF_wagotimesetzoneasync__fb_exit {(RTS_VOID_FCTPTR)wagotimesetzoneasync__fb_exit, "wagotimesetzoneasync__fb_exit", 0x9D8107F3, 0x01010005}
#elif defined(MIXED_LINK) && !defined(TSCTIME_EXTERNAL)
	#define USE_wagotimesetzoneasync__fb_exit
	#define EXT_wagotimesetzoneasync__fb_exit
	#define GET_wagotimesetzoneasync__fb_exit(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__fb_exit" ) 
	#define CAL_wagotimesetzoneasync__fb_exit  wagotimesetzoneasync__fb_exit
	#define CHK_wagotimesetzoneasync__fb_exit  TRUE
	#define EXP_wagotimesetzoneasync__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_exit", (RTS_UINTPTR)wagotimesetzoneasync__fb_exit, 1, 0x9D8107F3, 0x01010005) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscTimewagotimesetzoneasync__fb_exit
	#define EXT_TscTimewagotimesetzoneasync__fb_exit
	#define GET_TscTimewagotimesetzoneasync__fb_exit  ERR_OK
	#define CAL_TscTimewagotimesetzoneasync__fb_exit  wagotimesetzoneasync__fb_exit
	#define CHK_TscTimewagotimesetzoneasync__fb_exit  TRUE
	#define EXP_TscTimewagotimesetzoneasync__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_exit", (RTS_UINTPTR)wagotimesetzoneasync__fb_exit, 1, 0x9D8107F3, 0x01010005) 
#elif defined(CPLUSPLUS)
	#define USE_wagotimesetzoneasync__fb_exit
	#define EXT_wagotimesetzoneasync__fb_exit
	#define GET_wagotimesetzoneasync__fb_exit(fl)  CAL_CMGETAPI( "wagotimesetzoneasync__fb_exit" ) 
	#define CAL_wagotimesetzoneasync__fb_exit  wagotimesetzoneasync__fb_exit
	#define CHK_wagotimesetzoneasync__fb_exit  TRUE
	#define EXP_wagotimesetzoneasync__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_exit", (RTS_UINTPTR)wagotimesetzoneasync__fb_exit, 1, 0x9D8107F3, 0x01010005) 
#else /* DYNAMIC_LINK */
	#define USE_wagotimesetzoneasync__fb_exit  PFWAGOTIMESETZONEASYNC__FB_EXIT_IEC pfwagotimesetzoneasync__fb_exit;
	#define EXT_wagotimesetzoneasync__fb_exit  extern PFWAGOTIMESETZONEASYNC__FB_EXIT_IEC pfwagotimesetzoneasync__fb_exit;
	#define GET_wagotimesetzoneasync__fb_exit(fl)  s_pfCMGetAPI2( "wagotimesetzoneasync__fb_exit", (RTS_VOID_FCTPTR *)&pfwagotimesetzoneasync__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9D8107F3, 0x01010005)
	#define CAL_wagotimesetzoneasync__fb_exit  pfwagotimesetzoneasync__fb_exit
	#define CHK_wagotimesetzoneasync__fb_exit  (pfwagotimesetzoneasync__fb_exit != NULL)
	#define EXP_wagotimesetzoneasync__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"wagotimesetzoneasync__fb_exit", (RTS_UINTPTR)wagotimesetzoneasync__fb_exit, 1, 0x9D8107F3, 0x01010005) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ITscTime_C;

#ifdef CPLUSPLUS
class ITscTime : public IBase
{
	public:
};
	#ifndef ITF_TscTime
		#define ITF_TscTime static ITscTime *pITscTime = NULL;
	#endif
	#define EXTITF_TscTime
#else	/*CPLUSPLUS*/
	typedef ITscTime_C		ITscTime;
	#ifndef ITF_TscTime
		#define ITF_TscTime
	#endif
	#define EXTITF_TscTime
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCTIMEITF_H_*/
