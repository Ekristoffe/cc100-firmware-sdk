/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component Template</name>
 *  <description> 
 *  An example on how to implement a component.
 *  This component does no usefull work and it exports no functions
 *  which are intended to be used for anything. Use at your own risk.
 *  </description>
 *  <copyright>
 *  (c) 2003-2010 3S-Smart Software Solutions
 *  </copyright>
 */
#ifndef _TSCTIMEDEP_H_
#define _TSCTIMEDEP_H_

#define COMPONENT_NAME "TscTime" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscTime)
#define COMPONENT_NAME_UNQUOTED TscTime





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscTime 	ADDVENDORID(CMP_VENDORID, TSCTIME_CLASSID_C)
#define CMPID_TscTime		  TSCTIME_CMPID
#define ITFID_TscTime    ADDVENDORID(CMP_VENDORID, TSCTIME_CLASSID_C)

#define CMP_VERSION         UINT32_C(0x00000004)
#define CMP_VERSION_STRING "0.0.0.4"
#define CMP_VERSION_RC      0,0,0,4
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"				


#include "SysOutItf.h"


#include "SysTaskItf.h"


#include "SysMemItf.h"


#include "SysCpuHandlingItf.h"


#include "TscAsyncMgrItf.h"


#include "WagoTypesCommonItf.h"


#include "TscSharedPointerItf.h"








/**
 * \file TscTimeItf.h
 */
#include "TscTimeItf.h"







#ifndef RTS_TASKNAME_ASYNCSETTZTASK
    #define RTS_TASKNAME_ASYNCSETTZTASK           "AsyncSetTzTask"
#endif
#ifndef RTS_TASKPRIO_ASYNCSETTZTASK
    #define RTS_TASKPRIO_ASYNCSETTZTASK           TASKPRIO_NORMAL_BASE
#endif



        
















     
















     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pITscSharedPointer == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscSharedPointer, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscSharedPointer = (ITscSharedPointer *)pIBase->QueryInterface(pIBase, ITFID_ITscSharedPointer, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pIWagoTypesCommon == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CWagoTypesCommon, &initResult); \
            if (pIBase != NULL) \
            { \
                pIWagoTypesCommon = (IWagoTypesCommon *)pIBase->QueryInterface(pIBase, ITFID_IWagoTypesCommon, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pITscAsyncMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscAsyncMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscAsyncMgr = (ITscAsyncMgr *)pIBase->QueryInterface(pIBase, ITFID_ITscAsyncMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysCpuHandling == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysCpuHandling, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysCpuHandling = (ISysCpuHandling *)pIBase->QueryInterface(pIBase, ITFID_ISysCpuHandling, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysMem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysMem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysMem = (ISysMem *)pIBase->QueryInterface(pIBase, ITFID_ISysMem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysOut == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysOut, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysOut = (ISysOut *)pIBase->QueryInterface(pIBase, ITFID_ISysOut, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pITscSharedPointer = NULL; \
          pIWagoTypesCommon = NULL; \
          pITscAsyncMgr = NULL; \
          pISysCpuHandling = NULL; \
          pISysMem = NULL; \
          pISysTask = NULL; \
          pISysOut = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pITscSharedPointer != NULL) \
        { \
            pIBase = (IBase *)pITscSharedPointer->QueryInterface(pITscSharedPointer, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscSharedPointer = NULL; \
            } \
        } \
          if (pIWagoTypesCommon != NULL) \
        { \
            pIBase = (IBase *)pIWagoTypesCommon->QueryInterface(pIWagoTypesCommon, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pIWagoTypesCommon = NULL; \
            } \
        } \
          if (pITscAsyncMgr != NULL) \
        { \
            pIBase = (IBase *)pITscAsyncMgr->QueryInterface(pITscAsyncMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscAsyncMgr = NULL; \
            } \
        } \
          if (pISysCpuHandling != NULL) \
        { \
            pIBase = (IBase *)pISysCpuHandling->QueryInterface(pISysCpuHandling, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysCpuHandling = NULL; \
            } \
        } \
          if (pISysMem != NULL) \
        { \
            pIBase = (IBase *)pISysMem->QueryInterface(pISysMem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysMem = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
          if (pISysOut != NULL) \
        { \
            pIBase = (IBase *)pISysOut->QueryInterface(pISysOut, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysOut = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_TscSharedPointerNew(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerCopy(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerGetInstance(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerGetRefCount(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerDeref(0);\
          if (ERR_OK == importResult ) importResult = GET_SysCpuAtomicAdd(0);\
          if (ERR_OK == importResult ) importResult = GET_TscAsyncAdd(0);\
          if (ERR_OK == importResult ) importResult = GET_TscAsyncRemove(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemFreeData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemAllocData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskSetExit(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnd(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskLeave(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnter(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskResume(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskCreate(0);\
          /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCTIME_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)wagotimesetzoneasync__fb_exit, "wagotimesetzoneasync__fb_exit", 0x9D8107F3, 0x01010005 },\
          { (RTS_VOID_FCTPTR)wagotimesetzoneasync__fb_init, "wagotimesetzoneasync__fb_init", 0x8CCEDE30, 0x01010005 },\
          { (RTS_VOID_FCTPTR)wagotimesetzoneasync__main, "wagotimesetzoneasync__main", 0xA14EDD4A, 0x01010005 },\
          { (RTS_VOID_FCTPTR)wagotimesetzone, "wagotimesetzone", 0x09ADAB51, 0x01010005 },\
          { (RTS_VOID_FCTPTR)wagotimelocaltime, "wagotimelocaltime", 0xA06E43A1, 0x01010005 },\
          { (RTS_VOID_FCTPTR)wagotimegetzoneinfo, "wagotimegetzoneinfo", 0xF30A3DDA, 0x01010005 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCTIME_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                    
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCTIME_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                    \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut     \
	ITF_SysTask     \
	ITF_SysMem     \
	ITF_SysCpuHandling     \
	ITF_TscAsyncMgr     \
	ITF_WagoTypesCommon     \
	ITF_TscSharedPointer      \
    /*obsolete USE_LogAdd*/      \
    USE_SysTaskCreate      \
    USE_SysTaskResume      \
    USE_SysTaskEnter      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskSetExit      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_TscAsyncRemove      \
    USE_TscAsyncAdd      \
    USE_SysCpuAtomicAdd      \
    USE_TscSharedPointerDeref      \
    USE_TscSharedPointerGetRefCount      \
    USE_TscSharedPointerGetInstance      \
    USE_TscSharedPointerCopy      \
    USE_TscSharedPointerNew     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut    \
	ITF_SysTask    \
	ITF_SysMem    \
	ITF_SysCpuHandling    \
	ITF_TscAsyncMgr    \
	ITF_WagoTypesCommon    \
	ITF_TscSharedPointer     \
    /*obsolete USE_LogAdd*/      \
    USE_SysTaskCreate      \
    USE_SysTaskResume      \
    USE_SysTaskEnter      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskSetExit      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_TscAsyncRemove      \
    USE_TscAsyncAdd      \
    USE_SysCpuAtomicAdd      \
    USE_TscSharedPointerDeref      \
    USE_TscSharedPointerGetRefCount      \
    USE_TscSharedPointerGetInstance      \
    USE_TscSharedPointerCopy      \
    USE_TscSharedPointerNew     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysOut    \
	EXTITF_SysTask    \
	EXTITF_SysMem    \
	EXTITF_SysCpuHandling    \
	EXTITF_TscAsyncMgr    \
	EXTITF_WagoTypesCommon    \
	EXTITF_TscSharedPointer     \
    /*obsolete EXT_LogAdd*/  \
    EXT_SysTaskCreate  \
    EXT_SysTaskResume  \
    EXT_SysTaskEnter  \
    EXT_SysTaskLeave  \
    EXT_SysTaskEnd  \
    EXT_SysTaskSetExit  \
    EXT_SysMemAllocData  \
    EXT_SysMemFreeData  \
    EXT_TscAsyncRemove  \
    EXT_TscAsyncAdd  \
    EXT_SysCpuAtomicAdd  \
    EXT_TscSharedPointerDeref  \
    EXT_TscSharedPointerGetRefCount  \
    EXT_TscSharedPointerGetInstance  \
    EXT_TscSharedPointerCopy  \
    EXT_TscSharedPointerNew 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscTime__Entry
#endif


#ifdef CPLUSPLUS

class CTscTime : public ITscTime 
{
    public:
        CTscTime() : hTscTime(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscTime()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ITscTime *)this);            
            else if (iid == ITFID_ITscTime)
                pItf = dynamic_cast<ITscTime *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hTscTime;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
