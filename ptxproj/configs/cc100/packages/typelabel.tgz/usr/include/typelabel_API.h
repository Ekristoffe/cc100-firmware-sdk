//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     typelabel_API.h
///
///  \version  $Revision: 1 $
///
///  \brief    <Insert description here>
///
///  \author   <author> : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef TYPELABEL_API_H_
#define TYPELABEL_API_H_

#include <stdint.h>
#include <sys/types.h>

#define TYPELABEL_OPEN_READ   0x01  /* Open for reading */
#define TYPELABEL_OPEN_LOCK   0x02  /* Open with lock neccessary for writing */
#define TYPELABEL_OPEN_BLOCK  0x04  /* Block if device is Blocked */
#define TYPELABEL_OPEN_LOCKED 0x08  /* Open even if device is locked */

typedef enum {
  TYPELABEL_RETURN_OK,
  TYPELABEL_RETURN_ERROR,
  TYPELABEL_RETURN_REOPEN,
  TYPELABEL_RETURN_NOT_OPEN,
  TYPELABEL_RETURN_WRONLY,
  TYPELABEL_RETURN_RDONLY,
  TYPELABEL_RETURN_READ_FAILED,
  TYPELABEL_RETURN_LOCKED,
  TYPELABEL_RETURN_BAD_FLAGS,
  TYPELABEL_RETURN_EOF,
  TYPELABEL_BUFFER_TO_SMALL,
  TYPELABEL_RETURN_NOT_IMPLEMENTED
}tTypelabelReturn;

typedef struct stTypeLabelList   tTypeLabelList;
typedef struct stTypeLabel     * tTypeLabel;
typedef uint8_t tTypeLabelOpenFlags;

#if 0
#define ITER_SET 0 //set at position from beginning
#define ITER_END 1 //set at position from end - pos
typedef struct stTypelabelIter   tTypelabelIter;
#endif

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

tTypeLabel        typelabel_OBJECT_New(                     void);
void              typelabel_OBJECT_Destroy(                 tTypeLabel);
tTypelabelReturn  typelabel_OBJECT_Open(                    tTypeLabel);
void              typelabel_OBJECT_Close(                   tTypeLabel);
tTypelabelReturn  typelabel_OBJECT_SetOflags(               tTypeLabel,
                                                            tTypeLabelOpenFlags);
tTypelabelReturn  typelabel_OBJECT_Sync(                    tTypeLabel);
void              typelabel_OBJECT_PrintValueList(          tTypeLabel);
tTypelabelReturn  typelabel_OBJECT_SnprintValueLine(        char*,
                                                            uint32_t,
                                                            tTypeLabel);
char *            typelabel_OBJECT_GetValueLine(            tTypeLabel);
void              typelabel_OBJECT_FreeValueLine(           char *);
char            * typelabel_OBJECT_GetValue(                tTypeLabel,
                                                            const char*);
void              typelabel_OBJECT_FreeValue(                char *);
tTypeLabelList  * typelabel_OBJECT_ParseValueListFromStr(   tTypeLabelList *,
                                                            const char *);
tTypelabelReturn  typelabel_OBJECT_MergeWithList(           tTypeLabel,
                                                            tTypeLabelList *);

#if 0 //currently not implemented
tTypelabelIter    typelabel_OBJECT_IterSet(                 tTypeLabel,
                                                            int,
                                                            int);
tTypelabelReturn  typelabel_OBJECT_IterInc(                 tTypeLabel,
                                                            tTypelabelIter*);
tTypelabelReturn  typelabel_OBJECT_IterDec(                 tTypeLabel,
                                                            tTypelabelIter*);
#endif

char            * typelabel_QUICK_GetValue(                 const char*);
void              typelabel_QUICK_FreeValue(                char *);

void typelabel_SYSTEM_Close(void);
char * typelabel_SYSTEM_GetString(void);
int typelabel_SYSTEM_Get(const char * name, char **value);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus


#endif /* TYPELABEL_API_H_ */
//---- End of source file ------------------------------------------------------
