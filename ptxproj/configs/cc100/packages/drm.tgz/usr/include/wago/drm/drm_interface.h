//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     drm_interface.h
///
///  \brief    DRM Daemon ioctl interface.
///
///  \note     Don't use this interface directly, please use libwagodrm.h instead.
///
///  \author   WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_DRM_INTERFACE_H_
#define INC_DRM_INTERFACE_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <sys/ioctl.h>
#include <stdint.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------

#define DRM_PATH "/run/drm/drm"

#define HW_ID_LENGTH                40
#define MAX_CUSTOMER_NAME_LENGTH    320
#define MAX_LICENSES                10
#define SHORTENED_KEY_LENGTH        15
#define ENCRYPTED_LICENSEKEY_SIZE   64
#define LICENSES_DATA_MAX_LENGTH    1392
#define LICENSE_KEY_LENGTH          64

//Defines to calculate unique IDs for ioctl().
#define GROUP_DRM                       0x07
#define S_DRM_GET_LICENSE_STATE         0x01
#define S_DRM_GET_SHORT_LICENSES        0x02
#define S_DRM_GET_MAX_LICENSES          0x03
#define S_DRM_GET_HARDWARE_ID           0x04
#define S_DRM_GET_LICENSES              0x05
#define S_DRM_BEGIN_OPS                 0x06
#define S_DRM_ADD_LICENSE               0x07
#define S_DRM_REMOVE_LICENSE            0x08
#define S_DRM_COMMIT_OPS                0x09
#define S_DRM_CANCEL_OPS                0x0A
#define S_DRM_CHECK_EXPLICIT_LICENSE    0x0B
#define S_DRM_RELEASE_EXPLICIT_LICENSE  0x0C
#define S_DRM_ALLOCATE_CREDITS          0x0D
#define S_DRM_RELEASE_CREDITS           0x0E
#define S_DRM_GET_FREE_CREDITS          0x0F
#define S_DRM_FIND_EXPLICIT_LICENSE     0x10

/*
 * Defines with calculated unique ioctl commands, which represents a provided function.
 * Commands:
 * _IO    - No data
 * _IOR   - Allows to read at the given address
 * _IOW   - Allows to write at the given address
 * _IOWR  - Allows to write and read at the given address
 */
//FindExplicitLicense
#define DRM_IOC_FIND_EXPLICIT_LICENSE       _IOWR(GROUP_DRM, S_DRM_FIND_EXPLICIT_LICENSE, intern_stFindExplicitLicense)

//CheckExplicitLicense
#define DRM_IOC_CHECK_EXPLICIT_LICENSE      _IOWR(GROUP_DRM, S_DRM_CHECK_EXPLICIT_LICENSE, intern_stCheckExplicitLicense)

//ReleaseExplicitLicense
#define DRM_IOC_RELEASE_EXPLICIT_LICENSE    _IOWR(GROUP_DRM, S_DRM_RELEASE_EXPLICIT_LICENSE, intern_stReleaseExplicitLicense)

//AllocateCredits
#define DRM_IOC_ALLOCATE_CREDITS            _IOWR(GROUP_DRM, S_DRM_ALLOCATE_CREDITS, intern_stAllocateCredits)

//ReleaseCredits
#define DRM_IOC_RELEASE_CREDITS             _IOWR(GROUP_DRM, S_DRM_RELEASE_CREDITS, intern_stReleaseCredits)

//GetFreeCredits
#define DRM_IOC_GET_FREE_CREDITS            _IOWR(GROUP_DRM, S_DRM_GET_FREE_CREDITS, intern_stGetFreeCredits)

//GetLicenseState
#define DRM_IOC_STATE                       _IOR(GROUP_DRM, S_DRM_GET_LICENSE_STATE, intern_stGetLicenseState)

//GetShortenedLicenseKey
#define DRM_IOC_SHORT                       _IOR(GROUP_DRM, S_DRM_GET_SHORT_LICENSES, intern_stGetShortenedLicenseKeys)

//GetMaximumLicenses
#define DRM_IOC_MAX                         _IOR(GROUP_DRM, S_DRM_GET_MAX_LICENSES, uint16_t)

//GetLicenses
#define DRM_IOC_LICENSES                    _IOWR(GROUP_DRM, S_DRM_GET_LICENSES, intern_stGetLicenses)

//BeginLicenseOperation
#define DRM_IOC_BEGIN                       _IOR(GROUP_DRM, S_DRM_BEGIN_OPS, T_DrmErrnoItf)

//AddLicense
#define DRM_IOC_ADD                         _IOWR(GROUP_DRM, S_DRM_ADD_LICENSE, intern_stAddLicense)

//RemoveLicenseShortened
#define DRM_IOC_REMOVE                      _IOWR(GROUP_DRM, S_DRM_REMOVE_LICENSE, intern_stRemoveLicenseShortened)

//CommitLicenseOperations
#define DRM_IOC_COMMIT                      _IOR(GROUP_DRM, S_DRM_COMMIT_OPS, intern_stCommitLicenseOperation)

//CancelLicenseOperation
#define DRM_IOC_CANCEL                      _IOR(GROUP_DRM, S_DRM_CANCEL_OPS, T_DrmErrnoItf)

//Internal error codes
typedef enum DrmErrnoItf
{
  DrmItfSuccess = 0,
  //DRM errors 100-199
  DrmItfInternalError = 100,
  DrmItfLicenseKeyAlreadyExists = 101,
  DrmItfLicenseKeyNotTransferable = 102,
  DrmItfStorageTargetNotAvailable = 103,
  DrmItfLicenseKeyNotValid = 104,
  DrmItfEvaluationModeNotExtendable = 105,
  DrmItfMaximumLicenseReached = 106,
  DrmItfLicenseInUse = 107,
  DrmItfLicenseLocked = 108,
  DrmItfLicenseNotFound = 109,
  DrmItfInvalidState = 110,
  DrmItfLicenseNotCovered = 111,
  DrmItfNotEnoughCreditsAvailable = 112,
  DrmItfNotReady = 113

} T_DrmErrnoItf;

typedef struct stFindExplicitLicense
{
  uint8_t type;
  uint16_t code;
  T_DrmErrnoItf errorCode;
}intern_stFindExplicitLicense;

typedef struct stCheckExplicitLicense
{
  uint8_t type;
  uint16_t code;
  uint64_t handle;
  T_DrmErrnoItf errorCode;
}intern_stCheckExplicitLicense;

typedef struct stReleaseExplicitLicense
{
  uint8_t type;
  uint16_t code;
  uint64_t handle;
  T_DrmErrnoItf errorCode;
}intern_stReleaseExplicitLicense;

typedef struct stGetLicenseState
{
  uint16_t licenseState;
  uint32_t evalTime;
  T_DrmErrnoItf errorCode;
} intern_stGetLicenseState;

typedef struct stGetShortenedLicenseKeys
{
  char shortenedLicenses[MAX_LICENSES * SHORTENED_KEY_LENGTH + 1];
  uint16_t keyLength;
  uint16_t numLicenses;
  T_DrmErrnoItf errorCode;
} intern_stGetShortenedLicenseKeys;

typedef struct stAddLicense
{
  uint16_t storageLocation;
  uint8_t  licenseKey[ENCRYPTED_LICENSEKEY_SIZE];
  uint16_t customerNameLength;
  uint8_t  customerName[MAX_CUSTOMER_NAME_LENGTH];
  T_DrmErrnoItf errorCode;
} intern_stAddLicense;

typedef struct stCommitLicenseOperation
{
  uint32_t failedOperation;
  T_DrmErrnoItf errorCode;
} intern_stCommitLicenseOperation;

typedef struct stRemoveLicenseShortened
{
    uint8_t shortenedLicense[SHORTENED_KEY_LENGTH];
    uint16_t shortenedLicenseLength;
    T_DrmErrnoItf errorCode;
} intern_stRemoveLicenseShortened;

typedef struct stGetLicenses
{
    uint32_t  licensesDataLength;
    uint8_t   licensesData[LICENSES_DATA_MAX_LENGTH];
    uint16_t  licenseSource;
    T_DrmErrnoItf errorCode;
} intern_stGetLicenses;

typedef struct stAllocateCredits
{
    uint8_t creditType;
    uint32_t creditAmount;
    uint64_t handle;
    T_DrmErrnoItf errorCode;
} intern_stAllocateCredits;

typedef struct stReleaseCredits
{
    uint64_t handle;
    T_DrmErrnoItf errorCode;
} intern_stReleaseCredits;

typedef struct stGetFreeCredits
{
    uint8_t creditType;
    int32_t freeCredits;
    T_DrmErrnoItf errorCode;
} intern_stGetFreeCredits;

#endif /* INC_DRM_INTERFACE_H_ */
//---- End of source file ------------------------------------------------------

