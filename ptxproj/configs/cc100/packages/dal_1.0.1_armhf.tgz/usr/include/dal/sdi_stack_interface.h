//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     sdi_stack_interface.h
///
///  \version  $Revision$
///
///  \brief    Register and configure devices
///
///  \author   <rs> : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef _SDI_STACK_INTERFACE_
#define _SDI_STACK_INTERFACE_

#include <stddef.h>
#include <stdint.h>
#include "dal_types.h"
#include "events/events.h"

#include <ffi.h>
#include <glib.h>

/**
 *
 */
#define DAL_MAKE_VERSION(major,minor,patch) (\
      ((uint32_t)(major&0xffU)<<16U)|\
      ((uint32_t)(minor&0xffU)<<8U)|\
      ((uint32_t)(patch&0xffU)))

#define DAL_VERSION DAL_MAKE_VERSION(0U,7U,3784U)

#define MAX_FN_NAME_LEN 32


typedef struct stDalSystemInterface tDalSystemInterface;
typedef tDalSystemInterface *IDalSystem;
typedef struct stStackDeviceInterface tStackDeviceInterface;
typedef tStackDeviceInterface *IStackDevice;

/**
 * This is the signature of the device open method. The open method has to be named
 * "libraryname underscore open".
 * For example the canopen libs filename is libcopen.so:
 * -> name of the open function: libcopen_open
 * @param sdi This is the interface of the device. The device must fill in its function pointers.
 * @param dsi This is the interface for device to dal communication.
 * @return DAL_SUCCESS on success, DAL_FAILURE otherwise.
 */
typedef int32_t (*device_open)(tStackDeviceInterface* sdi, tDalSystemInterface* dsi);

/**
 * @brief Describes a function signature needed by libffi to call the function
 * at runtime.
 */
typedef struct fnDescr
{
   char fnName[MAX_FN_NAME_LEN + 1];         // function name
   void (*pFunc)(void);                          // function pointer
   uint8_t argNr;                                // number of arguments
   ffi_type **argTypes;                      // array of argument types
                                             // (defined by libffi, see example)
   ffi_type *retType;                        // return type (defined by libffi)
} tFnDescr;


/**
 * @note: Attention, don't set this structures content to \0 using memset
 * as this would wipe the Version and DeviceId fields also.
 */
struct stStackDeviceInterface
{
   /* define process image size and offsets */
   uint32_t Version; /**< The version of the SDI interface. Its up to the device to check it against the \sa DAL_VERSION define*/

   uint32_t InputByte; /**< Size of the input process image */
   uint32_t OutputByte; /**< Size of the output process image */

   tDeviceId DeviceId; /**< The device id. This is set by the DAL. Don't change. The device id is needed for sdi to dal communication and has to supplied for event generation.*/

   uint32_t Flags; /**< In the flags field the device has to specify its type \sa enum DeviceType. */

   /**
    * ReadBit reads one bit at the supplied offset and stores it in buf.
    * The offset is in units of bits.
    * @param[in] bitOffset Bit offset at which to read the bit.
    * @param[out] buf Pointer to where to store the bit.
    * @return DAL_SUCCESS on success, DAL_FAILURE otherwise.
    *
    * @example Lets assume this is the device's pii: { 0x11, 0x44 }
    *          When ReadBit(4, buffer) gets called,
    *          the value in buffer should be 0x10.
    *          ReadBit(0, buffer)  => *buffer = 0x01
    *          ReadBit(10, buffer) => *buffer = 0x04
    *          ReadBit(14, buffer) => *buffer = 0x40
    *
    *          @note: Keep in mind that the other bits in buffer
    *          have to be left untouched.
    *
    *          This is what you have to do basically:
    *          1. Get the byte offset.
    *          const uint32_t byteOffset = bitOffset / 8;
    *          2. Get a bit mask which selects the desired bit within the byte
    *          const uint32_t bitMask = 1 << (bitOffset % 8);
    *          3. Mask out the current value of that bit in the buffer.
    *          *buffer &= ~bitMask;
    *          4. Write the bit to the buffer:
    *          *buffer |= pii[byteOffset] & bitMask;
    */

   int32_t (*ReadBit)(uint32_t bitOffset,
                      uint8_t *buf);

   /**
    * Reads size bytes at position offset from the pii into buf.
    * @param[in] offset The offset to start read at.
    * @param[in] size The amount of bytes to read.
    * @param[out] buf
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*ReadBytes)(uint32_t offset,
                        uint32_t size,
                        uint8_t *buf);


   /**
    * Writes one bit from buf at bit position offset into the pio.
    * @param[in] bitOffset The offset in units of bits.
    * @param[in] buf Buffer containing the bit to write.
    * @return DAL_SUCCESS on success. DAL_FAILURE otherwise.
    */
   int32_t (*WriteBit)(uint32_t bitOffset,
                       uint8_t *buf);

   /**
    * Writes size bytes from buf into the pio at position offset.
    * @param offset The offset in bytes.
    * @param size The amount of bytes to write.
    * @param buf Buffer containing the data.
    * @return
    */
   int32_t (*WriteBytes)(uint32_t offset,
                         uint32_t size,
                         uint8_t *buf);

   /**
    * Starts the reading of process data. ReadStart can be used as
    * indication to update the incoming process data.
    * The device must assure that the pd is NOT updated between
    * ReadStart and ReadEnd.
    * @see ReadEnd
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*ReadStart)(void);

   /**
    * Ends the reading of process data.
    * @see ReadStart
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*ReadEnd)(void);

   /**
    * Starts the writing of process data.
    * The device has to assure that the pd is NOT transmitted between
    * WriteStart and WriteEnd.
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*WriteStart)(void);

   /**
    * Ends the writing of process data.
    * WriteEnd can be used as trigger to transmit the pio over the
    * FB.
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*WriteEnd)(void);

   /**
    * This configures a sub device i.e. bus node / slave or what ever.
    * Its only needed by master devices.
    * @param subdevice The address of the sub device.
    * @param confData The configuration data for the sub device.
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*ConfigureSubdevice)(int32_t subdevice,
                                 void *confData);


   int32_t (*ConfigureDevice)(void *confData);



   /* diagnostic interface function */
   int32_t (*DiagGetDeviceState)(size_t bufferSize,
                                 uint8_t *diagnoseBuffer,
                                 tBusState *busSate);

   int32_t (*DiagGetSubdeviceState)(void* getState,
                                    uint32_t size,
                                    int32_t subdeviceId,
                                    tDiagnoseState *diagState);

   /**
    * sdi_Close is called to close the device. The device should free any system
    * resources its holding here (threads, memory, mutexes, files, mmaps, etc..).
    * @return Returns DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*Close)(void);

   /** @brief Call this method to get the list of device-specific functions
    * that are to be exported by the device library.
    *
    * @return array of extRef function descriptions.
    */
   tFnDescr* (*GetDeviceSpecificFnList)(void);

   /**
    * This function is called when the application changes its status. Its up
    * to the device implementation to react accordingly.
    * @param state The new state of the application.
    * @return Return DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*ApplicationStateChanged)(tApplicationStateChangedEvent event);

   /**
    * Sets the watchdog time. The time until the watchdog triggers
    * is the multiplication of factor and timeout_us.
    * @param factor The factor specifies how often the timeout_us
    * has to elapse until the watchdog triggers.
    * @param timeout_us The timeout of the watchdog in microseconds.
    * @return Return DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*WatchdogSetTime)(uint32_t factor, uint32_t timeout_us);

   /**
    * Starts the watchdog.
    * @return DAL_SUCCESS on
    */
   int32_t (*WatchdogStart)(void);

   /**
    * Stops the watchdog.
    * @return Return DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*WatchdogStop)(void);

   /**
    * Triggers the watchdog.
    * @return Return DAL_SUCCESS on success, DAL_FAILURE otherwise.
    */
   int32_t (*WatchdogTrigger)(void);

};

/**
 * This interface is meant for SDI to DAL communication.
 */
struct stDalSystemInterface
{
   /**
    * This method should be called by the SDI device in case an error occurred.
    * Its the DAL's sort of equivalent to errno.
    * @param error The (device specific?) error code.
    */
   void (*SetLastError)(tDeviceId deviceId ,tError error);

   /**
    * Call this method to generate an deferred event.
    * The event is queued and later dispatched by separate thread.
    * @param deviceId The id of the device generating the event (event source).
    * @param event The event.
    * @param eventArgs The (optional) event arguments.
    */
   void (*GenerateEventAsync)(tDeviceId deviceId,
                              tEventId event,
                              tEventArgs eventArgs);

   /**
    * Call this method to generate an event. This method blocks until
    * all registered event handler are called.
    * @param deviceId The id of the device generating the event (event source).
    * @param event The event.
    * @param eventArgs The (optional) event arguments.
    */
   void (*GenerateEvent)(tDeviceId deviceId,
                         tEventId event,
                         tEventArgs eventArgs);

};

#endif

